webpackHotUpdate_N_E(2,{

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "./node_modules/next/dist/next-server/lib/runtime-config.js");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;




var _getLogger = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"),
    trace = _getLogger.trace; // https://github.com/vercel/next.js/issues/7713


var _getConfig = next_config__WEBPACK_IMPORTED_MODULE_0___default()(),
    _getConfig$publicRunt = _getConfig.publicRuntimeConfig,
    publicRuntimeConfig = _getConfig$publicRunt === void 0 ? {} : _getConfig$publicRunt;

var URL = "https://opencerts.io";
var API_MAIN_URL = "https://api.opencerts.io";
var API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
var API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
var GA_PRODUCTION_ID = "UA-130492260-1";
var GA_DEVELOPMENT_ID = "UA-130492260-2";
var IS_MAINNET = publicRuntimeConfig.network === "mainnet";
var NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

var GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
var CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

var getApiUrl = function getApiUrl(networkName) {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

var EMAIL_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/email");
var SHARE_LINK_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/storage");
var SHARE_LINK_TTL = 1209600;
var LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
var ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
var DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: "OpenCerts - %s",
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: "".concat(URL, "/static/images/opencerts.png"),
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace("NETWORK: ".concat(NETWORK_NAME));
trace("CAPTCHA_CLIENT_KEY: ".concat(CAPTCHA_CLIENT_KEY));
trace("EMAIL_API_URL: ".concat(EMAIL_API_URL));

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbmZpZy9pbmRleC50cyJdLCJuYW1lcyI6WyJnZXRMb2dnZXIiLCJ0cmFjZSIsImdldENvbmZpZyIsInB1YmxpY1J1bnRpbWVDb25maWciLCJVUkwiLCJBUElfTUFJTl9VUkwiLCJBUElfUk9QU1RFTl9VUkwiLCJBUElfUklOS0VCWV9VUkwiLCJHQV9QUk9EVUNUSU9OX0lEIiwiR0FfREVWRUxPUE1FTlRfSUQiLCJJU19NQUlOTkVUIiwibmV0d29yayIsIk5FVFdPUktfTkFNRSIsIkdBX0lEIiwiQ0FQVENIQV9DTElFTlRfS0VZIiwiZ2V0QXBpVXJsIiwibmV0d29ya05hbWUiLCJFTUFJTF9BUElfVVJMIiwiU0hBUkVfTElOS19BUElfVVJMIiwiU0hBUkVfTElOS19UVEwiLCJMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSIiwibGVnYWN5UmVuZGVyZXJVcmwiLCJFTlZJUk9OTUVOVCIsImNvbnRleHQiLCJERUZBVUxUX1NFTyIsInRpdGxlIiwidGl0bGVUZW1wbGF0ZSIsImRlc2NyaXB0aW9uIiwib3BlbkdyYXBoIiwidHlwZSIsInVybCIsImltYWdlcyIsIndpZHRoIiwiaGVpZ2h0IiwiYWx0IiwidHdpdHRlciIsImNhcmRUeXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOztpQkFFa0JBLCtEQUFTLENBQUMsUUFBRCxDO0lBQW5CQyxLLGNBQUFBLEssRUFDUjs7O2lCQUNxQ0Msa0RBQVMsRTt1Q0FBdENDLG1CO0lBQUFBLG1CLHNDQUFzQixFOztBQUV2QixJQUFNQyxHQUFHLEdBQUcsc0JBQVo7QUFDUCxJQUFNQyxZQUFZLEdBQUcsMEJBQXJCO0FBQ0EsSUFBTUMsZUFBZSxHQUFHLGtDQUF4QjtBQUNBLElBQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFFQSxJQUFNQyxnQkFBZ0IsR0FBRyxnQkFBekI7QUFDQSxJQUFNQyxpQkFBaUIsR0FBRyxnQkFBMUI7QUFFTyxJQUFNQyxVQUFVLEdBQUdQLG1CQUFtQixDQUFDUSxPQUFwQixLQUFnQyxTQUFuRDtBQUNBLElBQU1DLFlBQVksV0FBSUYsVUFBVSxHQUFHLFdBQUgsR0FBaUJQLG1CQUFtQixDQUFDUSxPQUFuRCx1Q0FBK0QsU0FBakYsQyxDQUE0Rjs7QUFFNUYsSUFBTUUsS0FBSyxHQUFHSCxVQUFVLEdBQUdGLGdCQUFILEdBQXNCQyxpQkFBOUM7QUFDQSxJQUFNSyxrQkFBa0IsR0FBRywwQ0FBM0I7O0FBRVAsSUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsV0FBRCxFQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1gsWUFBUCxDQUFqQyxLQUNLLElBQUlXLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPVCxlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLElBQU1XLGFBQWEsYUFBTUYsU0FBUyxDQUFDSCxZQUFELENBQWYsV0FBbkI7QUFDQSxJQUFNTSxrQkFBa0IsYUFBTUgsU0FBUyxDQUFDSCxZQUFELENBQWYsYUFBeEI7QUFDQSxJQUFNTyxjQUFjLEdBQUcsT0FBdkI7QUFFQSxJQUFNQyx5QkFBeUIsR0FBR2pCLG1CQUFtQixDQUFDa0IsaUJBQXBCLElBQXlDLDhCQUEzRTtBQUNBLElBQU1DLFdBQVcsR0FBR25CLG1CQUFtQixDQUFDb0IsT0FBcEIsS0FBZ0MsWUFBaEMsR0FBK0MsWUFBL0MsR0FBOEQsYUFBbEY7QUFFQSxJQUFNQyxXQUFXLEdBQUc7QUFDekJDLE9BQUssRUFBRSxtREFEa0I7QUFFekJDLGVBQWEsa0JBRlk7QUFHekJDLGFBQVcsRUFDVCxnSkFKdUI7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxRQUFJLEVBQUUsU0FERztBQUVUQyxPQUFHLEVBQUUxQixHQUZJO0FBR1RxQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRJLFVBQU0sRUFBRSxDQUNOO0FBQ0VELFNBQUcsWUFBSzFCLEdBQUwsaUNBREw7QUFFRTRCLFdBQUssRUFBRSxHQUZUO0FBR0VDLFlBQU0sRUFBRSxHQUhWO0FBSUVDLFNBQUcsRUFBRTtBQUpQLEtBRE07QUFOQyxHQUxjO0FBb0J6QkMsU0FBTyxFQUFFO0FBQ1BDLFlBQVEsRUFBRTtBQURIO0FBcEJnQixDQUFwQjtBQXlCUG5DLEtBQUssb0JBQWFXLFlBQWIsRUFBTDtBQUNBWCxLQUFLLCtCQUF3QmEsa0JBQXhCLEVBQUw7QUFDQWIsS0FBSywwQkFBbUJnQixhQUFuQixFQUFMIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrLzIuMmM2OTY1ZGY2NWFkNDM1ZjdmMzcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBnZXRDb25maWcgZnJvbSBcIm5leHQvY29uZmlnXCI7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tIFwiLi4vdXRpbHMvbG9nZ2VyXCI7XG5cbmNvbnN0IHsgdHJhY2UgfSA9IGdldExvZ2dlcihcImNvbmZpZ1wiKTtcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS92ZXJjZWwvbmV4dC5qcy9pc3N1ZXMvNzcxM1xuY29uc3QgeyBwdWJsaWNSdW50aW1lQ29uZmlnID0ge30gfSA9IGdldENvbmZpZygpO1xuXG5leHBvcnQgY29uc3QgVVJMID0gXCJodHRwczovL29wZW5jZXJ0cy5pb1wiO1xuY29uc3QgQVBJX01BSU5fVVJMID0gXCJodHRwczovL2FwaS5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9ST1BTVEVOX1VSTCA9IFwiaHR0cHM6Ly9hcGktcm9wc3Rlbi5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9SSU5LRUJZX1VSTCA9IFwiaHR0cHM6Ly9hcGktcmlua2VieS5vcGVuY2VydHMuaW9cIjtcblxuY29uc3QgR0FfUFJPRFVDVElPTl9JRCA9IFwiVUEtMTMwNDkyMjYwLTFcIjtcbmNvbnN0IEdBX0RFVkVMT1BNRU5UX0lEID0gXCJVQS0xMzA0OTIyNjAtMlwiO1xuXG5leHBvcnQgY29uc3QgSVNfTUFJTk5FVCA9IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yayA9PT0gXCJtYWlubmV0XCI7XG5leHBvcnQgY29uc3QgTkVUV09SS19OQU1FID0gKElTX01BSU5ORVQgPyBcImhvbWVzdGVhZFwiIDogcHVibGljUnVudGltZUNvbmZpZy5uZXR3b3JrKSA/PyBcInJvcHN0ZW5cIjsgLy8gZXhwZWN0ZWQgYnkgZXRoZXJzXG5cbmV4cG9ydCBjb25zdCBHQV9JRCA9IElTX01BSU5ORVQgPyBHQV9QUk9EVUNUSU9OX0lEIDogR0FfREVWRUxPUE1FTlRfSUQ7XG5leHBvcnQgY29uc3QgQ0FQVENIQV9DTElFTlRfS0VZID0gXCI2TGZpTDNFVUFBQUFBSHJmTHZsMktoUkFjWHBhbk5YRHF1Nk0wQ0NTXCI7XG5cbmNvbnN0IGdldEFwaVVybCA9IChuZXR3b3JrTmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgaWYgKG5ldHdvcmtOYW1lID09PSBcImhvbWVzdGVhZFwiKSByZXR1cm4gQVBJX01BSU5fVVJMO1xuICBlbHNlIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJyaW5rZWJ5XCIpIHJldHVybiBBUElfUklOS0VCWV9VUkw7XG4gIHJldHVybiBBUElfUk9QU1RFTl9VUkw7XG59O1xuZXhwb3J0IGNvbnN0IEVNQUlMX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vZW1haWxgO1xuZXhwb3J0IGNvbnN0IFNIQVJFX0xJTktfQVBJX1VSTCA9IGAke2dldEFwaVVybChORVRXT1JLX05BTUUpfS9zdG9yYWdlYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX1RUTCA9IDEyMDk2MDA7XG5cbmV4cG9ydCBjb25zdCBMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSID0gcHVibGljUnVudGltZUNvbmZpZy5sZWdhY3lSZW5kZXJlclVybCB8fCBcImh0dHBzOi8vbGVnYWN5Lm9wZW5jZXJ0cy5pby9cIjtcbmV4cG9ydCBjb25zdCBFTlZJUk9OTUVOVCA9IHB1YmxpY1J1bnRpbWVDb25maWcuY29udGV4dCA9PT0gXCJwcm9kdWN0aW9uXCIgPyBcInByb2R1Y3Rpb25cIiA6IFwiZGV2ZWxvcG1lbnRcIjtcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VPID0ge1xuICB0aXRsZTogXCJBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gIHRpdGxlVGVtcGxhdGU6IGBPcGVuQ2VydHMgLSAlc2AsXG4gIGRlc2NyaXB0aW9uOlxuICAgIFwiV2hldGhlciB5b3UncmUgYSBzdHVkZW50IG9yIGFuIGVtcGxveWVyLCBPcGVuQ2VydHMgbGV0cyB5b3UgdmVyaWZ5IHRoZSBjZXJ0aWZpY2F0ZXMgeW91IGhhdmUgb2YgYW55b25lIGZyb20gYW55IGluc3RpdHV0aW9uLiBBbGwgaW4gb25lIHBsYWNlLlwiLFxuICBvcGVuR3JhcGg6IHtcbiAgICB0eXBlOiBcIndlYnNpdGVcIixcbiAgICB1cmw6IFVSTCxcbiAgICB0aXRsZTogXCJPcGVuQ2VydHMgLSBBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgICBpbWFnZXM6IFtcbiAgICAgIHtcbiAgICAgICAgdXJsOiBgJHtVUkx9L3N0YXRpYy9pbWFnZXMvb3BlbmNlcnRzLnBuZ2AsXG4gICAgICAgIHdpZHRoOiA4MDAsXG4gICAgICAgIGhlaWdodDogNjAwLFxuICAgICAgICBhbHQ6IFwiT3BlbkNlcnRzXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHR3aXR0ZXI6IHtcbiAgICBjYXJkVHlwZTogXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIsXG4gIH0sXG59O1xuXG50cmFjZShgTkVUV09SSzogJHtORVRXT1JLX05BTUV9YCk7XG50cmFjZShgQ0FQVENIQV9DTElFTlRfS0VZOiAke0NBUFRDSEFfQ0xJRU5UX0tFWX1gKTtcbnRyYWNlKGBFTUFJTF9BUElfVVJMOiAke0VNQUlMX0FQSV9VUkx9YCk7XG4iXSwic291cmNlUm9vdCI6IiJ9