webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/CertificateDropZone/CertificateDropZoneContainer.tsx":
/*!*****************************************************************************!*\
  !*** ./src/components/CertificateDropZone/CertificateDropZoneContainer.tsx ***!
  \*****************************************************************************/
/*! exports provided: CertificateDropZoneContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CertificateDropZoneContainer", function() { return CertificateDropZoneContainer; });
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-dropzone */ "./node_modules/react-dropzone/dist/es/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../reducers/certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../reducers/certificate.selectors */ "./src/reducers/certificate.selectors.ts");
/* harmony import */ var _CertificateVerificationStatus__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./CertificateVerificationStatus */ "./src/components/CertificateDropZone/CertificateVerificationStatus.tsx");








var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\CertificateDropZone\\CertificateDropZoneContainer.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }









var CertificateDropZone = /*#__PURE__*/function (_Component) {
  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(CertificateDropZone, _Component);

  var _super = _createSuper(CertificateDropZone);

  function CertificateDropZone(props) {
    var _this;

    Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CertificateDropZone);

    _this = _super.call(this, props);
    _this.state = {
      fileError: false
    };
    _this.handleCertificateChange = _this.handleCertificateChange.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__["default"])(_this));
    _this.handleFileError = _this.handleFileError.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__["default"])(_this));
    return _this;
  } // eslint-disable-next-line class-methods-use-this


  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(CertificateDropZone, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      debugger;
      next_router__WEBPACK_IMPORTED_MODULE_8___default.a.prefetch("/viewer");
    }
  }, {
    key: "handleCertificateChange",
    value: function handleCertificateChange(certificate) {
      debugger;
      this.setState({
        fileError: false
      });
      this.props.updateCertificate(certificate);
    }
  }, {
    key: "handleFileError",
    value: function handleFileError() {
      debugger;
      this.setState({
        fileError: true
      });
    }
  }, {
    key: "resetData",
    value: function resetData() {
      this.props.resetData();
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_dropzone__WEBPACK_IMPORTED_MODULE_10__["default"], {
        onDrop: function onDrop(acceptedFiles) {
          debugger; // eslint-disable-next-line no-undef

          var reader = new FileReader();

          reader.onload = function () {
            try {
              // TODO enhance this
              var json = JSON.parse(reader.result);

              _this2.handleCertificateChange(json);
            } catch (e) {
              _this2.handleFileError();
            }
          };

          if (acceptedFiles && acceptedFiles.length && acceptedFiles.length > 0) acceptedFiles.map(function (f) {
            return reader.readAsText(f);
          });
        },
        children: function children(_ref) {
          var getRootProps = _ref.getRootProps,
              getInputProps = _ref.getInputProps,
              isDragAccept = _ref.isDragAccept;
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", _objectSpread(_objectSpread({}, getRootProps()), {}, {
            id: "certificate-dropzone",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("input", _objectSpread({}, getInputProps()), void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 78,
              columnNumber: 13
            }, _this2), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_CertificateVerificationStatus__WEBPACK_IMPORTED_MODULE_14__["CertificateVerificationStatus"], {
              fileError: _this2.state.fileError,
              verifying: _this2.props.verifying,
              verificationStatus: _this2.props.verificationStatus,
              retrieveCertificateByActionError: _this2.props.retrieveCertificateByActionError,
              resetData: _this2.resetData.bind(_this2),
              hover: isDragAccept
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 13
            }, _this2)]
          }), void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 11
          }, _this2);
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 7
      }, this);
    }
  }]);

  return CertificateDropZone;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

var CertificateDropZoneContainer = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["connect"])(function (store) {
  return {
    retrieveCertificateByActionError: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getCertificateByActionError"])(store),
    verifying: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getVerifying"])(store),
    verificationStatus: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getVerificationStatus"])(store)
  };
}, function (dispatch) {
  return {
    updateCertificate: function updateCertificate(payload) {
      return dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__["updateCertificate"])(payload));
    },
    resetData: function resetData() {
      return dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__["resetCertificateState"])());
    }
  };
})(CertificateDropZone);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvQ2VydGlmaWNhdGVEcm9wWm9uZS9DZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyLnRzeCJdLCJuYW1lcyI6WyJDZXJ0aWZpY2F0ZURyb3Bab25lIiwicHJvcHMiLCJzdGF0ZSIsImZpbGVFcnJvciIsImhhbmRsZUNlcnRpZmljYXRlQ2hhbmdlIiwiYmluZCIsImhhbmRsZUZpbGVFcnJvciIsIlJvdXRlciIsInByZWZldGNoIiwiY2VydGlmaWNhdGUiLCJzZXRTdGF0ZSIsInVwZGF0ZUNlcnRpZmljYXRlIiwicmVzZXREYXRhIiwiYWNjZXB0ZWRGaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJqc29uIiwiSlNPTiIsInBhcnNlIiwicmVzdWx0IiwiZSIsImxlbmd0aCIsIm1hcCIsImYiLCJyZWFkQXNUZXh0IiwiZ2V0Um9vdFByb3BzIiwiZ2V0SW5wdXRQcm9wcyIsImlzRHJhZ0FjY2VwdCIsInZlcmlmeWluZyIsInZlcmlmaWNhdGlvblN0YXR1cyIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yIiwiQ29tcG9uZW50IiwiQ2VydGlmaWNhdGVEcm9wWm9uZUNvbnRhaW5lciIsImNvbm5lY3QiLCJzdG9yZSIsImdldENlcnRpZmljYXRlQnlBY3Rpb25FcnJvciIsImdldFZlcmlmeWluZyIsImdldFZlcmlmaWNhdGlvblN0YXR1cyIsImRpc3BhdGNoIiwicGF5bG9hZCIsInJlc2V0Q2VydGlmaWNhdGVTdGF0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0lBY01BLG1COzs7OztBQUNKLCtCQUFZQyxLQUFaLEVBQXNEO0FBQUE7O0FBQUE7O0FBQ3BELDhCQUFNQSxLQUFOO0FBRUEsVUFBS0MsS0FBTCxHQUFhO0FBQ1hDLGVBQVMsRUFBRTtBQURBLEtBQWI7QUFHQSxVQUFLQyx1QkFBTCxHQUErQixNQUFLQSx1QkFBTCxDQUE2QkMsSUFBN0Isc05BQS9CO0FBQ0EsVUFBS0MsZUFBTCxHQUF1QixNQUFLQSxlQUFMLENBQXFCRCxJQUFyQixzTkFBdkI7QUFQb0Q7QUFRckQsRyxDQUVEOzs7Ozt3Q0FDMEI7QUFDeEI7QUFDQUUsd0RBQU0sQ0FBQ0MsUUFBUCxDQUFnQixTQUFoQjtBQUNEOzs7NENBRXVCQyxXLEVBQWdFO0FBQ3RGO0FBQ0EsV0FBS0MsUUFBTCxDQUFjO0FBQUVQLGlCQUFTLEVBQUU7QUFBYixPQUFkO0FBQ0EsV0FBS0YsS0FBTCxDQUFXVSxpQkFBWCxDQUE2QkYsV0FBN0I7QUFDRDs7O3NDQUV1QjtBQUN0QjtBQUNBLFdBQUtDLFFBQUwsQ0FBYztBQUFFUCxpQkFBUyxFQUFFO0FBQWIsT0FBZDtBQUNEOzs7Z0NBRWlCO0FBQ2hCLFdBQUtGLEtBQUwsQ0FBV1csU0FBWDtBQUNEOzs7NkJBRW1CO0FBQUE7O0FBQ2xCLDBCQUNFLHFFQUFDLHVEQUFEO0FBQ0UsY0FBTSxFQUFFLGdCQUFDQyxhQUFELEVBQW1CO0FBQ3pCLG1CQUR5QixDQUV6Qjs7QUFDQSxjQUFNQyxNQUFNLEdBQUcsSUFBSUMsVUFBSixFQUFmOztBQUNBRCxnQkFBTSxDQUFDRSxNQUFQLEdBQWdCLFlBQU07QUFDcEIsZ0JBQUk7QUFDRjtBQUNBLGtCQUFNQyxJQUFJLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxNQUFNLENBQUNNLE1BQWxCLENBQWI7O0FBQ0Esb0JBQUksQ0FBQ2hCLHVCQUFMLENBQTZCYSxJQUE3QjtBQUNELGFBSkQsQ0FJRSxPQUFPSSxDQUFQLEVBQVU7QUFDVixvQkFBSSxDQUFDZixlQUFMO0FBQ0Q7QUFDRixXQVJEOztBQVNBLGNBQUlPLGFBQWEsSUFBSUEsYUFBYSxDQUFDUyxNQUEvQixJQUF5Q1QsYUFBYSxDQUFDUyxNQUFkLEdBQXVCLENBQXBFLEVBQ0VULGFBQWEsQ0FBQ1UsR0FBZCxDQUFrQixVQUFDQyxDQUFEO0FBQUEsbUJBQU9WLE1BQU0sQ0FBQ1csVUFBUCxDQUFrQkQsQ0FBbEIsQ0FBUDtBQUFBLFdBQWxCO0FBQ0gsU0FoQkg7QUFBQSxrQkFrQkc7QUFBQSxjQUFHRSxZQUFILFFBQUdBLFlBQUg7QUFBQSxjQUFpQkMsYUFBakIsUUFBaUJBLGFBQWpCO0FBQUEsY0FBZ0NDLFlBQWhDLFFBQWdDQSxZQUFoQztBQUFBLDhCQUNDLDRHQUFTRixZQUFZLEVBQXJCO0FBQXlCLGNBQUUsRUFBQyxzQkFBNUI7QUFBQSxvQ0FDRSxnR0FBV0MsYUFBYSxFQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURGLGVBRUUscUVBQUMsNkZBQUQ7QUFDRSx1QkFBUyxFQUFFLE1BQUksQ0FBQ3pCLEtBQUwsQ0FBV0MsU0FEeEI7QUFFRSx1QkFBUyxFQUFFLE1BQUksQ0FBQ0YsS0FBTCxDQUFXNEIsU0FGeEI7QUFHRSxnQ0FBa0IsRUFBRSxNQUFJLENBQUM1QixLQUFMLENBQVc2QixrQkFIakM7QUFJRSw4Q0FBZ0MsRUFBRSxNQUFJLENBQUM3QixLQUFMLENBQVc4QixnQ0FKL0M7QUFLRSx1QkFBUyxFQUFFLE1BQUksQ0FBQ25CLFNBQUwsQ0FBZVAsSUFBZixDQUFvQixNQUFwQixDQUxiO0FBTUUsbUJBQUssRUFBRXVCO0FBTlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREQ7QUFBQTtBQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUFrQ0Q7Ozs7RUFuRStCSSwrQzs7QUFzRTNCLElBQU1DLDRCQUE0QixHQUFHQyw0REFBTyxDQUNqRCxVQUFDQyxLQUFEO0FBQUEsU0FBdUI7QUFDckJKLG9DQUFnQyxFQUFFSyxvR0FBMkIsQ0FBQ0QsS0FBRCxDQUR4QztBQUVyQk4sYUFBUyxFQUFFUSxxRkFBWSxDQUFDRixLQUFELENBRkY7QUFHckJMLHNCQUFrQixFQUFFUSw4RkFBcUIsQ0FBQ0gsS0FBRDtBQUhwQixHQUF2QjtBQUFBLENBRGlELEVBTWpELFVBQUNJLFFBQUQ7QUFBQSxTQUFlO0FBQ2I1QixxQkFBaUIsRUFBRSwyQkFBQzZCLE9BQUQ7QUFBQSxhQUEwREQsUUFBUSxDQUFDNUIsd0ZBQWlCLENBQUM2QixPQUFELENBQWxCLENBQWxFO0FBQUEsS0FETjtBQUViNUIsYUFBUyxFQUFFO0FBQUEsYUFBTTJCLFFBQVEsQ0FBQ0UsNEZBQXFCLEVBQXRCLENBQWQ7QUFBQTtBQUZFLEdBQWY7QUFBQSxDQU5pRCxDQUFQLENBVTFDekMsbUJBVjBDLENBQXJDIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjE5OWI3YTM5MmY5NzJlN2I2ODg1LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBWZXJpZmljYXRpb25GcmFnbWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29hLXZlcmlmeVwiO1xuaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcbmltcG9ydCBSb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBEcm9wem9uZSBmcm9tIFwicmVhY3QtZHJvcHpvbmVcIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCB7IFJvb3RTdGF0ZSB9IGZyb20gXCIuLi8uLi9yZWR1Y2Vyc1wiO1xuaW1wb3J0IHsgcmVzZXRDZXJ0aWZpY2F0ZVN0YXRlLCB1cGRhdGVDZXJ0aWZpY2F0ZSB9IGZyb20gXCIuLi8uLi9yZWR1Y2Vycy9jZXJ0aWZpY2F0ZS5hY3Rpb25zXCI7XG5pbXBvcnQgeyBnZXRDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3IsIGdldFZlcmlmaWNhdGlvblN0YXR1cywgZ2V0VmVyaWZ5aW5nIH0gZnJvbSBcIi4uLy4uL3JlZHVjZXJzL2NlcnRpZmljYXRlLnNlbGVjdG9yc1wiO1xuaW1wb3J0IHsgQ2VydGlmaWNhdGVWZXJpZmljYXRpb25TdGF0dXMgfSBmcm9tIFwiLi9DZXJ0aWZpY2F0ZVZlcmlmaWNhdGlvblN0YXR1c1wiO1xuXG5pbnRlcmZhY2UgQ2VydGlmaWNhdGVEcm9wWm9uZUNvbnRhaW5lclByb3BzIHtcbiAgXG4gIHVwZGF0ZUNlcnRpZmljYXRlOiAoY2VydGlmaWNhdGU6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD4pID0+IHZvaWQ7XG4gIHJlc2V0RGF0YTogKCkgPT4gdm9pZDtcbiAgdmVyaWZ5aW5nOiBib29sZWFuO1xuICB2ZXJpZmljYXRpb25TdGF0dXM6IFZlcmlmaWNhdGlvbkZyYWdtZW50W10gfCBudWxsO1xuICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25FcnJvcjogc3RyaW5nIHwgbnVsbDtcbn1cbmludGVyZmFjZSBDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyU3RhdGUge1xuICBmaWxlRXJyb3I6IGJvb2xlYW47XG59XG5cbmNsYXNzIENlcnRpZmljYXRlRHJvcFpvbmUgZXh0ZW5kcyBDb21wb25lbnQ8Q2VydGlmaWNhdGVEcm9wWm9uZUNvbnRhaW5lclByb3BzLCBDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyU3RhdGU+IHtcbiAgY29uc3RydWN0b3IocHJvcHM6IENlcnRpZmljYXRlRHJvcFpvbmVDb250YWluZXJQcm9wcykge1xuICAgIHN1cGVyKHByb3BzKTtcblxuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBmaWxlRXJyb3I6IGZhbHNlLFxuICAgIH07XG4gICAgdGhpcy5oYW5kbGVDZXJ0aWZpY2F0ZUNoYW5nZSA9IHRoaXMuaGFuZGxlQ2VydGlmaWNhdGVDaGFuZ2UuYmluZCh0aGlzKTtcbiAgICB0aGlzLmhhbmRsZUZpbGVFcnJvciA9IHRoaXMuaGFuZGxlRmlsZUVycm9yLmJpbmQodGhpcyk7XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY2xhc3MtbWV0aG9kcy11c2UtdGhpc1xuICBjb21wb25lbnREaWRNb3VudCgpOiB2b2lkIHtcbiAgICBkZWJ1Z2dlclxuICAgIFJvdXRlci5wcmVmZXRjaChcIi92aWV3ZXJcIik7XG4gIH1cblxuICBoYW5kbGVDZXJ0aWZpY2F0ZUNoYW5nZShjZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50Pik6IHZvaWQge1xuICAgIGRlYnVnZ2VyXG4gICAgdGhpcy5zZXRTdGF0ZSh7IGZpbGVFcnJvcjogZmFsc2UgfSk7XG4gICAgdGhpcy5wcm9wcy51cGRhdGVDZXJ0aWZpY2F0ZShjZXJ0aWZpY2F0ZSk7XG4gIH1cblxuICBoYW5kbGVGaWxlRXJyb3IoKTogdm9pZCB7XG4gICAgZGVidWdnZXJcbiAgICB0aGlzLnNldFN0YXRlKHsgZmlsZUVycm9yOiB0cnVlIH0pO1xuICB9XG5cbiAgcmVzZXREYXRhKCk6IHZvaWQge1xuICAgIHRoaXMucHJvcHMucmVzZXREYXRhKCk7XG4gIH1cblxuICByZW5kZXIoKTogUmVhY3ROb2RlIHtcbiAgICByZXR1cm4gKFxuICAgICAgPERyb3B6b25lXG4gICAgICAgIG9uRHJvcD17KGFjY2VwdGVkRmlsZXMpID0+IHtcbiAgICAgICAgICBkZWJ1Z2dlclxuICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxuICAgICAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICAgICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIC8vIFRPRE8gZW5oYW5jZSB0aGlzXG4gICAgICAgICAgICAgIGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nKTtcbiAgICAgICAgICAgICAgdGhpcy5oYW5kbGVDZXJ0aWZpY2F0ZUNoYW5nZShqc29uKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgdGhpcy5oYW5kbGVGaWxlRXJyb3IoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChhY2NlcHRlZEZpbGVzICYmIGFjY2VwdGVkRmlsZXMubGVuZ3RoICYmIGFjY2VwdGVkRmlsZXMubGVuZ3RoID4gMClcbiAgICAgICAgICAgIGFjY2VwdGVkRmlsZXMubWFwKChmKSA9PiByZWFkZXIucmVhZEFzVGV4dChmKSk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIHsoeyBnZXRSb290UHJvcHMsIGdldElucHV0UHJvcHMsIGlzRHJhZ0FjY2VwdCB9KSA9PiAoXG4gICAgICAgICAgPGRpdiB7Li4uZ2V0Um9vdFByb3BzKCl9IGlkPVwiY2VydGlmaWNhdGUtZHJvcHpvbmVcIj5cbiAgICAgICAgICAgIDxpbnB1dCB7Li4uZ2V0SW5wdXRQcm9wcygpfSAvPlxuICAgICAgICAgICAgPENlcnRpZmljYXRlVmVyaWZpY2F0aW9uU3RhdHVzXG4gICAgICAgICAgICAgIGZpbGVFcnJvcj17dGhpcy5zdGF0ZS5maWxlRXJyb3J9XG4gICAgICAgICAgICAgIHZlcmlmeWluZz17dGhpcy5wcm9wcy52ZXJpZnlpbmd9XG4gICAgICAgICAgICAgIHZlcmlmaWNhdGlvblN0YXR1cz17dGhpcy5wcm9wcy52ZXJpZmljYXRpb25TdGF0dXN9XG4gICAgICAgICAgICAgIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yPXt0aGlzLnByb3BzLnJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yfVxuICAgICAgICAgICAgICByZXNldERhdGE9e3RoaXMucmVzZXREYXRhLmJpbmQodGhpcyl9XG4gICAgICAgICAgICAgIGhvdmVyPXtpc0RyYWdBY2NlcHR9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9Ecm9wem9uZT5cbiAgICApO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyID0gY29ubmVjdChcbiAgKHN0b3JlOiBSb290U3RhdGUpID0+ICh7XG4gICAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3I6IGdldENlcnRpZmljYXRlQnlBY3Rpb25FcnJvcihzdG9yZSksXG4gICAgdmVyaWZ5aW5nOiBnZXRWZXJpZnlpbmcoc3RvcmUpLFxuICAgIHZlcmlmaWNhdGlvblN0YXR1czogZ2V0VmVyaWZpY2F0aW9uU3RhdHVzKHN0b3JlKSxcbiAgfSksXG4gIChkaXNwYXRjaCkgPT4gKHtcbiAgICB1cGRhdGVDZXJ0aWZpY2F0ZTogKHBheWxvYWQ6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD4pID0+IGRpc3BhdGNoKHVwZGF0ZUNlcnRpZmljYXRlKHBheWxvYWQpKSxcbiAgICByZXNldERhdGE6ICgpID0+IGRpc3BhdGNoKHJlc2V0Q2VydGlmaWNhdGVTdGF0ZSgpKSxcbiAgfSlcbikoQ2VydGlmaWNhdGVEcm9wWm9uZSk7XG4iXSwic291cmNlUm9vdCI6IiJ9