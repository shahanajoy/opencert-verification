webpackHotUpdate_N_E("pages/viewer",{

/***/ "./src/components/ViewerPageImages.tsx":
/*!*********************************************!*\
  !*** ./src/components/ViewerPageImages.tsx ***!
  \*********************************************/
/*! exports provided: icons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icons", function() { return icons; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\ViewerPageImages.tsx",
    _this = undefined;

/* eslint react/display-name: 0 */

var icons = {
  print: function print() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "56.81",
        height: "50.77",
        viewBox: "0 0 56.81 50.77",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("defs", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "a",
            x1: "29.18",
            y1: "34.39",
            x2: "29.18",
            y2: "18.05",
            gradientUnits: "userSpaceOnUse",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "0",
              stopColor: "#faa94e"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 10,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "1",
              stopColor: "#f47d4d"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 11,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 9,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Print"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M13.08,26.42V6.48a3.64,3.64,0,0,1,3.64-3.64H42.05a3.64,3.64,0,0,1,3.64,3.64V25M17.21,49.61H51.94A3.64,3.64,0,0,0,55.58,46V30.06a3.64,3.64,0,0,0-3.64-3.64H6.41a3.64,3.64,0,0,0-3.64,3.64V46a3.64,3.64,0,0,0,3.64,3.65H9.93M21.87,11.7H37.58m-15.71,7H37.58m5.58,15,6.81,0",
          transform: "translate(-0.77 -0.84)",
          fill: "#fff",
          strokeWidth: "4",
          stroke: "url(#a)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 5
    }, _this);
  },
  send: function send() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "59.6",
        height: "44.2",
        viewBox: "0 0 59.6 44.2",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("defs", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "a",
            x1: "29.8",
            y1: "17.28",
            x2: "29.8",
            y2: "31.55",
            gradientTransform: "matrix(1, 0, 0, -1, 0, 47)",
            gradientUnits: "userSpaceOnUse",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "0",
              stopColor: "#faa94e"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 38,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "1",
              stopColor: "#f47d4d"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "b",
            x1: "-569.09",
            y1: "98.35",
            x2: "-569.09",
            y2: "100.46",
            gradientTransform: "matrix(36.9, 0, 0, -14.68, 21029.48, 1503.59)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "c",
            x1: "30.56",
            y1: "55.8",
            x2: "30.56",
            y2: "61.4",
            gradientTransform: "matrix(0.99, 0.17, 0.19, -1, -21.61, 83.11)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "d",
            x1: "-456.93",
            y1: "-19.99",
            x2: "-456.93",
            y2: "-14.38",
            gradientTransform: "matrix(0.12, -0.99, -0.99, -0.11, 78.63, -424.23)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Email"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M57.6,32.1V39a3.69,3.69,0,0,1-3.7,3.7H5.7A3.69,3.69,0,0,1,2,39V6.2A3.69,3.69,0,0,1,5.7,2.5H53.8a3.69,3.69,0,0,1,3.7,3.7V23.3",
          transform: "translate(0 -0.5)",
          fill: "#fff",
          strokeWidth: "4",
          stroke: "url(#a)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            d: "M6.8,9.5,29.4,27.4,52,9.5",
            transform: "translate(0 -0.5)",
            fill: "#fff",
            strokeWidth: "4",
            stroke: "url(#b)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            x1: "12.6",
            y1: "36.3",
            x2: "26.6",
            y2: "23.3",
            fill: "none",
            strokeWidth: "4",
            stroke: "url(#c)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            x1: "46.5",
            y1: "36.2",
            x2: "33.1",
            y2: "23.3",
            fill: "none",
            strokeWidth: "4",
            stroke: "url(#d)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 86,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 5
    }, _this);
  },
  check: function check() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "17.32",
        height: "11.83",
        viewBox: "0 0 17.32 11.83",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "check"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M17.86,2.34,8.08,12.11a1,1,0,0,1-1.45,0L1.14,6.62A1,1,0,1,1,2.59,5.17L7.36,9.94,16.41.88a1,1,0,0,1,1.45,0A1,1,0,0,1,17.86,2.34Z",
          transform: "translate(-0.84 -0.58)",
          fill: "#fff"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 5
    }, _this);
  },
  checkCircle: function checkCircle() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "35",
        height: "35",
        viewBox: "0 0 35 35",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "check-circle"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M29.87,5.13a17.48,17.48,0,0,0-24.74,0,17.48,17.48,0,0,0,0,24.74,17.48,17.48,0,0,0,24.74,0,17.48,17.48,0,0,0,0-24.74Z",
          fill: "#09a63b"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 107,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M25.86,13.34l-9.78,9.77a1,1,0,0,1-1.45,0L9.14,17.62a1,1,0,0,1,1.45-1.45l4.77,4.77,9.05-9.06a1,1,0,0,1,1.45,0A1,1,0,0,1,25.86,13.34Z",
          fill: "#fff"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 104,
      columnNumber: 5
    }, _this);
  },
  arrow: function arrow() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "8.1",
        height: "14.36",
        viewBox: "0 0 8.1 14.36",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "arrow"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 121,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("polyline", {
          points: "0.74 0.68 6.74 7.13 0.74 13.68",
          fill: "none",
          stroke: "#09a63b",
          strokeWidth: "2"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 122,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 120,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 119,
      columnNumber: 5
    }, _this);
  }
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvVmlld2VyUGFnZUltYWdlcy50c3giXSwibmFtZXMiOlsiaWNvbnMiLCJwcmludCIsInNlbmQiLCJjaGVjayIsImNoZWNrQ2lyY2xlIiwiYXJyb3ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFTyxJQUFNQSxLQUFLLEdBQUc7QUFDbkJDLE9BQUssRUFBRTtBQUFBLHdCQUNMO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsNEJBQVg7QUFBd0MsYUFBSyxFQUFDLE9BQTlDO0FBQXNELGNBQU0sRUFBQyxPQUE3RDtBQUFxRSxlQUFPLEVBQUMsaUJBQTdFO0FBQUEsZ0NBQ0U7QUFBQSxpQ0FDRTtBQUFnQixjQUFFLEVBQUMsR0FBbkI7QUFBdUIsY0FBRSxFQUFDLE9BQTFCO0FBQWtDLGNBQUUsRUFBQyxPQUFyQztBQUE2QyxjQUFFLEVBQUMsT0FBaEQ7QUFBd0QsY0FBRSxFQUFDLE9BQTNEO0FBQW1FLHlCQUFhLEVBQUMsZ0JBQWpGO0FBQUEsb0NBQ0U7QUFBTSxvQkFBTSxFQUFDLEdBQWI7QUFBaUIsdUJBQVMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBTSxvQkFBTSxFQUFDLEdBQWI7QUFBaUIsdUJBQVMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFPRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQRixlQVFFO0FBQ0UsV0FBQyxFQUFDLDJRQURKO0FBRUUsbUJBQVMsRUFBQyx3QkFGWjtBQUdFLGNBQUksRUFBQyxNQUhQO0FBSUUscUJBQVcsRUFBQyxHQUpkO0FBS0UsZ0JBQU0sRUFBQztBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURLO0FBQUEsR0FEWTtBQXFCbkJDLE1BQUksRUFBRTtBQUFBLHdCQUNKO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsNEJBQVg7QUFBd0MsYUFBSyxFQUFDLE1BQTlDO0FBQXFELGNBQU0sRUFBQyxNQUE1RDtBQUFtRSxlQUFPLEVBQUMsZUFBM0U7QUFBQSxnQ0FDRTtBQUFBLGtDQUNFO0FBQ0UsY0FBRSxFQUFDLEdBREw7QUFFRSxjQUFFLEVBQUMsTUFGTDtBQUdFLGNBQUUsRUFBQyxPQUhMO0FBSUUsY0FBRSxFQUFDLE1BSkw7QUFLRSxjQUFFLEVBQUMsT0FMTDtBQU1FLDZCQUFpQixFQUFDLDRCQU5wQjtBQU9FLHlCQUFhLEVBQUMsZ0JBUGhCO0FBQUEsb0NBU0U7QUFBTSxvQkFBTSxFQUFDLEdBQWI7QUFBaUIsdUJBQVMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVRGLGVBVUU7QUFBTSxvQkFBTSxFQUFDLEdBQWI7QUFBaUIsdUJBQVMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQWFFO0FBQ0UsY0FBRSxFQUFDLEdBREw7QUFFRSxjQUFFLEVBQUMsU0FGTDtBQUdFLGNBQUUsRUFBQyxPQUhMO0FBSUUsY0FBRSxFQUFDLFNBSkw7QUFLRSxjQUFFLEVBQUMsUUFMTDtBQU1FLDZCQUFpQixFQUFDLCtDQU5wQjtBQU9FLHFCQUFTLEVBQUM7QUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGLGVBc0JFO0FBQ0UsY0FBRSxFQUFDLEdBREw7QUFFRSxjQUFFLEVBQUMsT0FGTDtBQUdFLGNBQUUsRUFBQyxNQUhMO0FBSUUsY0FBRSxFQUFDLE9BSkw7QUFLRSxjQUFFLEVBQUMsTUFMTDtBQU1FLDZCQUFpQixFQUFDLDZDQU5wQjtBQU9FLHFCQUFTLEVBQUM7QUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRCRixlQStCRTtBQUNFLGNBQUUsRUFBQyxHQURMO0FBRUUsY0FBRSxFQUFDLFNBRkw7QUFHRSxjQUFFLEVBQUMsUUFITDtBQUlFLGNBQUUsRUFBQyxTQUpMO0FBS0UsY0FBRSxFQUFDLFFBTEw7QUFNRSw2QkFBaUIsRUFBQyxtREFOcEI7QUFPRSxxQkFBUyxFQUFDO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBMENFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTFDRixlQTJDRTtBQUNFLFdBQUMsRUFBQyw4SEFESjtBQUVFLG1CQUFTLEVBQUMsbUJBRlo7QUFHRSxjQUFJLEVBQUMsTUFIUDtBQUlFLHFCQUFXLEVBQUMsR0FKZDtBQUtFLGdCQUFNLEVBQUM7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTNDRixlQWtERTtBQUFBLGtDQUNFO0FBQ0UsYUFBQyxFQUFDLDJCQURKO0FBRUUscUJBQVMsRUFBQyxtQkFGWjtBQUdFLGdCQUFJLEVBQUMsTUFIUDtBQUlFLHVCQUFXLEVBQUMsR0FKZDtBQUtFLGtCQUFNLEVBQUM7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBUUU7QUFBTSxjQUFFLEVBQUMsTUFBVDtBQUFnQixjQUFFLEVBQUMsTUFBbkI7QUFBMEIsY0FBRSxFQUFDLE1BQTdCO0FBQW9DLGNBQUUsRUFBQyxNQUF2QztBQUE4QyxnQkFBSSxFQUFDLE1BQW5EO0FBQTBELHVCQUFXLEVBQUMsR0FBdEU7QUFBMEUsa0JBQU0sRUFBQztBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBU0U7QUFBTSxjQUFFLEVBQUMsTUFBVDtBQUFnQixjQUFFLEVBQUMsTUFBbkI7QUFBMEIsY0FBRSxFQUFDLE1BQTdCO0FBQW9DLGNBQUUsRUFBQyxNQUF2QztBQUE4QyxnQkFBSSxFQUFDLE1BQW5EO0FBQTBELHVCQUFXLEVBQUMsR0FBdEU7QUFBMEUsa0JBQU0sRUFBQztBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURJO0FBQUEsR0FyQmE7QUF1Rm5CQyxPQUFLLEVBQUU7QUFBQSx3QkFDTDtBQUFBLDZCQUNFO0FBQUssYUFBSyxFQUFDLDRCQUFYO0FBQXdDLGFBQUssRUFBQyxPQUE5QztBQUFzRCxjQUFNLEVBQUMsT0FBN0Q7QUFBcUUsZUFBTyxFQUFDLGlCQUE3RTtBQUFBLGdDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFDRSxXQUFDLEVBQUMsaUlBREo7QUFFRSxtQkFBUyxFQUFDLHdCQUZaO0FBR0UsY0FBSSxFQUFDO0FBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREs7QUFBQSxHQXZGWTtBQW1HbkJDLGFBQVcsRUFBRTtBQUFBLHdCQUNYO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsNEJBQVg7QUFBd0MsYUFBSyxFQUFDLElBQTlDO0FBQW1ELGNBQU0sRUFBQyxJQUExRDtBQUErRCxlQUFPLEVBQUMsV0FBdkU7QUFBQSxnQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsV0FBQyxFQUFDLHNIQURKO0FBRUUsY0FBSSxFQUFDO0FBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQU1FO0FBQ0UsV0FBQyxFQUFDLHFJQURKO0FBRUUsY0FBSSxFQUFDO0FBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRFc7QUFBQSxHQW5HTTtBQWtIbkJDLE9BQUssRUFBRTtBQUFBLHdCQUNMO0FBQUEsNkJBQ0U7QUFBSyxhQUFLLEVBQUMsNEJBQVg7QUFBd0MsYUFBSyxFQUFDLEtBQTlDO0FBQW9ELGNBQU0sRUFBQyxPQUEzRDtBQUFtRSxlQUFPLEVBQUMsZUFBM0U7QUFBQSxnQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQVUsZ0JBQU0sRUFBQyxnQ0FBakI7QUFBa0QsY0FBSSxFQUFDLE1BQXZEO0FBQThELGdCQUFNLEVBQUMsU0FBckU7QUFBK0UscUJBQVcsRUFBQztBQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESztBQUFBO0FBbEhZLENBQWQiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvdmlld2VyLmYyNmM2MzJkZmVhNjliMmVjZDg5LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQgcmVhY3QvZGlzcGxheS1uYW1lOiAwICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCBpY29ucyA9IHtcbiAgcHJpbnQ6ICgpOiBSZWFjdC5SZWFjdEVsZW1lbnQgPT4gKFxuICAgIDxpPlxuICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCI1Ni44MVwiIGhlaWdodD1cIjUwLjc3XCIgdmlld0JveD1cIjAgMCA1Ni44MSA1MC43N1wiPlxuICAgICAgICA8ZGVmcz5cbiAgICAgICAgICA8bGluZWFyR3JhZGllbnQgaWQ9XCJhXCIgeDE9XCIyOS4xOFwiIHkxPVwiMzQuMzlcIiB4Mj1cIjI5LjE4XCIgeTI9XCIxOC4wNVwiIGdyYWRpZW50VW5pdHM9XCJ1c2VyU3BhY2VPblVzZVwiPlxuICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiMFwiIHN0b3BDb2xvcj1cIiNmYWE5NGVcIiAvPlxuICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiMVwiIHN0b3BDb2xvcj1cIiNmNDdkNGRcIiAvPlxuICAgICAgICAgIDwvbGluZWFyR3JhZGllbnQ+XG4gICAgICAgIDwvZGVmcz5cbiAgICAgICAgPHRpdGxlPlByaW50PC90aXRsZT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPVwiTTEzLjA4LDI2LjQyVjYuNDhhMy42NCwzLjY0LDAsMCwxLDMuNjQtMy42NEg0Mi4wNWEzLjY0LDMuNjQsMCwwLDEsMy42NCwzLjY0VjI1TTE3LjIxLDQ5LjYxSDUxLjk0QTMuNjQsMy42NCwwLDAsMCw1NS41OCw0NlYzMC4wNmEzLjY0LDMuNjQsMCwwLDAtMy42NC0zLjY0SDYuNDFhMy42NCwzLjY0LDAsMCwwLTMuNjQsMy42NFY0NmEzLjY0LDMuNjQsMCwwLDAsMy42NCwzLjY1SDkuOTNNMjEuODcsMTEuN0gzNy41OG0tMTUuNzEsN0gzNy41OG01LjU4LDE1LDYuODEsMFwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0wLjc3IC0wLjg0KVwiXG4gICAgICAgICAgZmlsbD1cIiNmZmZcIlxuICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXG4gICAgICAgICAgc3Ryb2tlPVwidXJsKCNhKVwiXG4gICAgICAgIC8+XG4gICAgICA8L3N2Zz5cbiAgICA8L2k+XG4gICksXG4gIHNlbmQ6ICgpOiBSZWFjdC5SZWFjdEVsZW1lbnQgPT4gKFxuICAgIDxpPlxuICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCI1OS42XCIgaGVpZ2h0PVwiNDQuMlwiIHZpZXdCb3g9XCIwIDAgNTkuNiA0NC4yXCI+XG4gICAgICAgIDxkZWZzPlxuICAgICAgICAgIDxsaW5lYXJHcmFkaWVudFxuICAgICAgICAgICAgaWQ9XCJhXCJcbiAgICAgICAgICAgIHgxPVwiMjkuOFwiXG4gICAgICAgICAgICB5MT1cIjE3LjI4XCJcbiAgICAgICAgICAgIHgyPVwiMjkuOFwiXG4gICAgICAgICAgICB5Mj1cIjMxLjU1XCJcbiAgICAgICAgICAgIGdyYWRpZW50VHJhbnNmb3JtPVwibWF0cml4KDEsIDAsIDAsIC0xLCAwLCA0NylcIlxuICAgICAgICAgICAgZ3JhZGllbnRVbml0cz1cInVzZXJTcGFjZU9uVXNlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwXCIgc3RvcENvbG9yPVwiI2ZhYTk0ZVwiIC8+XG4gICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxXCIgc3RvcENvbG9yPVwiI2Y0N2Q0ZFwiIC8+XG4gICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cbiAgICAgICAgICA8bGluZWFyR3JhZGllbnRcbiAgICAgICAgICAgIGlkPVwiYlwiXG4gICAgICAgICAgICB4MT1cIi01NjkuMDlcIlxuICAgICAgICAgICAgeTE9XCI5OC4zNVwiXG4gICAgICAgICAgICB4Mj1cIi01NjkuMDlcIlxuICAgICAgICAgICAgeTI9XCIxMDAuNDZcIlxuICAgICAgICAgICAgZ3JhZGllbnRUcmFuc2Zvcm09XCJtYXRyaXgoMzYuOSwgMCwgMCwgLTE0LjY4LCAyMTAyOS40OCwgMTUwMy41OSlcIlxuICAgICAgICAgICAgeGxpbmtIcmVmPVwiI2FcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGxpbmVhckdyYWRpZW50XG4gICAgICAgICAgICBpZD1cImNcIlxuICAgICAgICAgICAgeDE9XCIzMC41NlwiXG4gICAgICAgICAgICB5MT1cIjU1LjhcIlxuICAgICAgICAgICAgeDI9XCIzMC41NlwiXG4gICAgICAgICAgICB5Mj1cIjYxLjRcIlxuICAgICAgICAgICAgZ3JhZGllbnRUcmFuc2Zvcm09XCJtYXRyaXgoMC45OSwgMC4xNywgMC4xOSwgLTEsIC0yMS42MSwgODMuMTEpXCJcbiAgICAgICAgICAgIHhsaW5rSHJlZj1cIiNhXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxsaW5lYXJHcmFkaWVudFxuICAgICAgICAgICAgaWQ9XCJkXCJcbiAgICAgICAgICAgIHgxPVwiLTQ1Ni45M1wiXG4gICAgICAgICAgICB5MT1cIi0xOS45OVwiXG4gICAgICAgICAgICB4Mj1cIi00NTYuOTNcIlxuICAgICAgICAgICAgeTI9XCItMTQuMzhcIlxuICAgICAgICAgICAgZ3JhZGllbnRUcmFuc2Zvcm09XCJtYXRyaXgoMC4xMiwgLTAuOTksIC0wLjk5LCAtMC4xMSwgNzguNjMsIC00MjQuMjMpXCJcbiAgICAgICAgICAgIHhsaW5rSHJlZj1cIiNhXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2RlZnM+XG4gICAgICAgIDx0aXRsZT5FbWFpbDwvdGl0bGU+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZD1cIk01Ny42LDMyLjFWMzlhMy42OSwzLjY5LDAsMCwxLTMuNywzLjdINS43QTMuNjksMy42OSwwLDAsMSwyLDM5VjYuMkEzLjY5LDMuNjksMCwwLDEsNS43LDIuNUg1My44YTMuNjksMy42OSwwLDAsMSwzLjcsMy43VjIzLjNcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwIC0wLjUpXCJcbiAgICAgICAgICBmaWxsPVwiI2ZmZlwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCI0XCJcbiAgICAgICAgICBzdHJva2U9XCJ1cmwoI2EpXCJcbiAgICAgICAgLz5cbiAgICAgICAgPGc+XG4gICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgIGQ9XCJNNi44LDkuNSwyOS40LDI3LjQsNTIsOS41XCJcbiAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwIC0wLjUpXCJcbiAgICAgICAgICAgIGZpbGw9XCIjZmZmXCJcbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXG4gICAgICAgICAgICBzdHJva2U9XCJ1cmwoI2IpXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxsaW5lIHgxPVwiMTIuNlwiIHkxPVwiMzYuM1wiIHgyPVwiMjYuNlwiIHkyPVwiMjMuM1wiIGZpbGw9XCJub25lXCIgc3Ryb2tlV2lkdGg9XCI0XCIgc3Ryb2tlPVwidXJsKCNjKVwiIC8+XG4gICAgICAgICAgPGxpbmUgeDE9XCI0Ni41XCIgeTE9XCIzNi4yXCIgeDI9XCIzMy4xXCIgeTI9XCIyMy4zXCIgZmlsbD1cIm5vbmVcIiBzdHJva2VXaWR0aD1cIjRcIiBzdHJva2U9XCJ1cmwoI2QpXCIgLz5cbiAgICAgICAgPC9nPlxuICAgICAgPC9zdmc+XG4gICAgPC9pPlxuICApLFxuICBjaGVjazogKCk6IFJlYWN0LlJlYWN0RWxlbWVudCA9PiAoXG4gICAgPGk+XG4gICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjE3LjMyXCIgaGVpZ2h0PVwiMTEuODNcIiB2aWV3Qm94PVwiMCAwIDE3LjMyIDExLjgzXCI+XG4gICAgICAgIDx0aXRsZT5jaGVjazwvdGl0bGU+XG4gICAgICAgIDxwYXRoXG4gICAgICAgICAgZD1cIk0xNy44NiwyLjM0LDguMDgsMTIuMTFhMSwxLDAsMCwxLTEuNDUsMEwxLjE0LDYuNjJBMSwxLDAsMSwxLDIuNTksNS4xN0w3LjM2LDkuOTQsMTYuNDEuODhhMSwxLDAsMCwxLDEuNDUsMEExLDEsMCwwLDEsMTcuODYsMi4zNFpcIlxuICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgtMC44NCAtMC41OClcIlxuICAgICAgICAgIGZpbGw9XCIjZmZmXCJcbiAgICAgICAgLz5cbiAgICAgIDwvc3ZnPlxuICAgIDwvaT5cbiAgKSxcbiAgY2hlY2tDaXJjbGU6ICgpOiBSZWFjdC5SZWFjdEVsZW1lbnQgPT4gKFxuICAgIDxpPlxuICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIzNVwiIGhlaWdodD1cIjM1XCIgdmlld0JveD1cIjAgMCAzNSAzNVwiPlxuICAgICAgICA8dGl0bGU+Y2hlY2stY2lyY2xlPC90aXRsZT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPVwiTTI5Ljg3LDUuMTNhMTcuNDgsMTcuNDgsMCwwLDAtMjQuNzQsMCwxNy40OCwxNy40OCwwLDAsMCwwLDI0Ljc0LDE3LjQ4LDE3LjQ4LDAsMCwwLDI0Ljc0LDAsMTcuNDgsMTcuNDgsMCwwLDAsMC0yNC43NFpcIlxuICAgICAgICAgIGZpbGw9XCIjMDlhNjNiXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPVwiTTI1Ljg2LDEzLjM0bC05Ljc4LDkuNzdhMSwxLDAsMCwxLTEuNDUsMEw5LjE0LDE3LjYyYTEsMSwwLDAsMSwxLjQ1LTEuNDVsNC43Nyw0Ljc3LDkuMDUtOS4wNmExLDEsMCwwLDEsMS40NSwwQTEsMSwwLDAsMSwyNS44NiwxMy4zNFpcIlxuICAgICAgICAgIGZpbGw9XCIjZmZmXCJcbiAgICAgICAgLz5cbiAgICAgIDwvc3ZnPlxuICAgIDwvaT5cbiAgKSxcbiAgYXJyb3c6ICgpOiBSZWFjdC5SZWFjdEVsZW1lbnQgPT4gKFxuICAgIDxpPlxuICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCI4LjFcIiBoZWlnaHQ9XCIxNC4zNlwiIHZpZXdCb3g9XCIwIDAgOC4xIDE0LjM2XCI+XG4gICAgICAgIDx0aXRsZT5hcnJvdzwvdGl0bGU+XG4gICAgICAgIDxwb2x5bGluZSBwb2ludHM9XCIwLjc0IDAuNjggNi43NCA3LjEzIDAuNzQgMTMuNjhcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwOWE2M2JcIiBzdHJva2VXaWR0aD1cIjJcIiAvPlxuICAgICAgPC9zdmc+XG4gICAgPC9pPlxuICApLFxufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=