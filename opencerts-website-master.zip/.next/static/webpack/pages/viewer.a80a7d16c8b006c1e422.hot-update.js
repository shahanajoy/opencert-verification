webpackHotUpdate_N_E("pages/viewer",{

/***/ "./src/components/ViewerPageImages.tsx":
/*!*********************************************!*\
  !*** ./src/components/ViewerPageImages.tsx ***!
  \*********************************************/
/*! exports provided: icons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icons", function() { return icons; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\ViewerPageImages.tsx",
    _this = undefined;

/* eslint react/display-name: 0 */

var icons = {
  print: function print() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "56.81",
        height: "50.77",
        viewBox: "0 0 56.81 50.77",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("defs", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "a",
            x1: "29.18",
            y1: "34.39",
            x2: "29.18",
            y2: "18.05",
            gradientUnits: "userSpaceOnUse",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "0",
              stopColor: "#faa94e"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 10,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "1",
              stopColor: "#f47d4d"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 11,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 9,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Print"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M13.08,26.42V6.48a3.64,3.64,0,0,1,3.64-3.64H42.05a3.64,3.64,0,0,1,3.64,3.64V25M17.21,49.61H51.94A3.64,3.64,0,0,0,55.58,46V30.06a3.64,3.64,0,0,0-3.64-3.64H6.41a3.64,3.64,0,0,0-3.64,3.64V46a3.64,3.64,0,0,0,3.64,3.65H9.93M21.87,11.7H37.58m-15.71,7H37.58m5.58,15,6.81,0",
          transform: "translate(-0.77 -0.84)",
          fill: "#fff",
          strokeWidth: "4",
          stroke: "url(#a)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 5
    }, _this);
  },
  send: function send() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "59.6",
        height: "44.2",
        viewBox: "0 0 59.6 44.2",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("defs", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "a",
            x1: "29.8",
            y1: "17.28",
            x2: "29.8",
            y2: "31.55",
            gradientTransform: "matrix(1, 0, 0, -1, 0, 47)",
            gradientUnits: "userSpaceOnUse",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "0",
              stopColor: "#faa94e"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 38,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("stop", {
              offset: "1",
              stopColor: "#f47d4d"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "b",
            x1: "-569.09",
            y1: "98.35",
            x2: "-569.09",
            y2: "100.46",
            gradientTransform: "matrix(36.9, 0, 0, -14.68, 21029.48, 1503.59)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "c",
            x1: "30.56",
            y1: "55.8",
            x2: "30.56",
            y2: "61.4",
            gradientTransform: "matrix(0.99, 0.17, 0.19, -1, -21.61, 83.11)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("linearGradient", {
            id: "d",
            x1: "-456.93",
            y1: "-19.99",
            x2: "-456.93",
            y2: "-14.38",
            gradientTransform: "matrix(0.12, -0.99, -0.99, -0.11, 78.63, -424.23)",
            xlinkHref: "#a"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Email"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M57.6,32.1V39a3.69,3.69,0,0,1-3.7,3.7H5.7A3.69,3.69,0,0,1,2,39V6.2A3.69,3.69,0,0,1,5.7,2.5H53.8a3.69,3.69,0,0,1,3.7,3.7V23.3",
          transform: "translate(0 -0.5)",
          fill: "#fff",
          strokeWidth: "4",
          stroke: "url(#a)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
            d: "M6.8,9.5,29.4,27.4,52,9.5",
            transform: "translate(0 -0.5)",
            fill: "#fff",
            strokeWidth: "4",
            stroke: "url(#b)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            x1: "12.6",
            y1: "36.3",
            x2: "26.6",
            y2: "23.3",
            fill: "none",
            strokeWidth: "4",
            stroke: "url(#c)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("line", {
            x1: "46.5",
            y1: "36.2",
            x2: "33.1",
            y2: "23.3",
            fill: "none",
            strokeWidth: "4",
            stroke: "url(#d)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 86,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 5
    }, _this);
  },
  check: function check() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "17.32",
        height: "11.83",
        viewBox: "0 0 17.32 11.83",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "check"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M17.86,2.34,8.08,12.11a1,1,0,0,1-1.45,0L1.14,6.62A1,1,0,1,1,2.59,5.17L7.36,9.94,16.41.88a1,1,0,0,1,1.45,0A1,1,0,0,1,17.86,2.34Z",
          transform: "translate(-0.84 -0.58)",
          fill: "#fff"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 5
    }, _this);
  },
  checkCircle: function checkCircle() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "35",
        height: "35",
        viewBox: "0 0 35 35",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "check-circle"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M29.87,5.13a17.48,17.48,0,0,0-24.74,0,17.48,17.48,0,0,0,0,24.74,17.48,17.48,0,0,0,24.74,0,17.48,17.48,0,0,0,0-24.74Z",
          fill: "#09a63b"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 107,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
          d: "M25.86,13.34l-9.78,9.77a1,1,0,0,1-1.45,0L9.14,17.62a1,1,0,0,1,1.45-1.45l4.77,4.77,9.05-9.06a1,1,0,0,1,1.45,0A1,1,0,0,1,25.86,13.34Z",
          fill: "#fff"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 104,
      columnNumber: 5
    }, _this);
  }
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvVmlld2VyUGFnZUltYWdlcy50c3giXSwibmFtZXMiOlsiaWNvbnMiLCJwcmludCIsInNlbmQiLCJjaGVjayIsImNoZWNrQ2lyY2xlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRU8sSUFBTUEsS0FBSyxHQUFHO0FBQ25CQyxPQUFLLEVBQUU7QUFBQSx3QkFDTDtBQUFBLDZCQUNFO0FBQUssYUFBSyxFQUFDLDRCQUFYO0FBQXdDLGFBQUssRUFBQyxPQUE5QztBQUFzRCxjQUFNLEVBQUMsT0FBN0Q7QUFBcUUsZUFBTyxFQUFDLGlCQUE3RTtBQUFBLGdDQUNFO0FBQUEsaUNBQ0U7QUFBZ0IsY0FBRSxFQUFDLEdBQW5CO0FBQXVCLGNBQUUsRUFBQyxPQUExQjtBQUFrQyxjQUFFLEVBQUMsT0FBckM7QUFBNkMsY0FBRSxFQUFDLE9BQWhEO0FBQXdELGNBQUUsRUFBQyxPQUEzRDtBQUFtRSx5QkFBYSxFQUFDLGdCQUFqRjtBQUFBLG9DQUNFO0FBQU0sb0JBQU0sRUFBQyxHQUFiO0FBQWlCLHVCQUFTLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQU0sb0JBQU0sRUFBQyxHQUFiO0FBQWlCLHVCQUFTLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUEYsZUFRRTtBQUNFLFdBQUMsRUFBQywyUUFESjtBQUVFLG1CQUFTLEVBQUMsd0JBRlo7QUFHRSxjQUFJLEVBQUMsTUFIUDtBQUlFLHFCQUFXLEVBQUMsR0FKZDtBQUtFLGdCQUFNLEVBQUM7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESztBQUFBLEdBRFk7QUFxQm5CQyxNQUFJLEVBQUU7QUFBQSx3QkFDSjtBQUFBLDZCQUNFO0FBQUssYUFBSyxFQUFDLDRCQUFYO0FBQXdDLGFBQUssRUFBQyxNQUE5QztBQUFxRCxjQUFNLEVBQUMsTUFBNUQ7QUFBbUUsZUFBTyxFQUFDLGVBQTNFO0FBQUEsZ0NBQ0U7QUFBQSxrQ0FDRTtBQUNFLGNBQUUsRUFBQyxHQURMO0FBRUUsY0FBRSxFQUFDLE1BRkw7QUFHRSxjQUFFLEVBQUMsT0FITDtBQUlFLGNBQUUsRUFBQyxNQUpMO0FBS0UsY0FBRSxFQUFDLE9BTEw7QUFNRSw2QkFBaUIsRUFBQyw0QkFOcEI7QUFPRSx5QkFBYSxFQUFDLGdCQVBoQjtBQUFBLG9DQVNFO0FBQU0sb0JBQU0sRUFBQyxHQUFiO0FBQWlCLHVCQUFTLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURixlQVVFO0FBQU0sb0JBQU0sRUFBQyxHQUFiO0FBQWlCLHVCQUFTLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFhRTtBQUNFLGNBQUUsRUFBQyxHQURMO0FBRUUsY0FBRSxFQUFDLFNBRkw7QUFHRSxjQUFFLEVBQUMsT0FITDtBQUlFLGNBQUUsRUFBQyxTQUpMO0FBS0UsY0FBRSxFQUFDLFFBTEw7QUFNRSw2QkFBaUIsRUFBQywrQ0FOcEI7QUFPRSxxQkFBUyxFQUFDO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRixlQXNCRTtBQUNFLGNBQUUsRUFBQyxHQURMO0FBRUUsY0FBRSxFQUFDLE9BRkw7QUFHRSxjQUFFLEVBQUMsTUFITDtBQUlFLGNBQUUsRUFBQyxPQUpMO0FBS0UsY0FBRSxFQUFDLE1BTEw7QUFNRSw2QkFBaUIsRUFBQyw2Q0FOcEI7QUFPRSxxQkFBUyxFQUFDO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0QkYsZUErQkU7QUFDRSxjQUFFLEVBQUMsR0FETDtBQUVFLGNBQUUsRUFBQyxTQUZMO0FBR0UsY0FBRSxFQUFDLFFBSEw7QUFJRSxjQUFFLEVBQUMsU0FKTDtBQUtFLGNBQUUsRUFBQyxRQUxMO0FBTUUsNkJBQWlCLEVBQUMsbURBTnBCO0FBT0UscUJBQVMsRUFBQztBQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQTBDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkExQ0YsZUEyQ0U7QUFDRSxXQUFDLEVBQUMsOEhBREo7QUFFRSxtQkFBUyxFQUFDLG1CQUZaO0FBR0UsY0FBSSxFQUFDLE1BSFA7QUFJRSxxQkFBVyxFQUFDLEdBSmQ7QUFLRSxnQkFBTSxFQUFDO0FBTFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEzQ0YsZUFrREU7QUFBQSxrQ0FDRTtBQUNFLGFBQUMsRUFBQywyQkFESjtBQUVFLHFCQUFTLEVBQUMsbUJBRlo7QUFHRSxnQkFBSSxFQUFDLE1BSFA7QUFJRSx1QkFBVyxFQUFDLEdBSmQ7QUFLRSxrQkFBTSxFQUFDO0FBTFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVFFO0FBQU0sY0FBRSxFQUFDLE1BQVQ7QUFBZ0IsY0FBRSxFQUFDLE1BQW5CO0FBQTBCLGNBQUUsRUFBQyxNQUE3QjtBQUFvQyxjQUFFLEVBQUMsTUFBdkM7QUFBOEMsZ0JBQUksRUFBQyxNQUFuRDtBQUEwRCx1QkFBVyxFQUFDLEdBQXRFO0FBQTBFLGtCQUFNLEVBQUM7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQVNFO0FBQU0sY0FBRSxFQUFDLE1BQVQ7QUFBZ0IsY0FBRSxFQUFDLE1BQW5CO0FBQTBCLGNBQUUsRUFBQyxNQUE3QjtBQUFvQyxjQUFFLEVBQUMsTUFBdkM7QUFBOEMsZ0JBQUksRUFBQyxNQUFuRDtBQUEwRCx1QkFBVyxFQUFDLEdBQXRFO0FBQTBFLGtCQUFNLEVBQUM7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESTtBQUFBLEdBckJhO0FBdUZuQkMsT0FBSyxFQUFFO0FBQUEsd0JBQ0w7QUFBQSw2QkFDRTtBQUFLLGFBQUssRUFBQyw0QkFBWDtBQUF3QyxhQUFLLEVBQUMsT0FBOUM7QUFBc0QsY0FBTSxFQUFDLE9BQTdEO0FBQXFFLGVBQU8sRUFBQyxpQkFBN0U7QUFBQSxnQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsV0FBQyxFQUFDLGlJQURKO0FBRUUsbUJBQVMsRUFBQyx3QkFGWjtBQUdFLGNBQUksRUFBQztBQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURLO0FBQUEsR0F2Rlk7QUFtR25CQyxhQUFXLEVBQUU7QUFBQSx3QkFDWDtBQUFBLDZCQUNFO0FBQUssYUFBSyxFQUFDLDRCQUFYO0FBQXdDLGFBQUssRUFBQyxJQUE5QztBQUFtRCxjQUFNLEVBQUMsSUFBMUQ7QUFBK0QsZUFBTyxFQUFDLFdBQXZFO0FBQUEsZ0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUNFLFdBQUMsRUFBQyxzSEFESjtBQUVFLGNBQUksRUFBQztBQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkYsZUFNRTtBQUNFLFdBQUMsRUFBQyxxSUFESjtBQUVFLGNBQUksRUFBQztBQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURXO0FBQUE7QUFuR00sQ0FBZCIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy92aWV3ZXIuYTgwYTdkMTZjOGIwMDZjMWU0MjIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludCByZWFjdC9kaXNwbGF5LW5hbWU6IDAgKi9cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IGNvbnN0IGljb25zID0ge1xuICBwcmludDogKCk6IFJlYWN0LlJlYWN0RWxlbWVudCA9PiAoXG4gICAgPGk+XG4gICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjU2LjgxXCIgaGVpZ2h0PVwiNTAuNzdcIiB2aWV3Qm94PVwiMCAwIDU2LjgxIDUwLjc3XCI+XG4gICAgICAgIDxkZWZzPlxuICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cImFcIiB4MT1cIjI5LjE4XCIgeTE9XCIzNC4zOVwiIHgyPVwiMjkuMThcIiB5Mj1cIjE4LjA1XCIgZ3JhZGllbnRVbml0cz1cInVzZXJTcGFjZU9uVXNlXCI+XG4gICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwXCIgc3RvcENvbG9yPVwiI2ZhYTk0ZVwiIC8+XG4gICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxXCIgc3RvcENvbG9yPVwiI2Y0N2Q0ZFwiIC8+XG4gICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cbiAgICAgICAgPC9kZWZzPlxuICAgICAgICA8dGl0bGU+UHJpbnQ8L3RpdGxlPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGQ9XCJNMTMuMDgsMjYuNDJWNi40OGEzLjY0LDMuNjQsMCwwLDEsMy42NC0zLjY0SDQyLjA1YTMuNjQsMy42NCwwLDAsMSwzLjY0LDMuNjRWMjVNMTcuMjEsNDkuNjFINTEuOTRBMy42NCwzLjY0LDAsMCwwLDU1LjU4LDQ2VjMwLjA2YTMuNjQsMy42NCwwLDAsMC0zLjY0LTMuNjRINi40MWEzLjY0LDMuNjQsMCwwLDAtMy42NCwzLjY0VjQ2YTMuNjQsMy42NCwwLDAsMCwzLjY0LDMuNjVIOS45M00yMS44NywxMS43SDM3LjU4bS0xNS43MSw3SDM3LjU4bTUuNTgsMTUsNi44MSwwXCJcbiAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTAuNzcgLTAuODQpXCJcbiAgICAgICAgICBmaWxsPVwiI2ZmZlwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCI0XCJcbiAgICAgICAgICBzdHJva2U9XCJ1cmwoI2EpXCJcbiAgICAgICAgLz5cbiAgICAgIDwvc3ZnPlxuICAgIDwvaT5cbiAgKSxcbiAgc2VuZDogKCk6IFJlYWN0LlJlYWN0RWxlbWVudCA9PiAoXG4gICAgPGk+XG4gICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjU5LjZcIiBoZWlnaHQ9XCI0NC4yXCIgdmlld0JveD1cIjAgMCA1OS42IDQ0LjJcIj5cbiAgICAgICAgPGRlZnM+XG4gICAgICAgICAgPGxpbmVhckdyYWRpZW50XG4gICAgICAgICAgICBpZD1cImFcIlxuICAgICAgICAgICAgeDE9XCIyOS44XCJcbiAgICAgICAgICAgIHkxPVwiMTcuMjhcIlxuICAgICAgICAgICAgeDI9XCIyOS44XCJcbiAgICAgICAgICAgIHkyPVwiMzEuNTVcIlxuICAgICAgICAgICAgZ3JhZGllbnRUcmFuc2Zvcm09XCJtYXRyaXgoMSwgMCwgMCwgLTEsIDAsIDQ3KVwiXG4gICAgICAgICAgICBncmFkaWVudFVuaXRzPVwidXNlclNwYWNlT25Vc2VcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjBcIiBzdG9wQ29sb3I9XCIjZmFhOTRlXCIgLz5cbiAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjFcIiBzdG9wQ29sb3I9XCIjZjQ3ZDRkXCIgLz5cbiAgICAgICAgICA8L2xpbmVhckdyYWRpZW50PlxuICAgICAgICAgIDxsaW5lYXJHcmFkaWVudFxuICAgICAgICAgICAgaWQ9XCJiXCJcbiAgICAgICAgICAgIHgxPVwiLTU2OS4wOVwiXG4gICAgICAgICAgICB5MT1cIjk4LjM1XCJcbiAgICAgICAgICAgIHgyPVwiLTU2OS4wOVwiXG4gICAgICAgICAgICB5Mj1cIjEwMC40NlwiXG4gICAgICAgICAgICBncmFkaWVudFRyYW5zZm9ybT1cIm1hdHJpeCgzNi45LCAwLCAwLCAtMTQuNjgsIDIxMDI5LjQ4LCAxNTAzLjU5KVwiXG4gICAgICAgICAgICB4bGlua0hyZWY9XCIjYVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8bGluZWFyR3JhZGllbnRcbiAgICAgICAgICAgIGlkPVwiY1wiXG4gICAgICAgICAgICB4MT1cIjMwLjU2XCJcbiAgICAgICAgICAgIHkxPVwiNTUuOFwiXG4gICAgICAgICAgICB4Mj1cIjMwLjU2XCJcbiAgICAgICAgICAgIHkyPVwiNjEuNFwiXG4gICAgICAgICAgICBncmFkaWVudFRyYW5zZm9ybT1cIm1hdHJpeCgwLjk5LCAwLjE3LCAwLjE5LCAtMSwgLTIxLjYxLCA4My4xMSlcIlxuICAgICAgICAgICAgeGxpbmtIcmVmPVwiI2FcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGxpbmVhckdyYWRpZW50XG4gICAgICAgICAgICBpZD1cImRcIlxuICAgICAgICAgICAgeDE9XCItNDU2LjkzXCJcbiAgICAgICAgICAgIHkxPVwiLTE5Ljk5XCJcbiAgICAgICAgICAgIHgyPVwiLTQ1Ni45M1wiXG4gICAgICAgICAgICB5Mj1cIi0xNC4zOFwiXG4gICAgICAgICAgICBncmFkaWVudFRyYW5zZm9ybT1cIm1hdHJpeCgwLjEyLCAtMC45OSwgLTAuOTksIC0wLjExLCA3OC42MywgLTQyNC4yMylcIlxuICAgICAgICAgICAgeGxpbmtIcmVmPVwiI2FcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGVmcz5cbiAgICAgICAgPHRpdGxlPkVtYWlsPC90aXRsZT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPVwiTTU3LjYsMzIuMVYzOWEzLjY5LDMuNjksMCwwLDEtMy43LDMuN0g1LjdBMy42OSwzLjY5LDAsMCwxLDIsMzlWNi4yQTMuNjksMy42OSwwLDAsMSw1LjcsMi41SDUzLjhhMy42OSwzLjY5LDAsMCwxLDMuNywzLjdWMjMuM1wiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDAgLTAuNSlcIlxuICAgICAgICAgIGZpbGw9XCIjZmZmXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjRcIlxuICAgICAgICAgIHN0cm9rZT1cInVybCgjYSlcIlxuICAgICAgICAvPlxuICAgICAgICA8Zz5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgZD1cIk02LjgsOS41LDI5LjQsMjcuNCw1Miw5LjVcIlxuICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDAgLTAuNSlcIlxuICAgICAgICAgICAgZmlsbD1cIiNmZmZcIlxuICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCI0XCJcbiAgICAgICAgICAgIHN0cm9rZT1cInVybCgjYilcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGxpbmUgeDE9XCIxMi42XCIgeTE9XCIzNi4zXCIgeDI9XCIyNi42XCIgeTI9XCIyMy4zXCIgZmlsbD1cIm5vbmVcIiBzdHJva2VXaWR0aD1cIjRcIiBzdHJva2U9XCJ1cmwoI2MpXCIgLz5cbiAgICAgICAgICA8bGluZSB4MT1cIjQ2LjVcIiB5MT1cIjM2LjJcIiB4Mj1cIjMzLjFcIiB5Mj1cIjIzLjNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZVdpZHRoPVwiNFwiIHN0cm9rZT1cInVybCgjZClcIiAvPlxuICAgICAgICA8L2c+XG4gICAgICA8L3N2Zz5cbiAgICA8L2k+XG4gICksXG4gIGNoZWNrOiAoKTogUmVhY3QuUmVhY3RFbGVtZW50ID0+IChcbiAgICA8aT5cbiAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMTcuMzJcIiBoZWlnaHQ9XCIxMS44M1wiIHZpZXdCb3g9XCIwIDAgMTcuMzIgMTEuODNcIj5cbiAgICAgICAgPHRpdGxlPmNoZWNrPC90aXRsZT5cbiAgICAgICAgPHBhdGhcbiAgICAgICAgICBkPVwiTTE3Ljg2LDIuMzQsOC4wOCwxMi4xMWExLDEsMCwwLDEtMS40NSwwTDEuMTQsNi42MkExLDEsMCwxLDEsMi41OSw1LjE3TDcuMzYsOS45NCwxNi40MS44OGExLDEsMCwwLDEsMS40NSwwQTEsMSwwLDAsMSwxNy44NiwyLjM0WlwiXG4gICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC0wLjg0IC0wLjU4KVwiXG4gICAgICAgICAgZmlsbD1cIiNmZmZcIlxuICAgICAgICAvPlxuICAgICAgPC9zdmc+XG4gICAgPC9pPlxuICApLFxuICBjaGVja0NpcmNsZTogKCk6IFJlYWN0LlJlYWN0RWxlbWVudCA9PiAoXG4gICAgPGk+XG4gICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjM1XCIgaGVpZ2h0PVwiMzVcIiB2aWV3Qm94PVwiMCAwIDM1IDM1XCI+XG4gICAgICAgIDx0aXRsZT5jaGVjay1jaXJjbGU8L3RpdGxlPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGQ9XCJNMjkuODcsNS4xM2ExNy40OCwxNy40OCwwLDAsMC0yNC43NCwwLDE3LjQ4LDE3LjQ4LDAsMCwwLDAsMjQuNzQsMTcuNDgsMTcuNDgsMCwwLDAsMjQuNzQsMCwxNy40OCwxNy40OCwwLDAsMCwwLTI0Ljc0WlwiXG4gICAgICAgICAgZmlsbD1cIiMwOWE2M2JcIlxuICAgICAgICAvPlxuICAgICAgICA8cGF0aFxuICAgICAgICAgIGQ9XCJNMjUuODYsMTMuMzRsLTkuNzgsOS43N2ExLDEsMCwwLDEtMS40NSwwTDkuMTQsMTcuNjJhMSwxLDAsMCwxLDEuNDUtMS40NWw0Ljc3LDQuNzcsOS4wNS05LjA2YTEsMSwwLDAsMSwxLjQ1LDBBMSwxLDAsMCwxLDI1Ljg2LDEzLjM0WlwiXG4gICAgICAgICAgZmlsbD1cIiNmZmZcIlxuICAgICAgICAvPlxuICAgICAgPC9zdmc+XG4gICAgPC9pPlxuICApLFxuICBcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9