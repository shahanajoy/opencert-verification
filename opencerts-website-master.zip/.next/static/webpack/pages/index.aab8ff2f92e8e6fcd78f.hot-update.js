webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/Layout/DropzoneViewWrapper.tsx":
/*!*******************************************************!*\
  !*** ./src/components/Layout/DropzoneViewWrapper.tsx ***!
  \*******************************************************/
/*! exports provided: DropzoneViewWrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DropzoneViewWrapper", function() { return DropzoneViewWrapper; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\Layout\\DropzoneViewWrapper.tsx",
    _this = undefined;


var DropzoneViewWrapper = function DropzoneViewWrapper(_ref) {
  var hover = _ref.hover,
      accept = _ref.accept,
      children = _ref.children;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "rounded-2xl ".concat( // eslint-disable-next-line no-nested-ternary
    accept ? hover ? "bg-green-100" : "bg-blue-100" : "bg-pink-100"),
    "data-testid": "dropzone-view-wrapper",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "p-2",
      children: ["farshad", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "rounded-2xl border-2 border-dashed ie-fix-min-height ".concat(accept ? "border-blue" : "border-pink"),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex flex-wrap items-center",
          style: {
            minHeight: "560px"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "w-2/3 mx-auto",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center",
              children: children
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 3
  }, _this);
};
_c = DropzoneViewWrapper;

var _c;

$RefreshReg$(_c, "DropzoneViewWrapper");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvTGF5b3V0L0Ryb3B6b25lVmlld1dyYXBwZXIudHN4Il0sIm5hbWVzIjpbIkRyb3B6b25lVmlld1dyYXBwZXIiLCJob3ZlciIsImFjY2VwdCIsImNoaWxkcmVuIiwibWluSGVpZ2h0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQVFPLElBQU1BLG1CQUFzRSxHQUFHLFNBQXpFQSxtQkFBeUU7QUFBQSxNQUFHQyxLQUFILFFBQUdBLEtBQUg7QUFBQSxNQUFVQyxNQUFWLFFBQVVBLE1BQVY7QUFBQSxNQUFrQkMsUUFBbEIsUUFBa0JBLFFBQWxCO0FBQUEsc0JBQ3BGO0FBQ0UsYUFBUyx5QkFDUDtBQUNBRCxVQUFNLEdBQUlELEtBQUssR0FBRyxjQUFILEdBQW9CLGFBQTdCLEdBQThDLGFBRjdDLENBRFg7QUFLRSxtQkFBWSx1QkFMZDtBQUFBLDJCQU9FO0FBQUssZUFBUyxFQUFDLEtBQWY7QUFBQSx5Q0FFRTtBQUFLLGlCQUFTLGlFQUEwREMsTUFBTSxHQUFHLGFBQUgsR0FBbUIsYUFBbkYsQ0FBZDtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyw2QkFBZjtBQUE2QyxlQUFLLEVBQUU7QUFBRUUscUJBQVMsRUFBRTtBQUFiLFdBQXBEO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLGVBQWY7QUFBQSxtQ0FDRTtBQUFLLHVCQUFTLEVBQUMsYUFBZjtBQUFBLHdCQUE4QkQ7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FEb0Y7QUFBQSxDQUEvRTtLQUFNSCxtQiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5hYWI4ZmYyZjkyZThlNmZjZDc4Zi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIERyb3B6b25lVmlld1dyYXBwZXJQcm9wcyB7XG4gIGhvdmVyOiBib29sZWFuO1xuICBhY2NlcHQ6IGJvb2xlYW47XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59XG5cbmV4cG9ydCBjb25zdCBEcm9wem9uZVZpZXdXcmFwcGVyOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudDxEcm9wem9uZVZpZXdXcmFwcGVyUHJvcHM+ID0gKHsgaG92ZXIsIGFjY2VwdCwgY2hpbGRyZW4gfSkgPT4gKFxuICA8ZGl2XG4gICAgY2xhc3NOYW1lPXtgcm91bmRlZC0yeGwgJHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICAgICAgYWNjZXB0ID8gKGhvdmVyID8gXCJiZy1ncmVlbi0xMDBcIiA6IFwiYmctYmx1ZS0xMDBcIikgOiBcImJnLXBpbmstMTAwXCJcbiAgICB9YH1cbiAgICBkYXRhLXRlc3RpZD1cImRyb3B6b25lLXZpZXctd3JhcHBlclwiXG4gID5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxuICAgICAgZmFyc2hhZFxuICAgICAgPGRpdiBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBib3JkZXItMiBib3JkZXItZGFzaGVkIGllLWZpeC1taW4taGVpZ2h0ICR7YWNjZXB0ID8gXCJib3JkZXItYmx1ZVwiIDogXCJib3JkZXItcGlua1wifWB9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IG1pbkhlaWdodDogXCI1NjBweFwiIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yLzMgbXgtYXV0b1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG4pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==