webpackHotUpdate_N_E("pages/viewer",{

/***/ "./src/reducers/certificate.actions.ts":
/*!*********************************************!*\
  !*** ./src/reducers/certificate.actions.ts ***!
  \*********************************************/
/*! exports provided: RESET_CERTIFICATE, UPDATE_CERTIFICATE, VERIFYING_CERTIFICATE, VERIFYING_CERTIFICATE_COMPLETED, VERIFYING_CERTIFICATE_ERRORED, SENDING_CERTIFICATE, SENDING_CERTIFICATE_SUCCESS, SENDING_CERTIFICATE_FAILURE, SENDING_CERTIFICATE_RESET, GENERATE_SHARE_LINK, GENERATE_SHARE_LINK_SUCCESS, GENERATE_SHARE_LINK_FAILURE, GENERATE_SHARE_LINK_RESET, RETRIEVE_CERTIFICATE_BY_ACTION, RETRIEVE_CERTIFICATE_BY_ACTION_PENDING, RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS, RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE, CERTIFICATE_OBFUSCATE_UPDATE, resetCertificateState, updateCertificate, verifyingCertificate, verifyingCertificateCompleted, verifyingCertificateErrored, sendCertificate, sendCertificateSuccess, sendCertificateFailure, sendCertificateReset, generateShareLink, generateShareLinkReset, generateShareLinkSuccess, generateShareLinkFailure, retrieveCertificateByAction, retrieveCertificateByActionPending, retrieveCertificateByActionSuccess, retrieveCertificateByActionFailure, updateObfuscatedCertificate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RESET_CERTIFICATE", function() { return RESET_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_CERTIFICATE", function() { return UPDATE_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE", function() { return VERIFYING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_COMPLETED", function() { return VERIFYING_CERTIFICATE_COMPLETED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_ERRORED", function() { return VERIFYING_CERTIFICATE_ERRORED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE", function() { return SENDING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_SUCCESS", function() { return SENDING_CERTIFICATE_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_FAILURE", function() { return SENDING_CERTIFICATE_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_RESET", function() { return SENDING_CERTIFICATE_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK", function() { return GENERATE_SHARE_LINK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_SUCCESS", function() { return GENERATE_SHARE_LINK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_FAILURE", function() { return GENERATE_SHARE_LINK_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_RESET", function() { return GENERATE_SHARE_LINK_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION", function() { return RETRIEVE_CERTIFICATE_BY_ACTION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_PENDING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CERTIFICATE_OBFUSCATE_UPDATE", function() { return CERTIFICATE_OBFUSCATE_UPDATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCertificateState", function() { return resetCertificateState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCertificate", function() { return updateCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificate", function() { return verifyingCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateCompleted", function() { return verifyingCertificateCompleted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateErrored", function() { return verifyingCertificateErrored; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificate", function() { return sendCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateSuccess", function() { return sendCertificateSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateFailure", function() { return sendCertificateFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateReset", function() { return sendCertificateReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLink", function() { return generateShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkReset", function() { return generateShareLinkReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkSuccess", function() { return generateShareLinkSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkFailure", function() { return generateShareLinkFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByAction", function() { return retrieveCertificateByAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionPending", function() { return retrieveCertificateByActionPending; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionSuccess", function() { return retrieveCertificateByActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionFailure", function() { return retrieveCertificateByActionFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateObfuscatedCertificate", function() { return updateObfuscatedCertificate; });
// Action Creators
// Actions
var RESET_CERTIFICATE = "RESET_CERTIFICATE";
var UPDATE_CERTIFICATE = "UPDATE_CERTIFICATE";
var VERIFYING_CERTIFICATE = "VERIFYING_CERTIFICATE";
var VERIFYING_CERTIFICATE_COMPLETED = "VERIFYING_CERTIFICATE_COMPLETED"; // completed

var VERIFYING_CERTIFICATE_ERRORED = "VERIFYING_CERTIFICATE_ERRORED"; // errored

var SENDING_CERTIFICATE = "SENDING_CERTIFICATE";
var SENDING_CERTIFICATE_SUCCESS = "SENDING_CERTIFICATE_SUCCESS";
var SENDING_CERTIFICATE_FAILURE = "SENDING_CERTIFICATE_FAILURE";
var SENDING_CERTIFICATE_RESET = "SENDING_CERTIFICATE_RESET";
var GENERATE_SHARE_LINK = "GENERATE_SHARE_LINK";
var GENERATE_SHARE_LINK_SUCCESS = "GENERATE_SHARE_LINK_SUCCESS";
var GENERATE_SHARE_LINK_FAILURE = "GENERATE_SHARE_LINK_FAILURE";
var GENERATE_SHARE_LINK_RESET = "GENERATE_SHARE_LINK_RESET";
var RETRIEVE_CERTIFICATE_BY_ACTION = "RETRIEVE_CERTIFICATE_BY_ACTION";
var RETRIEVE_CERTIFICATE_BY_ACTION_PENDING = "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING";
var RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS = "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS";
var RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE = "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE";
var CERTIFICATE_OBFUSCATE_UPDATE = "CERTIFICATE_OBFUSCATE_UPDATE";
function resetCertificateState() {
  return {
    type: RESET_CERTIFICATE
  };
}
function updateCertificate(payload) {
  return {
    type: UPDATE_CERTIFICATE,
    payload: payload
  };
}
var verifyingCertificate = function verifyingCertificate() {
  return {
    type: VERIFYING_CERTIFICATE
  };
};
var verifyingCertificateCompleted = function verifyingCertificateCompleted(payload) {
  return {
    type: VERIFYING_CERTIFICATE_COMPLETED,
    payload: payload
  };
};
var verifyingCertificateErrored = function verifyingCertificateErrored(payload) {
  return {
    type: VERIFYING_CERTIFICATE_ERRORED,
    payload: payload
  };
};
function sendCertificate(payload) {
  return {
    type: SENDING_CERTIFICATE,
    payload: payload
  };
}
function sendCertificateSuccess() {
  return {
    type: SENDING_CERTIFICATE_SUCCESS
  };
}
function sendCertificateFailure(payload) {
  return {
    type: SENDING_CERTIFICATE_FAILURE,
    payload: payload
  };
}
function sendCertificateReset() {
  return {
    type: SENDING_CERTIFICATE_RESET
  };
}
function generateShareLink() {
  return {
    type: GENERATE_SHARE_LINK
  };
}
function generateShareLinkReset() {
  return {
    type: GENERATE_SHARE_LINK_RESET
  };
}
function generateShareLinkSuccess(payload) {
  return {
    type: GENERATE_SHARE_LINK_SUCCESS,
    payload: payload
  };
}
function generateShareLinkFailure(payload) {
  return {
    type: GENERATE_SHARE_LINK_FAILURE,
    payload: payload
  };
}
function retrieveCertificateByAction(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION,
    payload: payload
  };
}
function retrieveCertificateByActionPending() {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_PENDING
  };
}
function retrieveCertificateByActionSuccess() {
  debugger;
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS
  };
}
function retrieveCertificateByActionFailure(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE,
    payload: payload
  };
}
function updateObfuscatedCertificate(payload) {
  return {
    type: CERTIFICATE_OBFUSCATE_UPDATE,
    payload: payload
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3JlZHVjZXJzL2NlcnRpZmljYXRlLmFjdGlvbnMudHMiXSwibmFtZXMiOlsiUkVTRVRfQ0VSVElGSUNBVEUiLCJVUERBVEVfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEIiwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQiLCJTRU5ESU5HX0NFUlRJRklDQVRFIiwiU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTIiwiU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFIiwiU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVCIsIkdFTkVSQVRFX1NIQVJFX0xJTksiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MiLCJHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkUiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkciLCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyIsIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFIiwiQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURSIsInJlc2V0Q2VydGlmaWNhdGVTdGF0ZSIsInR5cGUiLCJ1cGRhdGVDZXJ0aWZpY2F0ZSIsInBheWxvYWQiLCJ2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSIsInZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkIiwidmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkIiwic2VuZENlcnRpZmljYXRlIiwic2VuZENlcnRpZmljYXRlU3VjY2VzcyIsInNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUiLCJzZW5kQ2VydGlmaWNhdGVSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rIiwiZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyIsImdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZSIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbiIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblBlbmRpbmciLCJyZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzIiwicmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZSIsInVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUNPLElBQU1BLGlCQUFpQixHQUFHLG1CQUExQjtBQUNBLElBQU1DLGtCQUFrQixHQUFHLG9CQUEzQjtBQUNBLElBQU1DLHFCQUFxQixHQUFHLHVCQUE5QjtBQUNBLElBQU1DLCtCQUErQixHQUFHLGlDQUF4QyxDLENBQTJFOztBQUMzRSxJQUFNQyw2QkFBNkIsR0FBRywrQkFBdEMsQyxDQUF1RTs7QUFDdkUsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsOEJBQThCLEdBQUcsZ0NBQXZDO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsNEJBQTRCLEdBQUcsOEJBQXJDO0FBS0EsU0FBU0MscUJBQVQsR0FBeUQ7QUFDOUQsU0FBTztBQUNMQyxRQUFJLEVBQUVuQjtBQURELEdBQVA7QUFHRDtBQU1NLFNBQVNvQixpQkFBVCxDQUEyQkMsT0FBM0IsRUFBMEc7QUFDL0csU0FBTztBQUNMRixRQUFJLEVBQUVsQixrQkFERDtBQUVMb0IsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLElBQU1DLG9CQUFvQixHQUFHLFNBQXZCQSxvQkFBdUI7QUFBQSxTQUFtQztBQUNyRUgsUUFBSSxFQUFFakI7QUFEK0QsR0FBbkM7QUFBQSxDQUE3QjtBQVFBLElBQU1xQiw2QkFBNkIsR0FBRyxTQUFoQ0EsNkJBQWdDLENBQzNDRixPQUQyQztBQUFBLFNBRUY7QUFDekNGLFFBQUksRUFBRWhCLCtCQURtQztBQUV6Q2tCLFdBQU8sRUFBUEE7QUFGeUMsR0FGRTtBQUFBLENBQXRDO0FBV0EsSUFBTUcsMkJBQTJCLEdBQUcsU0FBOUJBLDJCQUE4QixDQUFDSCxPQUFEO0FBQUEsU0FBeUQ7QUFDbEdGLFFBQUksRUFBRWYsNkJBRDRGO0FBRWxHaUIsV0FBTyxFQUFQQTtBQUZrRyxHQUF6RDtBQUFBLENBQXBDO0FBU0EsU0FBU0ksZUFBVCxDQUF5QkosT0FBekIsRUFBNkY7QUFDbEcsU0FBTztBQUNMRixRQUFJLEVBQUVkLG1CQUREO0FBRUxnQixXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBSU0sU0FBU0ssc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMUCxRQUFJLEVBQUViO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU3FCLHNCQUFULENBQWdDTixPQUFoQyxFQUErRTtBQUNwRixTQUFPO0FBQ0xGLFFBQUksRUFBRVosMkJBREQ7QUFFTGMsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNPLG9CQUFULEdBQTREO0FBQ2pFLFNBQU87QUFDTFQsUUFBSSxFQUFFWDtBQURELEdBQVA7QUFHRDtBQUtNLFNBQVNxQixpQkFBVCxHQUFzRDtBQUMzRCxTQUFPO0FBQ0xWLFFBQUksRUFBRVY7QUFERCxHQUFQO0FBR0Q7QUFJTSxTQUFTcUIsc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMWCxRQUFJLEVBQUVQO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU21CLHdCQUFULENBQWtDVixPQUFsQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRVQsMkJBREQ7QUFFTFcsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNXLHdCQUFULENBQWtDWCxPQUFsQyxFQUFtRjtBQUN4RixTQUFPO0FBQ0xGLFFBQUksRUFBRVIsMkJBREQ7QUFFTFUsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQU1NLFNBQVNZLDJCQUFULENBQXFDWixPQUFyQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRU4sOEJBREQ7QUFFTFEsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUlNLFNBQVNhLGtDQUFULEdBQWdGO0FBQ3JGLFNBQU87QUFDTGYsUUFBSSxFQUFFTDtBQURELEdBQVA7QUFHRDtBQUlNLFNBQVNxQixrQ0FBVCxHQUFnRjtBQUNyRjtBQUNBLFNBQU87QUFDTGhCLFFBQUksRUFBRUo7QUFERCxHQUFQO0FBR0Q7QUFNTSxTQUFTcUIsa0NBQVQsQ0FBNENmLE9BQTVDLEVBQTZGO0FBQ2xHLFNBQU87QUFDTEYsUUFBSSxFQUFFSCxzQ0FERDtBQUVMSyxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBTU0sU0FBU2dCLDJCQUFULENBQ0xoQixPQURLLEVBRTJCO0FBQ2hDLFNBQU87QUFDTEYsUUFBSSxFQUFFRiw0QkFERDtBQUVMSSxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL3ZpZXdlci42M2ZmNzVjZmY3NzkxZjRmZWQ1My5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQWN0aW9uIENyZWF0b3JzXG5pbXBvcnQgeyBWZXJpZmljYXRpb25GcmFnbWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29hLXZlcmlmeVwiO1xuaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcblxuLy8gQWN0aW9uc1xuZXhwb3J0IGNvbnN0IFJFU0VUX0NFUlRJRklDQVRFID0gXCJSRVNFVF9DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFVQREFURV9DRVJUSUZJQ0FURSA9IFwiVVBEQVRFX0NFUlRJRklDQVRFXCI7XG5leHBvcnQgY29uc3QgVkVSSUZZSU5HX0NFUlRJRklDQVRFID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVcIjtcbmV4cG9ydCBjb25zdCBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEXCI7IC8vIGNvbXBsZXRlZFxuZXhwb3J0IGNvbnN0IFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRFwiOyAvLyBlcnJvcmVkXG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURSA9IFwiU0VORElOR19DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUyA9IFwiU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTXCI7XG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOSyA9IFwiR0VORVJBVEVfU0hBUkVfTElOS1wiO1xuZXhwb3J0IGNvbnN0IEdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTUyA9IFwiR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUXCI7XG5leHBvcnQgY29uc3QgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OID0gXCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05cIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElORyA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkdcIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1NcIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRSA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFID0gXCJDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFXCI7XG5cbmludGVyZmFjZSBSZXNldENlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFU0VUX0NFUlRJRklDQVRFO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0Q2VydGlmaWNhdGVTdGF0ZSgpOiBSZXNldENlcnRpZmljYXRlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVNFVF9DRVJUSUZJQ0FURSxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFVwZGF0ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFVQREFURV9DRVJUSUZJQ0FURTtcbiAgcGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50Pjtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVDZXJ0aWZpY2F0ZShwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+KTogVXBkYXRlQ2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFVQREFURV9DRVJUSUZJQ0FURSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVkVSSUZZSU5HX0NFUlRJRklDQVRFO1xufVxuZXhwb3J0IGNvbnN0IHZlcmlmeWluZ0NlcnRpZmljYXRlID0gKCk6IFZlcmlmeWluZ0NlcnRpZmljYXRlQWN0aW9uID0+ICh7XG4gIHR5cGU6IFZFUklGWUlOR19DRVJUSUZJQ0FURSxcbn0pO1xuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRDtcbiAgcGF5bG9hZDogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXTtcbn1cbmV4cG9ydCBjb25zdCB2ZXJpZnlpbmdDZXJ0aWZpY2F0ZUNvbXBsZXRlZCA9IChcbiAgcGF5bG9hZDogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXVxuKTogVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb24gPT4gKHtcbiAgdHlwZTogVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRCxcbiAgcGF5bG9hZCxcbn0pO1xuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgY29uc3QgdmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkID0gKHBheWxvYWQ6IHN0cmluZyk6IFZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZEFjdGlvbiA9PiAoe1xuICB0eXBlOiBWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRCxcbiAgcGF5bG9hZCxcbn0pO1xuXG5pbnRlcmZhY2UgU2VuZENlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEU7XG4gIHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgY2FwdGNoYTogc3RyaW5nIH07XG59XG5leHBvcnQgZnVuY3Rpb24gc2VuZENlcnRpZmljYXRlKHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgY2FwdGNoYTogc3RyaW5nIH0pOiBTZW5kQ2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUztcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZW5kQ2VydGlmaWNhdGVTdWNjZXNzKCk6IFNlbmRDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUyxcbiAgfTtcbn1cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVGYWlsdXJlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRTtcbiAgcGF5bG9hZDogc3RyaW5nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUocGF5bG9hZDogc3RyaW5nKTogU2VuZENlcnRpZmljYXRlRmFpbHVyZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVSZXNldEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZVJlc2V0KCk6IFNlbmRDZXJ0aWZpY2F0ZVJlc2V0QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VULFxuICB9O1xufVxuXG5pbnRlcmZhY2UgR2VuZXJhdGVTaGFyZUxpbmtBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOSztcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGluaygpOiBHZW5lcmF0ZVNoYXJlTGlua0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOSyxcbiAgfTtcbn1cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIEdFTkVSQVRFX1NIQVJFX0xJTktfUkVTRVQ7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCgpOiBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VULFxuICB9O1xufVxuaW50ZXJmYWNlIEdlbmVyYXRlU2hhcmVMaW5rU3VjY2Vzc0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1M7XG4gIHBheWxvYWQ6IHsgaWQ6IHN0cmluZzsga2V5OiBzdHJpbmcgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGlua1N1Y2Nlc3MocGF5bG9hZDogeyBpZDogc3RyaW5nOyBrZXk6IHN0cmluZyB9KTogR2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlKHBheWxvYWQ6IHN0cmluZyk6IEdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTjtcbiAgcGF5bG9hZDogeyB1cmk6IHN0cmluZzsga2V5Pzogc3RyaW5nIH07XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uKHBheWxvYWQ6IHsgdXJpOiBzdHJpbmc7IGtleT86IHN0cmluZyB9KTogUmV0cmlldmVDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZVBlbmRpbmdBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkc7XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uUGVuZGluZygpOiBSZXRyaWV2ZUNlcnRpZmljYXRlUGVuZGluZ0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkcsXG4gIH07XG59XG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1M7XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3VjY2VzcygpOiBSZXRyaWV2ZUNlcnRpZmljYXRlU3VjY2Vzc0FjdGlvbiB7XG4gIGRlYnVnZ2VyXG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1MsXG4gIH07XG59XG5cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlRXJyb3JBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkU7XG4gIHBheWxvYWQ6IHN0cmluZztcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25GYWlsdXJlKHBheWxvYWQ6IHN0cmluZyk6IFJldHJpZXZlQ2VydGlmaWNhdGVFcnJvckFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFVwZGF0ZU9iZnVzY2F0ZWREb2N1bWVudEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFO1xuICBwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZShcbiAgcGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PlxuKTogVXBkYXRlT2JmdXNjYXRlZERvY3VtZW50QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmV4cG9ydCB0eXBlIENlcnRpZmljYXRlQWN0aW9uVHlwZXMgPVxuICB8IFJlc2V0Q2VydGlmaWNhdGVBY3Rpb25cbiAgfCBVcGRhdGVDZXJ0aWZpY2F0ZUFjdGlvblxuICB8IFZlcmlmeWluZ0NlcnRpZmljYXRlQWN0aW9uXG4gIHwgVmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkQWN0aW9uXG4gIHwgVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uXG4gIHwgU2VuZENlcnRpZmljYXRlRmFpbHVyZUFjdGlvblxuICB8IFNlbmRDZXJ0aWZpY2F0ZVJlc2V0QWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtBY3Rpb25cbiAgfCBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlQWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzQWN0aW9uXG4gIHwgUmV0cmlldmVDZXJ0aWZpY2F0ZVBlbmRpbmdBY3Rpb25cbiAgfCBSZXRyaWV2ZUNlcnRpZmljYXRlU3VjY2Vzc0FjdGlvblxuICB8IFJldHJpZXZlQ2VydGlmaWNhdGVFcnJvckFjdGlvblxuICB8IFVwZGF0ZU9iZnVzY2F0ZWREb2N1bWVudEFjdGlvbjtcbiJdLCJzb3VyY2VSb290IjoiIn0=