webpackHotUpdate_N_E("pages/viewer",{

/***/ "./pages/viewer.tsx":
/*!**************************!*\
  !*** ./pages/viewer.tsx ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _src_components_Layout_Body__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/components/Layout/Body */ "./src/components/Layout/Body.tsx");
/* harmony import */ var _src_components_ViewerPageContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/ViewerPageContainer */ "./src/components/ViewerPageContainer.tsx");


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\pages\\viewer.tsx",
    _this = undefined;






var ViewerPage = function ViewerPage() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Layout_Body__WEBPACK_IMPORTED_MODULE_3__["Wrapper"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_Layout_Body__WEBPACK_IMPORTED_MODULE_3__["Main"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_ViewerPageContainer__WEBPACK_IMPORTED_MODULE_4__["ViewerContainer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 3
  }, _this);
};

_c = ViewerPage;
/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])()(ViewerPage));

var _c;

$RefreshReg$(_c, "ViewerPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./src/components/Layout/FooterBar.tsx":
false,

/***/ "./src/components/Layout/NavigationBar/NavigationBar.tsx":
false,

/***/ "./src/components/Layout/NavigationBar/index.ts":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvdmlld2VyLnRzeCJdLCJuYW1lcyI6WyJWaWV3ZXJQYWdlIiwiY29ubmVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFHQTs7QUFFQSxJQUFNQSxVQUFtQyxHQUFHLFNBQXRDQSxVQUFzQztBQUFBLHNCQUMxQyxxRUFBQyxtRUFBRDtBQUFBLDJCQUVFLHFFQUFDLGdFQUFEO0FBQUEsNkJBQ0UscUVBQUMsbUZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRDBDO0FBQUEsQ0FBNUM7O0tBQU1BLFU7QUFVU0MsMEhBQU8sR0FBR0QsVUFBSCxDQUF0QiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy92aWV3ZXIuNTA0MTc4NzRhZjJlM2E1NWY1YmYuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCB7IFdyYXBwZXIsIE1haW4gfSBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvTGF5b3V0L0JvZHlcIjtcbmltcG9ydCB7IEZvb3RlckJhciB9IGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9MYXlvdXQvRm9vdGVyQmFyXCI7XG5pbXBvcnQgeyBOYXZpZ2F0aW9uQmFyIH0gZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL0xheW91dC9OYXZpZ2F0aW9uQmFyXCI7XG5pbXBvcnQgeyBWaWV3ZXJDb250YWluZXIgfSBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvVmlld2VyUGFnZUNvbnRhaW5lclwiO1xuXG5jb25zdCBWaWV3ZXJQYWdlOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudCA9ICgpID0+IChcbiAgPFdyYXBwZXI+XG4gICAgey8qIDxOYXZpZ2F0aW9uQmFyIC8+ICovfVxuICAgIDxNYWluPlxuICAgICAgPFZpZXdlckNvbnRhaW5lciAvPlxuICAgIDwvTWFpbj5cbiAgICB7LyogPEZvb3RlckJhciAvPiAqL31cbiAgPC9XcmFwcGVyPlxuKTtcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdCgpKFZpZXdlclBhZ2UpO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==