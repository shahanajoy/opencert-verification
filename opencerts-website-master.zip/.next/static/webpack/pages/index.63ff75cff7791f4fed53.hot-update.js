webpackHotUpdate_N_E("pages/index",{

/***/ "./src/reducers/certificate.actions.ts":
/*!*********************************************!*\
  !*** ./src/reducers/certificate.actions.ts ***!
  \*********************************************/
/*! exports provided: RESET_CERTIFICATE, UPDATE_CERTIFICATE, VERIFYING_CERTIFICATE, VERIFYING_CERTIFICATE_COMPLETED, VERIFYING_CERTIFICATE_ERRORED, SENDING_CERTIFICATE, SENDING_CERTIFICATE_SUCCESS, SENDING_CERTIFICATE_FAILURE, SENDING_CERTIFICATE_RESET, GENERATE_SHARE_LINK, GENERATE_SHARE_LINK_SUCCESS, GENERATE_SHARE_LINK_FAILURE, GENERATE_SHARE_LINK_RESET, RETRIEVE_CERTIFICATE_BY_ACTION, RETRIEVE_CERTIFICATE_BY_ACTION_PENDING, RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS, RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE, CERTIFICATE_OBFUSCATE_UPDATE, resetCertificateState, updateCertificate, verifyingCertificate, verifyingCertificateCompleted, verifyingCertificateErrored, sendCertificate, sendCertificateSuccess, sendCertificateFailure, sendCertificateReset, generateShareLink, generateShareLinkReset, generateShareLinkSuccess, generateShareLinkFailure, retrieveCertificateByAction, retrieveCertificateByActionPending, retrieveCertificateByActionSuccess, retrieveCertificateByActionFailure, updateObfuscatedCertificate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RESET_CERTIFICATE", function() { return RESET_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_CERTIFICATE", function() { return UPDATE_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE", function() { return VERIFYING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_COMPLETED", function() { return VERIFYING_CERTIFICATE_COMPLETED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_ERRORED", function() { return VERIFYING_CERTIFICATE_ERRORED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE", function() { return SENDING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_SUCCESS", function() { return SENDING_CERTIFICATE_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_FAILURE", function() { return SENDING_CERTIFICATE_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_RESET", function() { return SENDING_CERTIFICATE_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK", function() { return GENERATE_SHARE_LINK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_SUCCESS", function() { return GENERATE_SHARE_LINK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_FAILURE", function() { return GENERATE_SHARE_LINK_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_RESET", function() { return GENERATE_SHARE_LINK_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION", function() { return RETRIEVE_CERTIFICATE_BY_ACTION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_PENDING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CERTIFICATE_OBFUSCATE_UPDATE", function() { return CERTIFICATE_OBFUSCATE_UPDATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCertificateState", function() { return resetCertificateState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCertificate", function() { return updateCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificate", function() { return verifyingCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateCompleted", function() { return verifyingCertificateCompleted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateErrored", function() { return verifyingCertificateErrored; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificate", function() { return sendCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateSuccess", function() { return sendCertificateSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateFailure", function() { return sendCertificateFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateReset", function() { return sendCertificateReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLink", function() { return generateShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkReset", function() { return generateShareLinkReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkSuccess", function() { return generateShareLinkSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkFailure", function() { return generateShareLinkFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByAction", function() { return retrieveCertificateByAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionPending", function() { return retrieveCertificateByActionPending; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionSuccess", function() { return retrieveCertificateByActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionFailure", function() { return retrieveCertificateByActionFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateObfuscatedCertificate", function() { return updateObfuscatedCertificate; });
// Action Creators
// Actions
var RESET_CERTIFICATE = "RESET_CERTIFICATE";
var UPDATE_CERTIFICATE = "UPDATE_CERTIFICATE";
var VERIFYING_CERTIFICATE = "VERIFYING_CERTIFICATE";
var VERIFYING_CERTIFICATE_COMPLETED = "VERIFYING_CERTIFICATE_COMPLETED"; // completed

var VERIFYING_CERTIFICATE_ERRORED = "VERIFYING_CERTIFICATE_ERRORED"; // errored

var SENDING_CERTIFICATE = "SENDING_CERTIFICATE";
var SENDING_CERTIFICATE_SUCCESS = "SENDING_CERTIFICATE_SUCCESS";
var SENDING_CERTIFICATE_FAILURE = "SENDING_CERTIFICATE_FAILURE";
var SENDING_CERTIFICATE_RESET = "SENDING_CERTIFICATE_RESET";
var GENERATE_SHARE_LINK = "GENERATE_SHARE_LINK";
var GENERATE_SHARE_LINK_SUCCESS = "GENERATE_SHARE_LINK_SUCCESS";
var GENERATE_SHARE_LINK_FAILURE = "GENERATE_SHARE_LINK_FAILURE";
var GENERATE_SHARE_LINK_RESET = "GENERATE_SHARE_LINK_RESET";
var RETRIEVE_CERTIFICATE_BY_ACTION = "RETRIEVE_CERTIFICATE_BY_ACTION";
var RETRIEVE_CERTIFICATE_BY_ACTION_PENDING = "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING";
var RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS = "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS";
var RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE = "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE";
var CERTIFICATE_OBFUSCATE_UPDATE = "CERTIFICATE_OBFUSCATE_UPDATE";
function resetCertificateState() {
  return {
    type: RESET_CERTIFICATE
  };
}
function updateCertificate(payload) {
  return {
    type: UPDATE_CERTIFICATE,
    payload: payload
  };
}
var verifyingCertificate = function verifyingCertificate() {
  return {
    type: VERIFYING_CERTIFICATE
  };
};
var verifyingCertificateCompleted = function verifyingCertificateCompleted(payload) {
  return {
    type: VERIFYING_CERTIFICATE_COMPLETED,
    payload: payload
  };
};
var verifyingCertificateErrored = function verifyingCertificateErrored(payload) {
  return {
    type: VERIFYING_CERTIFICATE_ERRORED,
    payload: payload
  };
};
function sendCertificate(payload) {
  return {
    type: SENDING_CERTIFICATE,
    payload: payload
  };
}
function sendCertificateSuccess() {
  return {
    type: SENDING_CERTIFICATE_SUCCESS
  };
}
function sendCertificateFailure(payload) {
  return {
    type: SENDING_CERTIFICATE_FAILURE,
    payload: payload
  };
}
function sendCertificateReset() {
  return {
    type: SENDING_CERTIFICATE_RESET
  };
}
function generateShareLink() {
  return {
    type: GENERATE_SHARE_LINK
  };
}
function generateShareLinkReset() {
  return {
    type: GENERATE_SHARE_LINK_RESET
  };
}
function generateShareLinkSuccess(payload) {
  return {
    type: GENERATE_SHARE_LINK_SUCCESS,
    payload: payload
  };
}
function generateShareLinkFailure(payload) {
  return {
    type: GENERATE_SHARE_LINK_FAILURE,
    payload: payload
  };
}
function retrieveCertificateByAction(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION,
    payload: payload
  };
}
function retrieveCertificateByActionPending() {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_PENDING
  };
}
function retrieveCertificateByActionSuccess() {
  debugger;
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS
  };
}
function retrieveCertificateByActionFailure(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE,
    payload: payload
  };
}
function updateObfuscatedCertificate(payload) {
  return {
    type: CERTIFICATE_OBFUSCATE_UPDATE,
    payload: payload
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3JlZHVjZXJzL2NlcnRpZmljYXRlLmFjdGlvbnMudHMiXSwibmFtZXMiOlsiUkVTRVRfQ0VSVElGSUNBVEUiLCJVUERBVEVfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEIiwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQiLCJTRU5ESU5HX0NFUlRJRklDQVRFIiwiU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTIiwiU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFIiwiU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVCIsIkdFTkVSQVRFX1NIQVJFX0xJTksiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MiLCJHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkUiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkciLCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyIsIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFIiwiQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURSIsInJlc2V0Q2VydGlmaWNhdGVTdGF0ZSIsInR5cGUiLCJ1cGRhdGVDZXJ0aWZpY2F0ZSIsInBheWxvYWQiLCJ2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSIsInZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkIiwidmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkIiwic2VuZENlcnRpZmljYXRlIiwic2VuZENlcnRpZmljYXRlU3VjY2VzcyIsInNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUiLCJzZW5kQ2VydGlmaWNhdGVSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rIiwiZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyIsImdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZSIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbiIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblBlbmRpbmciLCJyZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzIiwicmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZSIsInVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUNPLElBQU1BLGlCQUFpQixHQUFHLG1CQUExQjtBQUNBLElBQU1DLGtCQUFrQixHQUFHLG9CQUEzQjtBQUNBLElBQU1DLHFCQUFxQixHQUFHLHVCQUE5QjtBQUNBLElBQU1DLCtCQUErQixHQUFHLGlDQUF4QyxDLENBQTJFOztBQUMzRSxJQUFNQyw2QkFBNkIsR0FBRywrQkFBdEMsQyxDQUF1RTs7QUFDdkUsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsOEJBQThCLEdBQUcsZ0NBQXZDO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsNEJBQTRCLEdBQUcsOEJBQXJDO0FBS0EsU0FBU0MscUJBQVQsR0FBeUQ7QUFDOUQsU0FBTztBQUNMQyxRQUFJLEVBQUVuQjtBQURELEdBQVA7QUFHRDtBQU1NLFNBQVNvQixpQkFBVCxDQUEyQkMsT0FBM0IsRUFBMEc7QUFDL0csU0FBTztBQUNMRixRQUFJLEVBQUVsQixrQkFERDtBQUVMb0IsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLElBQU1DLG9CQUFvQixHQUFHLFNBQXZCQSxvQkFBdUI7QUFBQSxTQUFtQztBQUNyRUgsUUFBSSxFQUFFakI7QUFEK0QsR0FBbkM7QUFBQSxDQUE3QjtBQVFBLElBQU1xQiw2QkFBNkIsR0FBRyxTQUFoQ0EsNkJBQWdDLENBQzNDRixPQUQyQztBQUFBLFNBRUY7QUFDekNGLFFBQUksRUFBRWhCLCtCQURtQztBQUV6Q2tCLFdBQU8sRUFBUEE7QUFGeUMsR0FGRTtBQUFBLENBQXRDO0FBV0EsSUFBTUcsMkJBQTJCLEdBQUcsU0FBOUJBLDJCQUE4QixDQUFDSCxPQUFEO0FBQUEsU0FBeUQ7QUFDbEdGLFFBQUksRUFBRWYsNkJBRDRGO0FBRWxHaUIsV0FBTyxFQUFQQTtBQUZrRyxHQUF6RDtBQUFBLENBQXBDO0FBU0EsU0FBU0ksZUFBVCxDQUF5QkosT0FBekIsRUFBNkY7QUFDbEcsU0FBTztBQUNMRixRQUFJLEVBQUVkLG1CQUREO0FBRUxnQixXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBSU0sU0FBU0ssc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMUCxRQUFJLEVBQUViO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU3FCLHNCQUFULENBQWdDTixPQUFoQyxFQUErRTtBQUNwRixTQUFPO0FBQ0xGLFFBQUksRUFBRVosMkJBREQ7QUFFTGMsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNPLG9CQUFULEdBQTREO0FBQ2pFLFNBQU87QUFDTFQsUUFBSSxFQUFFWDtBQURELEdBQVA7QUFHRDtBQUtNLFNBQVNxQixpQkFBVCxHQUFzRDtBQUMzRCxTQUFPO0FBQ0xWLFFBQUksRUFBRVY7QUFERCxHQUFQO0FBR0Q7QUFJTSxTQUFTcUIsc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMWCxRQUFJLEVBQUVQO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU21CLHdCQUFULENBQWtDVixPQUFsQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRVQsMkJBREQ7QUFFTFcsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNXLHdCQUFULENBQWtDWCxPQUFsQyxFQUFtRjtBQUN4RixTQUFPO0FBQ0xGLFFBQUksRUFBRVIsMkJBREQ7QUFFTFUsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQU1NLFNBQVNZLDJCQUFULENBQXFDWixPQUFyQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRU4sOEJBREQ7QUFFTFEsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUlNLFNBQVNhLGtDQUFULEdBQWdGO0FBQ3JGLFNBQU87QUFDTGYsUUFBSSxFQUFFTDtBQURELEdBQVA7QUFHRDtBQUlNLFNBQVNxQixrQ0FBVCxHQUFnRjtBQUNyRjtBQUNBLFNBQU87QUFDTGhCLFFBQUksRUFBRUo7QUFERCxHQUFQO0FBR0Q7QUFNTSxTQUFTcUIsa0NBQVQsQ0FBNENmLE9BQTVDLEVBQTZGO0FBQ2xHLFNBQU87QUFDTEYsUUFBSSxFQUFFSCxzQ0FERDtBQUVMSyxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBTU0sU0FBU2dCLDJCQUFULENBQ0xoQixPQURLLEVBRTJCO0FBQ2hDLFNBQU87QUFDTEYsUUFBSSxFQUFFRiw0QkFERDtBQUVMSSxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjYzZmY3NWNmZjc3OTFmNGZlZDUzLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBY3Rpb24gQ3JlYXRvcnNcbmltcG9ydCB7IFZlcmlmaWNhdGlvbkZyYWdtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb2EtdmVyaWZ5XCI7XG5pbXBvcnQgeyB2MiwgV3JhcHBlZERvY3VtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3Blbi1hdHRlc3RhdGlvblwiO1xuXG4vLyBBY3Rpb25zXG5leHBvcnQgY29uc3QgUkVTRVRfQ0VSVElGSUNBVEUgPSBcIlJFU0VUX0NFUlRJRklDQVRFXCI7XG5leHBvcnQgY29uc3QgVVBEQVRFX0NFUlRJRklDQVRFID0gXCJVUERBVEVfQ0VSVElGSUNBVEVcIjtcbmV4cG9ydCBjb25zdCBWRVJJRllJTkdfQ0VSVElGSUNBVEUgPSBcIlZFUklGWUlOR19DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFZFUklGWUlOR19DRVJUSUZJQ0FURV9DT01QTEVURUQgPSBcIlZFUklGWUlOR19DRVJUSUZJQ0FURV9DT01QTEVURURcIjsgLy8gY29tcGxldGVkXG5leHBvcnQgY29uc3QgVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQgPSBcIlZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEXCI7IC8vIGVycm9yZWRcbmV4cG9ydCBjb25zdCBTRU5ESU5HX0NFUlRJRklDQVRFID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFXCI7XG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFX1NVQ0NFU1NcIjtcbmV4cG9ydCBjb25zdCBTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkUgPSBcIlNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRVwiO1xuZXhwb3J0IGNvbnN0IFNFTkRJTkdfQ0VSVElGSUNBVEVfUkVTRVQgPSBcIlNFTkRJTkdfQ0VSVElGSUNBVEVfUkVTRVRcIjtcbmV4cG9ydCBjb25zdCBHRU5FUkFURV9TSEFSRV9MSU5LID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1NcIjtcbmV4cG9ydCBjb25zdCBHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkUgPSBcIkdFTkVSQVRFX1NIQVJFX0xJTktfRkFJTFVSRVwiO1xuZXhwb3J0IGNvbnN0IEdFTkVSQVRFX1NIQVJFX0xJTktfUkVTRVQgPSBcIkdFTkVSQVRFX1NIQVJFX0xJTktfUkVTRVRcIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT04gPSBcIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTlwiO1xuZXhwb3J0IGNvbnN0IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HID0gXCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElOR1wiO1xuZXhwb3J0IGNvbnN0IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9TVUNDRVNTID0gXCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTU1wiO1xuZXhwb3J0IGNvbnN0IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFID0gXCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRVwiO1xuZXhwb3J0IGNvbnN0IENFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEUgPSBcIkNFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEVcIjtcblxuaW50ZXJmYWNlIFJlc2V0Q2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVTRVRfQ0VSVElGSUNBVEU7XG59XG5leHBvcnQgZnVuY3Rpb24gcmVzZXRDZXJ0aWZpY2F0ZVN0YXRlKCk6IFJlc2V0Q2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFJFU0VUX0NFUlRJRklDQVRFLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgVXBkYXRlQ2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVVBEQVRFX0NFUlRJRklDQVRFO1xuICBwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZUNlcnRpZmljYXRlKHBheWxvYWQ6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD4pOiBVcGRhdGVDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogVVBEQVRFX0NFUlRJRklDQVRFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBWRVJJRllJTkdfQ0VSVElGSUNBVEU7XG59XG5leHBvcnQgY29uc3QgdmVyaWZ5aW5nQ2VydGlmaWNhdGUgPSAoKTogVmVyaWZ5aW5nQ2VydGlmaWNhdGVBY3Rpb24gPT4gKHtcbiAgdHlwZTogVkVSSUZZSU5HX0NFUlRJRklDQVRFLFxufSk7XG5cbmludGVyZmFjZSBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUNvbXBsZXRlZEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEO1xuICBwYXlsb2FkOiBWZXJpZmljYXRpb25GcmFnbWVudFtdO1xufVxuZXhwb3J0IGNvbnN0IHZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkID0gKFxuICBwYXlsb2FkOiBWZXJpZmljYXRpb25GcmFnbWVudFtdXG4pOiBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUNvbXBsZXRlZEFjdGlvbiA9PiAoe1xuICB0eXBlOiBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVELFxuICBwYXlsb2FkLFxufSk7XG5cbmludGVyZmFjZSBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUVycm9yZWRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQ7XG4gIHBheWxvYWQ6IHN0cmluZztcbn1cbmV4cG9ydCBjb25zdCB2ZXJpZnlpbmdDZXJ0aWZpY2F0ZUVycm9yZWQgPSAocGF5bG9hZDogc3RyaW5nKTogVmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkQWN0aW9uID0+ICh7XG4gIHR5cGU6IFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVELFxuICBwYXlsb2FkLFxufSk7XG5cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgU0VORElOR19DRVJUSUZJQ0FURTtcbiAgcGF5bG9hZDogeyBlbWFpbDogc3RyaW5nOyBjYXB0Y2hhOiBzdHJpbmcgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZW5kQ2VydGlmaWNhdGUocGF5bG9hZDogeyBlbWFpbDogc3RyaW5nOyBjYXB0Y2hhOiBzdHJpbmcgfSk6IFNlbmRDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogU0VORElOR19DRVJUSUZJQ0FURSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuaW50ZXJmYWNlIFNlbmRDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZVN1Y2Nlc3MoKTogU2VuZENlcnRpZmljYXRlU3VjY2Vzc0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTLFxuICB9O1xufVxuaW50ZXJmYWNlIFNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgZnVuY3Rpb24gc2VuZENlcnRpZmljYXRlRmFpbHVyZShwYXlsb2FkOiBzdHJpbmcpOiBTZW5kQ2VydGlmaWNhdGVGYWlsdXJlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFNlbmRDZXJ0aWZpY2F0ZVJlc2V0QWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEVfUkVTRVQ7XG59XG5leHBvcnQgZnVuY3Rpb24gc2VuZENlcnRpZmljYXRlUmVzZXQoKTogU2VuZENlcnRpZmljYXRlUmVzZXRBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEVfUkVTRVQsXG4gIH07XG59XG5cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBHRU5FUkFURV9TSEFSRV9MSU5LO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlU2hhcmVMaW5rKCk6IEdlbmVyYXRlU2hhcmVMaW5rQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LLFxuICB9O1xufVxuaW50ZXJmYWNlIEdlbmVyYXRlU2hhcmVMaW5rUmVzZXRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGlua1Jlc2V0KCk6IEdlbmVyYXRlU2hhcmVMaW5rUmVzZXRBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IEdFTkVSQVRFX1NIQVJFX0xJTktfUkVTRVQsXG4gIH07XG59XG5pbnRlcmZhY2UgR2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIEdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTUztcbiAgcGF5bG9hZDogeyBpZDogc3RyaW5nOyBrZXk6IHN0cmluZyB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyhwYXlsb2FkOiB7IGlkOiBzdHJpbmc7IGtleTogc3RyaW5nIH0pOiBHZW5lcmF0ZVNoYXJlTGlua1N1Y2Nlc3NBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IEdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTUyxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuaW50ZXJmYWNlIEdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkU7XG4gIHBheWxvYWQ6IHN0cmluZztcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmUocGF5bG9hZDogc3RyaW5nKTogR2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFJldHJpZXZlQ2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OO1xuICBwYXlsb2FkOiB7IHVyaTogc3RyaW5nOyBrZXk/OiBzdHJpbmcgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb24ocGF5bG9hZDogeyB1cmk6IHN0cmluZzsga2V5Pzogc3RyaW5nIH0pOiBSZXRyaWV2ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT04sXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlUGVuZGluZ0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElORztcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25QZW5kaW5nKCk6IFJldHJpZXZlQ2VydGlmaWNhdGVQZW5kaW5nQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElORyxcbiAgfTtcbn1cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlU3VjY2Vzc0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUztcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzKCk6IFJldHJpZXZlQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uIHtcbiAgZGVidWdnZXJcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFJldHJpZXZlQ2VydGlmaWNhdGVFcnJvckFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRTtcbiAgcGF5bG9hZDogc3RyaW5nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkZhaWx1cmUocGF5bG9hZDogc3RyaW5nKTogUmV0cmlldmVDZXJ0aWZpY2F0ZUVycm9yQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgVXBkYXRlT2JmdXNjYXRlZERvY3VtZW50QWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIENFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEU7XG4gIHBheWxvYWQ6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD47XG59XG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlT2JmdXNjYXRlZENlcnRpZmljYXRlKFxuICBwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+XG4pOiBVcGRhdGVPYmZ1c2NhdGVkRG9jdW1lbnRBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IENFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuZXhwb3J0IHR5cGUgQ2VydGlmaWNhdGVBY3Rpb25UeXBlcyA9XG4gIHwgUmVzZXRDZXJ0aWZpY2F0ZUFjdGlvblxuICB8IFVwZGF0ZUNlcnRpZmljYXRlQWN0aW9uXG4gIHwgVmVyaWZ5aW5nQ2VydGlmaWNhdGVBY3Rpb25cbiAgfCBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUVycm9yZWRBY3Rpb25cbiAgfCBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUNvbXBsZXRlZEFjdGlvblxuICB8IFNlbmRDZXJ0aWZpY2F0ZUFjdGlvblxuICB8IFNlbmRDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVGYWlsdXJlQWN0aW9uXG4gIHwgU2VuZENlcnRpZmljYXRlUmVzZXRBY3Rpb25cbiAgfCBHZW5lcmF0ZVNoYXJlTGlua0FjdGlvblxuICB8IEdlbmVyYXRlU2hhcmVMaW5rUmVzZXRBY3Rpb25cbiAgfCBHZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmVBY3Rpb25cbiAgfCBHZW5lcmF0ZVNoYXJlTGlua1N1Y2Nlc3NBY3Rpb25cbiAgfCBSZXRyaWV2ZUNlcnRpZmljYXRlUGVuZGluZ0FjdGlvblxuICB8IFJldHJpZXZlQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uXG4gIHwgUmV0cmlldmVDZXJ0aWZpY2F0ZUVycm9yQWN0aW9uXG4gIHwgVXBkYXRlT2JmdXNjYXRlZERvY3VtZW50QWN0aW9uO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==