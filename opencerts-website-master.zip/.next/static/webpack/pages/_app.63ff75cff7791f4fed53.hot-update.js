webpackHotUpdate_N_E("pages/_app",{

/***/ "./src/reducers/certificate.actions.ts":
/*!*********************************************!*\
  !*** ./src/reducers/certificate.actions.ts ***!
  \*********************************************/
/*! exports provided: RESET_CERTIFICATE, UPDATE_CERTIFICATE, VERIFYING_CERTIFICATE, VERIFYING_CERTIFICATE_COMPLETED, VERIFYING_CERTIFICATE_ERRORED, SENDING_CERTIFICATE, SENDING_CERTIFICATE_SUCCESS, SENDING_CERTIFICATE_FAILURE, SENDING_CERTIFICATE_RESET, GENERATE_SHARE_LINK, GENERATE_SHARE_LINK_SUCCESS, GENERATE_SHARE_LINK_FAILURE, GENERATE_SHARE_LINK_RESET, RETRIEVE_CERTIFICATE_BY_ACTION, RETRIEVE_CERTIFICATE_BY_ACTION_PENDING, RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS, RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE, CERTIFICATE_OBFUSCATE_UPDATE, resetCertificateState, updateCertificate, verifyingCertificate, verifyingCertificateCompleted, verifyingCertificateErrored, sendCertificate, sendCertificateSuccess, sendCertificateFailure, sendCertificateReset, generateShareLink, generateShareLinkReset, generateShareLinkSuccess, generateShareLinkFailure, retrieveCertificateByAction, retrieveCertificateByActionPending, retrieveCertificateByActionSuccess, retrieveCertificateByActionFailure, updateObfuscatedCertificate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RESET_CERTIFICATE", function() { return RESET_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_CERTIFICATE", function() { return UPDATE_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE", function() { return VERIFYING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_COMPLETED", function() { return VERIFYING_CERTIFICATE_COMPLETED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_ERRORED", function() { return VERIFYING_CERTIFICATE_ERRORED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE", function() { return SENDING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_SUCCESS", function() { return SENDING_CERTIFICATE_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_FAILURE", function() { return SENDING_CERTIFICATE_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_RESET", function() { return SENDING_CERTIFICATE_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK", function() { return GENERATE_SHARE_LINK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_SUCCESS", function() { return GENERATE_SHARE_LINK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_FAILURE", function() { return GENERATE_SHARE_LINK_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_RESET", function() { return GENERATE_SHARE_LINK_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION", function() { return RETRIEVE_CERTIFICATE_BY_ACTION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_PENDING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CERTIFICATE_OBFUSCATE_UPDATE", function() { return CERTIFICATE_OBFUSCATE_UPDATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCertificateState", function() { return resetCertificateState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCertificate", function() { return updateCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificate", function() { return verifyingCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateCompleted", function() { return verifyingCertificateCompleted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateErrored", function() { return verifyingCertificateErrored; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificate", function() { return sendCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateSuccess", function() { return sendCertificateSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateFailure", function() { return sendCertificateFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateReset", function() { return sendCertificateReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLink", function() { return generateShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkReset", function() { return generateShareLinkReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkSuccess", function() { return generateShareLinkSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkFailure", function() { return generateShareLinkFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByAction", function() { return retrieveCertificateByAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionPending", function() { return retrieveCertificateByActionPending; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionSuccess", function() { return retrieveCertificateByActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionFailure", function() { return retrieveCertificateByActionFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateObfuscatedCertificate", function() { return updateObfuscatedCertificate; });
// Action Creators
// Actions
var RESET_CERTIFICATE = "RESET_CERTIFICATE";
var UPDATE_CERTIFICATE = "UPDATE_CERTIFICATE";
var VERIFYING_CERTIFICATE = "VERIFYING_CERTIFICATE";
var VERIFYING_CERTIFICATE_COMPLETED = "VERIFYING_CERTIFICATE_COMPLETED"; // completed

var VERIFYING_CERTIFICATE_ERRORED = "VERIFYING_CERTIFICATE_ERRORED"; // errored

var SENDING_CERTIFICATE = "SENDING_CERTIFICATE";
var SENDING_CERTIFICATE_SUCCESS = "SENDING_CERTIFICATE_SUCCESS";
var SENDING_CERTIFICATE_FAILURE = "SENDING_CERTIFICATE_FAILURE";
var SENDING_CERTIFICATE_RESET = "SENDING_CERTIFICATE_RESET";
var GENERATE_SHARE_LINK = "GENERATE_SHARE_LINK";
var GENERATE_SHARE_LINK_SUCCESS = "GENERATE_SHARE_LINK_SUCCESS";
var GENERATE_SHARE_LINK_FAILURE = "GENERATE_SHARE_LINK_FAILURE";
var GENERATE_SHARE_LINK_RESET = "GENERATE_SHARE_LINK_RESET";
var RETRIEVE_CERTIFICATE_BY_ACTION = "RETRIEVE_CERTIFICATE_BY_ACTION";
var RETRIEVE_CERTIFICATE_BY_ACTION_PENDING = "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING";
var RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS = "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS";
var RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE = "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE";
var CERTIFICATE_OBFUSCATE_UPDATE = "CERTIFICATE_OBFUSCATE_UPDATE";
function resetCertificateState() {
  return {
    type: RESET_CERTIFICATE
  };
}
function updateCertificate(payload) {
  return {
    type: UPDATE_CERTIFICATE,
    payload: payload
  };
}
var verifyingCertificate = function verifyingCertificate() {
  return {
    type: VERIFYING_CERTIFICATE
  };
};
var verifyingCertificateCompleted = function verifyingCertificateCompleted(payload) {
  return {
    type: VERIFYING_CERTIFICATE_COMPLETED,
    payload: payload
  };
};
var verifyingCertificateErrored = function verifyingCertificateErrored(payload) {
  return {
    type: VERIFYING_CERTIFICATE_ERRORED,
    payload: payload
  };
};
function sendCertificate(payload) {
  return {
    type: SENDING_CERTIFICATE,
    payload: payload
  };
}
function sendCertificateSuccess() {
  return {
    type: SENDING_CERTIFICATE_SUCCESS
  };
}
function sendCertificateFailure(payload) {
  return {
    type: SENDING_CERTIFICATE_FAILURE,
    payload: payload
  };
}
function sendCertificateReset() {
  return {
    type: SENDING_CERTIFICATE_RESET
  };
}
function generateShareLink() {
  return {
    type: GENERATE_SHARE_LINK
  };
}
function generateShareLinkReset() {
  return {
    type: GENERATE_SHARE_LINK_RESET
  };
}
function generateShareLinkSuccess(payload) {
  return {
    type: GENERATE_SHARE_LINK_SUCCESS,
    payload: payload
  };
}
function generateShareLinkFailure(payload) {
  return {
    type: GENERATE_SHARE_LINK_FAILURE,
    payload: payload
  };
}
function retrieveCertificateByAction(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION,
    payload: payload
  };
}
function retrieveCertificateByActionPending() {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_PENDING
  };
}
function retrieveCertificateByActionSuccess() {
  debugger;
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS
  };
}
function retrieveCertificateByActionFailure(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE,
    payload: payload
  };
}
function updateObfuscatedCertificate(payload) {
  return {
    type: CERTIFICATE_OBFUSCATE_UPDATE,
    payload: payload
  };
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3JlZHVjZXJzL2NlcnRpZmljYXRlLmFjdGlvbnMudHMiXSwibmFtZXMiOlsiUkVTRVRfQ0VSVElGSUNBVEUiLCJVUERBVEVfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEUiLCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEIiwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQiLCJTRU5ESU5HX0NFUlRJRklDQVRFIiwiU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTIiwiU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFIiwiU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVCIsIkdFTkVSQVRFX1NIQVJFX0xJTksiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MiLCJHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkUiLCJHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkciLCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyIsIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFIiwiQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURSIsInJlc2V0Q2VydGlmaWNhdGVTdGF0ZSIsInR5cGUiLCJ1cGRhdGVDZXJ0aWZpY2F0ZSIsInBheWxvYWQiLCJ2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSIsInZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkIiwidmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkIiwic2VuZENlcnRpZmljYXRlIiwic2VuZENlcnRpZmljYXRlU3VjY2VzcyIsInNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUiLCJzZW5kQ2VydGlmaWNhdGVSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rIiwiZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyIsImdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZSIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbiIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblBlbmRpbmciLCJyZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzIiwicmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZSIsInVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUNPLElBQU1BLGlCQUFpQixHQUFHLG1CQUExQjtBQUNBLElBQU1DLGtCQUFrQixHQUFHLG9CQUEzQjtBQUNBLElBQU1DLHFCQUFxQixHQUFHLHVCQUE5QjtBQUNBLElBQU1DLCtCQUErQixHQUFHLGlDQUF4QyxDLENBQTJFOztBQUMzRSxJQUFNQyw2QkFBNkIsR0FBRywrQkFBdEMsQyxDQUF1RTs7QUFDdkUsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsbUJBQW1CLEdBQUcscUJBQTVCO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMsMkJBQTJCLEdBQUcsNkJBQXBDO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUcsMkJBQWxDO0FBQ0EsSUFBTUMsOEJBQThCLEdBQUcsZ0NBQXZDO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsc0NBQXNDLEdBQUcsd0NBQS9DO0FBQ0EsSUFBTUMsNEJBQTRCLEdBQUcsOEJBQXJDO0FBS0EsU0FBU0MscUJBQVQsR0FBeUQ7QUFDOUQsU0FBTztBQUNMQyxRQUFJLEVBQUVuQjtBQURELEdBQVA7QUFHRDtBQU1NLFNBQVNvQixpQkFBVCxDQUEyQkMsT0FBM0IsRUFBMEc7QUFDL0csU0FBTztBQUNMRixRQUFJLEVBQUVsQixrQkFERDtBQUVMb0IsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLElBQU1DLG9CQUFvQixHQUFHLFNBQXZCQSxvQkFBdUI7QUFBQSxTQUFtQztBQUNyRUgsUUFBSSxFQUFFakI7QUFEK0QsR0FBbkM7QUFBQSxDQUE3QjtBQVFBLElBQU1xQiw2QkFBNkIsR0FBRyxTQUFoQ0EsNkJBQWdDLENBQzNDRixPQUQyQztBQUFBLFNBRUY7QUFDekNGLFFBQUksRUFBRWhCLCtCQURtQztBQUV6Q2tCLFdBQU8sRUFBUEE7QUFGeUMsR0FGRTtBQUFBLENBQXRDO0FBV0EsSUFBTUcsMkJBQTJCLEdBQUcsU0FBOUJBLDJCQUE4QixDQUFDSCxPQUFEO0FBQUEsU0FBeUQ7QUFDbEdGLFFBQUksRUFBRWYsNkJBRDRGO0FBRWxHaUIsV0FBTyxFQUFQQTtBQUZrRyxHQUF6RDtBQUFBLENBQXBDO0FBU0EsU0FBU0ksZUFBVCxDQUF5QkosT0FBekIsRUFBNkY7QUFDbEcsU0FBTztBQUNMRixRQUFJLEVBQUVkLG1CQUREO0FBRUxnQixXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBSU0sU0FBU0ssc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMUCxRQUFJLEVBQUViO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU3FCLHNCQUFULENBQWdDTixPQUFoQyxFQUErRTtBQUNwRixTQUFPO0FBQ0xGLFFBQUksRUFBRVosMkJBREQ7QUFFTGMsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNPLG9CQUFULEdBQTREO0FBQ2pFLFNBQU87QUFDTFQsUUFBSSxFQUFFWDtBQURELEdBQVA7QUFHRDtBQUtNLFNBQVNxQixpQkFBVCxHQUFzRDtBQUMzRCxTQUFPO0FBQ0xWLFFBQUksRUFBRVY7QUFERCxHQUFQO0FBR0Q7QUFJTSxTQUFTcUIsc0JBQVQsR0FBZ0U7QUFDckUsU0FBTztBQUNMWCxRQUFJLEVBQUVQO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU21CLHdCQUFULENBQWtDVixPQUFsQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRVQsMkJBREQ7QUFFTFcsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUtNLFNBQVNXLHdCQUFULENBQWtDWCxPQUFsQyxFQUFtRjtBQUN4RixTQUFPO0FBQ0xGLFFBQUksRUFBRVIsMkJBREQ7QUFFTFUsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQU1NLFNBQVNZLDJCQUFULENBQXFDWixPQUFyQyxFQUF3RztBQUM3RyxTQUFPO0FBQ0xGLFFBQUksRUFBRU4sOEJBREQ7QUFFTFEsV0FBTyxFQUFQQTtBQUZLLEdBQVA7QUFJRDtBQUlNLFNBQVNhLGtDQUFULEdBQWdGO0FBQ3JGLFNBQU87QUFDTGYsUUFBSSxFQUFFTDtBQURELEdBQVA7QUFHRDtBQUlNLFNBQVNxQixrQ0FBVCxHQUFnRjtBQUNyRjtBQUNBLFNBQU87QUFDTGhCLFFBQUksRUFBRUo7QUFERCxHQUFQO0FBR0Q7QUFNTSxTQUFTcUIsa0NBQVQsQ0FBNENmLE9BQTVDLEVBQTZGO0FBQ2xHLFNBQU87QUFDTEYsUUFBSSxFQUFFSCxzQ0FERDtBQUVMSyxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEO0FBTU0sU0FBU2dCLDJCQUFULENBQ0xoQixPQURLLEVBRTJCO0FBQ2hDLFNBQU87QUFDTEYsUUFBSSxFQUFFRiw0QkFERDtBQUVMSSxXQUFPLEVBQVBBO0FBRkssR0FBUDtBQUlEIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL19hcHAuNjNmZjc1Y2ZmNzc5MWY0ZmVkNTMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEFjdGlvbiBDcmVhdG9yc1xuaW1wb3J0IHsgVmVyaWZpY2F0aW9uRnJhZ21lbnQgfSBmcm9tIFwiQGdvdnRlY2hzZy9vYS12ZXJpZnlcIjtcbmltcG9ydCB7IHYyLCBXcmFwcGVkRG9jdW1lbnQgfSBmcm9tIFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCI7XG5cbi8vIEFjdGlvbnNcbmV4cG9ydCBjb25zdCBSRVNFVF9DRVJUSUZJQ0FURSA9IFwiUkVTRVRfQ0VSVElGSUNBVEVcIjtcbmV4cG9ydCBjb25zdCBVUERBVEVfQ0VSVElGSUNBVEUgPSBcIlVQREFURV9DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFZFUklGWUlOR19DRVJUSUZJQ0FURSA9IFwiVkVSSUZZSU5HX0NFUlRJRklDQVRFXCI7XG5leHBvcnQgY29uc3QgVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRCA9IFwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRFwiOyAvLyBjb21wbGV0ZWRcbmV4cG9ydCBjb25zdCBWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRCA9IFwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRURcIjsgLy8gZXJyb3JlZFxuZXhwb3J0IGNvbnN0IFNFTkRJTkdfQ0VSVElGSUNBVEUgPSBcIlNFTkRJTkdfQ0VSVElGSUNBVEVcIjtcbmV4cG9ydCBjb25zdCBTRU5ESU5HX0NFUlRJRklDQVRFX1NVQ0NFU1MgPSBcIlNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTU1wiO1xuZXhwb3J0IGNvbnN0IFNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRSA9IFwiU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFXCI7XG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVCA9IFwiU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVFwiO1xuZXhwb3J0IGNvbnN0IEdFTkVSQVRFX1NIQVJFX0xJTksgPSBcIkdFTkVSQVRFX1NIQVJFX0xJTktcIjtcbmV4cG9ydCBjb25zdCBHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MgPSBcIkdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTU1wiO1xuZXhwb3J0IGNvbnN0IEdFTkVSQVRFX1NIQVJFX0xJTktfRkFJTFVSRSA9IFwiR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVCA9IFwiR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVFwiO1xuZXhwb3J0IGNvbnN0IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTiA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OXCI7XG5leHBvcnQgY29uc3QgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkcgPSBcIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HXCI7XG5leHBvcnQgY29uc3QgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1MgPSBcIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9TVUNDRVNTXCI7XG5leHBvcnQgY29uc3QgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkUgPSBcIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFXCI7XG5leHBvcnQgY29uc3QgQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURSA9IFwiQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURVwiO1xuXG5pbnRlcmZhY2UgUmVzZXRDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBSRVNFVF9DRVJUSUZJQ0FURTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXNldENlcnRpZmljYXRlU3RhdGUoKTogUmVzZXRDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVTRVRfQ0VSVElGSUNBVEUsXG4gIH07XG59XG5cbmludGVyZmFjZSBVcGRhdGVDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBVUERBVEVfQ0VSVElGSUNBVEU7XG4gIHBheWxvYWQ6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD47XG59XG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlQ2VydGlmaWNhdGUocGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50Pik6IFVwZGF0ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBVUERBVEVfQ0VSVElGSUNBVEUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFZlcmlmeWluZ0NlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFZFUklGWUlOR19DRVJUSUZJQ0FURTtcbn1cbmV4cG9ydCBjb25zdCB2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSA9ICgpOiBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUFjdGlvbiA9PiAoe1xuICB0eXBlOiBWRVJJRllJTkdfQ0VSVElGSUNBVEUsXG59KTtcblxuaW50ZXJmYWNlIFZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFZFUklGWUlOR19DRVJUSUZJQ0FURV9DT01QTEVURUQ7XG4gIHBheWxvYWQ6IFZlcmlmaWNhdGlvbkZyYWdtZW50W107XG59XG5leHBvcnQgY29uc3QgdmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWQgPSAoXG4gIHBheWxvYWQ6IFZlcmlmaWNhdGlvbkZyYWdtZW50W11cbik6IFZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkQWN0aW9uID0+ICh7XG4gIHR5cGU6IFZFUklGWUlOR19DRVJUSUZJQ0FURV9DT01QTEVURUQsXG4gIHBheWxvYWQsXG59KTtcblxuaW50ZXJmYWNlIFZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRDtcbiAgcGF5bG9hZDogc3RyaW5nO1xufVxuZXhwb3J0IGNvbnN0IHZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZCA9IChwYXlsb2FkOiBzdHJpbmcpOiBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUVycm9yZWRBY3Rpb24gPT4gKHtcbiAgdHlwZTogVkVSSUZZSU5HX0NFUlRJRklDQVRFX0VSUk9SRUQsXG4gIHBheWxvYWQsXG59KTtcblxuaW50ZXJmYWNlIFNlbmRDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBTRU5ESU5HX0NFUlRJRklDQVRFO1xuICBwYXlsb2FkOiB7IGVtYWlsOiBzdHJpbmc7IGNhcHRjaGE6IHN0cmluZyB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZShwYXlsb2FkOiB7IGVtYWlsOiBzdHJpbmc7IGNhcHRjaGE6IHN0cmluZyB9KTogU2VuZENlcnRpZmljYXRlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBTRU5ESU5HX0NFUlRJRklDQVRFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5pbnRlcmZhY2UgU2VuZENlcnRpZmljYXRlU3VjY2Vzc0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBTRU5ESU5HX0NFUlRJRklDQVRFX1NVQ0NFU1M7XG59XG5leHBvcnQgZnVuY3Rpb24gc2VuZENlcnRpZmljYXRlU3VjY2VzcygpOiBTZW5kQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBTRU5ESU5HX0NFUlRJRklDQVRFX1NVQ0NFU1MsXG4gIH07XG59XG5pbnRlcmZhY2UgU2VuZENlcnRpZmljYXRlRmFpbHVyZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkU7XG4gIHBheWxvYWQ6IHN0cmluZztcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZW5kQ2VydGlmaWNhdGVGYWlsdXJlKHBheWxvYWQ6IHN0cmluZyk6IFNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgU2VuZENlcnRpZmljYXRlUmVzZXRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZW5kQ2VydGlmaWNhdGVSZXNldCgpOiBTZW5kQ2VydGlmaWNhdGVSZXNldEFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogU0VORElOR19DRVJUSUZJQ0FURV9SRVNFVCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIEdlbmVyYXRlU2hhcmVMaW5rQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIEdFTkVSQVRFX1NIQVJFX0xJTks7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmsoKTogR2VuZXJhdGVTaGFyZUxpbmtBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IEdFTkVSQVRFX1NIQVJFX0xJTkssXG4gIH07XG59XG5pbnRlcmZhY2UgR2VuZXJhdGVTaGFyZUxpbmtSZXNldEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlU2hhcmVMaW5rUmVzZXQoKTogR2VuZXJhdGVTaGFyZUxpbmtSZXNldEFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVCxcbiAgfTtcbn1cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua1N1Y2Nlc3NBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTO1xuICBwYXlsb2FkOiB7IGlkOiBzdHJpbmc7IGtleTogc3RyaW5nIH07XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzKHBheWxvYWQ6IHsgaWQ6IHN0cmluZzsga2V5OiBzdHJpbmcgfSk6IEdlbmVyYXRlU2hhcmVMaW5rU3VjY2Vzc0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5pbnRlcmZhY2UgR2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIEdFTkVSQVRFX1NIQVJFX0xJTktfRkFJTFVSRTtcbiAgcGF5bG9hZDogc3RyaW5nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZShwYXlsb2FkOiBzdHJpbmcpOiBHZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IEdFTkVSQVRFX1NIQVJFX0xJTktfRkFJTFVSRSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT047XG4gIHBheWxvYWQ6IHsgdXJpOiBzdHJpbmc7IGtleT86IHN0cmluZyB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbihwYXlsb2FkOiB7IHVyaTogc3RyaW5nOyBrZXk/OiBzdHJpbmcgfSk6IFJldHJpZXZlQ2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTixcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuaW50ZXJmYWNlIFJldHJpZXZlQ2VydGlmaWNhdGVQZW5kaW5nQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblBlbmRpbmcoKTogUmV0cmlldmVDZXJ0aWZpY2F0ZVBlbmRpbmdBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HLFxuICB9O1xufVxuaW50ZXJmYWNlIFJldHJpZXZlQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9TVUNDRVNTO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblN1Y2Nlc3MoKTogUmV0cmlldmVDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICBkZWJ1Z2dlclxuICByZXR1cm4ge1xuICAgIHR5cGU6IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9TVUNDRVNTLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZUVycm9yQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZShwYXlsb2FkOiBzdHJpbmcpOiBSZXRyaWV2ZUNlcnRpZmljYXRlRXJyb3JBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBVcGRhdGVPYmZ1c2NhdGVkRG9jdW1lbnRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURTtcbiAgcGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50Pjtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVPYmZ1c2NhdGVkQ2VydGlmaWNhdGUoXG4gIHBheWxvYWQ6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD5cbik6IFVwZGF0ZU9iZnVzY2F0ZWREb2N1bWVudEFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogQ0VSVElGSUNBVEVfT0JGVVNDQVRFX1VQREFURSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5leHBvcnQgdHlwZSBDZXJ0aWZpY2F0ZUFjdGlvblR5cGVzID1cbiAgfCBSZXNldENlcnRpZmljYXRlQWN0aW9uXG4gIHwgVXBkYXRlQ2VydGlmaWNhdGVBY3Rpb25cbiAgfCBWZXJpZnlpbmdDZXJ0aWZpY2F0ZUFjdGlvblxuICB8IFZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZEFjdGlvblxuICB8IFZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkQWN0aW9uXG4gIHwgU2VuZENlcnRpZmljYXRlQWN0aW9uXG4gIHwgU2VuZENlcnRpZmljYXRlU3VjY2Vzc0FjdGlvblxuICB8IFNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmVBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVSZXNldEFjdGlvblxuICB8IEdlbmVyYXRlU2hhcmVMaW5rQWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtSZXNldEFjdGlvblxuICB8IEdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZUFjdGlvblxuICB8IEdlbmVyYXRlU2hhcmVMaW5rU3VjY2Vzc0FjdGlvblxuICB8IFJldHJpZXZlQ2VydGlmaWNhdGVQZW5kaW5nQWN0aW9uXG4gIHwgUmV0cmlldmVDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb25cbiAgfCBSZXRyaWV2ZUNlcnRpZmljYXRlRXJyb3JBY3Rpb25cbiAgfCBVcGRhdGVPYmZ1c2NhdGVkRG9jdW1lbnRBY3Rpb247XG4iXSwic291cmNlUm9vdCI6IiJ9