webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/CertificateDropZone/CertificateDropZoneContainer.tsx":
/*!*****************************************************************************!*\
  !*** ./src/components/CertificateDropZone/CertificateDropZoneContainer.tsx ***!
  \*****************************************************************************/
/*! exports provided: CertificateDropZoneContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CertificateDropZoneContainer", function() { return CertificateDropZoneContainer; });
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! next/router */ "./node_modules/next/dist/client/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-dropzone */ "./node_modules/react-dropzone/dist/es/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../reducers/certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../reducers/certificate.selectors */ "./src/reducers/certificate.selectors.ts");
/* harmony import */ var _CertificateVerificationStatus__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./CertificateVerificationStatus */ "./src/components/CertificateDropZone/CertificateVerificationStatus.tsx");








var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\CertificateDropZone\\CertificateDropZoneContainer.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_6__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }









var CertificateDropZone = /*#__PURE__*/function (_Component) {
  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_4__["default"])(CertificateDropZone, _Component);

  var _super = _createSuper(CertificateDropZone);

  function CertificateDropZone(props) {
    var _this;

    Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CertificateDropZone);

    _this = _super.call(this, props);
    _this.state = {
      fileError: false
    };
    _this.handleCertificateChange = _this.handleCertificateChange.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__["default"])(_this));
    _this.handleFileError = _this.handleFileError.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__["default"])(_this));
    return _this;
  } // eslint-disable-next-line class-methods-use-this


  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__["default"])(CertificateDropZone, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      debugger;
      next_router__WEBPACK_IMPORTED_MODULE_8___default.a.prefetch("/viewer");
    } // this is where the JSON is passed from the file we upload

  }, {
    key: "handleCertificateChange",
    value: function handleCertificateChange(certificate) {
      debugger;
      this.setState({
        fileError: false
      });
      this.props.updateCertificate(certificate);
    }
  }, {
    key: "handleFileError",
    value: function handleFileError() {
      debugger;
      this.setState({
        fileError: true
      });
    }
  }, {
    key: "resetData",
    value: function resetData() {
      this.props.resetData();
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_dropzone__WEBPACK_IMPORTED_MODULE_10__["default"], {
        onDrop: function onDrop(acceptedFiles) {
          debugger; // eslint-disable-next-line no-undef

          var reader = new FileReader();

          reader.onload = function () {
            try {
              // TODO enhance this
              var json = JSON.parse(reader.result);

              _this2.handleCertificateChange(json);
            } catch (e) {
              _this2.handleFileError();
            }
          };

          if (acceptedFiles && acceptedFiles.length && acceptedFiles.length > 0) acceptedFiles.map(function (f) {
            return reader.readAsText(f);
          });
        },
        children: function children(_ref) {
          var getRootProps = _ref.getRootProps,
              getInputProps = _ref.getInputProps,
              isDragAccept = _ref.isDragAccept;
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", _objectSpread(_objectSpread({}, getRootProps()), {}, {
            id: "certificate-dropzone",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("input", _objectSpread({}, getInputProps()), void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 13
            }, _this2), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_CertificateVerificationStatus__WEBPACK_IMPORTED_MODULE_14__["CertificateVerificationStatus"], {
              fileError: _this2.state.fileError,
              verifying: _this2.props.verifying,
              verificationStatus: _this2.props.verificationStatus,
              retrieveCertificateByActionError: _this2.props.retrieveCertificateByActionError,
              resetData: _this2.resetData.bind(_this2),
              hover: isDragAccept
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 80,
              columnNumber: 13
            }, _this2)]
          }), void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 11
          }, _this2);
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 7
      }, this);
    }
  }]);

  return CertificateDropZone;
}(react__WEBPACK_IMPORTED_MODULE_9__["Component"]);

var CertificateDropZoneContainer = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["connect"])(function (store) {
  return {
    retrieveCertificateByActionError: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getCertificateByActionError"])(store),
    verifying: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getVerifying"])(store),
    verificationStatus: Object(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_13__["getVerificationStatus"])(store)
  };
}, function (dispatch) {
  return {
    updateCertificate: function updateCertificate(payload) {
      return dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__["updateCertificate"])(payload));
    },
    resetData: function resetData() {
      return dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_12__["resetCertificateState"])());
    }
  };
})(CertificateDropZone);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvQ2VydGlmaWNhdGVEcm9wWm9uZS9DZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyLnRzeCJdLCJuYW1lcyI6WyJDZXJ0aWZpY2F0ZURyb3Bab25lIiwicHJvcHMiLCJzdGF0ZSIsImZpbGVFcnJvciIsImhhbmRsZUNlcnRpZmljYXRlQ2hhbmdlIiwiYmluZCIsImhhbmRsZUZpbGVFcnJvciIsIlJvdXRlciIsInByZWZldGNoIiwiY2VydGlmaWNhdGUiLCJzZXRTdGF0ZSIsInVwZGF0ZUNlcnRpZmljYXRlIiwicmVzZXREYXRhIiwiYWNjZXB0ZWRGaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJqc29uIiwiSlNPTiIsInBhcnNlIiwicmVzdWx0IiwiZSIsImxlbmd0aCIsIm1hcCIsImYiLCJyZWFkQXNUZXh0IiwiZ2V0Um9vdFByb3BzIiwiZ2V0SW5wdXRQcm9wcyIsImlzRHJhZ0FjY2VwdCIsInZlcmlmeWluZyIsInZlcmlmaWNhdGlvblN0YXR1cyIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yIiwiQ29tcG9uZW50IiwiQ2VydGlmaWNhdGVEcm9wWm9uZUNvbnRhaW5lciIsImNvbm5lY3QiLCJzdG9yZSIsImdldENlcnRpZmljYXRlQnlBY3Rpb25FcnJvciIsImdldFZlcmlmeWluZyIsImdldFZlcmlmaWNhdGlvblN0YXR1cyIsImRpc3BhdGNoIiwicGF5bG9hZCIsInJlc2V0Q2VydGlmaWNhdGVTdGF0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0lBY01BLG1COzs7OztBQUNKLCtCQUFZQyxLQUFaLEVBQXNEO0FBQUE7O0FBQUE7O0FBQ3BELDhCQUFNQSxLQUFOO0FBRUEsVUFBS0MsS0FBTCxHQUFhO0FBQ1hDLGVBQVMsRUFBRTtBQURBLEtBQWI7QUFHQSxVQUFLQyx1QkFBTCxHQUErQixNQUFLQSx1QkFBTCxDQUE2QkMsSUFBN0Isc05BQS9CO0FBQ0EsVUFBS0MsZUFBTCxHQUF1QixNQUFLQSxlQUFMLENBQXFCRCxJQUFyQixzTkFBdkI7QUFQb0Q7QUFRckQsRyxDQUVEOzs7Ozt3Q0FDMEI7QUFDeEI7QUFDQUUsd0RBQU0sQ0FBQ0MsUUFBUCxDQUFnQixTQUFoQjtBQUNELEssQ0FFRDs7Ozs0Q0FDd0JDLFcsRUFBZ0U7QUFDdEY7QUFDQSxXQUFLQyxRQUFMLENBQWM7QUFBRVAsaUJBQVMsRUFBRTtBQUFiLE9BQWQ7QUFDQSxXQUFLRixLQUFMLENBQVdVLGlCQUFYLENBQTZCRixXQUE3QjtBQUNEOzs7c0NBRXVCO0FBQ3RCO0FBQ0EsV0FBS0MsUUFBTCxDQUFjO0FBQUVQLGlCQUFTLEVBQUU7QUFBYixPQUFkO0FBQ0Q7OztnQ0FFaUI7QUFDaEIsV0FBS0YsS0FBTCxDQUFXVyxTQUFYO0FBQ0Q7Ozs2QkFFbUI7QUFBQTs7QUFDbEIsMEJBQ0UscUVBQUMsdURBQUQ7QUFDRSxjQUFNLEVBQUUsZ0JBQUNDLGFBQUQsRUFBbUI7QUFDekIsbUJBRHlCLENBRXpCOztBQUNBLGNBQU1DLE1BQU0sR0FBRyxJQUFJQyxVQUFKLEVBQWY7O0FBQ0FELGdCQUFNLENBQUNFLE1BQVAsR0FBZ0IsWUFBTTtBQUNwQixnQkFBSTtBQUNGO0FBQ0Esa0JBQU1DLElBQUksR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdMLE1BQU0sQ0FBQ00sTUFBbEIsQ0FBYjs7QUFDQSxvQkFBSSxDQUFDaEIsdUJBQUwsQ0FBNkJhLElBQTdCO0FBQ0QsYUFKRCxDQUlFLE9BQU9JLENBQVAsRUFBVTtBQUNWLG9CQUFJLENBQUNmLGVBQUw7QUFDRDtBQUNGLFdBUkQ7O0FBU0EsY0FBSU8sYUFBYSxJQUFJQSxhQUFhLENBQUNTLE1BQS9CLElBQXlDVCxhQUFhLENBQUNTLE1BQWQsR0FBdUIsQ0FBcEUsRUFDRVQsYUFBYSxDQUFDVSxHQUFkLENBQWtCLFVBQUNDLENBQUQ7QUFBQSxtQkFBT1YsTUFBTSxDQUFDVyxVQUFQLENBQWtCRCxDQUFsQixDQUFQO0FBQUEsV0FBbEI7QUFDSCxTQWhCSDtBQUFBLGtCQWtCRztBQUFBLGNBQUdFLFlBQUgsUUFBR0EsWUFBSDtBQUFBLGNBQWlCQyxhQUFqQixRQUFpQkEsYUFBakI7QUFBQSxjQUFnQ0MsWUFBaEMsUUFBZ0NBLFlBQWhDO0FBQUEsOEJBQ0MsNEdBQVNGLFlBQVksRUFBckI7QUFBeUIsY0FBRSxFQUFDLHNCQUE1QjtBQUFBLG9DQUNFLGdHQUFXQyxhQUFhLEVBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFFRSxxRUFBQyw2RkFBRDtBQUNFLHVCQUFTLEVBQUUsTUFBSSxDQUFDekIsS0FBTCxDQUFXQyxTQUR4QjtBQUVFLHVCQUFTLEVBQUUsTUFBSSxDQUFDRixLQUFMLENBQVc0QixTQUZ4QjtBQUdFLGdDQUFrQixFQUFFLE1BQUksQ0FBQzVCLEtBQUwsQ0FBVzZCLGtCQUhqQztBQUlFLDhDQUFnQyxFQUFFLE1BQUksQ0FBQzdCLEtBQUwsQ0FBVzhCLGdDQUovQztBQUtFLHVCQUFTLEVBQUUsTUFBSSxDQUFDbkIsU0FBTCxDQUFlUCxJQUFmLENBQW9CLE1BQXBCLENBTGI7QUFNRSxtQkFBSyxFQUFFdUI7QUFOVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERDtBQUFBO0FBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERjtBQWtDRDs7OztFQXBFK0JJLCtDOztBQXVFM0IsSUFBTUMsNEJBQTRCLEdBQUdDLDREQUFPLENBQ2pELFVBQUNDLEtBQUQ7QUFBQSxTQUF1QjtBQUNyQkosb0NBQWdDLEVBQUVLLG9HQUEyQixDQUFDRCxLQUFELENBRHhDO0FBRXJCTixhQUFTLEVBQUVRLHFGQUFZLENBQUNGLEtBQUQsQ0FGRjtBQUdyQkwsc0JBQWtCLEVBQUVRLDhGQUFxQixDQUFDSCxLQUFEO0FBSHBCLEdBQXZCO0FBQUEsQ0FEaUQsRUFNakQsVUFBQ0ksUUFBRDtBQUFBLFNBQWU7QUFDYjVCLHFCQUFpQixFQUFFLDJCQUFDNkIsT0FBRDtBQUFBLGFBQTBERCxRQUFRLENBQUM1Qix3RkFBaUIsQ0FBQzZCLE9BQUQsQ0FBbEIsQ0FBbEU7QUFBQSxLQUROO0FBRWI1QixhQUFTLEVBQUU7QUFBQSxhQUFNMkIsUUFBUSxDQUFDRSw0RkFBcUIsRUFBdEIsQ0FBZDtBQUFBO0FBRkUsR0FBZjtBQUFBLENBTmlELENBQVAsQ0FVMUN6QyxtQkFWMEMsQ0FBckMiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZjhkNTQ3MDNiYWRhM2U3MWU0NmYuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFZlcmlmaWNhdGlvbkZyYWdtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb2EtdmVyaWZ5XCI7XG5pbXBvcnQgeyB2MiwgV3JhcHBlZERvY3VtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3Blbi1hdHRlc3RhdGlvblwiO1xuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IERyb3B6b25lIGZyb20gXCJyZWFjdC1kcm9wem9uZVwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0IHsgUm9vdFN0YXRlIH0gZnJvbSBcIi4uLy4uL3JlZHVjZXJzXCI7XG5pbXBvcnQgeyByZXNldENlcnRpZmljYXRlU3RhdGUsIHVwZGF0ZUNlcnRpZmljYXRlIH0gZnJvbSBcIi4uLy4uL3JlZHVjZXJzL2NlcnRpZmljYXRlLmFjdGlvbnNcIjtcbmltcG9ydCB7IGdldENlcnRpZmljYXRlQnlBY3Rpb25FcnJvciwgZ2V0VmVyaWZpY2F0aW9uU3RhdHVzLCBnZXRWZXJpZnlpbmcgfSBmcm9tIFwiLi4vLi4vcmVkdWNlcnMvY2VydGlmaWNhdGUuc2VsZWN0b3JzXCI7XG5pbXBvcnQgeyBDZXJ0aWZpY2F0ZVZlcmlmaWNhdGlvblN0YXR1cyB9IGZyb20gXCIuL0NlcnRpZmljYXRlVmVyaWZpY2F0aW9uU3RhdHVzXCI7XG5cbmludGVyZmFjZSBDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyUHJvcHMge1xuICBcbiAgdXBkYXRlQ2VydGlmaWNhdGU6IChjZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PikgPT4gdm9pZDtcbiAgcmVzZXREYXRhOiAoKSA9PiB2b2lkO1xuICB2ZXJpZnlpbmc6IGJvb2xlYW47XG4gIHZlcmlmaWNhdGlvblN0YXR1czogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXSB8IG51bGw7XG4gIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yOiBzdHJpbmcgfCBudWxsO1xufVxuaW50ZXJmYWNlIENlcnRpZmljYXRlRHJvcFpvbmVDb250YWluZXJTdGF0ZSB7XG4gIGZpbGVFcnJvcjogYm9vbGVhbjtcbn1cblxuY2xhc3MgQ2VydGlmaWNhdGVEcm9wWm9uZSBleHRlbmRzIENvbXBvbmVudDxDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyUHJvcHMsIENlcnRpZmljYXRlRHJvcFpvbmVDb250YWluZXJTdGF0ZT4ge1xuICBjb25zdHJ1Y3Rvcihwcm9wczogQ2VydGlmaWNhdGVEcm9wWm9uZUNvbnRhaW5lclByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpO1xuXG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGZpbGVFcnJvcjogZmFsc2UsXG4gICAgfTtcbiAgICB0aGlzLmhhbmRsZUNlcnRpZmljYXRlQ2hhbmdlID0gdGhpcy5oYW5kbGVDZXJ0aWZpY2F0ZUNoYW5nZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMuaGFuZGxlRmlsZUVycm9yID0gdGhpcy5oYW5kbGVGaWxlRXJyb3IuYmluZCh0aGlzKTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjbGFzcy1tZXRob2RzLXVzZS10aGlzXG4gIGNvbXBvbmVudERpZE1vdW50KCk6IHZvaWQge1xuICAgIGRlYnVnZ2VyXG4gICAgUm91dGVyLnByZWZldGNoKFwiL3ZpZXdlclwiKTtcbiAgfVxuXG4gIC8vIHRoaXMgaXMgd2hlcmUgdGhlIEpTT04gaXMgcGFzc2VkIGZyb20gdGhlIGZpbGUgd2UgdXBsb2FkXG4gIGhhbmRsZUNlcnRpZmljYXRlQ2hhbmdlKGNlcnRpZmljYXRlOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+KTogdm9pZCB7XG4gICAgZGVidWdnZXJcbiAgICB0aGlzLnNldFN0YXRlKHsgZmlsZUVycm9yOiBmYWxzZSB9KTtcbiAgICB0aGlzLnByb3BzLnVwZGF0ZUNlcnRpZmljYXRlKGNlcnRpZmljYXRlKTtcbiAgfVxuXG4gIGhhbmRsZUZpbGVFcnJvcigpOiB2b2lkIHtcbiAgICBkZWJ1Z2dlclxuICAgIHRoaXMuc2V0U3RhdGUoeyBmaWxlRXJyb3I6IHRydWUgfSk7XG4gIH1cblxuICByZXNldERhdGEoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wcy5yZXNldERhdGEoKTtcbiAgfVxuXG4gIHJlbmRlcigpOiBSZWFjdE5vZGUge1xuICAgIHJldHVybiAoXG4gICAgICA8RHJvcHpvbmVcbiAgICAgICAgb25Ecm9wPXsoYWNjZXB0ZWRGaWxlcykgPT4ge1xuICAgICAgICAgIGRlYnVnZ2VyXG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgLy8gVE9ETyBlbmhhbmNlIHRoaXNcbiAgICAgICAgICAgICAgY29uc3QganNvbiA9IEpTT04ucGFyc2UocmVhZGVyLnJlc3VsdCBhcyBzdHJpbmcpO1xuICAgICAgICAgICAgICB0aGlzLmhhbmRsZUNlcnRpZmljYXRlQ2hhbmdlKGpzb24pO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICB0aGlzLmhhbmRsZUZpbGVFcnJvcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKGFjY2VwdGVkRmlsZXMgJiYgYWNjZXB0ZWRGaWxlcy5sZW5ndGggJiYgYWNjZXB0ZWRGaWxlcy5sZW5ndGggPiAwKVxuICAgICAgICAgICAgYWNjZXB0ZWRGaWxlcy5tYXAoKGYpID0+IHJlYWRlci5yZWFkQXNUZXh0KGYpKTtcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgeyh7IGdldFJvb3RQcm9wcywgZ2V0SW5wdXRQcm9wcywgaXNEcmFnQWNjZXB0IH0pID0+IChcbiAgICAgICAgICA8ZGl2IHsuLi5nZXRSb290UHJvcHMoKX0gaWQ9XCJjZXJ0aWZpY2F0ZS1kcm9wem9uZVwiPlxuICAgICAgICAgICAgPGlucHV0IHsuLi5nZXRJbnB1dFByb3BzKCl9IC8+XG4gICAgICAgICAgICA8Q2VydGlmaWNhdGVWZXJpZmljYXRpb25TdGF0dXNcbiAgICAgICAgICAgICAgZmlsZUVycm9yPXt0aGlzLnN0YXRlLmZpbGVFcnJvcn1cbiAgICAgICAgICAgICAgdmVyaWZ5aW5nPXt0aGlzLnByb3BzLnZlcmlmeWluZ31cbiAgICAgICAgICAgICAgdmVyaWZpY2F0aW9uU3RhdHVzPXt0aGlzLnByb3BzLnZlcmlmaWNhdGlvblN0YXR1c31cbiAgICAgICAgICAgICAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3I9e3RoaXMucHJvcHMucmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3J9XG4gICAgICAgICAgICAgIHJlc2V0RGF0YT17dGhpcy5yZXNldERhdGEuYmluZCh0aGlzKX1cbiAgICAgICAgICAgICAgaG92ZXI9e2lzRHJhZ0FjY2VwdH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0Ryb3B6b25lPlxuICAgICk7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IENlcnRpZmljYXRlRHJvcFpvbmVDb250YWluZXIgPSBjb25uZWN0KFxuICAoc3RvcmU6IFJvb3RTdGF0ZSkgPT4gKHtcbiAgICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25FcnJvcjogZ2V0Q2VydGlmaWNhdGVCeUFjdGlvbkVycm9yKHN0b3JlKSxcbiAgICB2ZXJpZnlpbmc6IGdldFZlcmlmeWluZyhzdG9yZSksXG4gICAgdmVyaWZpY2F0aW9uU3RhdHVzOiBnZXRWZXJpZmljYXRpb25TdGF0dXMoc3RvcmUpLFxuICB9KSxcbiAgKGRpc3BhdGNoKSA9PiAoe1xuICAgIHVwZGF0ZUNlcnRpZmljYXRlOiAocGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PikgPT4gZGlzcGF0Y2godXBkYXRlQ2VydGlmaWNhdGUocGF5bG9hZCkpLFxuICAgIHJlc2V0RGF0YTogKCkgPT4gZGlzcGF0Y2gocmVzZXRDZXJ0aWZpY2F0ZVN0YXRlKCkpLFxuICB9KVxuKShDZXJ0aWZpY2F0ZURyb3Bab25lKTtcbiJdLCJzb3VyY2VSb290IjoiIn0=