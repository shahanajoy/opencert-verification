webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/HomePageContent/DropZoneSection.tsx":
/*!************************************************************!*\
  !*** ./src/components/HomePageContent/DropZoneSection.tsx ***!
  \************************************************************/
/*! exports provided: DropZoneSectionContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DropZoneSectionContainer", function() { return DropZoneSectionContainer; });
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");
/* harmony import */ var _reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../reducers/certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _Analytics__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Analytics */ "./src/components/Analytics/index.ts");
/* harmony import */ var _CertificateDropZone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../CertificateDropZone */ "./src/components/CertificateDropZone/index.ts");








var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\HomePageContent\\DropZoneSection.tsx",
    _this = undefined;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }







var DEMO_CERT = "/static/demo/".concat(_config__WEBPACK_IMPORTED_MODULE_9__["NETWORK_NAME"], ".opencert");

function demoCount() {
  Object(_Analytics__WEBPACK_IMPORTED_MODULE_11__["analyticsEvent"])(window, {
    category: "USER_INTERACTION",
    action: "DEMO_CERTIFICATE_VIEWED"
  });
}

var DraggableDemoCertificate = function DraggableDemoCertificate() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
    className: "hidden lg:block",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
      className: "flex flex-wrap py-12",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
        className: "w-1/2 lg:pr-8",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "animate-pulsing",
          draggable: "true",
          onDragStart: function onDragStart(e) {
            return e.dataTransfer.setData(DEMO_CERT, "true");
          },
          onDragEnd: demoCount,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("a", {
            href: DEMO_CERT,
            className: "cursor-grab",
            download: "demo.opencert",
            rel: "noindex nofollow",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
              src: "/static/images/dropzone/cert.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 7
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
        className: "w-1/2",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
          src: "/static/images/dropzone/arrow.png",
          draggable: "false"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("p", {
          className: "text-orange mb-2",
          children: "Drag me over here to see a demo certificate and other features"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
          src: "/static/images/opencertslogo.svg",
          draggable: "false"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 3
  }, _this);
};

_c = DraggableDemoCertificate;

var MobileDemoCertificate = function MobileDemoCertificate() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("button", {
    className: "button bg-green hover:bg-green-300 mx-auto my-8 block lg:hidden",
    role: "button",
    draggable: "false",
    id: "demoClick",
    onClick: demoCount,
    children: "Click me for a demo certificate!"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 43,
    columnNumber: 3
  }, _this);
};

_c2 = MobileDemoCertificate;

var DropZoneSection = /*#__PURE__*/function (_Component) {
  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__["default"])(DropZoneSection, _Component);

  var _super = _createSuper(DropZoneSection);

  function DropZoneSection(props) {
    var _this2;

    Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DropZoneSection);

    _this2 = _super.call(this, props);
    _this2.handleDrop = _this2.handleDrop.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__["default"])(_this2));
    _this2.handleClick = _this2.handleClick.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__["default"])(_this2));
    return _this2;
  }

  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(DropZoneSection, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var elementDrop = document.getElementById("demoDrop");

      if (elementDrop) {
        elementDrop.addEventListener("drop", this.handleDrop);
      }

      var elementClick = document.getElementById("demoClick");

      if (elementClick) {
        elementClick.addEventListener("click", this.handleClick);
      }
    }
  }, {
    key: "handleDrop",
    value: function handleDrop(event) {
      var _this3 = this;

      if (event.dataTransfer && event.dataTransfer.getData(DEMO_CERT)) {
        window.fetch(DEMO_CERT).then(function (res) {
          return res.json();
        }).then(function (res) {
          _this3.props.updateCertificate(res);
        });
      }
    }
  }, {
    key: "handleClick",
    value: function handleClick() {
      var _this4 = this;

      window.fetch(DEMO_CERT).then(function (res) {
        return res.json();
      }).then(function (res) {
        _this4.props.updateCertificate(res);
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      var elementDrop = document.getElementById("demoDrop");

      if (elementDrop) {
        elementDrop.removeEventListener("drop", this.handleDrop);
      }

      var elementClick = document.getElementById("demoClick");

      if (elementClick) {
        elementClick.removeEventListener("click", this.handleClick);
      }
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("section", {
        className: "bg-navy text-white py-12",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "container",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            className: "flex flex-wrap",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              className: "w-full lg:w-2/3 lg:pl-10",
              id: "demoDrop",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(_CertificateDropZone__WEBPACK_IMPORTED_MODULE_12__["CertificateDropZoneContainer"], {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 118,
                columnNumber: 15
              }, this), "rar"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 117,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 7
      }, this);
    }
  }]);

  return DropZoneSection;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

var DropZoneSectionContainer = Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(null, function (dispatch) {
  return {
    updateCertificate: function updateCertificate(payload) {
      return dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_10__["updateCertificate"])(payload));
    }
  };
})(DropZoneSection);

var _c, _c2;

$RefreshReg$(_c, "DraggableDemoCertificate");
$RefreshReg$(_c2, "MobileDemoCertificate");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvSG9tZVBhZ2VDb250ZW50L0Ryb3Bab25lU2VjdGlvbi50c3giXSwibmFtZXMiOlsiREVNT19DRVJUIiwiTkVUV09SS19OQU1FIiwiZGVtb0NvdW50IiwiYW5hbHl0aWNzRXZlbnQiLCJ3aW5kb3ciLCJjYXRlZ29yeSIsImFjdGlvbiIsIkRyYWdnYWJsZURlbW9DZXJ0aWZpY2F0ZSIsImUiLCJkYXRhVHJhbnNmZXIiLCJzZXREYXRhIiwiTW9iaWxlRGVtb0NlcnRpZmljYXRlIiwiRHJvcFpvbmVTZWN0aW9uIiwicHJvcHMiLCJoYW5kbGVEcm9wIiwiYmluZCIsImhhbmRsZUNsaWNrIiwiZWxlbWVudERyb3AiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiYWRkRXZlbnRMaXN0ZW5lciIsImVsZW1lbnRDbGljayIsImV2ZW50IiwiZ2V0RGF0YSIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJ1cGRhdGVDZXJ0aWZpY2F0ZSIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJDb21wb25lbnQiLCJEcm9wWm9uZVNlY3Rpb25Db250YWluZXIiLCJjb25uZWN0IiwiZGlzcGF0Y2giLCJwYXlsb2FkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxJQUFNQSxTQUFTLDBCQUFtQkMsb0RBQW5CLGNBQWY7O0FBRUEsU0FBU0MsU0FBVCxHQUEyQjtBQUN6QkMsb0VBQWMsQ0FBQ0MsTUFBRCxFQUFTO0FBQ3JCQyxZQUFRLEVBQUUsa0JBRFc7QUFFckJDLFVBQU0sRUFBRTtBQUZhLEdBQVQsQ0FBZDtBQUlEOztBQUVELElBQU1DLHdCQUFpRCxHQUFHLFNBQXBEQSx3QkFBb0Q7QUFBQSxzQkFDeEQ7QUFBSyxhQUFTLEVBQUMsaUJBQWY7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxzQkFBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxlQUFmO0FBQUEsK0JBQ0U7QUFDRSxtQkFBUyxFQUFDLGlCQURaO0FBRUUsbUJBQVMsRUFBQyxNQUZaO0FBR0UscUJBQVcsRUFBRSxxQkFBQ0MsQ0FBRDtBQUFBLG1CQUFPQSxDQUFDLENBQUNDLFlBQUYsQ0FBZUMsT0FBZixDQUF1QlYsU0FBdkIsRUFBa0MsTUFBbEMsQ0FBUDtBQUFBLFdBSGY7QUFJRSxtQkFBUyxFQUFFRSxTQUpiO0FBQUEsaUNBTUU7QUFBRyxnQkFBSSxFQUFFRixTQUFUO0FBQW9CLHFCQUFTLEVBQUMsYUFBOUI7QUFBNEMsb0JBQVEsRUFBQyxlQUFyRDtBQUFxRSxlQUFHLEVBQUMsa0JBQXpFO0FBQUEsbUNBQ0U7QUFBSyxpQkFBRyxFQUFDO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBYUU7QUFBSyxpQkFBUyxFQUFDLE9BQWY7QUFBQSxnQ0FDRTtBQUFLLGFBQUcsRUFBQyxtQ0FBVDtBQUE2QyxtQkFBUyxFQUFDO0FBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUFHLG1CQUFTLEVBQUMsa0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkYsZUFHRTtBQUFLLGFBQUcsRUFBQyxrQ0FBVDtBQUE0QyxtQkFBUyxFQUFDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUR3RDtBQUFBLENBQTFEOztLQUFNTyx3Qjs7QUF3Qk4sSUFBTUkscUJBQThDLEdBQUcsU0FBakRBLHFCQUFpRDtBQUFBLHNCQUNyRDtBQUNFLGFBQVMsRUFBQyxpRUFEWjtBQUVFLFFBQUksRUFBQyxRQUZQO0FBR0UsYUFBUyxFQUFDLE9BSFo7QUFJRSxNQUFFLEVBQUMsV0FKTDtBQUtFLFdBQU8sRUFBRVQsU0FMWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURxRDtBQUFBLENBQXZEOztNQUFNUyxxQjs7SUFlQUMsZTs7Ozs7QUFDSiwyQkFBWUMsS0FBWixFQUF5QztBQUFBOztBQUFBOztBQUN2QywrQkFBTUEsS0FBTjtBQUNBLFdBQUtDLFVBQUwsR0FBa0IsT0FBS0EsVUFBTCxDQUFnQkMsSUFBaEIsdU5BQWxCO0FBQ0EsV0FBS0MsV0FBTCxHQUFtQixPQUFLQSxXQUFMLENBQWlCRCxJQUFqQix1TkFBbkI7QUFIdUM7QUFJeEM7Ozs7d0NBQ3lCO0FBQ3hCLFVBQU1FLFdBQVcsR0FBR0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLFVBQXhCLENBQXBCOztBQUNBLFVBQUlGLFdBQUosRUFBaUI7QUFDZkEsbUJBQVcsQ0FBQ0csZ0JBQVosQ0FBNkIsTUFBN0IsRUFBcUMsS0FBS04sVUFBMUM7QUFDRDs7QUFDRCxVQUFNTyxZQUFZLEdBQUdILFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixXQUF4QixDQUFyQjs7QUFDQSxVQUFJRSxZQUFKLEVBQWtCO0FBQ2hCQSxvQkFBWSxDQUFDRCxnQkFBYixDQUE4QixPQUE5QixFQUF1QyxLQUFLSixXQUE1QztBQUNEO0FBQ0Y7OzsrQkFDVU0sSyxFQUF3QjtBQUFBOztBQUNqQyxVQUFJQSxLQUFLLENBQUNiLFlBQU4sSUFBc0JhLEtBQUssQ0FBQ2IsWUFBTixDQUFtQmMsT0FBbkIsQ0FBMkJ2QixTQUEzQixDQUExQixFQUFpRTtBQUMvREksY0FBTSxDQUNIb0IsS0FESCxDQUNTeEIsU0FEVCxFQUVHeUIsSUFGSCxDQUVRLFVBQUNDLEdBQUQ7QUFBQSxpQkFBU0EsR0FBRyxDQUFDQyxJQUFKLEVBQVQ7QUFBQSxTQUZSLEVBR0dGLElBSEgsQ0FHUSxVQUFDQyxHQUFELEVBQVM7QUFDYixnQkFBSSxDQUFDYixLQUFMLENBQVdlLGlCQUFYLENBQTZCRixHQUE3QjtBQUNELFNBTEg7QUFNRDtBQUNGOzs7a0NBQ21CO0FBQUE7O0FBQ2xCdEIsWUFBTSxDQUNIb0IsS0FESCxDQUNTeEIsU0FEVCxFQUVHeUIsSUFGSCxDQUVRLFVBQUNDLEdBQUQ7QUFBQSxlQUFTQSxHQUFHLENBQUNDLElBQUosRUFBVDtBQUFBLE9BRlIsRUFHR0YsSUFISCxDQUdRLFVBQUNDLEdBQUQsRUFBUztBQUNiLGNBQUksQ0FBQ2IsS0FBTCxDQUFXZSxpQkFBWCxDQUE2QkYsR0FBN0I7QUFDRCxPQUxIO0FBTUQ7OzsyQ0FFNEI7QUFDM0IsVUFBTVQsV0FBVyxHQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsVUFBeEIsQ0FBcEI7O0FBQ0EsVUFBSUYsV0FBSixFQUFpQjtBQUNmQSxtQkFBVyxDQUFDWSxtQkFBWixDQUFnQyxNQUFoQyxFQUF3QyxLQUFLZixVQUE3QztBQUNEOztBQUNELFVBQU1PLFlBQVksR0FBR0gsUUFBUSxDQUFDQyxjQUFULENBQXdCLFdBQXhCLENBQXJCOztBQUNBLFVBQUlFLFlBQUosRUFBa0I7QUFDaEJBLG9CQUFZLENBQUNRLG1CQUFiLENBQWlDLE9BQWpDLEVBQTBDLEtBQUtiLFdBQS9DO0FBQ0Q7QUFDRjs7OzZCQUVtQjtBQUNsQiwwQkFDRTtBQUFTLGlCQUFTLEVBQUMsMEJBQW5CO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsZ0JBQWY7QUFBQSxtQ0FVRTtBQUFLLHVCQUFTLEVBQUMsMEJBQWY7QUFBMEMsZ0JBQUUsRUFBQyxVQUE3QztBQUFBLHNDQUNFLHFFQUFDLGtGQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUFxQkQ7Ozs7RUFwRTJCYywrQzs7QUF1RXZCLElBQU1DLHdCQUF3QixHQUFHQywyREFBTyxDQUFDLElBQUQsRUFBTyxVQUFDQyxRQUFEO0FBQUEsU0FBZTtBQUNuRUwscUJBQWlCLEVBQUUsMkJBQUNNLE9BQUQ7QUFBQSxhQUEwREQsUUFBUSxDQUFDTCx3RkFBaUIsQ0FBQ00sT0FBRCxDQUFsQixDQUFsRTtBQUFBO0FBRGdELEdBQWY7QUFBQSxDQUFQLENBQVAsQ0FFcEN0QixlQUZvQyxDQUFqQyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5jOWI3MjQ0OTZjYmEzN2FhYzQ4YS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0IHsgTkVUV09SS19OQU1FIH0gZnJvbSBcIi4uLy4uL2NvbmZpZ1wiO1xuaW1wb3J0IHsgdXBkYXRlQ2VydGlmaWNhdGUgfSBmcm9tIFwiLi4vLi4vcmVkdWNlcnMvY2VydGlmaWNhdGUuYWN0aW9uc1wiO1xuaW1wb3J0IHsgYW5hbHl0aWNzRXZlbnQgfSBmcm9tIFwiLi4vQW5hbHl0aWNzXCI7XG5pbXBvcnQgeyBDZXJ0aWZpY2F0ZURyb3Bab25lQ29udGFpbmVyIH0gZnJvbSBcIi4uL0NlcnRpZmljYXRlRHJvcFpvbmVcIjtcblxuY29uc3QgREVNT19DRVJUID0gYC9zdGF0aWMvZGVtby8ke05FVFdPUktfTkFNRX0ub3BlbmNlcnRgO1xuXG5mdW5jdGlvbiBkZW1vQ291bnQoKTogdm9pZCB7XG4gIGFuYWx5dGljc0V2ZW50KHdpbmRvdywge1xuICAgIGNhdGVnb3J5OiBcIlVTRVJfSU5URVJBQ1RJT05cIixcbiAgICBhY3Rpb246IFwiREVNT19DRVJUSUZJQ0FURV9WSUVXRURcIixcbiAgfSk7XG59XG5cbmNvbnN0IERyYWdnYWJsZURlbW9DZXJ0aWZpY2F0ZTogUmVhY3QuRnVuY3Rpb25Db21wb25lbnQgPSAoKSA9PiAoXG4gIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmJsb2NrXCI+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBweS0xMlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMiBsZzpwci04XCI+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLXB1bHNpbmdcIlxuICAgICAgICAgIGRyYWdnYWJsZT1cInRydWVcIlxuICAgICAgICAgIG9uRHJhZ1N0YXJ0PXsoZSkgPT4gZS5kYXRhVHJhbnNmZXIuc2V0RGF0YShERU1PX0NFUlQsIFwidHJ1ZVwiKX1cbiAgICAgICAgICBvbkRyYWdFbmQ9e2RlbW9Db3VudH1cbiAgICAgICAgPlxuICAgICAgICAgIDxhIGhyZWY9e0RFTU9fQ0VSVH0gY2xhc3NOYW1lPVwiY3Vyc29yLWdyYWJcIiBkb3dubG9hZD1cImRlbW8ub3BlbmNlcnRcIiByZWw9XCJub2luZGV4IG5vZm9sbG93XCI+XG4gICAgICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvaW1hZ2VzL2Ryb3B6b25lL2NlcnQucG5nXCIgLz5cbiAgICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XG4gICAgICAgIDxpbWcgc3JjPVwiL3N0YXRpYy9pbWFnZXMvZHJvcHpvbmUvYXJyb3cucG5nXCIgZHJhZ2dhYmxlPVwiZmFsc2VcIiAvPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZSBtYi0yXCI+RHJhZyBtZSBvdmVyIGhlcmUgdG8gc2VlIGEgZGVtbyBjZXJ0aWZpY2F0ZSBhbmQgb3RoZXIgZmVhdHVyZXM8L3A+XG4gICAgICAgIDxpbWcgc3JjPVwiL3N0YXRpYy9pbWFnZXMvb3BlbmNlcnRzbG9nby5zdmdcIiBkcmFnZ2FibGU9XCJmYWxzZVwiIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG4pO1xuXG5jb25zdCBNb2JpbGVEZW1vQ2VydGlmaWNhdGU6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50ID0gKCkgPT4gKFxuICA8YnV0dG9uXG4gICAgY2xhc3NOYW1lPVwiYnV0dG9uIGJnLWdyZWVuIGhvdmVyOmJnLWdyZWVuLTMwMCBteC1hdXRvIG15LTggYmxvY2sgbGc6aGlkZGVuXCJcbiAgICByb2xlPVwiYnV0dG9uXCJcbiAgICBkcmFnZ2FibGU9XCJmYWxzZVwiXG4gICAgaWQ9XCJkZW1vQ2xpY2tcIlxuICAgIG9uQ2xpY2s9e2RlbW9Db3VudH1cbiAgPlxuICAgIENsaWNrIG1lIGZvciBhIGRlbW8gY2VydGlmaWNhdGUhXG4gIDwvYnV0dG9uPlxuKTtcblxuaW50ZXJmYWNlIERyb3Bab25lU2VjdGlvblByb3BzIHtcbiAgdXBkYXRlQ2VydGlmaWNhdGU6IChjZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PikgPT4gdm9pZDtcbn1cbmNsYXNzIERyb3Bab25lU2VjdGlvbiBleHRlbmRzIENvbXBvbmVudDxEcm9wWm9uZVNlY3Rpb25Qcm9wcz4ge1xuICBjb25zdHJ1Y3Rvcihwcm9wczogRHJvcFpvbmVTZWN0aW9uUHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5oYW5kbGVEcm9wID0gdGhpcy5oYW5kbGVEcm9wLmJpbmQodGhpcyk7XG4gICAgdGhpcy5oYW5kbGVDbGljayA9IHRoaXMuaGFuZGxlQ2xpY2suYmluZCh0aGlzKTtcbiAgfVxuICBjb21wb25lbnREaWRNb3VudCgpOiB2b2lkIHtcbiAgICBjb25zdCBlbGVtZW50RHJvcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGVtb0Ryb3BcIik7XG4gICAgaWYgKGVsZW1lbnREcm9wKSB7XG4gICAgICBlbGVtZW50RHJvcC5hZGRFdmVudExpc3RlbmVyKFwiZHJvcFwiLCB0aGlzLmhhbmRsZURyb3ApO1xuICAgIH1cbiAgICBjb25zdCBlbGVtZW50Q2xpY2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRlbW9DbGlja1wiKTtcbiAgICBpZiAoZWxlbWVudENsaWNrKSB7XG4gICAgICBlbGVtZW50Q2xpY2suYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRoaXMuaGFuZGxlQ2xpY2spO1xuICAgIH1cbiAgfVxuICBoYW5kbGVEcm9wKGV2ZW50OiBEcmFnRXZlbnQpOiB2b2lkIHtcbiAgICBpZiAoZXZlbnQuZGF0YVRyYW5zZmVyICYmIGV2ZW50LmRhdGFUcmFuc2Zlci5nZXREYXRhKERFTU9fQ0VSVCkpIHtcbiAgICAgIHdpbmRvd1xuICAgICAgICAuZmV0Y2goREVNT19DRVJUKVxuICAgICAgICAudGhlbigocmVzKSA9PiByZXMuanNvbigpKVxuICAgICAgICAudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgdGhpcy5wcm9wcy51cGRhdGVDZXJ0aWZpY2F0ZShyZXMpO1xuICAgICAgICB9KTtcbiAgICB9XG4gIH1cbiAgaGFuZGxlQ2xpY2soKTogdm9pZCB7XG4gICAgd2luZG93XG4gICAgICAuZmV0Y2goREVNT19DRVJUKVxuICAgICAgLnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcbiAgICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgICAgdGhpcy5wcm9wcy51cGRhdGVDZXJ0aWZpY2F0ZShyZXMpO1xuICAgICAgfSk7XG4gIH1cblxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpOiB2b2lkIHtcbiAgICBjb25zdCBlbGVtZW50RHJvcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGVtb0Ryb3BcIik7XG4gICAgaWYgKGVsZW1lbnREcm9wKSB7XG4gICAgICBlbGVtZW50RHJvcC5yZW1vdmVFdmVudExpc3RlbmVyKFwiZHJvcFwiLCB0aGlzLmhhbmRsZURyb3ApO1xuICAgIH1cbiAgICBjb25zdCBlbGVtZW50Q2xpY2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRlbW9DbGlja1wiKTtcbiAgICBpZiAoZWxlbWVudENsaWNrKSB7XG4gICAgICBlbGVtZW50Q2xpY2sucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRoaXMuaGFuZGxlQ2xpY2spO1xuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpOiBSZWFjdE5vZGUge1xuICAgIHJldHVybiAoXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy1uYXZ5IHRleHQtd2hpdGUgcHktMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwXCI+XG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6dy0xLzMgbGc6cHItMTAgdGV4dC1jZW50ZXIgbGc6dGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LW1vbnRzZXJyYXQgbWItNVwiPkFuIGVhc3kgd2F5IHRvIGNoZWNrIGFuZCB2ZXJpZnkgeW91ciBjZXJ0aWZpY2F0ZXM8L2gxPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICBXaGV0aGVyIHlvdSYjMzk7cmUgYSBzdHVkZW50IG9yIGFuIGVtcGxveWVyLCBPcGVuQ2VydHMgbGV0cyB5b3UgdmVyaWZ5IHRoZSBjZXJ0aWZpY2F0ZXMgeW91IGhhdmUgb2ZcbiAgICAgICAgICAgICAgICBhbnlvbmUgZnJvbSBhbnkgaW5zdGl0dXRpb24uIEFsbCBpbiBvbmUgcGxhY2UuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPERyYWdnYWJsZURlbW9DZXJ0aWZpY2F0ZSAvPlxuICAgICAgICAgICAgICA8TW9iaWxlRGVtb0NlcnRpZmljYXRlIC8+XG4gICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBsZzp3LTIvMyBsZzpwbC0xMFwiIGlkPVwiZGVtb0Ryb3BcIj5cbiAgICAgICAgICAgICAgPENlcnRpZmljYXRlRHJvcFpvbmVDb250YWluZXIgLz5cbiAgICAgICAgICAgICAgcmFyXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgKTtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgRHJvcFpvbmVTZWN0aW9uQ29udGFpbmVyID0gY29ubmVjdChudWxsLCAoZGlzcGF0Y2gpID0+ICh7XG4gIHVwZGF0ZUNlcnRpZmljYXRlOiAocGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PikgPT4gZGlzcGF0Y2godXBkYXRlQ2VydGlmaWNhdGUocGF5bG9hZCkpLFxufSkpKERyb3Bab25lU2VjdGlvbik7XG4iXSwic291cmNlUm9vdCI6IiJ9