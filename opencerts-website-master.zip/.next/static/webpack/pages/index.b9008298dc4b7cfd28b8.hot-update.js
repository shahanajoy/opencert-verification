webpackHotUpdate_N_E("pages/index",{

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "./node_modules/next/dist/next-server/lib/runtime-config.js");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;




var _getLogger = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"),
    trace = _getLogger.trace; // https://github.com/vercel/next.js/issues/7713


var _getConfig = next_config__WEBPACK_IMPORTED_MODULE_0___default()(),
    _getConfig$publicRunt = _getConfig.publicRuntimeConfig,
    publicRuntimeConfig = _getConfig$publicRunt === void 0 ? {} : _getConfig$publicRunt;

var URL = "https://opencerts.io";
var API_MAIN_URL = "https://api.opencerts.io";
var API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
var API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
var GA_PRODUCTION_ID = "UA-130492260-1";
var GA_DEVELOPMENT_ID = "UA-130492260-2";
var IS_MAINNET = publicRuntimeConfig.network === "mainnet";
var NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

var GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
var CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

var getApiUrl = function getApiUrl(networkName) {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

var EMAIL_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/email");
var SHARE_LINK_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/storage");
var SHARE_LINK_TTL = 1209600;
var LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
var ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
var DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates 123",
  titleTemplate: "OpenCerts - %s",
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts 123 - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: "".concat(URL, "/static/images/opencerts.png"),
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace("NETWORK: ".concat(NETWORK_NAME));
trace("CAPTCHA_CLIENT_KEY: ".concat(CAPTCHA_CLIENT_KEY));
trace("EMAIL_API_URL: ".concat(EMAIL_API_URL));

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbmZpZy9pbmRleC50cyJdLCJuYW1lcyI6WyJnZXRMb2dnZXIiLCJ0cmFjZSIsImdldENvbmZpZyIsInB1YmxpY1J1bnRpbWVDb25maWciLCJVUkwiLCJBUElfTUFJTl9VUkwiLCJBUElfUk9QU1RFTl9VUkwiLCJBUElfUklOS0VCWV9VUkwiLCJHQV9QUk9EVUNUSU9OX0lEIiwiR0FfREVWRUxPUE1FTlRfSUQiLCJJU19NQUlOTkVUIiwibmV0d29yayIsIk5FVFdPUktfTkFNRSIsIkdBX0lEIiwiQ0FQVENIQV9DTElFTlRfS0VZIiwiZ2V0QXBpVXJsIiwibmV0d29ya05hbWUiLCJFTUFJTF9BUElfVVJMIiwiU0hBUkVfTElOS19BUElfVVJMIiwiU0hBUkVfTElOS19UVEwiLCJMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSIiwibGVnYWN5UmVuZGVyZXJVcmwiLCJFTlZJUk9OTUVOVCIsImNvbnRleHQiLCJERUZBVUxUX1NFTyIsInRpdGxlIiwidGl0bGVUZW1wbGF0ZSIsImRlc2NyaXB0aW9uIiwib3BlbkdyYXBoIiwidHlwZSIsInVybCIsImltYWdlcyIsIndpZHRoIiwiaGVpZ2h0IiwiYWx0IiwidHdpdHRlciIsImNhcmRUeXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOztpQkFFa0JBLCtEQUFTLENBQUMsUUFBRCxDO0lBQW5CQyxLLGNBQUFBLEssRUFDUjs7O2lCQUNxQ0Msa0RBQVMsRTt1Q0FBdENDLG1CO0lBQUFBLG1CLHNDQUFzQixFOztBQUV2QixJQUFNQyxHQUFHLEdBQUcsc0JBQVo7QUFDUCxJQUFNQyxZQUFZLEdBQUcsMEJBQXJCO0FBQ0EsSUFBTUMsZUFBZSxHQUFHLGtDQUF4QjtBQUNBLElBQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFFQSxJQUFNQyxnQkFBZ0IsR0FBRyxnQkFBekI7QUFDQSxJQUFNQyxpQkFBaUIsR0FBRyxnQkFBMUI7QUFFTyxJQUFNQyxVQUFVLEdBQUdQLG1CQUFtQixDQUFDUSxPQUFwQixLQUFnQyxTQUFuRDtBQUNBLElBQU1DLFlBQVksV0FBSUYsVUFBVSxHQUFHLFdBQUgsR0FBaUJQLG1CQUFtQixDQUFDUSxPQUFuRCx1Q0FBK0QsU0FBakYsQyxDQUE0Rjs7QUFFNUYsSUFBTUUsS0FBSyxHQUFHSCxVQUFVLEdBQUdGLGdCQUFILEdBQXNCQyxpQkFBOUM7QUFDQSxJQUFNSyxrQkFBa0IsR0FBRywwQ0FBM0I7O0FBRVAsSUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsV0FBRCxFQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1gsWUFBUCxDQUFqQyxLQUNLLElBQUlXLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPVCxlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLElBQU1XLGFBQWEsYUFBTUYsU0FBUyxDQUFDSCxZQUFELENBQWYsV0FBbkI7QUFDQSxJQUFNTSxrQkFBa0IsYUFBTUgsU0FBUyxDQUFDSCxZQUFELENBQWYsYUFBeEI7QUFDQSxJQUFNTyxjQUFjLEdBQUcsT0FBdkI7QUFFQSxJQUFNQyx5QkFBeUIsR0FBR2pCLG1CQUFtQixDQUFDa0IsaUJBQXBCLElBQXlDLDhCQUEzRTtBQUNBLElBQU1DLFdBQVcsR0FBR25CLG1CQUFtQixDQUFDb0IsT0FBcEIsS0FBZ0MsWUFBaEMsR0FBK0MsWUFBL0MsR0FBOEQsYUFBbEY7QUFFQSxJQUFNQyxXQUFXLEdBQUc7QUFDekJDLE9BQUssRUFBRSx1REFEa0I7QUFFekJDLGVBQWEsa0JBRlk7QUFHekJDLGFBQVcsRUFDVCxnSkFKdUI7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxRQUFJLEVBQUUsU0FERztBQUVUQyxPQUFHLEVBQUUxQixHQUZJO0FBR1RxQixTQUFLLEVBQUUsbUVBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRJLFVBQU0sRUFBRSxDQUNOO0FBQ0VELFNBQUcsWUFBSzFCLEdBQUwsaUNBREw7QUFFRTRCLFdBQUssRUFBRSxHQUZUO0FBR0VDLFlBQU0sRUFBRSxHQUhWO0FBSUVDLFNBQUcsRUFBRTtBQUpQLEtBRE07QUFOQyxHQUxjO0FBb0J6QkMsU0FBTyxFQUFFO0FBQ1BDLFlBQVEsRUFBRTtBQURIO0FBcEJnQixDQUFwQjtBQXlCUG5DLEtBQUssb0JBQWFXLFlBQWIsRUFBTDtBQUNBWCxLQUFLLCtCQUF3QmEsa0JBQXhCLEVBQUw7QUFDQWIsS0FBSywwQkFBbUJnQixhQUFuQixFQUFMIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmI5MDA4Mjk4ZGM0YjdjZmQyOGI4LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZ2V0Q29uZmlnIGZyb20gXCJuZXh0L2NvbmZpZ1wiO1xuaW1wb3J0IHsgZ2V0TG9nZ2VyIH0gZnJvbSBcIi4uL3V0aWxzL2xvZ2dlclwiO1xuXG5jb25zdCB7IHRyYWNlIH0gPSBnZXRMb2dnZXIoXCJjb25maWdcIik7XG4vLyBodHRwczovL2dpdGh1Yi5jb20vdmVyY2VsL25leHQuanMvaXNzdWVzLzc3MTNcbmNvbnN0IHsgcHVibGljUnVudGltZUNvbmZpZyA9IHt9IH0gPSBnZXRDb25maWcoKTtcblxuZXhwb3J0IGNvbnN0IFVSTCA9IFwiaHR0cHM6Ly9vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9NQUlOX1VSTCA9IFwiaHR0cHM6Ly9hcGkub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUk9QU1RFTl9VUkwgPSBcImh0dHBzOi8vYXBpLXJvcHN0ZW4ub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUklOS0VCWV9VUkwgPSBcImh0dHBzOi8vYXBpLXJpbmtlYnkub3BlbmNlcnRzLmlvXCI7XG5cbmNvbnN0IEdBX1BST0RVQ1RJT05fSUQgPSBcIlVBLTEzMDQ5MjI2MC0xXCI7XG5jb25zdCBHQV9ERVZFTE9QTUVOVF9JRCA9IFwiVUEtMTMwNDkyMjYwLTJcIjtcblxuZXhwb3J0IGNvbnN0IElTX01BSU5ORVQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLm5ldHdvcmsgPT09IFwibWFpbm5ldFwiO1xuZXhwb3J0IGNvbnN0IE5FVFdPUktfTkFNRSA9IChJU19NQUlOTkVUID8gXCJob21lc3RlYWRcIiA6IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yaykgPz8gXCJyb3BzdGVuXCI7IC8vIGV4cGVjdGVkIGJ5IGV0aGVyc1xuXG5leHBvcnQgY29uc3QgR0FfSUQgPSBJU19NQUlOTkVUID8gR0FfUFJPRFVDVElPTl9JRCA6IEdBX0RFVkVMT1BNRU5UX0lEO1xuZXhwb3J0IGNvbnN0IENBUFRDSEFfQ0xJRU5UX0tFWSA9IFwiNkxmaUwzRVVBQUFBQUhyZkx2bDJLaFJBY1hwYW5OWERxdTZNMENDU1wiO1xuXG5jb25zdCBnZXRBcGlVcmwgPSAobmV0d29ya05hbWU6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJob21lc3RlYWRcIikgcmV0dXJuIEFQSV9NQUlOX1VSTDtcbiAgZWxzZSBpZiAobmV0d29ya05hbWUgPT09IFwicmlua2VieVwiKSByZXR1cm4gQVBJX1JJTktFQllfVVJMO1xuICByZXR1cm4gQVBJX1JPUFNURU5fVVJMO1xufTtcbmV4cG9ydCBjb25zdCBFTUFJTF9BUElfVVJMID0gYCR7Z2V0QXBpVXJsKE5FVFdPUktfTkFNRSl9L2VtYWlsYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vc3RvcmFnZWA7XG5leHBvcnQgY29uc3QgU0hBUkVfTElOS19UVEwgPSAxMjA5NjAwO1xuXG5leHBvcnQgY29uc3QgTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiA9IHB1YmxpY1J1bnRpbWVDb25maWcubGVnYWN5UmVuZGVyZXJVcmwgfHwgXCJodHRwczovL2xlZ2FjeS5vcGVuY2VydHMuaW8vXCI7XG5leHBvcnQgY29uc3QgRU5WSVJPTk1FTlQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLmNvbnRleHQgPT09IFwicHJvZHVjdGlvblwiID8gXCJwcm9kdWN0aW9uXCIgOiBcImRldmVsb3BtZW50XCI7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFTyA9IHtcbiAgdGl0bGU6IFwiQW4gZWFzeSB3YXkgdG8gY2hlY2sgYW5kIHZlcmlmeSB5b3VyIGNlcnRpZmljYXRlcyAxMjNcIixcbiAgdGl0bGVUZW1wbGF0ZTogYE9wZW5DZXJ0cyAtICVzYCxcbiAgZGVzY3JpcHRpb246XG4gICAgXCJXaGV0aGVyIHlvdSdyZSBhIHN0dWRlbnQgb3IgYW4gZW1wbG95ZXIsIE9wZW5DZXJ0cyBsZXRzIHlvdSB2ZXJpZnkgdGhlIGNlcnRpZmljYXRlcyB5b3UgaGF2ZSBvZiBhbnlvbmUgZnJvbSBhbnkgaW5zdGl0dXRpb24uIEFsbCBpbiBvbmUgcGxhY2UuXCIsXG4gIG9wZW5HcmFwaDoge1xuICAgIHR5cGU6IFwid2Vic2l0ZVwiLFxuICAgIHVybDogVVJMLFxuICAgIHRpdGxlOiBcIk9wZW5DZXJ0cyAxMjMgLSBBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgICBpbWFnZXM6IFtcbiAgICAgIHtcbiAgICAgICAgdXJsOiBgJHtVUkx9L3N0YXRpYy9pbWFnZXMvb3BlbmNlcnRzLnBuZ2AsXG4gICAgICAgIHdpZHRoOiA4MDAsXG4gICAgICAgIGhlaWdodDogNjAwLFxuICAgICAgICBhbHQ6IFwiT3BlbkNlcnRzXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHR3aXR0ZXI6IHtcbiAgICBjYXJkVHlwZTogXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIsXG4gIH0sXG59O1xuXG50cmFjZShgTkVUV09SSzogJHtORVRXT1JLX05BTUV9YCk7XG50cmFjZShgQ0FQVENIQV9DTElFTlRfS0VZOiAke0NBUFRDSEFfQ0xJRU5UX0tFWX1gKTtcbnRyYWNlKGBFTUFJTF9BUElfVVJMOiAke0VNQUlMX0FQSV9VUkx9YCk7XG4iXSwic291cmNlUm9vdCI6IiJ9