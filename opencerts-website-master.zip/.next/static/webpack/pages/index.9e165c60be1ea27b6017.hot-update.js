webpackHotUpdate_N_E("pages/index",{

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "./node_modules/next/dist/next-server/lib/runtime-config.js");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;




var _getLogger = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"),
    trace = _getLogger.trace; // https://github.com/vercel/next.js/issues/7713


var _getConfig = next_config__WEBPACK_IMPORTED_MODULE_0___default()(),
    _getConfig$publicRunt = _getConfig.publicRuntimeConfig,
    publicRuntimeConfig = _getConfig$publicRunt === void 0 ? {} : _getConfig$publicRunt;

var URL = "https://opencerts.io";
var API_MAIN_URL = "https://api.opencerts.io";
var API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
var API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
var GA_PRODUCTION_ID = "UA-130492260-1";
var GA_DEVELOPMENT_ID = "UA-130492260-2";
var IS_MAINNET = publicRuntimeConfig.network === "mainnet";
var NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

var GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
var CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

var getApiUrl = function getApiUrl(networkName) {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

var EMAIL_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/email");
var SHARE_LINK_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/storage");
var SHARE_LINK_TTL = 1209600;
var LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
var ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
var DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: "OpenCerts - %s",
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: "",
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace("NETWORK: ".concat(NETWORK_NAME));
trace("CAPTCHA_CLIENT_KEY: ".concat(CAPTCHA_CLIENT_KEY));
trace("EMAIL_API_URL: ".concat(EMAIL_API_URL));

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbmZpZy9pbmRleC50cyJdLCJuYW1lcyI6WyJnZXRMb2dnZXIiLCJ0cmFjZSIsImdldENvbmZpZyIsInB1YmxpY1J1bnRpbWVDb25maWciLCJVUkwiLCJBUElfTUFJTl9VUkwiLCJBUElfUk9QU1RFTl9VUkwiLCJBUElfUklOS0VCWV9VUkwiLCJHQV9QUk9EVUNUSU9OX0lEIiwiR0FfREVWRUxPUE1FTlRfSUQiLCJJU19NQUlOTkVUIiwibmV0d29yayIsIk5FVFdPUktfTkFNRSIsIkdBX0lEIiwiQ0FQVENIQV9DTElFTlRfS0VZIiwiZ2V0QXBpVXJsIiwibmV0d29ya05hbWUiLCJFTUFJTF9BUElfVVJMIiwiU0hBUkVfTElOS19BUElfVVJMIiwiU0hBUkVfTElOS19UVEwiLCJMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSIiwibGVnYWN5UmVuZGVyZXJVcmwiLCJFTlZJUk9OTUVOVCIsImNvbnRleHQiLCJERUZBVUxUX1NFTyIsInRpdGxlIiwidGl0bGVUZW1wbGF0ZSIsImRlc2NyaXB0aW9uIiwib3BlbkdyYXBoIiwidHlwZSIsInVybCIsImltYWdlcyIsIndpZHRoIiwiaGVpZ2h0IiwiYWx0IiwidHdpdHRlciIsImNhcmRUeXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBOztpQkFFa0JBLCtEQUFTLENBQUMsUUFBRCxDO0lBQW5CQyxLLGNBQUFBLEssRUFDUjs7O2lCQUNxQ0Msa0RBQVMsRTt1Q0FBdENDLG1CO0lBQUFBLG1CLHNDQUFzQixFOztBQUV2QixJQUFNQyxHQUFHLEdBQUcsc0JBQVo7QUFDUCxJQUFNQyxZQUFZLEdBQUcsMEJBQXJCO0FBQ0EsSUFBTUMsZUFBZSxHQUFHLGtDQUF4QjtBQUNBLElBQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFFQSxJQUFNQyxnQkFBZ0IsR0FBRyxnQkFBekI7QUFDQSxJQUFNQyxpQkFBaUIsR0FBRyxnQkFBMUI7QUFFTyxJQUFNQyxVQUFVLEdBQUdQLG1CQUFtQixDQUFDUSxPQUFwQixLQUFnQyxTQUFuRDtBQUNBLElBQU1DLFlBQVksV0FBSUYsVUFBVSxHQUFHLFdBQUgsR0FBaUJQLG1CQUFtQixDQUFDUSxPQUFuRCx1Q0FBK0QsU0FBakYsQyxDQUE0Rjs7QUFFNUYsSUFBTUUsS0FBSyxHQUFHSCxVQUFVLEdBQUdGLGdCQUFILEdBQXNCQyxpQkFBOUM7QUFDQSxJQUFNSyxrQkFBa0IsR0FBRywwQ0FBM0I7O0FBRVAsSUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsV0FBRCxFQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1gsWUFBUCxDQUFqQyxLQUNLLElBQUlXLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPVCxlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLElBQU1XLGFBQWEsYUFBTUYsU0FBUyxDQUFDSCxZQUFELENBQWYsV0FBbkI7QUFDQSxJQUFNTSxrQkFBa0IsYUFBTUgsU0FBUyxDQUFDSCxZQUFELENBQWYsYUFBeEI7QUFDQSxJQUFNTyxjQUFjLEdBQUcsT0FBdkI7QUFFQSxJQUFNQyx5QkFBeUIsR0FBR2pCLG1CQUFtQixDQUFDa0IsaUJBQXBCLElBQXlDLDhCQUEzRTtBQUNBLElBQU1DLFdBQVcsR0FBR25CLG1CQUFtQixDQUFDb0IsT0FBcEIsS0FBZ0MsWUFBaEMsR0FBK0MsWUFBL0MsR0FBOEQsYUFBbEY7QUFFQSxJQUFNQyxXQUFXLEdBQUc7QUFDekJDLE9BQUssRUFBRSxtREFEa0I7QUFFekJDLGVBQWEsa0JBRlk7QUFHekJDLGFBQVcsRUFDVCxnSkFKdUI7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxRQUFJLEVBQUUsU0FERztBQUVUQyxPQUFHLEVBQUUxQixHQUZJO0FBR1RxQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRJLFVBQU0sRUFBRSxDQUNOO0FBQ0VELFNBQUcsSUFETDtBQUVFRSxXQUFLLEVBQUUsR0FGVDtBQUdFQyxZQUFNLEVBQUUsR0FIVjtBQUlFQyxTQUFHLEVBQUU7QUFKUCxLQURNO0FBTkMsR0FMYztBQW9CekJDLFNBQU8sRUFBRTtBQUNQQyxZQUFRLEVBQUU7QUFESDtBQXBCZ0IsQ0FBcEI7QUF5QlBuQyxLQUFLLG9CQUFhVyxZQUFiLEVBQUw7QUFDQVgsS0FBSywrQkFBd0JhLGtCQUF4QixFQUFMO0FBQ0FiLEtBQUssMEJBQW1CZ0IsYUFBbkIsRUFBTCIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC45ZTE2NWM2MGJlMWVhMjdiNjAxNy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGdldENvbmZpZyBmcm9tIFwibmV4dC9jb25maWdcIjtcbmltcG9ydCB7IGdldExvZ2dlciB9IGZyb20gXCIuLi91dGlscy9sb2dnZXJcIjtcblxuY29uc3QgeyB0cmFjZSB9ID0gZ2V0TG9nZ2VyKFwiY29uZmlnXCIpO1xuLy8gaHR0cHM6Ly9naXRodWIuY29tL3ZlcmNlbC9uZXh0LmpzL2lzc3Vlcy83NzEzXG5jb25zdCB7IHB1YmxpY1J1bnRpbWVDb25maWcgPSB7fSB9ID0gZ2V0Q29uZmlnKCk7XG5cbmV4cG9ydCBjb25zdCBVUkwgPSBcImh0dHBzOi8vb3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfTUFJTl9VUkwgPSBcImh0dHBzOi8vYXBpLm9wZW5jZXJ0cy5pb1wiO1xuY29uc3QgQVBJX1JPUFNURU5fVVJMID0gXCJodHRwczovL2FwaS1yb3BzdGVuLm9wZW5jZXJ0cy5pb1wiO1xuY29uc3QgQVBJX1JJTktFQllfVVJMID0gXCJodHRwczovL2FwaS1yaW5rZWJ5Lm9wZW5jZXJ0cy5pb1wiO1xuXG5jb25zdCBHQV9QUk9EVUNUSU9OX0lEID0gXCJVQS0xMzA0OTIyNjAtMVwiO1xuY29uc3QgR0FfREVWRUxPUE1FTlRfSUQgPSBcIlVBLTEzMDQ5MjI2MC0yXCI7XG5cbmV4cG9ydCBjb25zdCBJU19NQUlOTkVUID0gcHVibGljUnVudGltZUNvbmZpZy5uZXR3b3JrID09PSBcIm1haW5uZXRcIjtcbmV4cG9ydCBjb25zdCBORVRXT1JLX05BTUUgPSAoSVNfTUFJTk5FVCA/IFwiaG9tZXN0ZWFkXCIgOiBwdWJsaWNSdW50aW1lQ29uZmlnLm5ldHdvcmspID8/IFwicm9wc3RlblwiOyAvLyBleHBlY3RlZCBieSBldGhlcnNcblxuZXhwb3J0IGNvbnN0IEdBX0lEID0gSVNfTUFJTk5FVCA/IEdBX1BST0RVQ1RJT05fSUQgOiBHQV9ERVZFTE9QTUVOVF9JRDtcbmV4cG9ydCBjb25zdCBDQVBUQ0hBX0NMSUVOVF9LRVkgPSBcIjZMZmlMM0VVQUFBQUFIcmZMdmwyS2hSQWNYcGFuTlhEcXU2TTBDQ1NcIjtcblxuY29uc3QgZ2V0QXBpVXJsID0gKG5ldHdvcmtOYW1lOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBpZiAobmV0d29ya05hbWUgPT09IFwiaG9tZXN0ZWFkXCIpIHJldHVybiBBUElfTUFJTl9VUkw7XG4gIGVsc2UgaWYgKG5ldHdvcmtOYW1lID09PSBcInJpbmtlYnlcIikgcmV0dXJuIEFQSV9SSU5LRUJZX1VSTDtcbiAgcmV0dXJuIEFQSV9ST1BTVEVOX1VSTDtcbn07XG5leHBvcnQgY29uc3QgRU1BSUxfQVBJX1VSTCA9IGAke2dldEFwaVVybChORVRXT1JLX05BTUUpfS9lbWFpbGA7XG5leHBvcnQgY29uc3QgU0hBUkVfTElOS19BUElfVVJMID0gYCR7Z2V0QXBpVXJsKE5FVFdPUktfTkFNRSl9L3N0b3JhZ2VgO1xuZXhwb3J0IGNvbnN0IFNIQVJFX0xJTktfVFRMID0gMTIwOTYwMDtcblxuZXhwb3J0IGNvbnN0IExFR0FDWV9PUEVOQ0VSVFNfUkVOREVSRVIgPSBwdWJsaWNSdW50aW1lQ29uZmlnLmxlZ2FjeVJlbmRlcmVyVXJsIHx8IFwiaHR0cHM6Ly9sZWdhY3kub3BlbmNlcnRzLmlvL1wiO1xuZXhwb3J0IGNvbnN0IEVOVklST05NRU5UID0gcHVibGljUnVudGltZUNvbmZpZy5jb250ZXh0ID09PSBcInByb2R1Y3Rpb25cIiA/IFwicHJvZHVjdGlvblwiIDogXCJkZXZlbG9wbWVudFwiO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRU8gPSB7XG4gIHRpdGxlOiBcIkFuIGVhc3kgd2F5IHRvIGNoZWNrIGFuZCB2ZXJpZnkgeW91ciBjZXJ0aWZpY2F0ZXNcIixcbiAgdGl0bGVUZW1wbGF0ZTogYE9wZW5DZXJ0cyAtICVzYCxcbiAgZGVzY3JpcHRpb246XG4gICAgXCJXaGV0aGVyIHlvdSdyZSBhIHN0dWRlbnQgb3IgYW4gZW1wbG95ZXIsIE9wZW5DZXJ0cyBsZXRzIHlvdSB2ZXJpZnkgdGhlIGNlcnRpZmljYXRlcyB5b3UgaGF2ZSBvZiBhbnlvbmUgZnJvbSBhbnkgaW5zdGl0dXRpb24uIEFsbCBpbiBvbmUgcGxhY2UuXCIsXG4gIG9wZW5HcmFwaDoge1xuICAgIHR5cGU6IFwid2Vic2l0ZVwiLFxuICAgIHVybDogVVJMLFxuICAgIHRpdGxlOiBcIk9wZW5DZXJ0cyAtIEFuIGVhc3kgd2F5IHRvIGNoZWNrIGFuZCB2ZXJpZnkgeW91ciBjZXJ0aWZpY2F0ZXNcIixcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgIFwiV2hldGhlciB5b3UncmUgYSBzdHVkZW50IG9yIGFuIGVtcGxveWVyLCBPcGVuQ2VydHMgbGV0cyB5b3UgdmVyaWZ5IHRoZSBjZXJ0aWZpY2F0ZXMgeW91IGhhdmUgb2YgYW55b25lIGZyb20gYW55IGluc3RpdHV0aW9uLiBBbGwgaW4gb25lIHBsYWNlLlwiLFxuICAgIGltYWdlczogW1xuICAgICAge1xuICAgICAgICB1cmw6IGBgLFxuICAgICAgICB3aWR0aDogODAwLFxuICAgICAgICBoZWlnaHQ6IDYwMCxcbiAgICAgICAgYWx0OiBcIk9wZW5DZXJ0c1wiLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB0d2l0dGVyOiB7XG4gICAgY2FyZFR5cGU6IFwic3VtbWFyeV9sYXJnZV9pbWFnZVwiLFxuICB9LFxufTtcblxudHJhY2UoYE5FVFdPUks6ICR7TkVUV09SS19OQU1FfWApO1xudHJhY2UoYENBUFRDSEFfQ0xJRU5UX0tFWTogJHtDQVBUQ0hBX0NMSUVOVF9LRVl9YCk7XG50cmFjZShgRU1BSUxfQVBJX1VSTDogJHtFTUFJTF9BUElfVVJMfWApO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==