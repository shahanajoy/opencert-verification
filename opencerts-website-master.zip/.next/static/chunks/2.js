(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([[2],{

/***/ "./node_modules/next/dist/next-server/lib/runtime-config.js":
/*!******************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/runtime-config.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

exports.__esModule = true;
exports.setConfig = setConfig;
exports["default"] = void 0;
var runtimeConfig;

var _default = function _default() {
  return runtimeConfig;
};

exports["default"] = _default;

function setConfig(configValue) {
  runtimeConfig = configValue;
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../webpack/buildin/module.js */ "./node_modules/webpack/buildin/module.js")(module)))

/***/ }),

/***/ "./node_modules/react-async-script/lib/esm/async-script-loader.js":
/*!************************************************************************!*\
  !*** ./node_modules/react-async-script/lib/esm/async-script-loader.js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return makeAsyncScript; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! hoist-non-react-statics */ "./node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js");
/* harmony import */ var hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_2__);
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }




var SCRIPT_MAP = {}; // A counter used to generate a unique id for each component that uses the function

var idCount = 0;
function makeAsyncScript(getScriptURL, options) {
  options = options || {};
  return function wrapWithAsyncScript(WrappedComponent) {
    var wrappedComponentName = WrappedComponent.displayName || WrappedComponent.name || "Component";

    var AsyncScriptLoader =
    /*#__PURE__*/
    function (_Component) {
      _inheritsLoose(AsyncScriptLoader, _Component);

      function AsyncScriptLoader(props, context) {
        var _this;

        _this = _Component.call(this, props, context) || this;
        _this.state = {};
        _this.__scriptURL = "";
        return _this;
      }

      var _proto = AsyncScriptLoader.prototype;

      _proto.asyncScriptLoaderGetScriptLoaderID = function asyncScriptLoaderGetScriptLoaderID() {
        if (!this.__scriptLoaderID) {
          this.__scriptLoaderID = "async-script-loader-" + idCount++;
        }

        return this.__scriptLoaderID;
      };

      _proto.setupScriptURL = function setupScriptURL() {
        this.__scriptURL = typeof getScriptURL === "function" ? getScriptURL() : getScriptURL;
        return this.__scriptURL;
      };

      _proto.asyncScriptLoaderHandleLoad = function asyncScriptLoaderHandleLoad(state) {
        var _this2 = this;

        // use reacts setState callback to fire props.asyncScriptOnLoad with new state/entry
        this.setState(state, function () {
          return _this2.props.asyncScriptOnLoad && _this2.props.asyncScriptOnLoad(_this2.state);
        });
      };

      _proto.asyncScriptLoaderTriggerOnScriptLoaded = function asyncScriptLoaderTriggerOnScriptLoaded() {
        var mapEntry = SCRIPT_MAP[this.__scriptURL];

        if (!mapEntry || !mapEntry.loaded) {
          throw new Error("Script is not loaded.");
        }

        for (var obsKey in mapEntry.observers) {
          mapEntry.observers[obsKey](mapEntry);
        }

        delete window[options.callbackName];
      };

      _proto.componentDidMount = function componentDidMount() {
        var _this3 = this;

        var scriptURL = this.setupScriptURL();
        var key = this.asyncScriptLoaderGetScriptLoaderID();
        var _options = options,
            globalName = _options.globalName,
            callbackName = _options.callbackName,
            scriptId = _options.scriptId; // check if global object already attached to window

        if (globalName && typeof window[globalName] !== "undefined") {
          SCRIPT_MAP[scriptURL] = {
            loaded: true,
            observers: {}
          };
        } // check if script loading already


        if (SCRIPT_MAP[scriptURL]) {
          var entry = SCRIPT_MAP[scriptURL]; // if loaded or errored then "finish"

          if (entry && (entry.loaded || entry.errored)) {
            this.asyncScriptLoaderHandleLoad(entry);
            return;
          } // if still loading then callback to observer queue


          entry.observers[key] = function (entry) {
            return _this3.asyncScriptLoaderHandleLoad(entry);
          };

          return;
        }
        /*
         * hasn't started loading
         * start the "magic"
         * setup script to load and observers
         */


        var observers = {};

        observers[key] = function (entry) {
          return _this3.asyncScriptLoaderHandleLoad(entry);
        };

        SCRIPT_MAP[scriptURL] = {
          loaded: false,
          observers: observers
        };
        var script = document.createElement("script");
        script.src = scriptURL;
        script.async = true;

        for (var attribute in options.attributes) {
          script.setAttribute(attribute, options.attributes[attribute]);
        }

        if (scriptId) {
          script.id = scriptId;
        }

        var callObserverFuncAndRemoveObserver = function callObserverFuncAndRemoveObserver(func) {
          if (SCRIPT_MAP[scriptURL]) {
            var mapEntry = SCRIPT_MAP[scriptURL];
            var observersMap = mapEntry.observers;

            for (var obsKey in observersMap) {
              if (func(observersMap[obsKey])) {
                delete observersMap[obsKey];
              }
            }
          }
        };

        if (callbackName && typeof window !== "undefined") {
          window[callbackName] = function () {
            return _this3.asyncScriptLoaderTriggerOnScriptLoaded();
          };
        }

        script.onload = function () {
          var mapEntry = SCRIPT_MAP[scriptURL];

          if (mapEntry) {
            mapEntry.loaded = true;
            callObserverFuncAndRemoveObserver(function (observer) {
              if (callbackName) {
                return false;
              }

              observer(mapEntry);
              return true;
            });
          }
        };

        script.onerror = function () {
          var mapEntry = SCRIPT_MAP[scriptURL];

          if (mapEntry) {
            mapEntry.errored = true;
            callObserverFuncAndRemoveObserver(function (observer) {
              observer(mapEntry);
              return true;
            });
          }
        };

        document.body.appendChild(script);
      };

      _proto.componentWillUnmount = function componentWillUnmount() {
        // Remove tag script
        var scriptURL = this.__scriptURL;

        if (options.removeOnUnmount === true) {
          var allScripts = document.getElementsByTagName("script");

          for (var i = 0; i < allScripts.length; i += 1) {
            if (allScripts[i].src.indexOf(scriptURL) > -1) {
              if (allScripts[i].parentNode) {
                allScripts[i].parentNode.removeChild(allScripts[i]);
              }
            }
          }
        } // Clean the observer entry


        var mapEntry = SCRIPT_MAP[scriptURL];

        if (mapEntry) {
          delete mapEntry.observers[this.asyncScriptLoaderGetScriptLoaderID()];

          if (options.removeOnUnmount === true) {
            delete SCRIPT_MAP[scriptURL];
          }
        }
      };

      _proto.render = function render() {
        var globalName = options.globalName; // remove asyncScriptOnLoad from childProps

        var _this$props = this.props,
            asyncScriptOnLoad = _this$props.asyncScriptOnLoad,
            forwardedRef = _this$props.forwardedRef,
            childProps = _objectWithoutPropertiesLoose(_this$props, ["asyncScriptOnLoad", "forwardedRef"]); // eslint-disable-line no-unused-vars


        if (globalName && typeof window !== "undefined") {
          childProps[globalName] = typeof window[globalName] !== "undefined" ? window[globalName] : undefined;
        }

        childProps.ref = forwardedRef;
        return Object(react__WEBPACK_IMPORTED_MODULE_0__["createElement"])(WrappedComponent, childProps);
      };

      return AsyncScriptLoader;
    }(react__WEBPACK_IMPORTED_MODULE_0__["Component"]); // Note the second param "ref" provided by React.forwardRef.
    // We can pass it along to AsyncScriptLoader as a regular prop, e.g. "forwardedRef"
    // And it can then be attached to the Component.


    var ForwardedComponent = Object(react__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(function (props, ref) {
      return Object(react__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AsyncScriptLoader, _extends({}, props, {
        forwardedRef: ref
      }));
    });
    ForwardedComponent.displayName = "AsyncScriptLoader(" + wrappedComponentName + ")";
    ForwardedComponent.propTypes = {
      asyncScriptOnLoad: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func
    };
    return hoist_non_react_statics__WEBPACK_IMPORTED_MODULE_2___default()(ForwardedComponent, WrappedComponent);
  };
}

/***/ }),

/***/ "./node_modules/react-google-recaptcha/lib/esm/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-google-recaptcha/lib/esm/index.js ***!
  \**************************************************************/
/*! exports provided: default, ReCAPTCHA */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _recaptcha_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recaptcha-wrapper */ "./node_modules/react-google-recaptcha/lib/esm/recaptcha-wrapper.js");
/* harmony import */ var _recaptcha__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./recaptcha */ "./node_modules/react-google-recaptcha/lib/esm/recaptcha.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ReCAPTCHA", function() { return _recaptcha__WEBPACK_IMPORTED_MODULE_1__["default"]; });



/* harmony default export */ __webpack_exports__["default"] = (_recaptcha_wrapper__WEBPACK_IMPORTED_MODULE_0__["default"]);


/***/ }),

/***/ "./node_modules/react-google-recaptcha/lib/esm/recaptcha-wrapper.js":
/*!**************************************************************************!*\
  !*** ./node_modules/react-google-recaptcha/lib/esm/recaptcha-wrapper.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _recaptcha__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recaptcha */ "./node_modules/react-google-recaptcha/lib/esm/recaptcha.js");
/* harmony import */ var react_async_script__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-async-script */ "./node_modules/react-async-script/lib/esm/async-script-loader.js");


var callbackName = "onloadcallback";
var globalName = "grecaptcha";

function getOptions() {
  return typeof window !== "undefined" && window.recaptchaOptions || {};
}

function getURL() {
  var dynamicOptions = getOptions();
  var hostname = dynamicOptions.useRecaptchaNet ? "recaptcha.net" : "www.google.com";
  return "https://" + hostname + "/recaptcha/api.js?onload=" + callbackName + "&render=explicit";
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_async_script__WEBPACK_IMPORTED_MODULE_1__["default"])(getURL, {
  callbackName: callbackName,
  globalName: globalName
})(_recaptcha__WEBPACK_IMPORTED_MODULE_0__["default"]));

/***/ }),

/***/ "./node_modules/react-google-recaptcha/lib/esm/recaptcha.js":
/*!******************************************************************!*\
  !*** ./node_modules/react-google-recaptcha/lib/esm/recaptcha.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ReCAPTCHA; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }




var ReCAPTCHA =
/*#__PURE__*/
function (_React$Component) {
  _inheritsLoose(ReCAPTCHA, _React$Component);

  function ReCAPTCHA() {
    var _this;

    _this = _React$Component.call(this) || this;
    _this.handleExpired = _this.handleExpired.bind(_assertThisInitialized(_this));
    _this.handleErrored = _this.handleErrored.bind(_assertThisInitialized(_this));
    _this.handleChange = _this.handleChange.bind(_assertThisInitialized(_this));
    _this.handleRecaptchaRef = _this.handleRecaptchaRef.bind(_assertThisInitialized(_this));
    return _this;
  }

  var _proto = ReCAPTCHA.prototype;

  _proto.getValue = function getValue() {
    if (this.props.grecaptcha && this._widgetId !== undefined) {
      return this.props.grecaptcha.getResponse(this._widgetId);
    }

    return null;
  };

  _proto.getWidgetId = function getWidgetId() {
    if (this.props.grecaptcha && this._widgetId !== undefined) {
      return this._widgetId;
    }

    return null;
  };

  _proto.execute = function execute() {
    var grecaptcha = this.props.grecaptcha;

    if (grecaptcha && this._widgetId !== undefined) {
      return grecaptcha.execute(this._widgetId);
    } else {
      this._executeRequested = true;
    }
  };

  _proto.executeAsync = function executeAsync() {
    var _this2 = this;

    return new Promise(function (resolve, reject) {
      _this2.executionResolve = resolve;
      _this2.executionReject = reject;

      _this2.execute();
    });
  };

  _proto.reset = function reset() {
    if (this.props.grecaptcha && this._widgetId !== undefined) {
      this.props.grecaptcha.reset(this._widgetId);
    }
  };

  _proto.handleExpired = function handleExpired() {
    if (this.props.onExpired) {
      this.props.onExpired();
    } else {
      this.handleChange(null);
    }
  };

  _proto.handleErrored = function handleErrored() {
    if (this.props.onErrored) {
      this.props.onErrored();
    }

    if (this.executionReject) {
      this.executionReject();
      delete this.executionResolve;
      delete this.executionReject;
    }
  };

  _proto.handleChange = function handleChange(token) {
    if (this.props.onChange) {
      this.props.onChange(token);
    }

    if (this.executionResolve) {
      this.executionResolve(token);
      delete this.executionReject;
      delete this.executionResolve;
    }
  };

  _proto.explicitRender = function explicitRender() {
    if (this.props.grecaptcha && this.props.grecaptcha.render && this._widgetId === undefined) {
      var wrapper = document.createElement("div");
      this._widgetId = this.props.grecaptcha.render(wrapper, {
        sitekey: this.props.sitekey,
        callback: this.handleChange,
        theme: this.props.theme,
        type: this.props.type,
        tabindex: this.props.tabindex,
        "expired-callback": this.handleExpired,
        "error-callback": this.handleErrored,
        size: this.props.size,
        stoken: this.props.stoken,
        hl: this.props.hl,
        badge: this.props.badge
      });
      this.captcha.appendChild(wrapper);
    }

    if (this._executeRequested && this.props.grecaptcha && this._widgetId !== undefined) {
      this._executeRequested = false;
      this.execute();
    }
  };

  _proto.componentDidMount = function componentDidMount() {
    this.explicitRender();
  };

  _proto.componentDidUpdate = function componentDidUpdate() {
    this.explicitRender();
  };

  _proto.componentWillUnmount = function componentWillUnmount() {
    if (this._widgetId !== undefined) {
      this.delayOfCaptchaIframeRemoving();
      this.reset();
    }
  };

  _proto.delayOfCaptchaIframeRemoving = function delayOfCaptchaIframeRemoving() {
    var temporaryNode = document.createElement("div");
    document.body.appendChild(temporaryNode);
    temporaryNode.style.display = "none"; // move of the recaptcha to a temporary node

    while (this.captcha.firstChild) {
      temporaryNode.appendChild(this.captcha.firstChild);
    } // delete the temporary node after reset will be done


    setTimeout(function () {
      document.body.removeChild(temporaryNode);
    }, 5000);
  };

  _proto.handleRecaptchaRef = function handleRecaptchaRef(elem) {
    this.captcha = elem;
  };

  _proto.render = function render() {
    // consume properties owned by the reCATPCHA, pass the rest to the div so the user can style it.

    /* eslint-disable no-unused-vars */
    var _this$props = this.props,
        sitekey = _this$props.sitekey,
        onChange = _this$props.onChange,
        theme = _this$props.theme,
        type = _this$props.type,
        tabindex = _this$props.tabindex,
        onExpired = _this$props.onExpired,
        onErrored = _this$props.onErrored,
        size = _this$props.size,
        stoken = _this$props.stoken,
        grecaptcha = _this$props.grecaptcha,
        badge = _this$props.badge,
        hl = _this$props.hl,
        childProps = _objectWithoutPropertiesLoose(_this$props, ["sitekey", "onChange", "theme", "type", "tabindex", "onExpired", "onErrored", "size", "stoken", "grecaptcha", "badge", "hl"]);
    /* eslint-enable no-unused-vars */


    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", _extends({}, childProps, {
      ref: this.handleRecaptchaRef
    }));
  };

  return ReCAPTCHA;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);


ReCAPTCHA.displayName = "ReCAPTCHA";
ReCAPTCHA.propTypes = {
  sitekey: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  grecaptcha: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  theme: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(["dark", "light"]),
  type: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(["image", "audio"]),
  tabindex: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
  onExpired: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  onErrored: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func,
  size: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(["compact", "normal", "invisible"]),
  stoken: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  hl: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  badge: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(["bottomright", "bottomleft", "inline"])
};
ReCAPTCHA.defaultProps = {
  onChange: function onChange() {},
  theme: "light",
  type: "image",
  tabindex: 0,
  size: "normal",
  badge: "bottomright"
};

/***/ }),

/***/ "./src/components/CertificateSharing/CertificateSharingForm.tsx":
/*!**********************************************************************!*\
  !*** ./src/components/CertificateSharing/CertificateSharingForm.tsx ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js");
/* harmony import */ var C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-google-recaptcha */ "./node_modules/react-google-recaptcha/lib/esm/index.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");
/* harmony import */ var _reducers_shared__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../reducers/shared */ "./src/reducers/shared.ts");







var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\CertificateSharing\\CertificateSharingForm.tsx";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }






var CertificateSharingForm = /*#__PURE__*/function (_Component) {
  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__["default"])(CertificateSharingForm, _Component);

  var _super = _createSuper(CertificateSharingForm);

  function CertificateSharingForm(props) {
    var _this;

    Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CertificateSharingForm);

    _this = _super.call(this, props);
    _this.state = {
      captcha: "",
      email: ""
    };
    _this.handleCaptchaChange = _this.handleCaptchaChange.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__["default"])(_this));
    _this.handleEmailChange = _this.handleEmailChange.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__["default"])(_this));
    _this.handleSend = _this.handleSend.bind(Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__["default"])(_this));
    return _this;
  }

  Object(C_Users_MohamedFarshad_source_repos_DocumentWebViewer_opencerts_website_master_node_modules_next_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(CertificateSharingForm, [{
    key: "handleCaptchaChange",
    value: function handleCaptchaChange(value) {
      if (value) this.setState({
        captcha: value
      });
    }
  }, {
    key: "handleEmailChange",
    value: function handleEmailChange(event) {
      this.setState({
        email: event.target.value
      });
    }
  }, {
    key: "handleSend",
    value: function handleSend() {
      var _this$props = this.props,
          handleSendCertificate = _this$props.handleSendCertificate,
          emailSendingState = _this$props.emailSendingState;

      if (emailSendingState !== _reducers_shared__WEBPACK_IMPORTED_MODULE_10__["states"].PENDING) {
        handleSendCertificate({
          email: this.state.email,
          captcha: this.state.captcha
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      var emailSendingState = this.props.emailSendingState;
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
        className: "text-center",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("h3", {
          className: "mb-2",
          children: "Send your certificate"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 9
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("p", {
          children: "This sends an email with your .opencert attached, and instructions on how to view it."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 9
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("input", {
          className: "border p-2 w-64",
          value: this.state.email,
          onChange: this.handleEmailChange,
          placeholder: "Enter recipient's email"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 9
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "flex justify-center w-full my-4",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__["default"], {
            sitekey: _config__WEBPACK_IMPORTED_MODULE_9__["CAPTCHA_CLIENT_KEY"],
            onChange: this.handleCaptchaChange
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 9
        }, this), emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_10__["states"].SUCCESS && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "my-4",
          children: "Email successfully sent!"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 50
        }, this), emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_10__["states"].FAILURE && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "my-4",
          children: "An error occured, please check your email and captcha"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "mt-4",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("button", {
            type: "button",
            className: "button bg-navy text-white hover:bg-navy-300",
            onClick: this.handleSend,
            children: ["Send", emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_10__["states"].PENDING && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("i", {
              className: "ml-2 fas fa-spinner fa-pulse"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 68,
              columnNumber: 54
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 9
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 7
      }, this);
    }
  }]);

  return CertificateSharingForm;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]); // looks needed for dynamic import
// eslint-disable-next-line import/no-default-export


/* harmony default export */ __webpack_exports__["default"] = (CertificateSharingForm);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "./node_modules/next/dist/next-server/lib/runtime-config.js");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;




var _getLogger = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"),
    trace = _getLogger.trace; // https://github.com/vercel/next.js/issues/7713


var _getConfig = next_config__WEBPACK_IMPORTED_MODULE_0___default()(),
    _getConfig$publicRunt = _getConfig.publicRuntimeConfig,
    publicRuntimeConfig = _getConfig$publicRunt === void 0 ? {} : _getConfig$publicRunt;

var URL = "https://opencerts.io";
var API_MAIN_URL = "https://api.opencerts.io";
var API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
var API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
var GA_PRODUCTION_ID = "UA-130492260-1";
var GA_DEVELOPMENT_ID = "UA-130492260-2";
var IS_MAINNET = publicRuntimeConfig.network === "mainnet";
var NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

var GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
var CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

var getApiUrl = function getApiUrl(networkName) {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

var EMAIL_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/email");
var SHARE_LINK_API_URL = "".concat(getApiUrl(NETWORK_NAME), "/storage");
var SHARE_LINK_TTL = 1209600;
var LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
var ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
var DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: "OpenCerts - %s",
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: "".concat(URL, "/static/images/opencerts.png"),
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace("NETWORK: ".concat(NETWORK_NAME));
trace("CAPTCHA_CLIENT_KEY: ".concat(CAPTCHA_CLIENT_KEY));
trace("EMAIL_API_URL: ".concat(EMAIL_API_URL));

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./src/utils/logger.ts":
/*!*****************************!*\
  !*** ./src/utils/logger.ts ***!
  \*****************************/
/*! exports provided: trace, error, getLogger */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trace", function() { return trace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLogger", function() { return getLogger; });
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! debug */ "./node_modules/debug/src/browser.js");
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(debug__WEBPACK_IMPORTED_MODULE_0__);
 // not using .extends because of stupid next.js resolve modules bug where its picking up old version of debug

var trace = function trace(namespace) {
  return debug__WEBPACK_IMPORTED_MODULE_0___default()("opencerts-website:trace:".concat(namespace));
};
var error = function error(namespace) {
  return debug__WEBPACK_IMPORTED_MODULE_0___default()("opencerts-website:error:".concat(namespace));
};
var getLogger = function getLogger(namespace) {
  return {
    trace: trace(namespace),
    error: error(namespace)
  };
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9ydW50aW1lLWNvbmZpZy50cyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3JlYWN0LWFzeW5jLXNjcmlwdC9saWIvZXNtL2FzeW5jLXNjcmlwdC1sb2FkZXIuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1nb29nbGUtcmVjYXB0Y2hhL2xpYi9lc20vaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1nb29nbGUtcmVjYXB0Y2hhL2xpYi9lc20vcmVjYXB0Y2hhLXdyYXBwZXIuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1nb29nbGUtcmVjYXB0Y2hhL2xpYi9lc20vcmVjYXB0Y2hhLmpzIiwid2VicGFjazovL19OX0UvLi9zcmMvY29tcG9uZW50cy9DZXJ0aWZpY2F0ZVNoYXJpbmcvQ2VydGlmaWNhdGVTaGFyaW5nRm9ybS50c3giLCJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9jb25maWcvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vX05fRS8uL3NyYy91dGlscy9sb2dnZXIudHMiXSwibmFtZXMiOlsicnVudGltZUNvbmZpZyIsIkNlcnRpZmljYXRlU2hhcmluZ0Zvcm0iLCJwcm9wcyIsInN0YXRlIiwiY2FwdGNoYSIsImVtYWlsIiwiaGFuZGxlQ2FwdGNoYUNoYW5nZSIsImJpbmQiLCJoYW5kbGVFbWFpbENoYW5nZSIsImhhbmRsZVNlbmQiLCJ2YWx1ZSIsInNldFN0YXRlIiwiZXZlbnQiLCJ0YXJnZXQiLCJoYW5kbGVTZW5kQ2VydGlmaWNhdGUiLCJlbWFpbFNlbmRpbmdTdGF0ZSIsInN0YXRlcyIsIlBFTkRJTkciLCJDQVBUQ0hBX0NMSUVOVF9LRVkiLCJTVUNDRVNTIiwiRkFJTFVSRSIsIkNvbXBvbmVudCIsImdldExvZ2dlciIsInRyYWNlIiwiZ2V0Q29uZmlnIiwicHVibGljUnVudGltZUNvbmZpZyIsIlVSTCIsIkFQSV9NQUlOX1VSTCIsIkFQSV9ST1BTVEVOX1VSTCIsIkFQSV9SSU5LRUJZX1VSTCIsIkdBX1BST0RVQ1RJT05fSUQiLCJHQV9ERVZFTE9QTUVOVF9JRCIsIklTX01BSU5ORVQiLCJuZXR3b3JrIiwiTkVUV09SS19OQU1FIiwiR0FfSUQiLCJnZXRBcGlVcmwiLCJuZXR3b3JrTmFtZSIsIkVNQUlMX0FQSV9VUkwiLCJTSEFSRV9MSU5LX0FQSV9VUkwiLCJTSEFSRV9MSU5LX1RUTCIsIkxFR0FDWV9PUEVOQ0VSVFNfUkVOREVSRVIiLCJsZWdhY3lSZW5kZXJlclVybCIsIkVOVklST05NRU5UIiwiY29udGV4dCIsIkRFRkFVTFRfU0VPIiwidGl0bGUiLCJ0aXRsZVRlbXBsYXRlIiwiZGVzY3JpcHRpb24iLCJvcGVuR3JhcGgiLCJ0eXBlIiwidXJsIiwiaW1hZ2VzIiwid2lkdGgiLCJoZWlnaHQiLCJhbHQiLCJ0d2l0dGVyIiwiY2FyZFR5cGUiLCJuYW1lc3BhY2UiLCJkZWJ1ZyIsImVycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7ZUFFZSxTLFFBQUEsR0FBTTtBQUNuQjs7Ozs7QUFHSyxnQ0FBMkM7QUFDaERBLGVBQWEsR0FBYkE7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQixnREFBZ0QsZ0JBQWdCLHNCQUFzQixPQUFPLDJCQUEyQiwwQkFBMEIseURBQXlELDJCQUEyQixFQUFFLEVBQUUsRUFBRSxlQUFlLEdBQUcsd0NBQXdDOztBQUUzVCwwREFBMEQsK0JBQStCLGlCQUFpQixzQ0FBc0MsWUFBWSxZQUFZLHVCQUF1QixPQUFPLHFCQUFxQiwwQ0FBMEMsMkJBQTJCLEVBQUUsZUFBZTs7QUFFalQsK0NBQStDLDBEQUEwRCwyQ0FBMkMsaUNBQWlDOztBQUV4SDtBQUMxQjtBQUNnQjtBQUNuRCxvQkFBb0I7O0FBRXBCO0FBQ2U7QUFDZjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDOztBQUV6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzs7O0FBR1Q7QUFDQSw0Q0FBNEM7O0FBRTVDO0FBQ0E7QUFDQTtBQUNBLFdBQVc7OztBQUdYO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSx5QkFBeUIsdUJBQXVCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7OztBQUdUOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDRDQUE0Qzs7QUFFNUM7QUFDQTtBQUNBO0FBQ0EsMkdBQTJHOzs7QUFHM0c7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZSwyREFBYTtBQUM1Qjs7QUFFQTtBQUNBLEtBQUssQ0FBQywrQ0FBUyxFQUFFO0FBQ2pCO0FBQ0E7OztBQUdBLDZCQUE2Qix3REFBVTtBQUN2QyxhQUFhLDJEQUFhLCtCQUErQjtBQUN6RDtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBLHlCQUF5QixpREFBUztBQUNsQztBQUNBLFdBQVcsOERBQVk7QUFDdkI7QUFDQSxDOzs7Ozs7Ozs7Ozs7QUNuUEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFtRDtBQUNmO0FBQ3JCLHlIQUFnQixFQUFDOzs7Ozs7Ozs7Ozs7O0FDRmhDO0FBQUE7QUFBQTtBQUFvQztBQUNtQjtBQUN2RDtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVlLGlJQUFxQjtBQUNwQztBQUNBO0FBQ0EsQ0FBQyxFQUFFLGtEQUFTLENBQUMsRTs7Ozs7Ozs7Ozs7O0FDbEJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQixnREFBZ0QsZ0JBQWdCLHNCQUFzQixPQUFPLDJCQUEyQiwwQkFBMEIseURBQXlELDJCQUEyQixFQUFFLEVBQUUsRUFBRSxlQUFlLEdBQUcsd0NBQXdDOztBQUUzVCwwREFBMEQsK0JBQStCLGlCQUFpQixzQ0FBc0MsWUFBWSxZQUFZLHVCQUF1QixPQUFPLHFCQUFxQiwwQ0FBMEMsMkJBQTJCLEVBQUUsZUFBZTs7QUFFalQsdUNBQXVDLHVCQUF1Qix1RkFBdUYsRUFBRSxhQUFhOztBQUVwSywrQ0FBK0MsMERBQTBELDJDQUEyQyxpQ0FBaUM7O0FBRTNKO0FBQ1M7O0FBRW5DO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUM7O0FBRXpDO0FBQ0E7QUFDQSxLQUFLOzs7QUFHTDtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQSxXQUFXLDRDQUFLLGlDQUFpQztBQUNqRDtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBLENBQUMsQ0FBQyw0Q0FBSzs7QUFFeUI7QUFDaEM7QUFDQTtBQUNBLFdBQVcsaURBQVM7QUFDcEIsWUFBWSxpREFBUztBQUNyQixjQUFjLGlEQUFTO0FBQ3ZCLFNBQVMsaURBQVM7QUFDbEIsUUFBUSxpREFBUztBQUNqQixZQUFZLGlEQUFTO0FBQ3JCLGFBQWEsaURBQVM7QUFDdEIsYUFBYSxpREFBUztBQUN0QixRQUFRLGlEQUFTO0FBQ2pCLFVBQVUsaURBQVM7QUFDbkIsTUFBTSxpREFBUztBQUNmLFNBQVMsaURBQVM7QUFDbEI7QUFDQTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdk5BO0FBQ0E7QUFDQTtBQUNBOztJQVVNQyxzQjs7Ozs7QUFDSixrQ0FBWUMsS0FBWixFQUFnRDtBQUFBOztBQUFBOztBQUM5Qyw4QkFBTUEsS0FBTjtBQUVBLFVBQUtDLEtBQUwsR0FBYTtBQUNYQyxhQUFPLEVBQUUsRUFERTtBQUVYQyxXQUFLLEVBQUU7QUFGSSxLQUFiO0FBS0EsVUFBS0MsbUJBQUwsR0FBMkIsTUFBS0EsbUJBQUwsQ0FBeUJDLElBQXpCLHNOQUEzQjtBQUNBLFVBQUtDLGlCQUFMLEdBQXlCLE1BQUtBLGlCQUFMLENBQXVCRCxJQUF2QixzTkFBekI7QUFDQSxVQUFLRSxVQUFMLEdBQWtCLE1BQUtBLFVBQUwsQ0FBZ0JGLElBQWhCLHNOQUFsQjtBQVY4QztBQVcvQzs7Ozt3Q0FFbUJHLEssRUFBNEI7QUFDOUMsVUFBSUEsS0FBSixFQUFXLEtBQUtDLFFBQUwsQ0FBYztBQUFFUCxlQUFPLEVBQUVNO0FBQVgsT0FBZDtBQUNaOzs7c0NBRWlCRSxLLEVBQTRDO0FBQzVELFdBQUtELFFBQUwsQ0FBYztBQUFFTixhQUFLLEVBQUVPLEtBQUssQ0FBQ0MsTUFBTixDQUFhSDtBQUF0QixPQUFkO0FBQ0Q7OztpQ0FFa0I7QUFBQSx3QkFDb0MsS0FBS1IsS0FEekM7QUFBQSxVQUNUWSxxQkFEUyxlQUNUQSxxQkFEUztBQUFBLFVBQ2NDLGlCQURkLGVBQ2NBLGlCQURkOztBQUVqQixVQUFJQSxpQkFBaUIsS0FBS0Msd0RBQU0sQ0FBQ0MsT0FBakMsRUFBMEM7QUFDeENILDZCQUFxQixDQUFDO0FBQ3BCVCxlQUFLLEVBQUUsS0FBS0YsS0FBTCxDQUFXRSxLQURFO0FBRXBCRCxpQkFBTyxFQUFFLEtBQUtELEtBQUwsQ0FBV0M7QUFGQSxTQUFELENBQXJCO0FBSUQ7QUFDRjs7OzZCQUVtQjtBQUFBLFVBQ1ZXLGlCQURVLEdBQ1ksS0FBS2IsS0FEakIsQ0FDVmEsaUJBRFU7QUFFbEIsMEJBQ0U7QUFBSyxpQkFBUyxFQUFDLGFBQWY7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBR0U7QUFDRSxtQkFBUyxFQUFDLGlCQURaO0FBRUUsZUFBSyxFQUFFLEtBQUtaLEtBQUwsQ0FBV0UsS0FGcEI7QUFHRSxrQkFBUSxFQUFFLEtBQUtHLGlCQUhqQjtBQUlFLHFCQUFXLEVBQUM7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGLGVBU0U7QUFBSyxtQkFBUyxFQUFDLGlDQUFmO0FBQUEsaUNBQ0UscUVBQUMsOERBQUQ7QUFBVyxtQkFBTyxFQUFFVSwwREFBcEI7QUFBd0Msb0JBQVEsRUFBRSxLQUFLWjtBQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFURixFQVlHUyxpQkFBaUIsS0FBS0Msd0RBQU0sQ0FBQ0csT0FBN0IsaUJBQXdDO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVozQyxFQWFHSixpQkFBaUIsS0FBS0Msd0RBQU0sQ0FBQ0ksT0FBN0IsaUJBQ0M7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZEosZUFnQkU7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxpQ0FDRTtBQUFRLGdCQUFJLEVBQUMsUUFBYjtBQUFzQixxQkFBUyxFQUFDLDZDQUFoQztBQUE4RSxtQkFBTyxFQUFFLEtBQUtYLFVBQTVGO0FBQUEsK0JBRUdNLGlCQUFpQixLQUFLQyx3REFBTSxDQUFDQyxPQUE3QixpQkFBd0M7QUFBRyx1QkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREY7QUF5QkQ7Ozs7RUEzRGtDSSwrQyxHQTZEckM7QUFDQTs7O0FBQ2VwQixxRkFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1RUE7QUFDQTs7aUJBRWtCcUIsK0RBQVMsQ0FBQyxRQUFELEM7SUFBbkJDLEssY0FBQUEsSyxFQUNSOzs7aUJBQ3FDQyxrREFBUyxFO3VDQUF0Q0MsbUI7SUFBQUEsbUIsc0NBQXNCLEU7O0FBRXZCLElBQU1DLEdBQUcsR0FBRyxzQkFBWjtBQUNQLElBQU1DLFlBQVksR0FBRywwQkFBckI7QUFDQSxJQUFNQyxlQUFlLEdBQUcsa0NBQXhCO0FBQ0EsSUFBTUMsZUFBZSxHQUFHLGtDQUF4QjtBQUVBLElBQU1DLGdCQUFnQixHQUFHLGdCQUF6QjtBQUNBLElBQU1DLGlCQUFpQixHQUFHLGdCQUExQjtBQUVPLElBQU1DLFVBQVUsR0FBR1AsbUJBQW1CLENBQUNRLE9BQXBCLEtBQWdDLFNBQW5EO0FBQ0EsSUFBTUMsWUFBWSxXQUFJRixVQUFVLEdBQUcsV0FBSCxHQUFpQlAsbUJBQW1CLENBQUNRLE9BQW5ELHVDQUErRCxTQUFqRixDLENBQTRGOztBQUU1RixJQUFNRSxLQUFLLEdBQUdILFVBQVUsR0FBR0YsZ0JBQUgsR0FBc0JDLGlCQUE5QztBQUNBLElBQU1iLGtCQUFrQixHQUFHLDBDQUEzQjs7QUFFUCxJQUFNa0IsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsV0FBRCxFQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1YsWUFBUCxDQUFqQyxLQUNLLElBQUlVLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPUixlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLElBQU1VLGFBQWEsYUFBTUYsU0FBUyxDQUFDRixZQUFELENBQWYsV0FBbkI7QUFDQSxJQUFNSyxrQkFBa0IsYUFBTUgsU0FBUyxDQUFDRixZQUFELENBQWYsYUFBeEI7QUFDQSxJQUFNTSxjQUFjLEdBQUcsT0FBdkI7QUFFQSxJQUFNQyx5QkFBeUIsR0FBR2hCLG1CQUFtQixDQUFDaUIsaUJBQXBCLElBQXlDLDhCQUEzRTtBQUNBLElBQU1DLFdBQVcsR0FBR2xCLG1CQUFtQixDQUFDbUIsT0FBcEIsS0FBZ0MsWUFBaEMsR0FBK0MsWUFBL0MsR0FBOEQsYUFBbEY7QUFFQSxJQUFNQyxXQUFXLEdBQUc7QUFDekJDLE9BQUssRUFBRSxtREFEa0I7QUFFekJDLGVBQWEsa0JBRlk7QUFHekJDLGFBQVcsRUFDVCxnSkFKdUI7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxRQUFJLEVBQUUsU0FERztBQUVUQyxPQUFHLEVBQUV6QixHQUZJO0FBR1RvQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRJLFVBQU0sRUFBRSxDQUNOO0FBQ0VELFNBQUcsWUFBS3pCLEdBQUwsaUNBREw7QUFFRTJCLFdBQUssRUFBRSxHQUZUO0FBR0VDLFlBQU0sRUFBRSxHQUhWO0FBSUVDLFNBQUcsRUFBRTtBQUpQLEtBRE07QUFOQyxHQUxjO0FBb0J6QkMsU0FBTyxFQUFFO0FBQ1BDLFlBQVEsRUFBRTtBQURIO0FBcEJnQixDQUFwQjtBQXlCUGxDLEtBQUssb0JBQWFXLFlBQWIsRUFBTDtBQUNBWCxLQUFLLCtCQUF3Qkwsa0JBQXhCLEVBQUw7QUFDQUssS0FBSywwQkFBbUJlLGFBQW5CLEVBQUw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Q0FFQTs7QUFDTyxJQUFNZixLQUFLLEdBQUcsU0FBUkEsS0FBUSxDQUFDbUMsU0FBRDtBQUFBLFNBQWlDQyw0Q0FBSyxtQ0FBNEJELFNBQTVCLEVBQXRDO0FBQUEsQ0FBZDtBQUNBLElBQU1FLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNGLFNBQUQ7QUFBQSxTQUFpQ0MsNENBQUssbUNBQTRCRCxTQUE1QixFQUF0QztBQUFBLENBQWQ7QUFFQSxJQUFNcEMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ29DLFNBQUQ7QUFBQSxTQUE4RDtBQUNyRm5DLFNBQUssRUFBRUEsS0FBSyxDQUFDbUMsU0FBRCxDQUR5RTtBQUVyRkUsU0FBSyxFQUFFQSxLQUFLLENBQUNGLFNBQUQ7QUFGeUUsR0FBOUQ7QUFBQSxDQUFsQiIsImZpbGUiOiJzdGF0aWMvY2h1bmtzLzIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJsZXQgcnVudGltZUNvbmZpZzogYW55XG5cbmV4cG9ydCBkZWZhdWx0ICgpID0+IHtcbiAgcmV0dXJuIHJ1bnRpbWVDb25maWdcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNldENvbmZpZyhjb25maWdWYWx1ZTogYW55KTogdm9pZCB7XG4gIHJ1bnRpbWVDb25maWcgPSBjb25maWdWYWx1ZVxufVxuIiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7IF9leHRlbmRzID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiAodGFyZ2V0KSB7IGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7IHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV07IGZvciAodmFyIGtleSBpbiBzb3VyY2UpIHsgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzb3VyY2UsIGtleSkpIHsgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTsgfSB9IH0gcmV0dXJuIHRhcmdldDsgfTsgcmV0dXJuIF9leHRlbmRzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7IH1cblxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IHt9OyB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7IHZhciBrZXksIGk7IGZvciAoaSA9IDA7IGkgPCBzb3VyY2VLZXlzLmxlbmd0aDsgaSsrKSB7IGtleSA9IHNvdXJjZUtleXNbaV07IGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7IHRhcmdldFtrZXldID0gc291cmNlW2tleV07IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5mdW5jdGlvbiBfaW5oZXJpdHNMb29zZShzdWJDbGFzcywgc3VwZXJDbGFzcykgeyBzdWJDbGFzcy5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKHN1cGVyQ2xhc3MucHJvdG90eXBlKTsgc3ViQ2xhc3MucHJvdG90eXBlLmNvbnN0cnVjdG9yID0gc3ViQ2xhc3M7IHN1YkNsYXNzLl9fcHJvdG9fXyA9IHN1cGVyQ2xhc3M7IH1cblxuaW1wb3J0IHsgQ29tcG9uZW50LCBjcmVhdGVFbGVtZW50LCBmb3J3YXJkUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gXCJwcm9wLXR5cGVzXCI7XG5pbXBvcnQgaG9pc3RTdGF0aWNzIGZyb20gXCJob2lzdC1ub24tcmVhY3Qtc3RhdGljc1wiO1xudmFyIFNDUklQVF9NQVAgPSB7fTsgLy8gQSBjb3VudGVyIHVzZWQgdG8gZ2VuZXJhdGUgYSB1bmlxdWUgaWQgZm9yIGVhY2ggY29tcG9uZW50IHRoYXQgdXNlcyB0aGUgZnVuY3Rpb25cblxudmFyIGlkQ291bnQgPSAwO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbWFrZUFzeW5jU2NyaXB0KGdldFNjcmlwdFVSTCwgb3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXBXaXRoQXN5bmNTY3JpcHQoV3JhcHBlZENvbXBvbmVudCkge1xuICAgIHZhciB3cmFwcGVkQ29tcG9uZW50TmFtZSA9IFdyYXBwZWRDb21wb25lbnQuZGlzcGxheU5hbWUgfHwgV3JhcHBlZENvbXBvbmVudC5uYW1lIHx8IFwiQ29tcG9uZW50XCI7XG5cbiAgICB2YXIgQXN5bmNTY3JpcHRMb2FkZXIgPVxuICAgIC8qI19fUFVSRV9fKi9cbiAgICBmdW5jdGlvbiAoX0NvbXBvbmVudCkge1xuICAgICAgX2luaGVyaXRzTG9vc2UoQXN5bmNTY3JpcHRMb2FkZXIsIF9Db21wb25lbnQpO1xuXG4gICAgICBmdW5jdGlvbiBBc3luY1NjcmlwdExvYWRlcihwcm9wcywgY29udGV4dCkge1xuICAgICAgICB2YXIgX3RoaXM7XG5cbiAgICAgICAgX3RoaXMgPSBfQ29tcG9uZW50LmNhbGwodGhpcywgcHJvcHMsIGNvbnRleHQpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLnN0YXRlID0ge307XG4gICAgICAgIF90aGlzLl9fc2NyaXB0VVJMID0gXCJcIjtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgICAgfVxuXG4gICAgICB2YXIgX3Byb3RvID0gQXN5bmNTY3JpcHRMb2FkZXIucHJvdG90eXBlO1xuXG4gICAgICBfcHJvdG8uYXN5bmNTY3JpcHRMb2FkZXJHZXRTY3JpcHRMb2FkZXJJRCA9IGZ1bmN0aW9uIGFzeW5jU2NyaXB0TG9hZGVyR2V0U2NyaXB0TG9hZGVySUQoKSB7XG4gICAgICAgIGlmICghdGhpcy5fX3NjcmlwdExvYWRlcklEKSB7XG4gICAgICAgICAgdGhpcy5fX3NjcmlwdExvYWRlcklEID0gXCJhc3luYy1zY3JpcHQtbG9hZGVyLVwiICsgaWRDb3VudCsrO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuX19zY3JpcHRMb2FkZXJJRDtcbiAgICAgIH07XG5cbiAgICAgIF9wcm90by5zZXR1cFNjcmlwdFVSTCA9IGZ1bmN0aW9uIHNldHVwU2NyaXB0VVJMKCkge1xuICAgICAgICB0aGlzLl9fc2NyaXB0VVJMID0gdHlwZW9mIGdldFNjcmlwdFVSTCA9PT0gXCJmdW5jdGlvblwiID8gZ2V0U2NyaXB0VVJMKCkgOiBnZXRTY3JpcHRVUkw7XG4gICAgICAgIHJldHVybiB0aGlzLl9fc2NyaXB0VVJMO1xuICAgICAgfTtcblxuICAgICAgX3Byb3RvLmFzeW5jU2NyaXB0TG9hZGVySGFuZGxlTG9hZCA9IGZ1bmN0aW9uIGFzeW5jU2NyaXB0TG9hZGVySGFuZGxlTG9hZChzdGF0ZSkge1xuICAgICAgICB2YXIgX3RoaXMyID0gdGhpcztcblxuICAgICAgICAvLyB1c2UgcmVhY3RzIHNldFN0YXRlIGNhbGxiYWNrIHRvIGZpcmUgcHJvcHMuYXN5bmNTY3JpcHRPbkxvYWQgd2l0aCBuZXcgc3RhdGUvZW50cnlcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiBfdGhpczIucHJvcHMuYXN5bmNTY3JpcHRPbkxvYWQgJiYgX3RoaXMyLnByb3BzLmFzeW5jU2NyaXB0T25Mb2FkKF90aGlzMi5zdGF0ZSk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgX3Byb3RvLmFzeW5jU2NyaXB0TG9hZGVyVHJpZ2dlck9uU2NyaXB0TG9hZGVkID0gZnVuY3Rpb24gYXN5bmNTY3JpcHRMb2FkZXJUcmlnZ2VyT25TY3JpcHRMb2FkZWQoKSB7XG4gICAgICAgIHZhciBtYXBFbnRyeSA9IFNDUklQVF9NQVBbdGhpcy5fX3NjcmlwdFVSTF07XG5cbiAgICAgICAgaWYgKCFtYXBFbnRyeSB8fCAhbWFwRW50cnkubG9hZGVkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU2NyaXB0IGlzIG5vdCBsb2FkZWQuXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yICh2YXIgb2JzS2V5IGluIG1hcEVudHJ5Lm9ic2VydmVycykge1xuICAgICAgICAgIG1hcEVudHJ5Lm9ic2VydmVyc1tvYnNLZXldKG1hcEVudHJ5KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGRlbGV0ZSB3aW5kb3dbb3B0aW9ucy5jYWxsYmFja05hbWVdO1xuICAgICAgfTtcblxuICAgICAgX3Byb3RvLmNvbXBvbmVudERpZE1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICAgIHZhciBfdGhpczMgPSB0aGlzO1xuXG4gICAgICAgIHZhciBzY3JpcHRVUkwgPSB0aGlzLnNldHVwU2NyaXB0VVJMKCk7XG4gICAgICAgIHZhciBrZXkgPSB0aGlzLmFzeW5jU2NyaXB0TG9hZGVyR2V0U2NyaXB0TG9hZGVySUQoKTtcbiAgICAgICAgdmFyIF9vcHRpb25zID0gb3B0aW9ucyxcbiAgICAgICAgICAgIGdsb2JhbE5hbWUgPSBfb3B0aW9ucy5nbG9iYWxOYW1lLFxuICAgICAgICAgICAgY2FsbGJhY2tOYW1lID0gX29wdGlvbnMuY2FsbGJhY2tOYW1lLFxuICAgICAgICAgICAgc2NyaXB0SWQgPSBfb3B0aW9ucy5zY3JpcHRJZDsgLy8gY2hlY2sgaWYgZ2xvYmFsIG9iamVjdCBhbHJlYWR5IGF0dGFjaGVkIHRvIHdpbmRvd1xuXG4gICAgICAgIGlmIChnbG9iYWxOYW1lICYmIHR5cGVvZiB3aW5kb3dbZ2xvYmFsTmFtZV0gIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICBTQ1JJUFRfTUFQW3NjcmlwdFVSTF0gPSB7XG4gICAgICAgICAgICBsb2FkZWQ6IHRydWUsXG4gICAgICAgICAgICBvYnNlcnZlcnM6IHt9XG4gICAgICAgICAgfTtcbiAgICAgICAgfSAvLyBjaGVjayBpZiBzY3JpcHQgbG9hZGluZyBhbHJlYWR5XG5cblxuICAgICAgICBpZiAoU0NSSVBUX01BUFtzY3JpcHRVUkxdKSB7XG4gICAgICAgICAgdmFyIGVudHJ5ID0gU0NSSVBUX01BUFtzY3JpcHRVUkxdOyAvLyBpZiBsb2FkZWQgb3IgZXJyb3JlZCB0aGVuIFwiZmluaXNoXCJcblxuICAgICAgICAgIGlmIChlbnRyeSAmJiAoZW50cnkubG9hZGVkIHx8IGVudHJ5LmVycm9yZWQpKSB7XG4gICAgICAgICAgICB0aGlzLmFzeW5jU2NyaXB0TG9hZGVySGFuZGxlTG9hZChlbnRyeSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfSAvLyBpZiBzdGlsbCBsb2FkaW5nIHRoZW4gY2FsbGJhY2sgdG8gb2JzZXJ2ZXIgcXVldWVcblxuXG4gICAgICAgICAgZW50cnkub2JzZXJ2ZXJzW2tleV0gPSBmdW5jdGlvbiAoZW50cnkpIHtcbiAgICAgICAgICAgIHJldHVybiBfdGhpczMuYXN5bmNTY3JpcHRMb2FkZXJIYW5kbGVMb2FkKGVudHJ5KTtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8qXG4gICAgICAgICAqIGhhc24ndCBzdGFydGVkIGxvYWRpbmdcbiAgICAgICAgICogc3RhcnQgdGhlIFwibWFnaWNcIlxuICAgICAgICAgKiBzZXR1cCBzY3JpcHQgdG8gbG9hZCBhbmQgb2JzZXJ2ZXJzXG4gICAgICAgICAqL1xuXG5cbiAgICAgICAgdmFyIG9ic2VydmVycyA9IHt9O1xuXG4gICAgICAgIG9ic2VydmVyc1trZXldID0gZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgcmV0dXJuIF90aGlzMy5hc3luY1NjcmlwdExvYWRlckhhbmRsZUxvYWQoZW50cnkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIFNDUklQVF9NQVBbc2NyaXB0VVJMXSA9IHtcbiAgICAgICAgICBsb2FkZWQ6IGZhbHNlLFxuICAgICAgICAgIG9ic2VydmVyczogb2JzZXJ2ZXJzXG4gICAgICAgIH07XG4gICAgICAgIHZhciBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuICAgICAgICBzY3JpcHQuc3JjID0gc2NyaXB0VVJMO1xuICAgICAgICBzY3JpcHQuYXN5bmMgPSB0cnVlO1xuXG4gICAgICAgIGZvciAodmFyIGF0dHJpYnV0ZSBpbiBvcHRpb25zLmF0dHJpYnV0ZXMpIHtcbiAgICAgICAgICBzY3JpcHQuc2V0QXR0cmlidXRlKGF0dHJpYnV0ZSwgb3B0aW9ucy5hdHRyaWJ1dGVzW2F0dHJpYnV0ZV0pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHNjcmlwdElkKSB7XG4gICAgICAgICAgc2NyaXB0LmlkID0gc2NyaXB0SWQ7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgY2FsbE9ic2VydmVyRnVuY0FuZFJlbW92ZU9ic2VydmVyID0gZnVuY3Rpb24gY2FsbE9ic2VydmVyRnVuY0FuZFJlbW92ZU9ic2VydmVyKGZ1bmMpIHtcbiAgICAgICAgICBpZiAoU0NSSVBUX01BUFtzY3JpcHRVUkxdKSB7XG4gICAgICAgICAgICB2YXIgbWFwRW50cnkgPSBTQ1JJUFRfTUFQW3NjcmlwdFVSTF07XG4gICAgICAgICAgICB2YXIgb2JzZXJ2ZXJzTWFwID0gbWFwRW50cnkub2JzZXJ2ZXJzO1xuXG4gICAgICAgICAgICBmb3IgKHZhciBvYnNLZXkgaW4gb2JzZXJ2ZXJzTWFwKSB7XG4gICAgICAgICAgICAgIGlmIChmdW5jKG9ic2VydmVyc01hcFtvYnNLZXldKSkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBvYnNlcnZlcnNNYXBbb2JzS2V5XTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoY2FsbGJhY2tOYW1lICYmIHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICB3aW5kb3dbY2FsbGJhY2tOYW1lXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfdGhpczMuYXN5bmNTY3JpcHRMb2FkZXJUcmlnZ2VyT25TY3JpcHRMb2FkZWQoKTtcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgc2NyaXB0Lm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgbWFwRW50cnkgPSBTQ1JJUFRfTUFQW3NjcmlwdFVSTF07XG5cbiAgICAgICAgICBpZiAobWFwRW50cnkpIHtcbiAgICAgICAgICAgIG1hcEVudHJ5LmxvYWRlZCA9IHRydWU7XG4gICAgICAgICAgICBjYWxsT2JzZXJ2ZXJGdW5jQW5kUmVtb3ZlT2JzZXJ2ZXIoZnVuY3Rpb24gKG9ic2VydmVyKSB7XG4gICAgICAgICAgICAgIGlmIChjYWxsYmFja05hbWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBvYnNlcnZlcihtYXBFbnRyeSk7XG4gICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHNjcmlwdC5vbmVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBtYXBFbnRyeSA9IFNDUklQVF9NQVBbc2NyaXB0VVJMXTtcblxuICAgICAgICAgIGlmIChtYXBFbnRyeSkge1xuICAgICAgICAgICAgbWFwRW50cnkuZXJyb3JlZCA9IHRydWU7XG4gICAgICAgICAgICBjYWxsT2JzZXJ2ZXJGdW5jQW5kUmVtb3ZlT2JzZXJ2ZXIoZnVuY3Rpb24gKG9ic2VydmVyKSB7XG4gICAgICAgICAgICAgIG9ic2VydmVyKG1hcEVudHJ5KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgICAgfTtcblxuICAgICAgX3Byb3RvLmNvbXBvbmVudFdpbGxVbm1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgICAgIC8vIFJlbW92ZSB0YWcgc2NyaXB0XG4gICAgICAgIHZhciBzY3JpcHRVUkwgPSB0aGlzLl9fc2NyaXB0VVJMO1xuXG4gICAgICAgIGlmIChvcHRpb25zLnJlbW92ZU9uVW5tb3VudCA9PT0gdHJ1ZSkge1xuICAgICAgICAgIHZhciBhbGxTY3JpcHRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG5cbiAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFNjcmlwdHMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICAgIGlmIChhbGxTY3JpcHRzW2ldLnNyYy5pbmRleE9mKHNjcmlwdFVSTCkgPiAtMSkge1xuICAgICAgICAgICAgICBpZiAoYWxsU2NyaXB0c1tpXS5wYXJlbnROb2RlKSB7XG4gICAgICAgICAgICAgICAgYWxsU2NyaXB0c1tpXS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGFsbFNjcmlwdHNbaV0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IC8vIENsZWFuIHRoZSBvYnNlcnZlciBlbnRyeVxuXG5cbiAgICAgICAgdmFyIG1hcEVudHJ5ID0gU0NSSVBUX01BUFtzY3JpcHRVUkxdO1xuXG4gICAgICAgIGlmIChtYXBFbnRyeSkge1xuICAgICAgICAgIGRlbGV0ZSBtYXBFbnRyeS5vYnNlcnZlcnNbdGhpcy5hc3luY1NjcmlwdExvYWRlckdldFNjcmlwdExvYWRlcklEKCldO1xuXG4gICAgICAgICAgaWYgKG9wdGlvbnMucmVtb3ZlT25Vbm1vdW50ID09PSB0cnVlKSB7XG4gICAgICAgICAgICBkZWxldGUgU0NSSVBUX01BUFtzY3JpcHRVUkxdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgX3Byb3RvLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgICAgdmFyIGdsb2JhbE5hbWUgPSBvcHRpb25zLmdsb2JhbE5hbWU7IC8vIHJlbW92ZSBhc3luY1NjcmlwdE9uTG9hZCBmcm9tIGNoaWxkUHJvcHNcblxuICAgICAgICB2YXIgX3RoaXMkcHJvcHMgPSB0aGlzLnByb3BzLFxuICAgICAgICAgICAgYXN5bmNTY3JpcHRPbkxvYWQgPSBfdGhpcyRwcm9wcy5hc3luY1NjcmlwdE9uTG9hZCxcbiAgICAgICAgICAgIGZvcndhcmRlZFJlZiA9IF90aGlzJHByb3BzLmZvcndhcmRlZFJlZixcbiAgICAgICAgICAgIGNoaWxkUHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShfdGhpcyRwcm9wcywgW1wiYXN5bmNTY3JpcHRPbkxvYWRcIiwgXCJmb3J3YXJkZWRSZWZcIl0pOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVudXNlZC12YXJzXG5cblxuICAgICAgICBpZiAoZ2xvYmFsTmFtZSAmJiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgY2hpbGRQcm9wc1tnbG9iYWxOYW1lXSA9IHR5cGVvZiB3aW5kb3dbZ2xvYmFsTmFtZV0gIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3dbZ2xvYmFsTmFtZV0gOiB1bmRlZmluZWQ7XG4gICAgICAgIH1cblxuICAgICAgICBjaGlsZFByb3BzLnJlZiA9IGZvcndhcmRlZFJlZjtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQoV3JhcHBlZENvbXBvbmVudCwgY2hpbGRQcm9wcyk7XG4gICAgICB9O1xuXG4gICAgICByZXR1cm4gQXN5bmNTY3JpcHRMb2FkZXI7XG4gICAgfShDb21wb25lbnQpOyAvLyBOb3RlIHRoZSBzZWNvbmQgcGFyYW0gXCJyZWZcIiBwcm92aWRlZCBieSBSZWFjdC5mb3J3YXJkUmVmLlxuICAgIC8vIFdlIGNhbiBwYXNzIGl0IGFsb25nIHRvIEFzeW5jU2NyaXB0TG9hZGVyIGFzIGEgcmVndWxhciBwcm9wLCBlLmcuIFwiZm9yd2FyZGVkUmVmXCJcbiAgICAvLyBBbmQgaXQgY2FuIHRoZW4gYmUgYXR0YWNoZWQgdG8gdGhlIENvbXBvbmVudC5cblxuXG4gICAgdmFyIEZvcndhcmRlZENvbXBvbmVudCA9IGZvcndhcmRSZWYoZnVuY3Rpb24gKHByb3BzLCByZWYpIHtcbiAgICAgIHJldHVybiBjcmVhdGVFbGVtZW50KEFzeW5jU2NyaXB0TG9hZGVyLCBfZXh0ZW5kcyh7fSwgcHJvcHMsIHtcbiAgICAgICAgZm9yd2FyZGVkUmVmOiByZWZcbiAgICAgIH0pKTtcbiAgICB9KTtcbiAgICBGb3J3YXJkZWRDb21wb25lbnQuZGlzcGxheU5hbWUgPSBcIkFzeW5jU2NyaXB0TG9hZGVyKFwiICsgd3JhcHBlZENvbXBvbmVudE5hbWUgKyBcIilcIjtcbiAgICBGb3J3YXJkZWRDb21wb25lbnQucHJvcFR5cGVzID0ge1xuICAgICAgYXN5bmNTY3JpcHRPbkxvYWQ6IFByb3BUeXBlcy5mdW5jXG4gICAgfTtcbiAgICByZXR1cm4gaG9pc3RTdGF0aWNzKEZvcndhcmRlZENvbXBvbmVudCwgV3JhcHBlZENvbXBvbmVudCk7XG4gIH07XG59IiwiaW1wb3J0IFJlY2FwdGNoYVdyYXBwZXIgZnJvbSBcIi4vcmVjYXB0Y2hhLXdyYXBwZXJcIjtcbmltcG9ydCBSZUNBUFRDSEEgZnJvbSBcIi4vcmVjYXB0Y2hhXCI7XG5leHBvcnQgZGVmYXVsdCBSZWNhcHRjaGFXcmFwcGVyO1xuZXhwb3J0IHsgUmVDQVBUQ0hBIH07IiwiaW1wb3J0IFJlQ0FQVENIQSBmcm9tIFwiLi9yZWNhcHRjaGFcIjtcbmltcG9ydCBtYWtlQXN5bmNTY3JpcHRMb2FkZXIgZnJvbSBcInJlYWN0LWFzeW5jLXNjcmlwdFwiO1xudmFyIGNhbGxiYWNrTmFtZSA9IFwib25sb2FkY2FsbGJhY2tcIjtcbnZhciBnbG9iYWxOYW1lID0gXCJncmVjYXB0Y2hhXCI7XG5cbmZ1bmN0aW9uIGdldE9wdGlvbnMoKSB7XG4gIHJldHVybiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5yZWNhcHRjaGFPcHRpb25zIHx8IHt9O1xufVxuXG5mdW5jdGlvbiBnZXRVUkwoKSB7XG4gIHZhciBkeW5hbWljT3B0aW9ucyA9IGdldE9wdGlvbnMoKTtcbiAgdmFyIGhvc3RuYW1lID0gZHluYW1pY09wdGlvbnMudXNlUmVjYXB0Y2hhTmV0ID8gXCJyZWNhcHRjaGEubmV0XCIgOiBcInd3dy5nb29nbGUuY29tXCI7XG4gIHJldHVybiBcImh0dHBzOi8vXCIgKyBob3N0bmFtZSArIFwiL3JlY2FwdGNoYS9hcGkuanM/b25sb2FkPVwiICsgY2FsbGJhY2tOYW1lICsgXCImcmVuZGVyPWV4cGxpY2l0XCI7XG59XG5cbmV4cG9ydCBkZWZhdWx0IG1ha2VBc3luY1NjcmlwdExvYWRlcihnZXRVUkwsIHtcbiAgY2FsbGJhY2tOYW1lOiBjYWxsYmFja05hbWUsXG4gIGdsb2JhbE5hbWU6IGdsb2JhbE5hbWVcbn0pKFJlQ0FQVENIQSk7IiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7IF9leHRlbmRzID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiAodGFyZ2V0KSB7IGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7IHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV07IGZvciAodmFyIGtleSBpbiBzb3VyY2UpIHsgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzb3VyY2UsIGtleSkpIHsgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTsgfSB9IH0gcmV0dXJuIHRhcmdldDsgfTsgcmV0dXJuIF9leHRlbmRzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7IH1cblxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IHt9OyB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7IHZhciBrZXksIGk7IGZvciAoaSA9IDA7IGkgPCBzb3VyY2VLZXlzLmxlbmd0aDsgaSsrKSB7IGtleSA9IHNvdXJjZUtleXNbaV07IGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7IHRhcmdldFtrZXldID0gc291cmNlW2tleV07IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5mdW5jdGlvbiBfYXNzZXJ0VGhpc0luaXRpYWxpemVkKHNlbGYpIHsgaWYgKHNlbGYgPT09IHZvaWQgMCkgeyB0aHJvdyBuZXcgUmVmZXJlbmNlRXJyb3IoXCJ0aGlzIGhhc24ndCBiZWVuIGluaXRpYWxpc2VkIC0gc3VwZXIoKSBoYXNuJ3QgYmVlbiBjYWxsZWRcIik7IH0gcmV0dXJuIHNlbGY7IH1cblxuZnVuY3Rpb24gX2luaGVyaXRzTG9vc2Uoc3ViQ2xhc3MsIHN1cGVyQ2xhc3MpIHsgc3ViQ2xhc3MucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckNsYXNzLnByb3RvdHlwZSk7IHN1YkNsYXNzLnByb3RvdHlwZS5jb25zdHJ1Y3RvciA9IHN1YkNsYXNzOyBzdWJDbGFzcy5fX3Byb3RvX18gPSBzdXBlckNsYXNzOyB9XG5cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSBcInByb3AtdHlwZXNcIjtcblxudmFyIFJlQ0FQVENIQSA9XG4vKiNfX1BVUkVfXyovXG5mdW5jdGlvbiAoX1JlYWN0JENvbXBvbmVudCkge1xuICBfaW5oZXJpdHNMb29zZShSZUNBUFRDSEEsIF9SZWFjdCRDb21wb25lbnQpO1xuXG4gIGZ1bmN0aW9uIFJlQ0FQVENIQSgpIHtcbiAgICB2YXIgX3RoaXM7XG5cbiAgICBfdGhpcyA9IF9SZWFjdCRDb21wb25lbnQuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgIF90aGlzLmhhbmRsZUV4cGlyZWQgPSBfdGhpcy5oYW5kbGVFeHBpcmVkLmJpbmQoX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpcykpO1xuICAgIF90aGlzLmhhbmRsZUVycm9yZWQgPSBfdGhpcy5oYW5kbGVFcnJvcmVkLmJpbmQoX2Fzc2VydFRoaXNJbml0aWFsaXplZChfdGhpcykpO1xuICAgIF90aGlzLmhhbmRsZUNoYW5nZSA9IF90aGlzLmhhbmRsZUNoYW5nZS5iaW5kKF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQoX3RoaXMpKTtcbiAgICBfdGhpcy5oYW5kbGVSZWNhcHRjaGFSZWYgPSBfdGhpcy5oYW5kbGVSZWNhcHRjaGFSZWYuYmluZChfYXNzZXJ0VGhpc0luaXRpYWxpemVkKF90aGlzKSk7XG4gICAgcmV0dXJuIF90aGlzO1xuICB9XG5cbiAgdmFyIF9wcm90byA9IFJlQ0FQVENIQS5wcm90b3R5cGU7XG5cbiAgX3Byb3RvLmdldFZhbHVlID0gZnVuY3Rpb24gZ2V0VmFsdWUoKSB7XG4gICAgaWYgKHRoaXMucHJvcHMuZ3JlY2FwdGNoYSAmJiB0aGlzLl93aWRnZXRJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gdGhpcy5wcm9wcy5ncmVjYXB0Y2hhLmdldFJlc3BvbnNlKHRoaXMuX3dpZGdldElkKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBfcHJvdG8uZ2V0V2lkZ2V0SWQgPSBmdW5jdGlvbiBnZXRXaWRnZXRJZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wcy5ncmVjYXB0Y2hhICYmIHRoaXMuX3dpZGdldElkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB0aGlzLl93aWRnZXRJZDtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBfcHJvdG8uZXhlY3V0ZSA9IGZ1bmN0aW9uIGV4ZWN1dGUoKSB7XG4gICAgdmFyIGdyZWNhcHRjaGEgPSB0aGlzLnByb3BzLmdyZWNhcHRjaGE7XG5cbiAgICBpZiAoZ3JlY2FwdGNoYSAmJiB0aGlzLl93aWRnZXRJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZ3JlY2FwdGNoYS5leGVjdXRlKHRoaXMuX3dpZGdldElkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fZXhlY3V0ZVJlcXVlc3RlZCA9IHRydWU7XG4gICAgfVxuICB9O1xuXG4gIF9wcm90by5leGVjdXRlQXN5bmMgPSBmdW5jdGlvbiBleGVjdXRlQXN5bmMoKSB7XG4gICAgdmFyIF90aGlzMiA9IHRoaXM7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgX3RoaXMyLmV4ZWN1dGlvblJlc29sdmUgPSByZXNvbHZlO1xuICAgICAgX3RoaXMyLmV4ZWN1dGlvblJlamVjdCA9IHJlamVjdDtcblxuICAgICAgX3RoaXMyLmV4ZWN1dGUoKTtcbiAgICB9KTtcbiAgfTtcblxuICBfcHJvdG8ucmVzZXQgPSBmdW5jdGlvbiByZXNldCgpIHtcbiAgICBpZiAodGhpcy5wcm9wcy5ncmVjYXB0Y2hhICYmIHRoaXMuX3dpZGdldElkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcHMuZ3JlY2FwdGNoYS5yZXNldCh0aGlzLl93aWRnZXRJZCk7XG4gICAgfVxuICB9O1xuXG4gIF9wcm90by5oYW5kbGVFeHBpcmVkID0gZnVuY3Rpb24gaGFuZGxlRXhwaXJlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wcy5vbkV4cGlyZWQpIHtcbiAgICAgIHRoaXMucHJvcHMub25FeHBpcmVkKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaGFuZGxlQ2hhbmdlKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBfcHJvdG8uaGFuZGxlRXJyb3JlZCA9IGZ1bmN0aW9uIGhhbmRsZUVycm9yZWQoKSB7XG4gICAgaWYgKHRoaXMucHJvcHMub25FcnJvcmVkKSB7XG4gICAgICB0aGlzLnByb3BzLm9uRXJyb3JlZCgpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmV4ZWN1dGlvblJlamVjdCkge1xuICAgICAgdGhpcy5leGVjdXRpb25SZWplY3QoKTtcbiAgICAgIGRlbGV0ZSB0aGlzLmV4ZWN1dGlvblJlc29sdmU7XG4gICAgICBkZWxldGUgdGhpcy5leGVjdXRpb25SZWplY3Q7XG4gICAgfVxuICB9O1xuXG4gIF9wcm90by5oYW5kbGVDaGFuZ2UgPSBmdW5jdGlvbiBoYW5kbGVDaGFuZ2UodG9rZW4pIHtcbiAgICBpZiAodGhpcy5wcm9wcy5vbkNoYW5nZSkge1xuICAgICAgdGhpcy5wcm9wcy5vbkNoYW5nZSh0b2tlbik7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuZXhlY3V0aW9uUmVzb2x2ZSkge1xuICAgICAgdGhpcy5leGVjdXRpb25SZXNvbHZlKHRva2VuKTtcbiAgICAgIGRlbGV0ZSB0aGlzLmV4ZWN1dGlvblJlamVjdDtcbiAgICAgIGRlbGV0ZSB0aGlzLmV4ZWN1dGlvblJlc29sdmU7XG4gICAgfVxuICB9O1xuXG4gIF9wcm90by5leHBsaWNpdFJlbmRlciA9IGZ1bmN0aW9uIGV4cGxpY2l0UmVuZGVyKCkge1xuICAgIGlmICh0aGlzLnByb3BzLmdyZWNhcHRjaGEgJiYgdGhpcy5wcm9wcy5ncmVjYXB0Y2hhLnJlbmRlciAmJiB0aGlzLl93aWRnZXRJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YXIgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICB0aGlzLl93aWRnZXRJZCA9IHRoaXMucHJvcHMuZ3JlY2FwdGNoYS5yZW5kZXIod3JhcHBlciwge1xuICAgICAgICBzaXRla2V5OiB0aGlzLnByb3BzLnNpdGVrZXksXG4gICAgICAgIGNhbGxiYWNrOiB0aGlzLmhhbmRsZUNoYW5nZSxcbiAgICAgICAgdGhlbWU6IHRoaXMucHJvcHMudGhlbWUsXG4gICAgICAgIHR5cGU6IHRoaXMucHJvcHMudHlwZSxcbiAgICAgICAgdGFiaW5kZXg6IHRoaXMucHJvcHMudGFiaW5kZXgsXG4gICAgICAgIFwiZXhwaXJlZC1jYWxsYmFja1wiOiB0aGlzLmhhbmRsZUV4cGlyZWQsXG4gICAgICAgIFwiZXJyb3ItY2FsbGJhY2tcIjogdGhpcy5oYW5kbGVFcnJvcmVkLFxuICAgICAgICBzaXplOiB0aGlzLnByb3BzLnNpemUsXG4gICAgICAgIHN0b2tlbjogdGhpcy5wcm9wcy5zdG9rZW4sXG4gICAgICAgIGhsOiB0aGlzLnByb3BzLmhsLFxuICAgICAgICBiYWRnZTogdGhpcy5wcm9wcy5iYWRnZVxuICAgICAgfSk7XG4gICAgICB0aGlzLmNhcHRjaGEuYXBwZW5kQ2hpbGQod3JhcHBlcik7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2V4ZWN1dGVSZXF1ZXN0ZWQgJiYgdGhpcy5wcm9wcy5ncmVjYXB0Y2hhICYmIHRoaXMuX3dpZGdldElkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuX2V4ZWN1dGVSZXF1ZXN0ZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuZXhlY3V0ZSgpO1xuICAgIH1cbiAgfTtcblxuICBfcHJvdG8uY29tcG9uZW50RGlkTW91bnQgPSBmdW5jdGlvbiBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICB0aGlzLmV4cGxpY2l0UmVuZGVyKCk7XG4gIH07XG5cbiAgX3Byb3RvLmNvbXBvbmVudERpZFVwZGF0ZSA9IGZ1bmN0aW9uIGNvbXBvbmVudERpZFVwZGF0ZSgpIHtcbiAgICB0aGlzLmV4cGxpY2l0UmVuZGVyKCk7XG4gIH07XG5cbiAgX3Byb3RvLmNvbXBvbmVudFdpbGxVbm1vdW50ID0gZnVuY3Rpb24gY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgaWYgKHRoaXMuX3dpZGdldElkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuZGVsYXlPZkNhcHRjaGFJZnJhbWVSZW1vdmluZygpO1xuICAgICAgdGhpcy5yZXNldCgpO1xuICAgIH1cbiAgfTtcblxuICBfcHJvdG8uZGVsYXlPZkNhcHRjaGFJZnJhbWVSZW1vdmluZyA9IGZ1bmN0aW9uIGRlbGF5T2ZDYXB0Y2hhSWZyYW1lUmVtb3ZpbmcoKSB7XG4gICAgdmFyIHRlbXBvcmFyeU5vZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGVtcG9yYXJ5Tm9kZSk7XG4gICAgdGVtcG9yYXJ5Tm9kZS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7IC8vIG1vdmUgb2YgdGhlIHJlY2FwdGNoYSB0byBhIHRlbXBvcmFyeSBub2RlXG5cbiAgICB3aGlsZSAodGhpcy5jYXB0Y2hhLmZpcnN0Q2hpbGQpIHtcbiAgICAgIHRlbXBvcmFyeU5vZGUuYXBwZW5kQ2hpbGQodGhpcy5jYXB0Y2hhLmZpcnN0Q2hpbGQpO1xuICAgIH0gLy8gZGVsZXRlIHRoZSB0ZW1wb3Jhcnkgbm9kZSBhZnRlciByZXNldCB3aWxsIGJlIGRvbmVcblxuXG4gICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRlbXBvcmFyeU5vZGUpO1xuICAgIH0sIDUwMDApO1xuICB9O1xuXG4gIF9wcm90by5oYW5kbGVSZWNhcHRjaGFSZWYgPSBmdW5jdGlvbiBoYW5kbGVSZWNhcHRjaGFSZWYoZWxlbSkge1xuICAgIHRoaXMuY2FwdGNoYSA9IGVsZW07XG4gIH07XG5cbiAgX3Byb3RvLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAvLyBjb25zdW1lIHByb3BlcnRpZXMgb3duZWQgYnkgdGhlIHJlQ0FUUENIQSwgcGFzcyB0aGUgcmVzdCB0byB0aGUgZGl2IHNvIHRoZSB1c2VyIGNhbiBzdHlsZSBpdC5cblxuICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXG4gICAgdmFyIF90aGlzJHByb3BzID0gdGhpcy5wcm9wcyxcbiAgICAgICAgc2l0ZWtleSA9IF90aGlzJHByb3BzLnNpdGVrZXksXG4gICAgICAgIG9uQ2hhbmdlID0gX3RoaXMkcHJvcHMub25DaGFuZ2UsXG4gICAgICAgIHRoZW1lID0gX3RoaXMkcHJvcHMudGhlbWUsXG4gICAgICAgIHR5cGUgPSBfdGhpcyRwcm9wcy50eXBlLFxuICAgICAgICB0YWJpbmRleCA9IF90aGlzJHByb3BzLnRhYmluZGV4LFxuICAgICAgICBvbkV4cGlyZWQgPSBfdGhpcyRwcm9wcy5vbkV4cGlyZWQsXG4gICAgICAgIG9uRXJyb3JlZCA9IF90aGlzJHByb3BzLm9uRXJyb3JlZCxcbiAgICAgICAgc2l6ZSA9IF90aGlzJHByb3BzLnNpemUsXG4gICAgICAgIHN0b2tlbiA9IF90aGlzJHByb3BzLnN0b2tlbixcbiAgICAgICAgZ3JlY2FwdGNoYSA9IF90aGlzJHByb3BzLmdyZWNhcHRjaGEsXG4gICAgICAgIGJhZGdlID0gX3RoaXMkcHJvcHMuYmFkZ2UsXG4gICAgICAgIGhsID0gX3RoaXMkcHJvcHMuaGwsXG4gICAgICAgIGNoaWxkUHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShfdGhpcyRwcm9wcywgW1wic2l0ZWtleVwiLCBcIm9uQ2hhbmdlXCIsIFwidGhlbWVcIiwgXCJ0eXBlXCIsIFwidGFiaW5kZXhcIiwgXCJvbkV4cGlyZWRcIiwgXCJvbkVycm9yZWRcIiwgXCJzaXplXCIsIFwic3Rva2VuXCIsIFwiZ3JlY2FwdGNoYVwiLCBcImJhZGdlXCIsIFwiaGxcIl0pO1xuICAgIC8qIGVzbGludC1lbmFibGUgbm8tdW51c2VkLXZhcnMgKi9cblxuXG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgX2V4dGVuZHMoe30sIGNoaWxkUHJvcHMsIHtcbiAgICAgIHJlZjogdGhpcy5oYW5kbGVSZWNhcHRjaGFSZWZcbiAgICB9KSk7XG4gIH07XG5cbiAgcmV0dXJuIFJlQ0FQVENIQTtcbn0oUmVhY3QuQ29tcG9uZW50KTtcblxuZXhwb3J0IHsgUmVDQVBUQ0hBIGFzIGRlZmF1bHQgfTtcblJlQ0FQVENIQS5kaXNwbGF5TmFtZSA9IFwiUmVDQVBUQ0hBXCI7XG5SZUNBUFRDSEEucHJvcFR5cGVzID0ge1xuICBzaXRla2V5OiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIG9uQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgZ3JlY2FwdGNoYTogUHJvcFR5cGVzLm9iamVjdCxcbiAgdGhlbWU6IFByb3BUeXBlcy5vbmVPZihbXCJkYXJrXCIsIFwibGlnaHRcIl0pLFxuICB0eXBlOiBQcm9wVHlwZXMub25lT2YoW1wiaW1hZ2VcIiwgXCJhdWRpb1wiXSksXG4gIHRhYmluZGV4OiBQcm9wVHlwZXMubnVtYmVyLFxuICBvbkV4cGlyZWQ6IFByb3BUeXBlcy5mdW5jLFxuICBvbkVycm9yZWQ6IFByb3BUeXBlcy5mdW5jLFxuICBzaXplOiBQcm9wVHlwZXMub25lT2YoW1wiY29tcGFjdFwiLCBcIm5vcm1hbFwiLCBcImludmlzaWJsZVwiXSksXG4gIHN0b2tlbjogUHJvcFR5cGVzLnN0cmluZyxcbiAgaGw6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGJhZGdlOiBQcm9wVHlwZXMub25lT2YoW1wiYm90dG9tcmlnaHRcIiwgXCJib3R0b21sZWZ0XCIsIFwiaW5saW5lXCJdKVxufTtcblJlQ0FQVENIQS5kZWZhdWx0UHJvcHMgPSB7XG4gIG9uQ2hhbmdlOiBmdW5jdGlvbiBvbkNoYW5nZSgpIHt9LFxuICB0aGVtZTogXCJsaWdodFwiLFxuICB0eXBlOiBcImltYWdlXCIsXG4gIHRhYmluZGV4OiAwLFxuICBzaXplOiBcIm5vcm1hbFwiLFxuICBiYWRnZTogXCJib3R0b21yaWdodFwiXG59OyIsImltcG9ydCBSZWFjdCwgeyBDaGFuZ2VFdmVudCwgQ29tcG9uZW50LCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBSZUNBUFRDSEEgZnJvbSBcInJlYWN0LWdvb2dsZS1yZWNhcHRjaGFcIjtcbmltcG9ydCB7IENBUFRDSEFfQ0xJRU5UX0tFWSB9IGZyb20gXCIuLi8uLi9jb25maWdcIjtcbmltcG9ydCB7IHN0YXRlcyB9IGZyb20gXCIuLi8uLi9yZWR1Y2Vycy9zaGFyZWRcIjtcbmludGVyZmFjZSBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtUHJvcHMge1xuICBlbWFpbFNlbmRpbmdTdGF0ZTogc3RyaW5nO1xuICBoYW5kbGVTZW5kQ2VydGlmaWNhdGU6IChldmVudDogeyBjYXB0Y2hhOiBzdHJpbmc7IGVtYWlsOiBzdHJpbmcgfSkgPT4gdm9pZDtcbiAgaGFuZGxlU2hhcmluZ1RvZ2dsZTogKCkgPT4gdm9pZDtcbn1cbmludGVyZmFjZSBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtU3RhdGUge1xuICBjYXB0Y2hhOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG59XG5jbGFzcyBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtIGV4dGVuZHMgQ29tcG9uZW50PENlcnRpZmljYXRlU2hhcmluZ0Zvcm1Qcm9wcywgQ2VydGlmaWNhdGVTaGFyaW5nRm9ybVN0YXRlPiB7XG4gIGNvbnN0cnVjdG9yKHByb3BzOiBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtUHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG5cbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgY2FwdGNoYTogXCJcIixcbiAgICAgIGVtYWlsOiBcIlwiLFxuICAgIH07XG5cbiAgICB0aGlzLmhhbmRsZUNhcHRjaGFDaGFuZ2UgPSB0aGlzLmhhbmRsZUNhcHRjaGFDaGFuZ2UuYmluZCh0aGlzKTtcbiAgICB0aGlzLmhhbmRsZUVtYWlsQ2hhbmdlID0gdGhpcy5oYW5kbGVFbWFpbENoYW5nZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMuaGFuZGxlU2VuZCA9IHRoaXMuaGFuZGxlU2VuZC5iaW5kKHRoaXMpO1xuICB9XG5cbiAgaGFuZGxlQ2FwdGNoYUNoYW5nZSh2YWx1ZTogc3RyaW5nIHwgbnVsbCk6IHZvaWQge1xuICAgIGlmICh2YWx1ZSkgdGhpcy5zZXRTdGF0ZSh7IGNhcHRjaGE6IHZhbHVlIH0pO1xuICB9XG5cbiAgaGFuZGxlRW1haWxDaGFuZ2UoZXZlbnQ6IENoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KTogdm9pZCB7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IGVtYWlsOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG4gIH1cblxuICBoYW5kbGVTZW5kKCk6IHZvaWQge1xuICAgIGNvbnN0IHsgaGFuZGxlU2VuZENlcnRpZmljYXRlLCBlbWFpbFNlbmRpbmdTdGF0ZSB9ID0gdGhpcy5wcm9wcztcbiAgICBpZiAoZW1haWxTZW5kaW5nU3RhdGUgIT09IHN0YXRlcy5QRU5ESU5HKSB7XG4gICAgICBoYW5kbGVTZW5kQ2VydGlmaWNhdGUoe1xuICAgICAgICBlbWFpbDogdGhpcy5zdGF0ZS5lbWFpbCxcbiAgICAgICAgY2FwdGNoYTogdGhpcy5zdGF0ZS5jYXB0Y2hhLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCk6IFJlYWN0Tm9kZSB7XG4gICAgY29uc3QgeyBlbWFpbFNlbmRpbmdTdGF0ZSB9ID0gdGhpcy5wcm9wcztcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMlwiPlNlbmQgeW91ciBjZXJ0aWZpY2F0ZTwvaDM+XG4gICAgICAgIDxwPlRoaXMgc2VuZHMgYW4gZW1haWwgd2l0aCB5b3VyIC5vcGVuY2VydCBhdHRhY2hlZCwgYW5kIGluc3RydWN0aW9ucyBvbiBob3cgdG8gdmlldyBpdC48L3A+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgdy02NFwiXG4gICAgICAgICAgdmFsdWU9e3RoaXMuc3RhdGUuZW1haWx9XG4gICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlRW1haWxDaGFuZ2V9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZWNpcGllbnQncyBlbWFpbFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciB3LWZ1bGwgbXktNFwiPlxuICAgICAgICAgIDxSZUNBUFRDSEEgc2l0ZWtleT17Q0FQVENIQV9DTElFTlRfS0VZfSBvbkNoYW5nZT17dGhpcy5oYW5kbGVDYXB0Y2hhQ2hhbmdlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2VtYWlsU2VuZGluZ1N0YXRlID09PSBzdGF0ZXMuU1VDQ0VTUyAmJiA8ZGl2IGNsYXNzTmFtZT1cIm15LTRcIj5FbWFpbCBzdWNjZXNzZnVsbHkgc2VudCE8L2Rpdj59XG4gICAgICAgIHtlbWFpbFNlbmRpbmdTdGF0ZSA9PT0gc3RhdGVzLkZBSUxVUkUgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNFwiPkFuIGVycm9yIG9jY3VyZWQsIHBsZWFzZSBjaGVjayB5b3VyIGVtYWlsIGFuZCBjYXB0Y2hhPC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ1dHRvbiBiZy1uYXZ5IHRleHQtd2hpdGUgaG92ZXI6YmctbmF2eS0zMDBcIiBvbkNsaWNrPXt0aGlzLmhhbmRsZVNlbmR9PlxuICAgICAgICAgICAgU2VuZFxuICAgICAgICAgICAge2VtYWlsU2VuZGluZ1N0YXRlID09PSBzdGF0ZXMuUEVORElORyAmJiA8aSBjbGFzc05hbWU9XCJtbC0yIGZhcyBmYS1zcGlubmVyIGZhLXB1bHNlXCIgLz59XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuLy8gbG9va3MgbmVlZGVkIGZvciBkeW5hbWljIGltcG9ydFxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1kZWZhdWx0LWV4cG9ydFxuZXhwb3J0IGRlZmF1bHQgQ2VydGlmaWNhdGVTaGFyaW5nRm9ybTtcbiIsImltcG9ydCBnZXRDb25maWcgZnJvbSBcIm5leHQvY29uZmlnXCI7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tIFwiLi4vdXRpbHMvbG9nZ2VyXCI7XG5cbmNvbnN0IHsgdHJhY2UgfSA9IGdldExvZ2dlcihcImNvbmZpZ1wiKTtcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS92ZXJjZWwvbmV4dC5qcy9pc3N1ZXMvNzcxM1xuY29uc3QgeyBwdWJsaWNSdW50aW1lQ29uZmlnID0ge30gfSA9IGdldENvbmZpZygpO1xuXG5leHBvcnQgY29uc3QgVVJMID0gXCJodHRwczovL29wZW5jZXJ0cy5pb1wiO1xuY29uc3QgQVBJX01BSU5fVVJMID0gXCJodHRwczovL2FwaS5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9ST1BTVEVOX1VSTCA9IFwiaHR0cHM6Ly9hcGktcm9wc3Rlbi5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9SSU5LRUJZX1VSTCA9IFwiaHR0cHM6Ly9hcGktcmlua2VieS5vcGVuY2VydHMuaW9cIjtcblxuY29uc3QgR0FfUFJPRFVDVElPTl9JRCA9IFwiVUEtMTMwNDkyMjYwLTFcIjtcbmNvbnN0IEdBX0RFVkVMT1BNRU5UX0lEID0gXCJVQS0xMzA0OTIyNjAtMlwiO1xuXG5leHBvcnQgY29uc3QgSVNfTUFJTk5FVCA9IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yayA9PT0gXCJtYWlubmV0XCI7XG5leHBvcnQgY29uc3QgTkVUV09SS19OQU1FID0gKElTX01BSU5ORVQgPyBcImhvbWVzdGVhZFwiIDogcHVibGljUnVudGltZUNvbmZpZy5uZXR3b3JrKSA/PyBcInJvcHN0ZW5cIjsgLy8gZXhwZWN0ZWQgYnkgZXRoZXJzXG5cbmV4cG9ydCBjb25zdCBHQV9JRCA9IElTX01BSU5ORVQgPyBHQV9QUk9EVUNUSU9OX0lEIDogR0FfREVWRUxPUE1FTlRfSUQ7XG5leHBvcnQgY29uc3QgQ0FQVENIQV9DTElFTlRfS0VZID0gXCI2TGZpTDNFVUFBQUFBSHJmTHZsMktoUkFjWHBhbk5YRHF1Nk0wQ0NTXCI7XG5cbmNvbnN0IGdldEFwaVVybCA9IChuZXR3b3JrTmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgaWYgKG5ldHdvcmtOYW1lID09PSBcImhvbWVzdGVhZFwiKSByZXR1cm4gQVBJX01BSU5fVVJMO1xuICBlbHNlIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJyaW5rZWJ5XCIpIHJldHVybiBBUElfUklOS0VCWV9VUkw7XG4gIHJldHVybiBBUElfUk9QU1RFTl9VUkw7XG59O1xuZXhwb3J0IGNvbnN0IEVNQUlMX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vZW1haWxgO1xuZXhwb3J0IGNvbnN0IFNIQVJFX0xJTktfQVBJX1VSTCA9IGAke2dldEFwaVVybChORVRXT1JLX05BTUUpfS9zdG9yYWdlYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX1RUTCA9IDEyMDk2MDA7XG5cbmV4cG9ydCBjb25zdCBMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSID0gcHVibGljUnVudGltZUNvbmZpZy5sZWdhY3lSZW5kZXJlclVybCB8fCBcImh0dHBzOi8vbGVnYWN5Lm9wZW5jZXJ0cy5pby9cIjtcbmV4cG9ydCBjb25zdCBFTlZJUk9OTUVOVCA9IHB1YmxpY1J1bnRpbWVDb25maWcuY29udGV4dCA9PT0gXCJwcm9kdWN0aW9uXCIgPyBcInByb2R1Y3Rpb25cIiA6IFwiZGV2ZWxvcG1lbnRcIjtcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VPID0ge1xuICB0aXRsZTogXCJBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gIHRpdGxlVGVtcGxhdGU6IGBPcGVuQ2VydHMgLSAlc2AsXG4gIGRlc2NyaXB0aW9uOlxuICAgIFwiV2hldGhlciB5b3UncmUgYSBzdHVkZW50IG9yIGFuIGVtcGxveWVyLCBPcGVuQ2VydHMgbGV0cyB5b3UgdmVyaWZ5IHRoZSBjZXJ0aWZpY2F0ZXMgeW91IGhhdmUgb2YgYW55b25lIGZyb20gYW55IGluc3RpdHV0aW9uLiBBbGwgaW4gb25lIHBsYWNlLlwiLFxuICBvcGVuR3JhcGg6IHtcbiAgICB0eXBlOiBcIndlYnNpdGVcIixcbiAgICB1cmw6IFVSTCxcbiAgICB0aXRsZTogXCJPcGVuQ2VydHMgLSBBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgICBpbWFnZXM6IFtcbiAgICAgIHtcbiAgICAgICAgdXJsOiBgJHtVUkx9L3N0YXRpYy9pbWFnZXMvb3BlbmNlcnRzLnBuZ2AsXG4gICAgICAgIHdpZHRoOiA4MDAsXG4gICAgICAgIGhlaWdodDogNjAwLFxuICAgICAgICBhbHQ6IFwiT3BlbkNlcnRzXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHR3aXR0ZXI6IHtcbiAgICBjYXJkVHlwZTogXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIsXG4gIH0sXG59O1xuXG50cmFjZShgTkVUV09SSzogJHtORVRXT1JLX05BTUV9YCk7XG50cmFjZShgQ0FQVENIQV9DTElFTlRfS0VZOiAke0NBUFRDSEFfQ0xJRU5UX0tFWX1gKTtcbnRyYWNlKGBFTUFJTF9BUElfVVJMOiAke0VNQUlMX0FQSV9VUkx9YCk7XG4iLCJpbXBvcnQgZGVidWcsIHsgRGVidWdnZXIgfSBmcm9tIFwiZGVidWdcIjtcblxuLy8gbm90IHVzaW5nIC5leHRlbmRzIGJlY2F1c2Ugb2Ygc3R1cGlkIG5leHQuanMgcmVzb2x2ZSBtb2R1bGVzIGJ1ZyB3aGVyZSBpdHMgcGlja2luZyB1cCBvbGQgdmVyc2lvbiBvZiBkZWJ1Z1xuZXhwb3J0IGNvbnN0IHRyYWNlID0gKG5hbWVzcGFjZTogc3RyaW5nKTogRGVidWdnZXIgPT4gZGVidWcoYG9wZW5jZXJ0cy13ZWJzaXRlOnRyYWNlOiR7bmFtZXNwYWNlfWApO1xuZXhwb3J0IGNvbnN0IGVycm9yID0gKG5hbWVzcGFjZTogc3RyaW5nKTogRGVidWdnZXIgPT4gZGVidWcoYG9wZW5jZXJ0cy13ZWJzaXRlOmVycm9yOiR7bmFtZXNwYWNlfWApO1xuXG5leHBvcnQgY29uc3QgZ2V0TG9nZ2VyID0gKG5hbWVzcGFjZTogc3RyaW5nKTogeyB0cmFjZTogRGVidWdnZXI7IGVycm9yOiBEZWJ1Z2dlciB9ID0+ICh7XG4gIHRyYWNlOiB0cmFjZShuYW1lc3BhY2UpLFxuICBlcnJvcjogZXJyb3IobmFtZXNwYWNlKSxcbn0pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==