module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.AppInitialProps = _utils.AppInitialProps;
exports.NextWebVitalsMetric = _utils.NextWebVitalsMetric;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps({
  Component,
  ctx
}) {
  const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    const {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return /*#__PURE__*/_react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
let warnContainer;
let warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn(`Warning: the \`Container\` in \`_app\` has been deprecated and should be removed. https://err.sh/vercel/next.js/app-container-deprecated`);
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error(`Warning: the 'url' property is deprecated. https://err.sh/vercel/next.js/url-deprecated`);
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  const {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      const pushRoute = as ? href : '';
      const pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      const replaceRoute = as ? href : '';
      const replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_ga__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-ga */ "next-ga");
/* harmony import */ var next_ga__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_ga__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-seo */ "next-seo");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _src_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/config */ "./src/config/index.ts");
/* harmony import */ var _src_reducers_featureToggle_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/reducers/featureToggle.actions */ "./src/reducers/featureToggle.actions.ts");
/* harmony import */ var _src_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../src/store */ "./src/store.ts");
/* harmony import */ var _src_tailwind_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../src/tailwind.css */ "./src/tailwind.css");
/* harmony import */ var _src_tailwind_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_src_tailwind_css__WEBPACK_IMPORTED_MODULE_11__);


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\pages\\_app.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore repository has been archived, will wait to upgrade to fix












const FeatureFlagLoader = ({
  children
}) => {
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_7__["useDispatch"])();
  react__WEBPACK_IMPORTED_MODULE_6___default.a.useEffect(() => {
    const run = async () => {
      const featureToggle = await window.fetch("https://s3-ap-southeast-1.amazonaws.com/opencerts.io/feature-toggle.json", {
        method: "GET"
      }).then(response => response.json());
      dispatch(Object(_src_reducers_featureToggle_actions__WEBPACK_IMPORTED_MODULE_9__["updateFeatureToggles"])(Object(lodash__WEBPACK_IMPORTED_MODULE_1__["mapValues"])(featureToggle, _src_config__WEBPACK_IMPORTED_MODULE_8__["ENVIRONMENT"])));
    };

    run();
  }, [dispatch]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: children
  }, void 0, false);
};

class MyApp extends next_app__WEBPACK_IMPORTED_MODULE_4___default.a {
  render() {
    const {
      Component,
      pageProps
    } = this.props;
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(FeatureFlagLoader, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_seo__WEBPACK_IMPORTED_MODULE_3__["DefaultSeo"], _objectSpread({}, _src_config__WEBPACK_IMPORTED_MODULE_8__["DEFAULT_SEO"]), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, this)
    }, void 0, false);
  }

}

const appWrappedWithGA = next_ga__WEBPACK_IMPORTED_MODULE_2___default()(_src_config__WEBPACK_IMPORTED_MODULE_8__["GA_ID"], next_router__WEBPACK_IMPORTED_MODULE_5___default.a)(MyApp);
/* harmony default export */ __webpack_exports__["default"] = (_src_store__WEBPACK_IMPORTED_MODULE_10__["wrapper"].withRedux(appWrappedWithGA));

/***/ }),

/***/ "./public/static/registry.json":
/*!*************************************!*\
  !*** ./public/static/registry.json ***!
  \*************************************/
/*! exports provided: issuers, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"issuers\":{\"0x007d40224f6562461633ccfbaffd359ebb2fc9ba\":{\"name\":\"Government Technology Agency of Singapore (GovTech)\",\"displayCard\":true,\"website\":\"https://www.tech.gov.sg\",\"email\":\"info@tech.gov.sg\",\"phone\":\"+65 6211 2100\",\"logo\":\"/static/images/GOVTECH_logo.png\",\"id\":\"govtech-registry\"},\"0x5CA3b9daC85DA4DE4030e59C1a0248004209e348\":{\"name\":\"Nanyang Polytechnic\",\"displayCard\":true,\"website\":\"https://www.nyp.edu.sg/\",\"email\":\"askNYP@nyp.edu.sg\",\"phone\":\"+65 6451 5115\",\"logo\":\"/static/images/NYP_logo.png\",\"id\":\"nyp-registry\"},\"0xa5d801265D29A6F1015a641BfC0e39Ee3dA2AC76\":{\"name\":\"Ngee Ann Polytechnic\",\"displayCard\":true,\"website\":\"https://www.np.edu.sg\",\"email\":\"asknp@np.edu.sg\",\"phone\":\"+65 6466 6555\",\"logo\":\"/static/images/NP_logo.svg\",\"id\":\"np-registry\",\"group\":\"np-registry\"},\"0x828dB5254a44e8630068107A2536219e0C84cacA\":{\"name\":\"Ngee Ann Polytechnic CET Academy\",\"displayCard\":true,\"website\":\"https://www.np.edu.sg\",\"email\":\"enquiryCET@np.edu.sg\",\"phone\":\"+65 6460 6353\",\"logo\":\"/static/images/NP_logo.svg\",\"id\":\"np-registry-academy\",\"group\":\"np-registry\"},\"0xE4a94Ef9C26904A02Cd6735F7D4De1D840146a0f\":{\"name\":\"Singapore Examinations and Assessment Board\",\"displayCard\":true,\"website\":\"https://www.seab.gov.sg/\",\"email\":\"\",\"phone\":\"+65 6872 2220\",\"logo\":\"/static/images/SEAB_logo_crop.png\",\"id\":\"seab-registry\"},\"0x24a7DE31D231221ab6B1B325Ca5F1AA7bfbaaabA\":{\"name\":\"Singapore Institute of Technology\",\"displayCard\":true,\"website\":\"https://www.singaporetech.edu.sg/\",\"email\":\"\",\"phone\":\"+65 6592 1136\",\"logo\":\"/static/images/SIT_logo.png\",\"id\":\"sit-registry\"},\"0x78CE67fcb40D9D9552A313670A2e0eef11043995\":{\"name\":\"SkillsFuture Singapore\",\"displayCard\":true,\"website\":\"https://www.ssg-wsg.gov.sg/\",\"email\":\"\",\"phone\":\"+65 6785 5785\",\"logo\":\"/static/images/SSG_logo.png\",\"id\":\"ssg-registry\"},\"0x4d05f843718da742b4229938f972a3eb969c25ce\":{\"name\":\"Temasek Polytechnic\",\"displayCard\":true,\"website\":\"https://www.tp.edu.sg/home\",\"email\":\"enquiry@tp.edu.sg\",\"phone\":\"+65 6789 8220\",\"logo\":\"/static/images/TP_logo.svg\",\"id\":\"tp-registry\"},\"0x0CE38eBEa3B943Ee6DA24163710b25Ef8654f39E\":{\"name\":\"Institute of Technical Education\",\"displayCard\":true,\"website\":\"https://www.ite.edu.sg\",\"email\":\"training@ite.edu.sg\",\"phone\":\"1800-2222 111\",\"logo\":\"/static/images/ITE_logo.png\",\"id\":\"ite-registry\"},\"0x18270bA6dA0380a2cbC705bc6C0AD6651282bD14\":{\"name\":\"Republic Polytechnic\",\"displayCard\":true,\"website\":\"https://www.rp.edu.sg/\",\"email\":\"one-stop@rp.edu.sg\",\"phone\":\"+65 6510 3000\",\"logo\":\"/static/images/RP_logo.svg\",\"id\":\"rp-registry\"},\"0x96a7bEefb0A7fb6B9d2101B0A27a734fA97E7221\":{\"name\":\"Singapore University of Technology and Design\",\"displayCard\":true,\"website\":\"https://sutd.edu.sg\",\"email\":\"opencert@sutd.edu.sg\",\"phone\":\"+65 6499 8922\",\"logo\":\"/static/images/SUTD_logo.png\",\"id\":\"sutd-registry\"},\"0x16E949FcDC655765959Ac085CA7B1aE353D6Ca35\":{\"name\":\"Nanyang Technological University\",\"displayCard\":true,\"website\":\"https://www.ntu.edu.sg\",\"email\":\"deg_verify@ntu.edu.sg\",\"phone\":\"+65 6592 2448\",\"logo\":\"/static/images/NTU_logo.png\",\"id\":\"ntu-registry\"},\"0x61783202d023fd08dcc7d7ca8a196697c46c9d57\":{\"name\":\"Nanyang Technological University\",\"displayCard\":true,\"website\":\"https://www.ntu.edu.sg\",\"email\":\"deg_verify@ntu.edu.sg\",\"phone\":\"+65 6592 2448\",\"logo\":\"/static/images/NTU_logo.png\",\"id\":\"ntu-registry\"},\"0xCFa2B7Fc3FdD5CA55715581e34420268CCcd3039\":{\"name\":\"Singapore Management University\",\"displayCard\":true,\"website\":\"https://www.smu.edu.sg\",\"email\":\"digitalcert@smu.edu.sg\",\"phone\":\"+65 6828 0583 / +65 6808 5264 / +65 6808 5138\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry\",\"group\":\"smu-registry\"},\"0x6c806e3E0Ea393eC7E8b7E7fa62eF92Fcd039404\":{\"name\":\"Singapore Management University Academy\",\"displayCard\":true,\"website\":\"https://academy.smu.edu.sg\",\"email\":\"academy@smu.edu.sg\",\"phone\":\"+65 6828 9688\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-academy\",\"group\":\"smu-registry\"},\"0x38c8d4cbc63a23739abfe9c280a3c533a8dbebf5\":{\"name\":\"Singapore Management University School of Accountancy\",\"displayCard\":true,\"website\":\"https://accountancy.smu.edu.sg\",\"email\":\"accountancy@smu.edu.sg\",\"phone\":\"+65 6828 0632\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-accountancy\",\"group\":\"smu-registry\"},\"0x6a8899bbe8bb1535e60cf9237fc6806c26066dee\":{\"name\":\"Singapore Management University School of Economics\",\"displayCard\":true,\"website\":\"https://economics.smu.edu.sg\",\"email\":\"economics_enquiries@smu.edu.sg\",\"phone\":\"+65 6808 5108\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-economics\",\"group\":\"smu-registry\"},\"0x94cbba4b50d2c29d247221a7cc2dda356054078b\":{\"name\":\"Singapore Management University School of Information Systems\",\"displayCard\":true,\"website\":\"https://sis.smu.edu.sg\",\"email\":\"enquiries@sis.smu.edu.sg\",\"phone\":\"+65 6808 5108\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-sis\",\"group\":\"smu-registry\"},\"0x5a8027a5fa187d495546c4041966703bf9018a11\":{\"name\":\"Singapore Management University Lee Kong Chian School of Business\",\"displayCard\":true,\"website\":\"https://business.smu.edu.sg\",\"email\":\"bschool@smu.edu.sg\",\"phone\":\"+65 6828 0549\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-business\",\"group\":\"smu-registry\"},\"0x86e7e573a18df76ed840d6ae2af11785c1453911\":{\"name\":\"Singapore Management University School of Law\",\"displayCard\":true,\"website\":\"https://law.smu.edu.sg\",\"email\":\"law@smu.edu.sg\",\"phone\":\"+65 6828 0502\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-law\",\"group\":\"smu-registry\"},\"0x5b3e03ec154629c67ad5d32e34048aac3fb0ddbe\":{\"name\":\"Singapore Management University Institute of Service Excellence\",\"displayCard\":true,\"website\":\"https://ise.smu.edu.sg\",\"email\":\"ise@smu.edu.sg\",\"phone\":\"+65 6828 0111\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-excellence\",\"group\":\"smu-registry\"},\"0xA204F16717fbF580d6A0535b58063fB4fce969fF\":{\"name\":\"National University of Singapore\",\"displayCard\":true,\"website\":\"http://www.nus.edu.sg/\",\"email\":\"transcript@nus.edu.sg\",\"phone\":\"+65 6516 2304\",\"logo\":\"/static/images/NUS_logo.svg\",\"id\":\"nus-registry\"},\"0x66671988ee465b5c23Ef18838B32b1666d0EC8d6\":{\"name\":\"National University of Singapore\",\"displayCard\":true,\"website\":\"http://www.nus.edu.sg/\",\"email\":\"transcript@nus.edu.sg\",\"phone\":\"+65 6516 2304\",\"logo\":\"/static/images/NUS_logo.svg\",\"id\":\"nus-registry\"},\"0x69Ec8cA1A2A19566128F4157Dca6249d89046F1F\":{\"name\":\"Singapore Polytechnic\",\"displayCard\":true,\"website\":\"https://www.sp.edu.sg\",\"email\":\"contactus@sp.edu.sg\",\"phone\":\"+65 6775 1133\",\"logo\":\"/static/images/SP_logo.svg\",\"id\":\"sp-registry\"},\"0x45b04D7EFdfA1B25296e5BC9eC88E3ae3C53CE9f\":{\"name\":\"Singapore University of Social Sciences\",\"displayCard\":true,\"website\":\"https://www.suss.edu.sg/\",\"email\":\"alumni@suss.edu.sg\",\"phone\":\"+65 6248 9215\",\"logo\":\"/static/images/SUSS_logo.png\",\"id\":\"suss-registry\"},\"0x9cf976dc45bb5a9336238759e89051E7b09e016b\":{\"name\":\"National Institute of Early Childhood Development\",\"displayCard\":true,\"website\":\"https://www.niec.edu.sg/\",\"email\":\"aa@niec.edu.sg\",\"phone\":\"+65 6332 0668\",\"logo\":\"/static/images/NIEC_logo.png\",\"id\":\"niec-registry\"},\"0xa53C84A422D9cCc5C4aDA9fa65B03e2Bb25E2D03\":{\"name\":\"Lasalle College of the Arts\",\"displayCard\":true,\"website\":\"https://www.lasalle.edu.sg/\",\"email\":\"academic.admin@lasalle.edu.sg\",\"phone\":\"+65 6496 5200\",\"logo\":\"/static/images/LASALLE_logo.png\",\"id\":\"lasalle-registry\"},\"0x5af87c7C799FdD24418f436ccc5d0ef00a1D755B\":{\"name\":\"Nanyang Academy of Fine Arts\",\"displayCard\":true,\"website\":\"https://www.nafa.edu.sg/\",\"email\":\"nafacerts@nafa.edu.sg\",\"phone\":\"+65 6512 4000\",\"logo\":\"/static/images/NAFA_Arts_logo.png\",\"id\":\"nanyang-art-registry\"},\"0xb3c1404732585ddEB837Af28eBdAec504ed8Ba04\":{\"name\":\"ROPSTEN: Singapore Management University\",\"displayCard\":false},\"0x3FFB6b913E9874c7ddabD564d85676Bc5cAd16d4\":{\"name\":\"ROPSTEN: Nanyang Technological University\",\"displayCard\":false},\"0xdcb5bce006f5f369579854ec32ec6fa53ba915be\":{\"name\":\"ROPSTEN: Nanyang Polytechnic\",\"displayCard\":false},\"0xfEbB273495F5C2c4783E23424Fe9773691b57fcB\":{\"name\":\"ROPSTEN: National University of Singapore\",\"displayCard\":false},\"0x866Fb78aC3c87019aBff9FB566acfF66F75Cfa46\":{\"name\":\"ROPSTEN: Ngee Ann Polytechnic\",\"displayCard\":false},\"0xc36484efa1544c32ffed2e80a1ea9f0dfc517495\":{\"name\":\"ROPSTEN: Ngee Ann Polytechnic\",\"displayCard\":false},\"0xeDe1B6Fc03f1a9C6905C93a2fceb06E19624a55E\":{\"name\":\"ROPSTEN: Singapore Examinations and Assessment Board\",\"displayCard\":false},\"0x897E224a6a8b72535D67940B3B8CE53f9B596800\":{\"name\":\"ROPSTEN: Singapore Institute of Technology\",\"displayCard\":false},\"0x3f43FB8546E97b2c1D5eD087767C0d2eb2e13f8b\":{\"name\":\"ROPSTEN: Singapore Institute of Technology (Ledger Nano)\",\"displayCard\":false},\"0xCE4D56Fea4a4EB33E8A3502CEe6Db075224C896d\":{\"name\":\"ROPSTEN: Skillsfuture Singapore\",\"displayCard\":false},\"0xe825e69383a57eB686Fc7b8c455Dd982bB9680f6\":{\"name\":\"ROPSTEN: Temasek Polytechnic\",\"displayCard\":false},\"0xE5c693015460868F817799CAFb363EEDb4F9E446\":{\"name\":\"ROPSTEN: Institute of Technical Education\",\"displayCard\":false},\"0xdcA6Eea7024151c270b50FcA9E67161119B06BAD\":{\"name\":\"ROPSTEN: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false},\"0x532C9Ff853CA54370D7492cD84040F9f8099f11B\":{\"name\":\"ROPSTEN: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false},\"0x061aFcFF60b90E0F633F8ef157e01BaB9b2FfDD3\":{\"name\":\"ROPSTEN: Republic Polytechnic\",\"displayCard\":false},\"0x2456FC81C1342fB79D7C58A4682F031208A44d7F\":{\"name\":\"ROPSTEN: Singapore University of Technology and Design\",\"displayCard\":false},\"0x46cf931c320ce7277753dbb15567dD684404e36C\":{\"name\":\"ROPSTEN: Singapore University of Social Sciences\",\"displayCard\":false},\"0x146d1e1938dc0f5fbb2179727c2fa61522cd1834\":{\"name\":\"ROPSTEN: National Institute of Early Childhood Development\",\"displayCard\":false},\"0xb02bcBb4865d0301F6e4A5f46043498f7c348E03\":{\"name\":\"ROPSTEN: Lasalle College of the Arts\",\"displayCard\":false},\"0x7Ee2B9a0043Bda975398477695ba5c2361acC50C\":{\"name\":\"RINKEBY: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false}}}");

/***/ }),

/***/ "./src/components/Analytics/index.ts":
/*!*******************************************!*\
  !*** ./src/components/Analytics/index.ts ***!
  \*******************************************/
/*! exports provided: validateEvent, stringifyEvent, analyticsEvent, sendEventCertificateViewedDetailed, triggerErrorLogging */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validateEvent", function() { return validateEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stringifyEvent", function() { return stringifyEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "analyticsEvent", function() { return analyticsEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendEventCertificateViewedDetailed", function() { return sendEventCertificateViewedDetailed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "triggerErrorLogging", function() { return triggerErrorLogging; });
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @govtechsg/open-attestation */ "@govtechsg/open-attestation");
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../public/static/registry.json */ "./public/static/registry.json");
var _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../../public/static/registry.json */ "./public/static/registry.json", 1);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/logger */ "./src/utils/logger.ts");



const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_2__["getLogger"])("components:Analytics:");
const {
  trace: traceDev
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_2__["getLogger"])("components:Analytics(Inactive):");

/*
 * This function checks if an address is in registry.json to provide property access.
 */
function isInRegistry(value) {
  return value in _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers;
}

const validateEvent = ({
  category,
  action,
  value
}) => {
  if (!category) throw new Error("Category is required");
  if (!action) throw new Error("Action is required");
  if (value && typeof value !== "number") throw new Error("Value must be a number");
};
const stringifyEvent = ({
  category,
  action,
  label,
  value
}) => `Category*: ${category}, Action*: ${action}, Label: ${label}, Value: ${value}`;
const analyticsEvent = (window, event) => {
  validateEvent(event);

  if (false) {}

  traceDev(stringifyEvent(event));
};
const sendEventCertificateViewedDetailed = ({
  issuer,
  certificateData
}) => {
  var _ref, _ref2, _ref3, _issuer$certificateSt, _certificateData$id, _certificateData$name, _certificateData$issu;

  let label = "";
  let issuerName = "";
  let registryId = null;
  const separator = ";";
  const store = (_ref = (_ref2 = (_ref3 = (_issuer$certificateSt = issuer.certificateStore) !== null && _issuer$certificateSt !== void 0 ? _issuer$certificateSt : issuer.documentStore) !== null && _ref3 !== void 0 ? _ref3 : issuer.tokenRegistry) !== null && _ref2 !== void 0 ? _ref2 : issuer.id) !== null && _ref !== void 0 ? _ref : ""; // use id for DID

  const id = (_certificateData$id = certificateData === null || certificateData === void 0 ? void 0 : certificateData.id) !== null && _certificateData$id !== void 0 ? _certificateData$id : "";
  const name = (_certificateData$name = certificateData === null || certificateData === void 0 ? void 0 : certificateData.name) !== null && _certificateData$name !== void 0 ? _certificateData$name : "";
  const issuedOn = (_certificateData$issu = certificateData === null || certificateData === void 0 ? void 0 : certificateData.issuedOn) !== null && _certificateData$issu !== void 0 ? _certificateData$issu : "";

  if (isInRegistry(store)) {
    var _issuerName, _registryIssuer$id;

    const registryIssuer = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store];
    registryId = registryIssuer.id;
    issuerName = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store].name;
    label = `"store":"${store}"${separator}"document_id":"${id}"${separator}"name":"${name}"${separator}"issued_on":"${issuedOn}"${separator}"issuer_name":"${(_issuerName = issuerName) !== null && _issuerName !== void 0 ? _issuerName : ""}"${separator}"issuer_id":"${(_registryIssuer$id = registryIssuer.id) !== null && _registryIssuer$id !== void 0 ? _registryIssuer$id : ""}"`;
  } else if (issuer.identityProof) {
    var _issuerName2;

    issuerName = issuer.identityProof.location || "";
    label = `"store":"${store}"${separator}"document_id":"${id}"${separator}"name":"${name}"${separator}"issued_on":"${issuedOn}"${separator}"issuer_name":"${(_issuerName2 = issuerName) !== null && _issuerName2 !== void 0 ? _issuerName2 : ""}"`;
  } else {
    label = "Something went wrong, please check the analytics code of sendEventCertificateViewedDetailed";
  }

  analyticsEvent(window, {
    category: "CERTIFICATE_DETAILS",
    action: `VIEWED - ${issuerName}`,
    label,
    options: {
      nonInteraction: true,
      dimension1: store || "(not set)",
      dimension2: id || "(not set)",
      dimension3: name || "(not set)",
      dimension4: issuedOn || "(not set)",
      dimension5: issuerName || "(not set)",
      dimension6: registryId || "(not set)"
    }
  });
};
function triggerErrorLogging(rawCertificate, errors) {
  const certificate = Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__["getData"])(rawCertificate);
  const id = certificate === null || certificate === void 0 ? void 0 : certificate.id;
  const name = certificate === null || certificate === void 0 ? void 0 : certificate.name;
  const issuedOn = certificate === null || certificate === void 0 ? void 0 : certificate.issuedOn;
  const errorsList = errors.join(","); // If there are multiple issuers in a certificate, we send multiple events!

  certificate.issuers.forEach(issuer => {
    var _ref4, _ref5, _ref6, _issuer$certificateSt2;

    const store = (_ref4 = (_ref5 = (_ref6 = (_issuer$certificateSt2 = issuer.certificateStore) !== null && _issuer$certificateSt2 !== void 0 ? _issuer$certificateSt2 : issuer.documentStore) !== null && _ref6 !== void 0 ? _ref6 : issuer.tokenRegistry) !== null && _ref5 !== void 0 ? _ref5 : issuer.id) !== null && _ref4 !== void 0 ? _ref4 : ""; // use id for DID

    let issuerName = issuer.name;
    let registryId = null;

    if (isInRegistry(store)) {
      const registryIssuer = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store];
      issuerName = registryIssuer.name;
      registryId = registryIssuer.id;
    } else if (issuer.identityProof) {
      issuerName = issuer.identityProof.location || "";
    }

    analyticsEvent(window, {
      category: "CERTIFICATE_ERROR",
      action: `ERROR - ${issuerName}`,
      label: errorsList,
      options: {
        nonInteraction: true,
        dimension1: store || "(not set)",
        dimension2: id || "(not set)",
        dimension3: name || "(not set)",
        dimension4: issuedOn || "(not set)",
        dimension5: issuerName || "(not set)",
        dimension6: registryId || "(not set)",
        dimension7: errorsList
      }
    });
  });
}

/***/ }),

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "next/config");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;



const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"); // https://github.com/vercel/next.js/issues/7713

const {
  publicRuntimeConfig = {}
} = next_config__WEBPACK_IMPORTED_MODULE_0___default()();
const URL = "https://opencerts.io";
const API_MAIN_URL = "https://api.opencerts.io";
const API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
const API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
const GA_PRODUCTION_ID = "UA-130492260-1";
const GA_DEVELOPMENT_ID = "UA-130492260-2";
const IS_MAINNET = publicRuntimeConfig.network === "mainnet";
const NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

const GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
const CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

const getApiUrl = networkName => {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

const EMAIL_API_URL = `${getApiUrl(NETWORK_NAME)}/email`;
const SHARE_LINK_API_URL = `${getApiUrl(NETWORK_NAME)}/storage`;
const SHARE_LINK_TTL = 1209600;
const LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
const ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
const DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: `OpenCerts - %s`,
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: `${URL}/static/images/opencerts.png`,
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace(`NETWORK: ${NETWORK_NAME}`);
trace(`CAPTCHA_CLIENT_KEY: ${CAPTCHA_CLIENT_KEY}`);
trace(`EMAIL_API_URL: ${EMAIL_API_URL}`);

/***/ }),

/***/ "./src/reducers/certificate.actions.ts":
/*!*********************************************!*\
  !*** ./src/reducers/certificate.actions.ts ***!
  \*********************************************/
/*! exports provided: RESET_CERTIFICATE, UPDATE_CERTIFICATE, VERIFYING_CERTIFICATE, VERIFYING_CERTIFICATE_COMPLETED, VERIFYING_CERTIFICATE_ERRORED, SENDING_CERTIFICATE, SENDING_CERTIFICATE_SUCCESS, SENDING_CERTIFICATE_FAILURE, SENDING_CERTIFICATE_RESET, GENERATE_SHARE_LINK, GENERATE_SHARE_LINK_SUCCESS, GENERATE_SHARE_LINK_FAILURE, GENERATE_SHARE_LINK_RESET, RETRIEVE_CERTIFICATE_BY_ACTION, RETRIEVE_CERTIFICATE_BY_ACTION_PENDING, RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS, RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE, CERTIFICATE_OBFUSCATE_UPDATE, resetCertificateState, updateCertificate, verifyingCertificate, verifyingCertificateCompleted, verifyingCertificateErrored, sendCertificate, sendCertificateSuccess, sendCertificateFailure, sendCertificateReset, generateShareLink, generateShareLinkReset, generateShareLinkSuccess, generateShareLinkFailure, retrieveCertificateByAction, retrieveCertificateByActionPending, retrieveCertificateByActionSuccess, retrieveCertificateByActionFailure, updateObfuscatedCertificate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RESET_CERTIFICATE", function() { return RESET_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_CERTIFICATE", function() { return UPDATE_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE", function() { return VERIFYING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_COMPLETED", function() { return VERIFYING_CERTIFICATE_COMPLETED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERIFYING_CERTIFICATE_ERRORED", function() { return VERIFYING_CERTIFICATE_ERRORED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE", function() { return SENDING_CERTIFICATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_SUCCESS", function() { return SENDING_CERTIFICATE_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_FAILURE", function() { return SENDING_CERTIFICATE_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SENDING_CERTIFICATE_RESET", function() { return SENDING_CERTIFICATE_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK", function() { return GENERATE_SHARE_LINK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_SUCCESS", function() { return GENERATE_SHARE_LINK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_FAILURE", function() { return GENERATE_SHARE_LINK_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENERATE_SHARE_LINK_RESET", function() { return GENERATE_SHARE_LINK_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION", function() { return RETRIEVE_CERTIFICATE_BY_ACTION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_PENDING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE", function() { return RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CERTIFICATE_OBFUSCATE_UPDATE", function() { return CERTIFICATE_OBFUSCATE_UPDATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetCertificateState", function() { return resetCertificateState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCertificate", function() { return updateCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificate", function() { return verifyingCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateCompleted", function() { return verifyingCertificateCompleted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyingCertificateErrored", function() { return verifyingCertificateErrored; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificate", function() { return sendCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateSuccess", function() { return sendCertificateSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateFailure", function() { return sendCertificateFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificateReset", function() { return sendCertificateReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLink", function() { return generateShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkReset", function() { return generateShareLinkReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkSuccess", function() { return generateShareLinkSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLinkFailure", function() { return generateShareLinkFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByAction", function() { return retrieveCertificateByAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionPending", function() { return retrieveCertificateByActionPending; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionSuccess", function() { return retrieveCertificateByActionSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByActionFailure", function() { return retrieveCertificateByActionFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateObfuscatedCertificate", function() { return updateObfuscatedCertificate; });
// Action Creators
// Actions
const RESET_CERTIFICATE = "RESET_CERTIFICATE";
const UPDATE_CERTIFICATE = "UPDATE_CERTIFICATE";
const VERIFYING_CERTIFICATE = "VERIFYING_CERTIFICATE";
const VERIFYING_CERTIFICATE_COMPLETED = "VERIFYING_CERTIFICATE_COMPLETED"; // completed

const VERIFYING_CERTIFICATE_ERRORED = "VERIFYING_CERTIFICATE_ERRORED"; // errored

const SENDING_CERTIFICATE = "SENDING_CERTIFICATE";
const SENDING_CERTIFICATE_SUCCESS = "SENDING_CERTIFICATE_SUCCESS";
const SENDING_CERTIFICATE_FAILURE = "SENDING_CERTIFICATE_FAILURE";
const SENDING_CERTIFICATE_RESET = "SENDING_CERTIFICATE_RESET";
const GENERATE_SHARE_LINK = "GENERATE_SHARE_LINK";
const GENERATE_SHARE_LINK_SUCCESS = "GENERATE_SHARE_LINK_SUCCESS";
const GENERATE_SHARE_LINK_FAILURE = "GENERATE_SHARE_LINK_FAILURE";
const GENERATE_SHARE_LINK_RESET = "GENERATE_SHARE_LINK_RESET";
const RETRIEVE_CERTIFICATE_BY_ACTION = "RETRIEVE_CERTIFICATE_BY_ACTION";
const RETRIEVE_CERTIFICATE_BY_ACTION_PENDING = "RETRIEVE_CERTIFICATE_BY_ACTION_PENDING";
const RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS = "RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS";
const RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE = "RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE";
const CERTIFICATE_OBFUSCATE_UPDATE = "CERTIFICATE_OBFUSCATE_UPDATE";
function resetCertificateState() {
  return {
    type: RESET_CERTIFICATE
  };
}
function updateCertificate(payload) {
  return {
    type: UPDATE_CERTIFICATE,
    payload
  };
}
const verifyingCertificate = () => ({
  type: VERIFYING_CERTIFICATE
});
const verifyingCertificateCompleted = payload => ({
  type: VERIFYING_CERTIFICATE_COMPLETED,
  payload
});
const verifyingCertificateErrored = payload => ({
  type: VERIFYING_CERTIFICATE_ERRORED,
  payload
});
function sendCertificate(payload) {
  return {
    type: SENDING_CERTIFICATE,
    payload
  };
}
function sendCertificateSuccess() {
  return {
    type: SENDING_CERTIFICATE_SUCCESS
  };
}
function sendCertificateFailure(payload) {
  return {
    type: SENDING_CERTIFICATE_FAILURE,
    payload
  };
}
function sendCertificateReset() {
  return {
    type: SENDING_CERTIFICATE_RESET
  };
}
function generateShareLink() {
  return {
    type: GENERATE_SHARE_LINK
  };
}
function generateShareLinkReset() {
  return {
    type: GENERATE_SHARE_LINK_RESET
  };
}
function generateShareLinkSuccess(payload) {
  return {
    type: GENERATE_SHARE_LINK_SUCCESS,
    payload
  };
}
function generateShareLinkFailure(payload) {
  return {
    type: GENERATE_SHARE_LINK_FAILURE,
    payload
  };
}
function retrieveCertificateByAction(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION,
    payload
  };
}
function retrieveCertificateByActionPending() {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_PENDING
  };
}
function retrieveCertificateByActionSuccess() {
  debugger;
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS
  };
}
function retrieveCertificateByActionFailure(payload) {
  return {
    type: RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE,
    payload
  };
}
function updateObfuscatedCertificate(payload) {
  return {
    type: CERTIFICATE_OBFUSCATE_UPDATE,
    payload
  };
}

/***/ }),

/***/ "./src/reducers/certificate.selectors.ts":
/*!***********************************************!*\
  !*** ./src/reducers/certificate.selectors.ts ***!
  \***********************************************/
/*! exports provided: getCertificate, getVerifying, getVerificationStatus, getEmailSendingState, getShareLink, getShareLinkState, getCertificateByActionError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCertificate", function() { return getCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getVerifying", function() { return getVerifying; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getVerificationStatus", function() { return getVerificationStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEmailSendingState", function() { return getEmailSendingState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getShareLink", function() { return getShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getShareLinkState", function() { return getShareLinkState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCertificateByActionError", function() { return getCertificateByActionError; });
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shared */ "./src/reducers/shared.ts");

function getCertificate(store) {
  return store.certificate.rawModified;
}
function getVerifying(store) {
  return store.certificate.verificationPending || store.certificate.retrieveCertificateByActionState === _shared__WEBPACK_IMPORTED_MODULE_0__["states"].PENDING;
}
function getVerificationStatus(store) {
  return store.certificate.verificationStatus;
}
function getEmailSendingState(store) {
  return store.certificate.emailState;
}
function getShareLink(store) {
  return store.certificate.shareLink;
}
function getShareLinkState(store) {
  return store.certificate.shareLinkState;
}
function getCertificateByActionError(store) {
  return store.certificate.retrieveCertificateByActionError;
}

/***/ }),

/***/ "./src/reducers/certificate.ts":
/*!*************************************!*\
  !*** ./src/reducers/certificate.ts ***!
  \*************************************/
/*! exports provided: initialState, reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
/* harmony import */ var _certificate_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared */ "./src/reducers/shared.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const initialState = {
  raw: null,
  rawModified: null,
  verificationPending: false,
  verificationStatus: null,
  verificationError: null,
  emailState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].INITIAL,
  emailError: null,
  shareLink: {},
  shareLinkState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].INITIAL,
  shareLinkError: null,
  retrieveCertificateByActionState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].INITIAL,
  retrieveCertificateByActionError: null
}; // Reducers

function reducer(state = initialState, action) {
  switch (action.type) {
    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["RESET_CERTIFICATE"]:
      return _objectSpread({}, initialState);

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["UPDATE_CERTIFICATE"]:
      return _objectSpread(_objectSpread({}, initialState), {}, {
        raw: action.payload,
        rawModified: action.payload
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["VERIFYING_CERTIFICATE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        verificationPending: true,
        verificationStatus: null
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["VERIFYING_CERTIFICATE_COMPLETED"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        verificationPending: false,
        verificationStatus: action.payload
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["VERIFYING_CERTIFICATE_ERRORED"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        verificationPending: false,
        verificationError: action.payload
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["SENDING_CERTIFICATE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        emailState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].PENDING,
        emailError: null
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["SENDING_CERTIFICATE_RESET"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        emailState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].INITIAL,
        emailError: null
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["SENDING_CERTIFICATE_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        emailState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].SUCCESS,
        emailError: null
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["SENDING_CERTIFICATE_FAILURE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        emailState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].FAILURE,
        emailError: action.payload
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["GENERATE_SHARE_LINK_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        shareLink: action.payload,
        shareLinkState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].SUCCESS
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["GENERATE_SHARE_LINK_FAILURE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        shareLink: {},
        shareLinkState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].FAILURE
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["GENERATE_SHARE_LINK_RESET"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        shareLink: {},
        shareLinkState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].INITIAL
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["RETRIEVE_CERTIFICATE_BY_ACTION_PENDING"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        retrieveCertificateByActionState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].PENDING
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["RETRIEVE_CERTIFICATE_BY_ACTION_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        retrieveCertificateByActionState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].SUCCESS
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["RETRIEVE_CERTIFICATE_BY_ACTION_FAILURE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        retrieveCertificateByActionState: _shared__WEBPACK_IMPORTED_MODULE_1__["states"].FAILURE,
        retrieveCertificateByActionError: action.payload
      });

    case _certificate_actions__WEBPACK_IMPORTED_MODULE_0__["CERTIFICATE_OBFUSCATE_UPDATE"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        rawModified: action.payload
      });

    default:
      return state;
  }
}

/***/ }),

/***/ "./src/reducers/featureToggle.actions.ts":
/*!***********************************************!*\
  !*** ./src/reducers/featureToggle.actions.ts ***!
  \***********************************************/
/*! exports provided: UPDATE_FEATURE_TOGGLES, updateFeatureToggles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_FEATURE_TOGGLES", function() { return UPDATE_FEATURE_TOGGLES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateFeatureToggles", function() { return updateFeatureToggles; });
const UPDATE_FEATURE_TOGGLES = "UPDATE_FEATURE_TOGGLES";
function updateFeatureToggles(payload) {
  return {
    type: UPDATE_FEATURE_TOGGLES,
    payload
  };
}

/***/ }),

/***/ "./src/reducers/featureToggle.ts":
/*!***************************************!*\
  !*** ./src/reducers/featureToggle.ts ***!
  \***************************************/
/*! exports provided: reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
const initialState = {};
function reducer(state = initialState, action) {
  switch (action.type) {
    case "UPDATE_FEATURE_TOGGLES":
      return action.payload;

    default:
      return state;
  }
}

/***/ }),

/***/ "./src/reducers/index.ts":
/*!*******************************!*\
  !*** ./src/reducers/index.ts ***!
  \*******************************/
/*! exports provided: rootReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rootReducer", function() { return rootReducer; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _certificate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./certificate */ "./src/reducers/certificate.ts");
/* harmony import */ var _featureToggle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./featureToggle */ "./src/reducers/featureToggle.ts");



const rootReducer = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  certificate: _certificate__WEBPACK_IMPORTED_MODULE_1__["reducer"],
  featureToggle: _featureToggle__WEBPACK_IMPORTED_MODULE_2__["reducer"]
});

/***/ }),

/***/ "./src/reducers/shared.ts":
/*!********************************!*\
  !*** ./src/reducers/shared.ts ***!
  \********************************/
/*! exports provided: states */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "states", function() { return states; });
let states;

(function (states) {
  states["INITIAL"] = "INITIAL";
  states["PENDING"] = "PENDING";
  states["SUCCESS"] = "SUCCESS";
  states["FAILURE"] = "FAILURE";
})(states || (states = {}));

/***/ }),

/***/ "./src/sagas/certificate.ts":
/*!**********************************!*\
  !*** ./src/sagas/certificate.ts ***!
  \**********************************/
/*! exports provided: verifyCertificate, sendCertificate, generateShareLink, retrieveCertificateByAction, sagas */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "verifyCertificate", function() { return verifyCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendCertificate", function() { return sendCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateShareLink", function() { return generateShareLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retrieveCertificateByAction", function() { return retrieveCertificateByAction; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sagas", function() { return sagas; });
/* harmony import */ var _govtechsg_oa_encryption__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @govtechsg/oa-encryption */ "@govtechsg/oa-encryption");
/* harmony import */ var _govtechsg_oa_encryption__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_oa_encryption__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @govtechsg/opencerts-verify */ "@govtechsg/opencerts-verify");
/* harmony import */ var _govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ethers */ "ethers");
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! redux-saga/effects */ "redux-saga/effects");
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! isomorphic-fetch */ "isomorphic-fetch");
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_Analytics__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Analytics */ "./src/components/Analytics/index.ts");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../config */ "./src/config/index.ts");
/* harmony import */ var _reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../reducers/certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../reducers/certificate.selectors */ "./src/reducers/certificate.selectors.ts");
/* harmony import */ var _services_email__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/email */ "./src/services/email/index.ts");
/* harmony import */ var _services_fragment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../services/fragment */ "./src/services/fragment.ts");
/* harmony import */ var _services_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../services/link */ "./src/services/link/index.ts");
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
/* eslint-disable @typescript-eslint/explicit-module-boundary-types,@typescript-eslint/explicit-function-return-type */














const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_13__["getLogger"])("saga:certificate"); // lower priority === higher priority, so infura has priority, alchemy is used as fallback

const provider = new ethers__WEBPACK_IMPORTED_MODULE_2__["ethers"].providers.FallbackProvider([{
  priority: 1,
  provider: new ethers__WEBPACK_IMPORTED_MODULE_2__["ethers"].providers.InfuraProvider(_config__WEBPACK_IMPORTED_MODULE_7__["NETWORK_NAME"], "01b3ed28c54f4ae49cb4e27df560c5e8")
}, {
  priority: 10,
  provider: new ethers__WEBPACK_IMPORTED_MODULE_2__["ethers"].providers.AlchemyProvider(_config__WEBPACK_IMPORTED_MODULE_7__["NETWORK_NAME"], "FK1x9CdE8NStKjVt236D_LP7B6MMCFOs")
}], 1);
function* verifyCertificate({
  payload: certificate
}) {
  try {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["verifyingCertificate"])());
    const fragments = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["call"])(Object(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__["verify"])({
      provider
    }), certificate);
    trace(`Verification Status: ${JSON.stringify(fragments)}`);
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["verifyingCertificateCompleted"])(fragments));

    if (Object(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__["isValid"])(fragments)) {
      next_router__WEBPACK_IMPORTED_MODULE_3___default.a.push("/viewer");
    } else {
      const errors = [];

      if (!Object(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__["isValid"])(fragments, ["DOCUMENT_INTEGRITY"])) {
        errors.push("CERTIFICATE_HASH");
      }

      if (!Object(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__["isValid"])(fragments, ["DOCUMENT_STATUS"])) {
        if (Object(_services_fragment__WEBPACK_IMPORTED_MODULE_11__["certificateNotIssued"])(fragments)) errors.push("UNISSUED_CERTIFICATE");else if (Object(_services_fragment__WEBPACK_IMPORTED_MODULE_11__["certificateRevoked"])(fragments)) errors.push("REVOKED_CERTIFICATE");else if (Object(_services_fragment__WEBPACK_IMPORTED_MODULE_11__["serverError"])(fragments)) errors.push("SERVER_ERROR");else if (Object(_services_fragment__WEBPACK_IMPORTED_MODULE_11__["invalidArgument"])(fragments)) errors.push("INVALID_ARGUMENT");else if (Object(_services_fragment__WEBPACK_IMPORTED_MODULE_11__["contractNotFound"])(fragments)) errors.push("CERTIFICATE_STORE_NOT_FOUND");else errors.push("ETHERS_UNHANDLED_ERROR");
      }

      if (!Object(_govtechsg_opencerts_verify__WEBPACK_IMPORTED_MODULE_1__["isValid"])(fragments, ["ISSUER_IDENTITY"])) {
        errors.push("ISSUER_IDENTITY");
      }

      if (errors.length > 0) {
        Object(_components_Analytics__WEBPACK_IMPORTED_MODULE_6__["triggerErrorLogging"])(certificate, errors);
      }
    }
  } catch (e) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["verifyingCertificateErrored"])(e.message));
  }
}
function* sendCertificate({
  payload
}) {
  try {
    const certificate = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["select"])(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_9__["getCertificate"]);
    const {
      email,
      captcha
    } = payload;
    const success = yield Object(_services_email__WEBPACK_IMPORTED_MODULE_10__["sendEmail"])({
      certificate,
      email,
      captcha
    });

    if (!success) {
      throw new Error("Fail to send certificate");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["sendCertificateSuccess"])());
  } catch (e) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["sendCertificateFailure"])(e.message));
  }
}
function* generateShareLink() {
  try {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["generateShareLinkReset"])());
    const certificate = yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["select"])(_reducers_certificate_selectors__WEBPACK_IMPORTED_MODULE_9__["getCertificate"]);
    const success = yield Object(_services_link__WEBPACK_IMPORTED_MODULE_12__["generateLink"])(certificate);

    if (!success) {
      throw new Error("Fail to generate certificate share link");
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["generateShareLinkSuccess"])(success));
  } catch (e) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["generateShareLinkFailure"])(e.message));
  }
}
function* retrieveCertificateByAction({
  payload: {
    uri,
    key
  }
}) {
  try {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["retrieveCertificateByActionPending"])()); // if a key has been provided, let's assume

    let certificate = yield window.fetch(uri).then(response => {
      if (response.status >= 400 && response.status < 600) {
        throw new Error(`Unable to load the certificate from ${uri}`);
      }

      return response.json();
    });
    certificate = certificate.document || certificate; // opencerts-function returns the document in a nested document object

    if (!certificate) {
      throw new Error(`Certificate at address ${uri} is empty`);
    } // if there is a key and the type is "OPEN-ATTESTATION-TYPE-1", let's use oa-encryption


    if (key && certificate.type === "OPEN-ATTESTATION-TYPE-1") {
      certificate = JSON.parse(Object(_govtechsg_oa_encryption__WEBPACK_IMPORTED_MODULE_0__["decryptString"])({
        tag: certificate.tag,
        cipherText: certificate.cipherText,
        iv: certificate.iv,
        key,
        type: certificate.type
      }));
    } else if (key || certificate.type) {
      throw new Error(`Unable to decrypt certificate with key=${key} and type=${certificate.type}`);
    }

    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["updateCertificate"])(certificate));
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["retrieveCertificateByActionSuccess"])());
  } catch (e) {
    yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["put"])(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["retrieveCertificateByActionFailure"])(e.message));
  }
} // TODO https://github.com/redux-saga/redux-saga/issues/1883

const sagas = [// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["takeEvery"])(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["RETRIEVE_CERTIFICATE_BY_ACTION"], retrieveCertificateByAction), // eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["takeEvery"])(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["UPDATE_CERTIFICATE"], verifyCertificate), // eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["takeEvery"])(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["SENDING_CERTIFICATE"], sendCertificate), Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_4__["takeEvery"])(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_8__["GENERATE_SHARE_LINK"], generateShareLink)];

/***/ }),

/***/ "./src/sagas/index.ts":
/*!****************************!*\
  !*** ./src/sagas/index.ts ***!
  \****************************/
/*! exports provided: rootSaga */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rootSaga", function() { return rootSaga; });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux-saga/effects */ "redux-saga/effects");
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _certificate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./certificate */ "./src/sagas/certificate.ts");


function* rootSaga() {
  yield Object(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__["all"])([..._certificate__WEBPACK_IMPORTED_MODULE_1__["sagas"]]);
}

/***/ }),

/***/ "./src/services/email/index.ts":
/*!*************************************!*\
  !*** ./src/services/email/index.ts ***!
  \*************************************/
/*! exports provided: sendEmail */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendEmail", function() { return sendEmail; });
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-fetch */ "isomorphic-fetch");
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");


function sendEmail({
  certificate,
  email,
  captcha
}) {
  return window.fetch(_config__WEBPACK_IMPORTED_MODULE_1__["EMAIL_API_URL"], {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      data: certificate,
      to: email,
      captcha
    })
  }).then(res => res.status === 200);
}

/***/ }),

/***/ "./src/services/fragment.ts":
/*!**********************************!*\
  !*** ./src/services/fragment.ts ***!
  \**********************************/
/*! exports provided: addressInvalid, contractNotFound, certificateNotIssued, certificateRevoked, invalidArgument, serverError, unhandledError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addressInvalid", function() { return addressInvalid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "contractNotFound", function() { return contractNotFound; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "certificateNotIssued", function() { return certificateNotIssued; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "certificateRevoked", function() { return certificateRevoked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "invalidArgument", function() { return invalidArgument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "serverError", function() { return serverError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unhandledError", function() { return unhandledError; });
/* harmony import */ var _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @govtechsg/oa-verify */ "@govtechsg/oa-verify");
/* harmony import */ var _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__);


const getFragmentsFor = (fragments, name) => fragments.filter(status => status.name === name)[0]; // this function check if the reason of the error is that the document store or token registry is invalid


const addressInvalid = fragments => {
  var _documentStoreIssuedF, _documentStoreIssuedF2, _tokenRegistryMintedF, _tokenRegistryMintedF2;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus");
  const tokenRegistryMintedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumTokenRegistryStatus"); // 2 is the error code used by oa-verify in case of invalid address

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF === void 0 ? void 0 : _documentStoreIssuedF.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].DOCUMENT_NOT_ISSUED && (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF2 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF2 === void 0 ? void 0 : _documentStoreIssuedF2.message.toLowerCase()) === "Invalid document store address".toLowerCase() || (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF === void 0 ? void 0 : _tokenRegistryMintedF.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumTokenRegistryStatusCode"].DOCUMENT_NOT_MINTED && (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF2 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF2 === void 0 ? void 0 : _tokenRegistryMintedF2.message.toLowerCase()) === "Invalid token registry address".toLowerCase();
}; // this function check if the reason of the error is that the document store

const contractNotFound = fragments => {
  var _documentStoreIssuedF3, _documentStoreIssuedF4;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus"); // 404 is the error code used by oa-verify in case of contract not found

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF3 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF3 === void 0 ? void 0 : _documentStoreIssuedF3.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].DOCUMENT_NOT_ISSUED && (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF4 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF4 === void 0 ? void 0 : _documentStoreIssuedF4.message.toLowerCase()) === "Contract is not found".toLowerCase();
}; // this function check if the reason of the error is that the document store or token has not been issued

const certificateNotIssued = fragments => {
  var _documentStoreIssuedF5, _tokenRegistryMintedF3;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus");
  const tokenRegistryMintedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumTokenRegistryStatus"); // 1 is the error code used by oa-verify in case of document / token not issued / minted

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF5 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF5 === void 0 ? void 0 : _documentStoreIssuedF5.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].DOCUMENT_NOT_ISSUED || (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF3 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF3 === void 0 ? void 0 : _tokenRegistryMintedF3.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumTokenRegistryStatusCode"].DOCUMENT_NOT_MINTED;
}; // this function check if the reason of the error is that the document store or token has not been issued

const certificateRevoked = fragments => {
  var _documentStoreIssuedF6;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus"); // 1 is the error code used by oa-verify in case of document / token not issued / minted

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF6 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF6 === void 0 ? void 0 : _documentStoreIssuedF6.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].DOCUMENT_REVOKED;
}; // this function check if the error is caused by an invalid merkle root (incorrect length/odd length/invalid characters)

const invalidArgument = fragments => {
  var _documentStoreIssuedF7, _documentStoreIssuedF8, _tokenRegistryMintedF4, _tokenRegistryMintedF5;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus");
  const tokenRegistryMintedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumTokenRegistryStatus"); // why INVALID_ARGUMENT is because we follow the error codes returned by Ethers (https://docs.ethers.io/v5/api/utils/logger/#errors)

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF7 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF7 === void 0 ? void 0 : _documentStoreIssuedF7.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].DOCUMENT_NOT_ISSUED && (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF8 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF8 === void 0 ? void 0 : _documentStoreIssuedF8.message.toLowerCase()) === "Invalid call arguments".toLowerCase() || (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF4 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF4 === void 0 ? void 0 : _tokenRegistryMintedF4.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumTokenRegistryStatusCode"].INVALID_ARGUMENT && (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF5 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF5 === void 0 ? void 0 : _tokenRegistryMintedF5.message.toLowerCase()) === "Invalid contract arguments".toLowerCase();
}; // this function check if the reason of the error is that we can't connect to Ethereum (due to any HTTP 4xx or 5xx errors)

const serverError = fragments => {
  var _documentStoreIssuedF9, _tokenRegistryMintedF6;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus");
  const tokenRegistryMintedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumTokenRegistryStatus"); // 429 is the error code used by oa-verify in case of Ethers returning a missing response error

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF9 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF9 === void 0 ? void 0 : _documentStoreIssuedF9.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].SERVER_ERROR || (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF6 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF6 === void 0 ? void 0 : _tokenRegistryMintedF6.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumTokenRegistryStatusCode"].SERVER_ERROR;
}; // this function catches all other unhandled errors

const unhandledError = fragments => {
  var _documentStoreIssuedF10, _tokenRegistryMintedF7;

  const documentStoreIssuedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumDocumentStoreStatus");
  const tokenRegistryMintedFragment = getFragmentsFor(fragments, "OpenAttestationEthereumTokenRegistryStatus"); // 3 is the error code used by oa-verify in case of weird errors that we didn't foresee to handle

  return (documentStoreIssuedFragment === null || documentStoreIssuedFragment === void 0 ? void 0 : (_documentStoreIssuedF10 = documentStoreIssuedFragment.reason) === null || _documentStoreIssuedF10 === void 0 ? void 0 : _documentStoreIssuedF10.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].ETHERS_UNHANDLED_ERROR || (tokenRegistryMintedFragment === null || tokenRegistryMintedFragment === void 0 ? void 0 : (_tokenRegistryMintedF7 = tokenRegistryMintedFragment.reason) === null || _tokenRegistryMintedF7 === void 0 ? void 0 : _tokenRegistryMintedF7.code) === _govtechsg_oa_verify__WEBPACK_IMPORTED_MODULE_0__["OpenAttestationEthereumDocumentStoreStatusCode"].ETHERS_UNHANDLED_ERROR;
};

/***/ }),

/***/ "./src/services/link/index.ts":
/*!************************************!*\
  !*** ./src/services/link/index.ts ***!
  \************************************/
/*! exports provided: generateLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "generateLink", function() { return generateLink; });
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-fetch */ "isomorphic-fetch");
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");


function generateLink(certificate) {
  return window.fetch(`${_config__WEBPACK_IMPORTED_MODULE_1__["SHARE_LINK_API_URL"]}/`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      ttl: _config__WEBPACK_IMPORTED_MODULE_1__["SHARE_LINK_TTL"],
      document: certificate
    })
  }).then(res => res.json());
}

/***/ }),

/***/ "./src/store.ts":
/*!**********************!*\
  !*** ./src/store.ts ***!
  \**********************/
/*! exports provided: initStore, wrapper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initStore", function() { return initStore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wrapper", function() { return wrapper; });
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-redux-wrapper */ "next-redux-wrapper");
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-devtools-extension */ "redux-devtools-extension");
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_saga__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! redux-saga */ "redux-saga");
/* harmony import */ var redux_saga__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_saga__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reducers */ "./src/reducers/index.ts");
/* harmony import */ var _sagas__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sagas */ "./src/sagas/index.ts");






const sagaMiddleware = redux_saga__WEBPACK_IMPORTED_MODULE_3___default()();
const initStore = () => {
  const store = Object(redux__WEBPACK_IMPORTED_MODULE_1__["createStore"])(_reducers__WEBPACK_IMPORTED_MODULE_4__["rootReducer"], Object(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__["composeWithDevTools"])(Object(redux__WEBPACK_IMPORTED_MODULE_1__["applyMiddleware"])(sagaMiddleware)));
  sagaMiddleware.run(_sagas__WEBPACK_IMPORTED_MODULE_5__["rootSaga"]);
  return store;
};
const wrapper = Object(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_0__["createWrapper"])(initStore);

/***/ }),

/***/ "./src/tailwind.css":
/*!**************************!*\
  !*** ./src/tailwind.css ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./src/utils/logger.ts":
/*!*****************************!*\
  !*** ./src/utils/logger.ts ***!
  \*****************************/
/*! exports provided: trace, error, getLogger */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trace", function() { return trace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLogger", function() { return getLogger; });
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! debug */ "debug");
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(debug__WEBPACK_IMPORTED_MODULE_0__);
 // not using .extends because of stupid next.js resolve modules bug where its picking up old version of debug

const trace = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:trace:${namespace}`);
const error = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:error:${namespace}`);
const getLogger = namespace => ({
  trace: trace(namespace),
  error: error(namespace)
});

/***/ }),

/***/ 0:
/*!*****************************************!*\
  !*** multi private-next-pages/_app.tsx ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.tsx */"./pages/_app.tsx");


/***/ }),

/***/ "@govtechsg/oa-encryption":
/*!*******************************************!*\
  !*** external "@govtechsg/oa-encryption" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@govtechsg/oa-encryption");

/***/ }),

/***/ "@govtechsg/oa-verify":
/*!***************************************!*\
  !*** external "@govtechsg/oa-verify" ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@govtechsg/oa-verify");

/***/ }),

/***/ "@govtechsg/open-attestation":
/*!**********************************************!*\
  !*** external "@govtechsg/open-attestation" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@govtechsg/open-attestation");

/***/ }),

/***/ "@govtechsg/opencerts-verify":
/*!**********************************************!*\
  !*** external "@govtechsg/opencerts-verify" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@govtechsg/opencerts-verify");

/***/ }),

/***/ "debug":
/*!************************!*\
  !*** external "debug" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("debug");

/***/ }),

/***/ "ethers":
/*!*************************!*\
  !*** external "ethers" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("ethers");

/***/ }),

/***/ "isomorphic-fetch":
/*!***********************************!*\
  !*** external "isomorphic-fetch" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("isomorphic-fetch");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "next-ga":
/*!**************************!*\
  !*** external "next-ga" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-ga");

/***/ }),

/***/ "next-redux-wrapper":
/*!*************************************!*\
  !*** external "next-redux-wrapper" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "next-seo":
/*!***************************!*\
  !*** external "next-seo" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-seo");

/***/ }),

/***/ "next/config":
/*!******************************!*\
  !*** external "next/config" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/config");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "redux-devtools-extension":
/*!*******************************************!*\
  !*** external "redux-devtools-extension" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ "redux-saga":
/*!*****************************!*\
  !*** external "redux-saga" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-saga");

/***/ }),

/***/ "redux-saga/effects":
/*!*************************************!*\
  !*** external "redux-saga/effects" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-saga/effects");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2FwcC5qcyIsIndlYnBhY2s6Ly8vLi4vLi4vcGFnZXMvX2FwcC50c3giLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovLy8uL3BhZ2VzL19hcHAudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL0FuYWx5dGljcy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29uZmlnL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9yZWR1Y2Vycy9jZXJ0aWZpY2F0ZS5hY3Rpb25zLnRzIiwid2VicGFjazovLy8uL3NyYy9yZWR1Y2Vycy9jZXJ0aWZpY2F0ZS5zZWxlY3RvcnMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3JlZHVjZXJzL2NlcnRpZmljYXRlLnRzIiwid2VicGFjazovLy8uL3NyYy9yZWR1Y2Vycy9mZWF0dXJlVG9nZ2xlLmFjdGlvbnMudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3JlZHVjZXJzL2ZlYXR1cmVUb2dnbGUudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3JlZHVjZXJzL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9yZWR1Y2Vycy9zaGFyZWQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NhZ2FzL2NlcnRpZmljYXRlLnRzIiwid2VicGFjazovLy8uL3NyYy9zYWdhcy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvc2VydmljZXMvZW1haWwvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NlcnZpY2VzL2ZyYWdtZW50LnRzIiwid2VicGFjazovLy8uL3NyYy9zZXJ2aWNlcy9saW5rL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9zdG9yZS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvbG9nZ2VyLnRzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBnb3Z0ZWNoc2cvb2EtZW5jcnlwdGlvblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBnb3Z0ZWNoc2cvb2EtdmVyaWZ5XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQGdvdnRlY2hzZy9vcGVuY2VydHMtdmVyaWZ5XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZGVidWdcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJldGhlcnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJpc29tb3JwaGljLWZldGNoXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibG9kYXNoXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC1nYVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQtcmVkdXgtd3JhcHBlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQtc2VvXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9jb25maWdcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtcmVkdXhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlZHV4LXNhZ2FcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eC1zYWdhL2VmZmVjdHNcIiJdLCJuYW1lcyI6WyJwYWdlUHJvcHMiLCJSZWFjdCIsIkNvbXBvbmVudCIsImNvbXBvbmVudERpZENhdGNoIiwicmVuZGVyIiwiX19OX1NTRyIsInVybCIsImNyZWF0ZVVybCIsIkFwcCIsIm9yaWdHZXRJbml0aWFsUHJvcHMiLCJhcHBHZXRJbml0aWFsUHJvcHMiLCJnZXRJbml0aWFsUHJvcHMiLCJ3YXJuQ29udGFpbmVyIiwiY29uc29sZSIsIndhcm5VcmwiLCJwIiwiYmFjayIsInJvdXRlciIsInB1c2giLCJwdXNoVG8iLCJwdXNoUm91dGUiLCJhcyIsInB1c2hVcmwiLCJyZXBsYWNlIiwicmVwbGFjZVRvIiwicmVwbGFjZVJvdXRlIiwicmVwbGFjZVVybCIsIkZlYXR1cmVGbGFnTG9hZGVyIiwiY2hpbGRyZW4iLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwidXNlRWZmZWN0IiwicnVuIiwiZmVhdHVyZVRvZ2dsZSIsIndpbmRvdyIsImZldGNoIiwibWV0aG9kIiwidGhlbiIsInJlc3BvbnNlIiwianNvbiIsInVwZGF0ZUZlYXR1cmVUb2dnbGVzIiwibWFwVmFsdWVzIiwiRU5WSVJPTk1FTlQiLCJNeUFwcCIsInByb3BzIiwiREVGQVVMVF9TRU8iLCJhcHBXcmFwcGVkV2l0aEdBIiwid2l0aEdBIiwiR0FfSUQiLCJSb3V0ZXIiLCJ3cmFwcGVyIiwid2l0aFJlZHV4IiwidHJhY2UiLCJnZXRMb2dnZXIiLCJ0cmFjZURldiIsImlzSW5SZWdpc3RyeSIsInZhbHVlIiwicmVnaXN0cnkiLCJpc3N1ZXJzIiwidmFsaWRhdGVFdmVudCIsImNhdGVnb3J5IiwiYWN0aW9uIiwiRXJyb3IiLCJzdHJpbmdpZnlFdmVudCIsImxhYmVsIiwiYW5hbHl0aWNzRXZlbnQiLCJldmVudCIsInNlbmRFdmVudENlcnRpZmljYXRlVmlld2VkRGV0YWlsZWQiLCJpc3N1ZXIiLCJjZXJ0aWZpY2F0ZURhdGEiLCJpc3N1ZXJOYW1lIiwicmVnaXN0cnlJZCIsInNlcGFyYXRvciIsInN0b3JlIiwiY2VydGlmaWNhdGVTdG9yZSIsImRvY3VtZW50U3RvcmUiLCJ0b2tlblJlZ2lzdHJ5IiwiaWQiLCJuYW1lIiwiaXNzdWVkT24iLCJyZWdpc3RyeUlzc3VlciIsImlkZW50aXR5UHJvb2YiLCJsb2NhdGlvbiIsIm9wdGlvbnMiLCJub25JbnRlcmFjdGlvbiIsImRpbWVuc2lvbjEiLCJkaW1lbnNpb24yIiwiZGltZW5zaW9uMyIsImRpbWVuc2lvbjQiLCJkaW1lbnNpb241IiwiZGltZW5zaW9uNiIsInRyaWdnZXJFcnJvckxvZ2dpbmciLCJyYXdDZXJ0aWZpY2F0ZSIsImVycm9ycyIsImNlcnRpZmljYXRlIiwiZ2V0RGF0YSIsImVycm9yc0xpc3QiLCJqb2luIiwiZm9yRWFjaCIsImRpbWVuc2lvbjciLCJwdWJsaWNSdW50aW1lQ29uZmlnIiwiZ2V0Q29uZmlnIiwiVVJMIiwiQVBJX01BSU5fVVJMIiwiQVBJX1JPUFNURU5fVVJMIiwiQVBJX1JJTktFQllfVVJMIiwiR0FfUFJPRFVDVElPTl9JRCIsIkdBX0RFVkVMT1BNRU5UX0lEIiwiSVNfTUFJTk5FVCIsIm5ldHdvcmsiLCJORVRXT1JLX05BTUUiLCJDQVBUQ0hBX0NMSUVOVF9LRVkiLCJnZXRBcGlVcmwiLCJuZXR3b3JrTmFtZSIsIkVNQUlMX0FQSV9VUkwiLCJTSEFSRV9MSU5LX0FQSV9VUkwiLCJTSEFSRV9MSU5LX1RUTCIsIkxFR0FDWV9PUEVOQ0VSVFNfUkVOREVSRVIiLCJsZWdhY3lSZW5kZXJlclVybCIsImNvbnRleHQiLCJ0aXRsZSIsInRpdGxlVGVtcGxhdGUiLCJkZXNjcmlwdGlvbiIsIm9wZW5HcmFwaCIsInR5cGUiLCJpbWFnZXMiLCJ3aWR0aCIsImhlaWdodCIsImFsdCIsInR3aXR0ZXIiLCJjYXJkVHlwZSIsIlJFU0VUX0NFUlRJRklDQVRFIiwiVVBEQVRFX0NFUlRJRklDQVRFIiwiVkVSSUZZSU5HX0NFUlRJRklDQVRFIiwiVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRCIsIlZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEIiwiU0VORElOR19DRVJUSUZJQ0FURSIsIlNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUyIsIlNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRSIsIlNFTkRJTkdfQ0VSVElGSUNBVEVfUkVTRVQiLCJHRU5FUkFURV9TSEFSRV9MSU5LIiwiR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTIiwiR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFIiwiR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVCIsIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTiIsIlJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HIiwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1MiLCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRSIsIkNFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEUiLCJyZXNldENlcnRpZmljYXRlU3RhdGUiLCJ1cGRhdGVDZXJ0aWZpY2F0ZSIsInBheWxvYWQiLCJ2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSIsInZlcmlmeWluZ0NlcnRpZmljYXRlQ29tcGxldGVkIiwidmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkIiwic2VuZENlcnRpZmljYXRlIiwic2VuZENlcnRpZmljYXRlU3VjY2VzcyIsInNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUiLCJzZW5kQ2VydGlmaWNhdGVSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rIiwiZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCIsImdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyIsImdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZSIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbiIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblBlbmRpbmciLCJyZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzIiwicmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZSIsInVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSIsImdldENlcnRpZmljYXRlIiwicmF3TW9kaWZpZWQiLCJnZXRWZXJpZnlpbmciLCJ2ZXJpZmljYXRpb25QZW5kaW5nIiwicmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3RhdGUiLCJzdGF0ZXMiLCJQRU5ESU5HIiwiZ2V0VmVyaWZpY2F0aW9uU3RhdHVzIiwidmVyaWZpY2F0aW9uU3RhdHVzIiwiZ2V0RW1haWxTZW5kaW5nU3RhdGUiLCJlbWFpbFN0YXRlIiwiZ2V0U2hhcmVMaW5rIiwic2hhcmVMaW5rIiwiZ2V0U2hhcmVMaW5rU3RhdGUiLCJzaGFyZUxpbmtTdGF0ZSIsImdldENlcnRpZmljYXRlQnlBY3Rpb25FcnJvciIsInJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yIiwiaW5pdGlhbFN0YXRlIiwicmF3IiwidmVyaWZpY2F0aW9uRXJyb3IiLCJJTklUSUFMIiwiZW1haWxFcnJvciIsInNoYXJlTGlua0Vycm9yIiwicmVkdWNlciIsInN0YXRlIiwiU1VDQ0VTUyIsIkZBSUxVUkUiLCJVUERBVEVfRkVBVFVSRV9UT0dHTEVTIiwicm9vdFJlZHVjZXIiLCJjb21iaW5lUmVkdWNlcnMiLCJwcm92aWRlciIsImV0aGVycyIsInByb3ZpZGVycyIsIkZhbGxiYWNrUHJvdmlkZXIiLCJwcmlvcml0eSIsIkluZnVyYVByb3ZpZGVyIiwicHJvY2VzcyIsIkFsY2hlbXlQcm92aWRlciIsInZlcmlmeUNlcnRpZmljYXRlIiwicHV0IiwiZnJhZ21lbnRzIiwiY2FsbCIsInZlcmlmeSIsIkpTT04iLCJzdHJpbmdpZnkiLCJpc1ZhbGlkIiwiY2VydGlmaWNhdGVOb3RJc3N1ZWQiLCJjZXJ0aWZpY2F0ZVJldm9rZWQiLCJzZXJ2ZXJFcnJvciIsImludmFsaWRBcmd1bWVudCIsImNvbnRyYWN0Tm90Rm91bmQiLCJsZW5ndGgiLCJlIiwibWVzc2FnZSIsInNlbGVjdCIsImVtYWlsIiwiY2FwdGNoYSIsInN1Y2Nlc3MiLCJzZW5kRW1haWwiLCJnZW5lcmF0ZUxpbmsiLCJ1cmkiLCJrZXkiLCJzdGF0dXMiLCJkb2N1bWVudCIsInBhcnNlIiwiZGVjcnlwdFN0cmluZyIsInRhZyIsImNpcGhlclRleHQiLCJpdiIsInNhZ2FzIiwidGFrZUV2ZXJ5Iiwicm9vdFNhZ2EiLCJhbGwiLCJjZXJ0aWZpY2F0ZVNhZ2EiLCJoZWFkZXJzIiwiQWNjZXB0IiwiYm9keSIsImRhdGEiLCJ0byIsInJlcyIsImdldEZyYWdtZW50c0ZvciIsImZpbHRlciIsImFkZHJlc3NJbnZhbGlkIiwiZG9jdW1lbnRTdG9yZUlzc3VlZEZyYWdtZW50IiwidG9rZW5SZWdpc3RyeU1pbnRlZEZyYWdtZW50IiwicmVhc29uIiwiY29kZSIsIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c0NvZGUiLCJET0NVTUVOVF9OT1RfSVNTVUVEIiwidG9Mb3dlckNhc2UiLCJPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bVRva2VuUmVnaXN0cnlTdGF0dXNDb2RlIiwiRE9DVU1FTlRfTk9UX01JTlRFRCIsIkRPQ1VNRU5UX1JFVk9LRUQiLCJJTlZBTElEX0FSR1VNRU5UIiwiU0VSVkVSX0VSUk9SIiwidW5oYW5kbGVkRXJyb3IiLCJFVEhFUlNfVU5IQU5ETEVEX0VSUk9SIiwidHRsIiwic2FnYU1pZGRsZXdhcmUiLCJjcmVhdGVTYWdhTWlkZGxld2FyZSIsImluaXRTdG9yZSIsImNyZWF0ZVN0b3JlIiwiY29tcG9zZVdpdGhEZXZUb29scyIsImFwcGx5TWlkZGxld2FyZSIsImNyZWF0ZVdyYXBwZXIiLCJuYW1lc3BhY2UiLCJkZWJ1ZyIsImVycm9yIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUN4RkEsK0Q7Ozs7Ozs7Ozs7O0FDQUEsaUJBQWlCLG1CQUFPLENBQUMsaUVBQW1COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTVDOztBQUNBOzs7O0FBa0JBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGtDQUFrQztBQUFBO0FBQWxDO0FBQWtDLENBQWxDLEVBR3lDO0FBQ3ZDLFFBQU1BLFNBQVMsR0FBRyxNQUFNLDJDQUF4QixHQUF3QixDQUF4QjtBQUNBLFNBQU87QUFBUDtBQUFPLEdBQVA7QUFHYTs7QUFBQSxrQkFBMkNDLGVBQU1DLFNBQWpELENBR2I7QUFJQTtBQUNBO0FBQ0E7QUFDQUMsbUJBQWlCLG9CQUE0QztBQUMzRDtBQUdGQzs7QUFBQUEsUUFBTSxHQUFHO0FBQ1AsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUFxRCxLQUEzRDtBQUdBLHdCQUNFLHFFQUdJO0FBQ0E7QUFDSSxNQUFFQyxPQUFPLElBQVQsV0FBd0I7QUFBRUMsU0FBRyxFQUFFQyxTQUFTLENBQXhDLE1BQXdDO0FBQWhCLEtBQXhCLEdBTlYsRUFDRSxFQURGO0FBZkY7O0FBQUE7OztBQUhtQkMsRyxDQUlaQyxtQkFKWUQsR0FJVUUsa0JBSlZGO0FBQUFBLEcsQ0FLWkcsZUFMWUgsR0FLTUUsa0JBTE5GO0FBK0JyQjtBQUNBOztBQUVBLFVBQTJDO0FBQ3pDSSxlQUFhLEdBQUcscUJBQVMsTUFBTTtBQUM3QkMsV0FBTyxDQUFQQTtBQURGRCxHQUFnQixDQUFoQkE7QUFNQUUsU0FBTyxHQUFHLHFCQUFTLE1BQU07QUFDdkJELFdBQU8sQ0FBUEE7QUFERkMsR0FBVSxDQUFWQTtBQU9GLEMsQ0FBQTs7O0FBQ08sc0JBQTJCO0FBQ2hDLFlBQTJDRixhQUFhO0FBQ3hELFNBQU9HLENBQUMsQ0FBUjtBQUdLOztBQUFBLDJCQUFtQztBQUN4QztBQUNBLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFOO0FBQ0EsU0FBTztBQUNMLGdCQUFZO0FBQ1YsZ0JBQTJDRCxPQUFPO0FBQ2xEO0FBSEc7O0FBS0wsbUJBQWU7QUFDYixnQkFBMkNBLE9BQU87QUFDbEQ7QUFQRzs7QUFTTCxpQkFBYTtBQUNYLGdCQUEyQ0EsT0FBTztBQUNsRDtBQVhHOztBQWFMRSxRQUFJLEVBQUUsTUFBTTtBQUNWLGdCQUEyQ0YsT0FBTztBQUNsREcsWUFBTSxDQUFOQTtBQWZHO0FBaUJMQyxRQUFJLEVBQUUsYUFBOEI7QUFDbEMsZ0JBQTJDSixPQUFPO0FBQ2xELGFBQU9HLE1BQU0sQ0FBTkEsVUFBUCxFQUFPQSxDQUFQO0FBbkJHO0FBcUJMRSxVQUFNLEVBQUUsY0FBK0I7QUFDckMsZ0JBQTJDTCxPQUFPO0FBQ2xELFlBQU1NLFNBQVMsR0FBR0MsRUFBRSxVQUFwQjtBQUNBLFlBQU1DLE9BQU8sR0FBR0QsRUFBRSxJQUFsQjtBQUVBLGFBQU9KLE1BQU0sQ0FBTkEsZ0JBQVAsT0FBT0EsQ0FBUDtBQTFCRztBQTRCTE0sV0FBTyxFQUFFLGFBQThCO0FBQ3JDLGdCQUEyQ1QsT0FBTztBQUNsRCxhQUFPRyxNQUFNLENBQU5BLGFBQVAsRUFBT0EsQ0FBUDtBQTlCRztBQWdDTE8sYUFBUyxFQUFFLGNBQStCO0FBQ3hDLGdCQUEyQ1YsT0FBTztBQUNsRCxZQUFNVyxZQUFZLEdBQUdKLEVBQUUsVUFBdkI7QUFDQSxZQUFNSyxVQUFVLEdBQUdMLEVBQUUsSUFBckI7QUFFQSxhQUFPSixNQUFNLENBQU5BLHNCQUFQLFVBQU9BLENBQVA7QUFyQ0o7QUFBTyxHQUFQO0FBd0NELEM7Ozs7Ozs7Ozs7O0FDaElEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NDTEE7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDNkI7O0FBRTdCLE1BQU1VLGlCQUEwQyxHQUFHLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWtCO0FBQ25FLFFBQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7QUFDQTdCLDhDQUFLLENBQUM4QixTQUFOLENBQWdCLE1BQU07QUFDcEIsVUFBTUMsR0FBRyxHQUFHLFlBQTJCO0FBQ3JDLFlBQU1DLGFBQWEsR0FBRyxNQUFNQyxNQUFNLENBQy9CQyxLQUR5QixDQUNuQiwwRUFEbUIsRUFDeUQ7QUFDakZDLGNBQU0sRUFBRTtBQUR5RSxPQUR6RCxFQUl6QkMsSUFKeUIsQ0FJbkJDLFFBQUQsSUFBY0EsUUFBUSxDQUFDQyxJQUFULEVBSk0sQ0FBNUI7QUFLQVYsY0FBUSxDQUFDVyxnR0FBb0IsQ0FBQ0Msd0RBQVMsQ0FBQ1IsYUFBRCxFQUFnQlMsdURBQWhCLENBQVYsQ0FBckIsQ0FBUjtBQUNELEtBUEQ7O0FBUUFWLE9BQUc7QUFDSixHQVZELEVBVUcsQ0FBQ0gsUUFBRCxDQVZIO0FBV0Esc0JBQU87QUFBQSxjQUFHRDtBQUFILG1CQUFQO0FBQ0QsQ0FkRDs7QUFnQkEsTUFBTWUsS0FBTixTQUFvQm5DLCtDQUFwQixDQUF3QjtBQUN0QkosUUFBTSxHQUFnQjtBQUNwQixVQUFNO0FBQUVGLGVBQUY7QUFBYUY7QUFBYixRQUEyQixLQUFLNEMsS0FBdEM7QUFDQSx3QkFDRTtBQUFBLDZCQUNFLHFFQUFDLGlCQUFEO0FBQUEsZ0NBQ0UscUVBQUMsbURBQUQsb0JBQWdCQyx1REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLHFFQUFDLFNBQUQsb0JBQWU3QyxTQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYscUJBREY7QUFRRDs7QUFYcUI7O0FBY3hCLE1BQU04QyxnQkFBZ0IsR0FBR0MsOENBQU0sQ0FBQ0MsaURBQUQsRUFBUUMsa0RBQVIsQ0FBTixDQUFzQk4sS0FBdEIsQ0FBekI7QUFDZU8sa0hBQU8sQ0FBQ0MsU0FBUixDQUFrQkwsZ0JBQWxCLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBLE1BQU07QUFBRU07QUFBRixJQUFZQywrREFBUyxDQUFDLHVCQUFELENBQTNCO0FBQ0EsTUFBTTtBQUFFRCxPQUFLLEVBQUVFO0FBQVQsSUFBc0JELCtEQUFTLENBQUMsaUNBQUQsQ0FBckM7O0FBVUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0UsWUFBVCxDQUFzQkMsS0FBdEIsRUFBNkU7QUFDM0UsU0FBT0EsS0FBSyxJQUFJQyx5REFBUSxDQUFDQyxPQUF6QjtBQUNEOztBQUVNLE1BQU1DLGFBQWEsR0FBRyxDQUFDO0FBQUVDLFVBQUY7QUFBWUMsUUFBWjtBQUFvQkw7QUFBcEIsQ0FBRCxLQUE4QztBQUN6RSxNQUFJLENBQUNJLFFBQUwsRUFBZSxNQUFNLElBQUlFLEtBQUosQ0FBVSxzQkFBVixDQUFOO0FBQ2YsTUFBSSxDQUFDRCxNQUFMLEVBQWEsTUFBTSxJQUFJQyxLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQUNiLE1BQUlOLEtBQUssSUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQTlCLEVBQXdDLE1BQU0sSUFBSU0sS0FBSixDQUFVLHdCQUFWLENBQU47QUFDekMsQ0FKTTtBQU1BLE1BQU1DLGNBQWMsR0FBRyxDQUFDO0FBQUVILFVBQUY7QUFBWUMsUUFBWjtBQUFvQkcsT0FBcEI7QUFBMkJSO0FBQTNCLENBQUQsS0FDM0IsY0FBYUksUUFBUyxjQUFhQyxNQUFPLFlBQVdHLEtBQU0sWUFBV1IsS0FBTSxFQUR4RTtBQUdBLE1BQU1TLGNBQWMsR0FBRyxDQUFDL0IsTUFBRCxFQUFzQ2dDLEtBQXRDLEtBQTZEO0FBQ3pGUCxlQUFhLENBQUNPLEtBQUQsQ0FBYjs7QUFDQSxNQUFJLEtBQUosRUFBdUUsRUFJdEU7O0FBQ0RaLFVBQVEsQ0FBQ1MsY0FBYyxDQUFDRyxLQUFELENBQWYsQ0FBUjtBQUNELENBUk07QUFVQSxNQUFNQyxrQ0FBa0MsR0FBRyxDQUFDO0FBQ2pEQyxRQURpRDtBQUVqREM7QUFGaUQsQ0FBRCxLQU10QztBQUFBOztBQUNWLE1BQUlMLEtBQUssR0FBRyxFQUFaO0FBQ0EsTUFBSU0sVUFBVSxHQUFHLEVBQWpCO0FBQ0EsTUFBSUMsVUFBVSxHQUFHLElBQWpCO0FBRUEsUUFBTUMsU0FBUyxHQUFHLEdBQWxCO0FBQ0EsUUFBTUMsS0FBSyxzREFBR0wsTUFBTSxDQUFDTSxnQkFBVix5RUFBOEJOLE1BQU0sQ0FBQ08sYUFBckMseUNBQXNEUCxNQUFNLENBQUNRLGFBQTdELHlDQUE4RVIsTUFBTSxDQUFDUyxFQUFyRix1Q0FBMkYsRUFBdEcsQ0FOVSxDQU1nRzs7QUFDMUcsUUFBTUEsRUFBRSwwQkFBR1IsZUFBSCxhQUFHQSxlQUFILHVCQUFHQSxlQUFlLENBQUVRLEVBQXBCLHFFQUEwQixFQUFsQztBQUNBLFFBQU1DLElBQUksNEJBQUdULGVBQUgsYUFBR0EsZUFBSCx1QkFBR0EsZUFBZSxDQUFFUyxJQUFwQix5RUFBNEIsRUFBdEM7QUFDQSxRQUFNQyxRQUFRLDRCQUFHVixlQUFILGFBQUdBLGVBQUgsdUJBQUdBLGVBQWUsQ0FBRVUsUUFBcEIseUVBQWdDLEVBQTlDOztBQUVBLE1BQUl4QixZQUFZLENBQUNrQixLQUFELENBQWhCLEVBQXlCO0FBQUE7O0FBQ3ZCLFVBQU1PLGNBQTZCLEdBQUd2Qix5REFBUSxDQUFDQyxPQUFULENBQWlCZSxLQUFqQixDQUF0QztBQUNBRixjQUFVLEdBQUdTLGNBQWMsQ0FBQ0gsRUFBNUI7QUFDQVAsY0FBVSxHQUFHYix5REFBUSxDQUFDQyxPQUFULENBQWlCZSxLQUFqQixFQUF3QkssSUFBckM7QUFDQWQsU0FBSyxHQUFJLFlBQVdTLEtBQU0sSUFBR0QsU0FBVSxrQkFBaUJLLEVBQUcsSUFBR0wsU0FBVSxXQUFVTSxJQUFLLElBQUdOLFNBQVUsZ0JBQWVPLFFBQVMsSUFBR1AsU0FBVSxrQkFBakksZUFDTkYsVUFETSxxREFDUSxFQUNmLElBQUdFLFNBQVUsZ0JBRk4sc0JBRXFCUSxjQUFjLENBQUNILEVBRnBDLG1FQUUwQyxFQUFHLEdBRnJEO0FBR0QsR0FQRCxNQU9PLElBQUlULE1BQU0sQ0FBQ2EsYUFBWCxFQUEwQjtBQUFBOztBQUMvQlgsY0FBVSxHQUFHRixNQUFNLENBQUNhLGFBQVAsQ0FBcUJDLFFBQXJCLElBQWlDLEVBQTlDO0FBQ0FsQixTQUFLLEdBQUksWUFBV1MsS0FBTSxJQUFHRCxTQUFVLGtCQUFpQkssRUFBRyxJQUFHTCxTQUFVLFdBQVVNLElBQUssSUFBR04sU0FBVSxnQkFBZU8sUUFBUyxJQUFHUCxTQUFVLGtCQUFqSSxnQkFDTkYsVUFETSx1REFDUSxFQUNmLEdBRkQ7QUFHRCxHQUxNLE1BS0E7QUFDTE4sU0FBSyxHQUFHLDZGQUFSO0FBQ0Q7O0FBQ0RDLGdCQUFjLENBQUMvQixNQUFELEVBQVM7QUFDckIwQixZQUFRLEVBQUUscUJBRFc7QUFFckJDLFVBQU0sRUFBRyxZQUFXUyxVQUFXLEVBRlY7QUFHckJOLFNBSHFCO0FBSXJCbUIsV0FBTyxFQUFFO0FBQ1BDLG9CQUFjLEVBQUUsSUFEVDtBQUVQQyxnQkFBVSxFQUFFWixLQUFLLElBQUksV0FGZDtBQUdQYSxnQkFBVSxFQUFFVCxFQUFFLElBQUksV0FIWDtBQUlQVSxnQkFBVSxFQUFFVCxJQUFJLElBQUksV0FKYjtBQUtQVSxnQkFBVSxFQUFFVCxRQUFRLElBQUksV0FMakI7QUFNUFUsZ0JBQVUsRUFBRW5CLFVBQVUsSUFBSSxXQU5uQjtBQU9Qb0IsZ0JBQVUsRUFBRW5CLFVBQVUsSUFBSTtBQVBuQjtBQUpZLEdBQVQsQ0FBZDtBQWNELENBOUNNO0FBZ0RBLFNBQVNvQixtQkFBVCxDQUNMQyxjQURLLEVBRUxDLE1BRkssRUFHQztBQUNOLFFBQU1DLFdBQThFLEdBQUdDLDJFQUFPLENBQUNILGNBQUQsQ0FBOUY7QUFFQSxRQUFNZixFQUFFLEdBQUdpQixXQUFILGFBQUdBLFdBQUgsdUJBQUdBLFdBQVcsQ0FBRWpCLEVBQXhCO0FBQ0EsUUFBTUMsSUFBSSxHQUFHZ0IsV0FBSCxhQUFHQSxXQUFILHVCQUFHQSxXQUFXLENBQUVoQixJQUExQjtBQUNBLFFBQU1DLFFBQVEsR0FBR2UsV0FBSCxhQUFHQSxXQUFILHVCQUFHQSxXQUFXLENBQUVmLFFBQTlCO0FBQ0EsUUFBTWlCLFVBQVUsR0FBR0gsTUFBTSxDQUFDSSxJQUFQLENBQVksR0FBWixDQUFuQixDQU5NLENBUU47O0FBQ0FILGFBQVcsQ0FBQ3BDLE9BQVosQ0FBb0J3QyxPQUFwQixDQUE2QjlCLE1BQUQsSUFBdUI7QUFBQTs7QUFDakQsVUFBTUssS0FBSyx3REFBR0wsTUFBTSxDQUFDTSxnQkFBViwyRUFBOEJOLE1BQU0sQ0FBQ08sYUFBckMseUNBQXNEUCxNQUFNLENBQUNRLGFBQTdELHlDQUE4RVIsTUFBTSxDQUFDUyxFQUFyRix5Q0FBMkYsRUFBdEcsQ0FEaUQsQ0FDeUQ7O0FBQzFHLFFBQUlQLFVBQVUsR0FBR0YsTUFBTSxDQUFDVSxJQUF4QjtBQUNBLFFBQUlQLFVBQVUsR0FBRyxJQUFqQjs7QUFFQSxRQUFJaEIsWUFBWSxDQUFDa0IsS0FBRCxDQUFoQixFQUF5QjtBQUN2QixZQUFNTyxjQUE2QixHQUFHdkIseURBQVEsQ0FBQ0MsT0FBVCxDQUFpQmUsS0FBakIsQ0FBdEM7QUFDQUgsZ0JBQVUsR0FBR1UsY0FBYyxDQUFDRixJQUE1QjtBQUNBUCxnQkFBVSxHQUFHUyxjQUFjLENBQUNILEVBQTVCO0FBQ0QsS0FKRCxNQUlPLElBQUlULE1BQU0sQ0FBQ2EsYUFBWCxFQUEwQjtBQUMvQlgsZ0JBQVUsR0FBR0YsTUFBTSxDQUFDYSxhQUFQLENBQXFCQyxRQUFyQixJQUFpQyxFQUE5QztBQUNEOztBQUVEakIsa0JBQWMsQ0FBQy9CLE1BQUQsRUFBUztBQUNyQjBCLGNBQVEsRUFBRSxtQkFEVztBQUVyQkMsWUFBTSxFQUFHLFdBQVVTLFVBQVcsRUFGVDtBQUdyQk4sV0FBSyxFQUFFZ0MsVUFIYztBQUlyQmIsYUFBTyxFQUFFO0FBQ1BDLHNCQUFjLEVBQUUsSUFEVDtBQUVQQyxrQkFBVSxFQUFFWixLQUFLLElBQUksV0FGZDtBQUdQYSxrQkFBVSxFQUFFVCxFQUFFLElBQUksV0FIWDtBQUlQVSxrQkFBVSxFQUFFVCxJQUFJLElBQUksV0FKYjtBQUtQVSxrQkFBVSxFQUFFVCxRQUFRLElBQUksV0FMakI7QUFNUFUsa0JBQVUsRUFBRW5CLFVBQVUsSUFBSSxXQU5uQjtBQU9Qb0Isa0JBQVUsRUFBRW5CLFVBQVUsSUFBSSxXQVBuQjtBQVFQNEIsa0JBQVUsRUFBRUg7QUFSTDtBQUpZLEtBQVQsQ0FBZDtBQWVELEdBNUJEO0FBNkJELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbElEO0FBQ0E7QUFFQSxNQUFNO0FBQUU1QztBQUFGLElBQVlDLCtEQUFTLENBQUMsUUFBRCxDQUEzQixDLENBQ0E7O0FBQ0EsTUFBTTtBQUFFK0MscUJBQW1CLEdBQUc7QUFBeEIsSUFBK0JDLGtEQUFTLEVBQTlDO0FBRU8sTUFBTUMsR0FBRyxHQUFHLHNCQUFaO0FBQ1AsTUFBTUMsWUFBWSxHQUFHLDBCQUFyQjtBQUNBLE1BQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFDQSxNQUFNQyxlQUFlLEdBQUcsa0NBQXhCO0FBRUEsTUFBTUMsZ0JBQWdCLEdBQUcsZ0JBQXpCO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcsZ0JBQTFCO0FBRU8sTUFBTUMsVUFBVSxHQUFHUixtQkFBbUIsQ0FBQ1MsT0FBcEIsS0FBZ0MsU0FBbkQ7QUFDQSxNQUFNQyxZQUFZLFdBQUlGLFVBQVUsR0FBRyxXQUFILEdBQWlCUixtQkFBbUIsQ0FBQ1MsT0FBbkQsdUNBQStELFNBQWpGLEMsQ0FBNEY7O0FBRTVGLE1BQU03RCxLQUFLLEdBQUc0RCxVQUFVLEdBQUdGLGdCQUFILEdBQXNCQyxpQkFBOUM7QUFDQSxNQUFNSSxrQkFBa0IsR0FBRywwQ0FBM0I7O0FBRVAsTUFBTUMsU0FBUyxHQUFJQyxXQUFELElBQWlDO0FBQ2pELE1BQUlBLFdBQVcsS0FBSyxXQUFwQixFQUFpQyxPQUFPVixZQUFQLENBQWpDLEtBQ0ssSUFBSVUsV0FBVyxLQUFLLFNBQXBCLEVBQStCLE9BQU9SLGVBQVA7QUFDcEMsU0FBT0QsZUFBUDtBQUNELENBSkQ7O0FBS08sTUFBTVUsYUFBYSxHQUFJLEdBQUVGLFNBQVMsQ0FBQ0YsWUFBRCxDQUFlLFFBQWpEO0FBQ0EsTUFBTUssa0JBQWtCLEdBQUksR0FBRUgsU0FBUyxDQUFDRixZQUFELENBQWUsVUFBdEQ7QUFDQSxNQUFNTSxjQUFjLEdBQUcsT0FBdkI7QUFFQSxNQUFNQyx5QkFBeUIsR0FBR2pCLG1CQUFtQixDQUFDa0IsaUJBQXBCLElBQXlDLDhCQUEzRTtBQUNBLE1BQU01RSxXQUFXLEdBQUcwRCxtQkFBbUIsQ0FBQ21CLE9BQXBCLEtBQWdDLFlBQWhDLEdBQStDLFlBQS9DLEdBQThELGFBQWxGO0FBRUEsTUFBTTFFLFdBQVcsR0FBRztBQUN6QjJFLE9BQUssRUFBRSxtREFEa0I7QUFFekJDLGVBQWEsRUFBRyxnQkFGUztBQUd6QkMsYUFBVyxFQUNULGdKQUp1QjtBQUt6QkMsV0FBUyxFQUFFO0FBQ1RDLFFBQUksRUFBRSxTQURHO0FBRVR0SCxPQUFHLEVBQUVnRyxHQUZJO0FBR1RrQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRHLFVBQU0sRUFBRSxDQUNOO0FBQ0V2SCxTQUFHLEVBQUcsR0FBRWdHLEdBQUksOEJBRGQ7QUFFRXdCLFdBQUssRUFBRSxHQUZUO0FBR0VDLFlBQU0sRUFBRSxHQUhWO0FBSUVDLFNBQUcsRUFBRTtBQUpQLEtBRE07QUFOQyxHQUxjO0FBb0J6QkMsU0FBTyxFQUFFO0FBQ1BDLFlBQVEsRUFBRTtBQURIO0FBcEJnQixDQUFwQjtBQXlCUDlFLEtBQUssQ0FBRSxZQUFXMEQsWUFBYSxFQUExQixDQUFMO0FBQ0ExRCxLQUFLLENBQUUsdUJBQXNCMkQsa0JBQW1CLEVBQTNDLENBQUw7QUFDQTNELEtBQUssQ0FBRSxrQkFBaUI4RCxhQUFjLEVBQWpDLENBQUwsQzs7Ozs7Ozs7Ozs7O0FDNURBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFJQTtBQUNPLE1BQU1pQixpQkFBaUIsR0FBRyxtQkFBMUI7QUFDQSxNQUFNQyxrQkFBa0IsR0FBRyxvQkFBM0I7QUFDQSxNQUFNQyxxQkFBcUIsR0FBRyx1QkFBOUI7QUFDQSxNQUFNQywrQkFBK0IsR0FBRyxpQ0FBeEMsQyxDQUEyRTs7QUFDM0UsTUFBTUMsNkJBQTZCLEdBQUcsK0JBQXRDLEMsQ0FBdUU7O0FBQ3ZFLE1BQU1DLG1CQUFtQixHQUFHLHFCQUE1QjtBQUNBLE1BQU1DLDJCQUEyQixHQUFHLDZCQUFwQztBQUNBLE1BQU1DLDJCQUEyQixHQUFHLDZCQUFwQztBQUNBLE1BQU1DLHlCQUF5QixHQUFHLDJCQUFsQztBQUNBLE1BQU1DLG1CQUFtQixHQUFHLHFCQUE1QjtBQUNBLE1BQU1DLDJCQUEyQixHQUFHLDZCQUFwQztBQUNBLE1BQU1DLDJCQUEyQixHQUFHLDZCQUFwQztBQUNBLE1BQU1DLHlCQUF5QixHQUFHLDJCQUFsQztBQUNBLE1BQU1DLDhCQUE4QixHQUFHLGdDQUF2QztBQUNBLE1BQU1DLHNDQUFzQyxHQUFHLHdDQUEvQztBQUNBLE1BQU1DLHNDQUFzQyxHQUFHLHdDQUEvQztBQUNBLE1BQU1DLHNDQUFzQyxHQUFHLHdDQUEvQztBQUNBLE1BQU1DLDRCQUE0QixHQUFHLDhCQUFyQztBQUtBLFNBQVNDLHFCQUFULEdBQXlEO0FBQzlELFNBQU87QUFDTHpCLFFBQUksRUFBRU87QUFERCxHQUFQO0FBR0Q7QUFNTSxTQUFTbUIsaUJBQVQsQ0FBMkJDLE9BQTNCLEVBQTBHO0FBQy9HLFNBQU87QUFDTDNCLFFBQUksRUFBRVEsa0JBREQ7QUFFTG1CO0FBRkssR0FBUDtBQUlEO0FBS00sTUFBTUMsb0JBQW9CLEdBQUcsT0FBbUM7QUFDckU1QixNQUFJLEVBQUVTO0FBRCtELENBQW5DLENBQTdCO0FBUUEsTUFBTW9CLDZCQUE2QixHQUN4Q0YsT0FEMkMsS0FFRjtBQUN6QzNCLE1BQUksRUFBRVUsK0JBRG1DO0FBRXpDaUI7QUFGeUMsQ0FGRSxDQUF0QztBQVdBLE1BQU1HLDJCQUEyQixHQUFJSCxPQUFELEtBQXlEO0FBQ2xHM0IsTUFBSSxFQUFFVyw2QkFENEY7QUFFbEdnQjtBQUZrRyxDQUF6RCxDQUFwQztBQVNBLFNBQVNJLGVBQVQsQ0FBeUJKLE9BQXpCLEVBQTZGO0FBQ2xHLFNBQU87QUFDTDNCLFFBQUksRUFBRVksbUJBREQ7QUFFTGU7QUFGSyxHQUFQO0FBSUQ7QUFJTSxTQUFTSyxzQkFBVCxHQUFnRTtBQUNyRSxTQUFPO0FBQ0xoQyxRQUFJLEVBQUVhO0FBREQsR0FBUDtBQUdEO0FBS00sU0FBU29CLHNCQUFULENBQWdDTixPQUFoQyxFQUErRTtBQUNwRixTQUFPO0FBQ0wzQixRQUFJLEVBQUVjLDJCQUREO0FBRUxhO0FBRkssR0FBUDtBQUlEO0FBS00sU0FBU08sb0JBQVQsR0FBNEQ7QUFDakUsU0FBTztBQUNMbEMsUUFBSSxFQUFFZTtBQURELEdBQVA7QUFHRDtBQUtNLFNBQVNvQixpQkFBVCxHQUFzRDtBQUMzRCxTQUFPO0FBQ0xuQyxRQUFJLEVBQUVnQjtBQURELEdBQVA7QUFHRDtBQUlNLFNBQVNvQixzQkFBVCxHQUFnRTtBQUNyRSxTQUFPO0FBQ0xwQyxRQUFJLEVBQUVtQjtBQURELEdBQVA7QUFHRDtBQUtNLFNBQVNrQix3QkFBVCxDQUFrQ1YsT0FBbEMsRUFBd0c7QUFDN0csU0FBTztBQUNMM0IsUUFBSSxFQUFFaUIsMkJBREQ7QUFFTFU7QUFGSyxHQUFQO0FBSUQ7QUFLTSxTQUFTVyx3QkFBVCxDQUFrQ1gsT0FBbEMsRUFBbUY7QUFDeEYsU0FBTztBQUNMM0IsUUFBSSxFQUFFa0IsMkJBREQ7QUFFTFM7QUFGSyxHQUFQO0FBSUQ7QUFNTSxTQUFTWSwyQkFBVCxDQUFxQ1osT0FBckMsRUFBd0c7QUFDN0csU0FBTztBQUNMM0IsUUFBSSxFQUFFb0IsOEJBREQ7QUFFTE87QUFGSyxHQUFQO0FBSUQ7QUFJTSxTQUFTYSxrQ0FBVCxHQUFnRjtBQUNyRixTQUFPO0FBQ0x4QyxRQUFJLEVBQUVxQjtBQURELEdBQVA7QUFHRDtBQUlNLFNBQVNvQixrQ0FBVCxHQUFnRjtBQUNyRjtBQUNBLFNBQU87QUFDTHpDLFFBQUksRUFBRXNCO0FBREQsR0FBUDtBQUdEO0FBTU0sU0FBU29CLGtDQUFULENBQTRDZixPQUE1QyxFQUE2RjtBQUNsRyxTQUFPO0FBQ0wzQixRQUFJLEVBQUV1QixzQ0FERDtBQUVMSTtBQUZLLEdBQVA7QUFJRDtBQU1NLFNBQVNnQiwyQkFBVCxDQUNMaEIsT0FESyxFQUUyQjtBQUNoQyxTQUFPO0FBQ0wzQixRQUFJLEVBQUV3Qiw0QkFERDtBQUVMRztBQUZLLEdBQVA7QUFJRCxDOzs7Ozs7Ozs7Ozs7QUNsTUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFHTyxTQUFTaUIsY0FBVCxDQUF3Qi9GLEtBQXhCLEVBQThGO0FBQ25HLFNBQU9BLEtBQUssQ0FBQ3FCLFdBQU4sQ0FBa0IyRSxXQUF6QjtBQUNEO0FBRU0sU0FBU0MsWUFBVCxDQUFzQmpHLEtBQXRCLEVBQWlEO0FBQ3RELFNBQU9BLEtBQUssQ0FBQ3FCLFdBQU4sQ0FBa0I2RSxtQkFBbEIsSUFBeUNsRyxLQUFLLENBQUNxQixXQUFOLENBQWtCOEUsZ0NBQWxCLEtBQXVEQyw4Q0FBTSxDQUFDQyxPQUE5RztBQUNEO0FBRU0sU0FBU0MscUJBQVQsQ0FBK0J0RyxLQUEvQixFQUFnRjtBQUNyRixTQUFPQSxLQUFLLENBQUNxQixXQUFOLENBQWtCa0Ysa0JBQXpCO0FBQ0Q7QUFFTSxTQUFTQyxvQkFBVCxDQUE4QnhHLEtBQTlCLEVBQXdEO0FBQzdELFNBQU9BLEtBQUssQ0FBQ3FCLFdBQU4sQ0FBa0JvRixVQUF6QjtBQUNEO0FBRU0sU0FBU0MsWUFBVCxDQUFzQjFHLEtBQXRCLEVBQXVFO0FBQzVFLFNBQU9BLEtBQUssQ0FBQ3FCLFdBQU4sQ0FBa0JzRixTQUF6QjtBQUNEO0FBRU0sU0FBU0MsaUJBQVQsQ0FBMkI1RyxLQUEzQixFQUFxRDtBQUMxRCxTQUFPQSxLQUFLLENBQUNxQixXQUFOLENBQWtCd0YsY0FBekI7QUFDRDtBQUVNLFNBQVNDLDJCQUFULENBQXFDOUcsS0FBckMsRUFBc0U7QUFDM0UsU0FBT0EsS0FBSyxDQUFDcUIsV0FBTixDQUFrQjBGLGdDQUF6QjtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0JEO0FBbUJBO0FBcUJPLE1BQU1DLFlBQThCLEdBQUc7QUFDNUNDLEtBQUcsRUFBRSxJQUR1QztBQUU1Q2pCLGFBQVcsRUFBRSxJQUYrQjtBQUk1Q0UscUJBQW1CLEVBQUUsS0FKdUI7QUFLNUNLLG9CQUFrQixFQUFFLElBTHdCO0FBTTVDVyxtQkFBaUIsRUFBRSxJQU55QjtBQVE1Q1QsWUFBVSxFQUFFTCw4Q0FBTSxDQUFDZSxPQVJ5QjtBQVM1Q0MsWUFBVSxFQUFFLElBVGdDO0FBVzVDVCxXQUFTLEVBQUUsRUFYaUM7QUFZNUNFLGdCQUFjLEVBQUVULDhDQUFNLENBQUNlLE9BWnFCO0FBYTVDRSxnQkFBYyxFQUFFLElBYjRCO0FBZTVDbEIsa0NBQWdDLEVBQUVDLDhDQUFNLENBQUNlLE9BZkc7QUFnQjVDSixrQ0FBZ0MsRUFBRTtBQWhCVSxDQUF2QyxDLENBbUJQOztBQUNPLFNBQVNPLE9BQVQsQ0FBaUJDLEtBQUssR0FBR1AsWUFBekIsRUFBdUM1SCxNQUF2QyxFQUF5RjtBQUM5RixVQUFRQSxNQUFNLENBQUMrRCxJQUFmO0FBQ0UsU0FBS08sc0VBQUw7QUFDRSwrQkFDS3NELFlBREw7O0FBR0YsU0FBS3JELHVFQUFMO0FBQ0UsNkNBQ0txRCxZQURMO0FBRUVDLFdBQUcsRUFBRTdILE1BQU0sQ0FBQzBGLE9BRmQ7QUFHRWtCLG1CQUFXLEVBQUU1RyxNQUFNLENBQUMwRjtBQUh0Qjs7QUFLRixTQUFLbEIsMEVBQUw7QUFDRSw2Q0FDSzJELEtBREw7QUFFRXJCLDJCQUFtQixFQUFFLElBRnZCO0FBR0VLLDBCQUFrQixFQUFFO0FBSHRCOztBQUtGLFNBQUsxQyxvRkFBTDtBQUNFLDZDQUNLMEQsS0FETDtBQUVFckIsMkJBQW1CLEVBQUUsS0FGdkI7QUFHRUssMEJBQWtCLEVBQUVuSCxNQUFNLENBQUMwRjtBQUg3Qjs7QUFLRixTQUFLaEIsa0ZBQUw7QUFDRSw2Q0FDS3lELEtBREw7QUFFRXJCLDJCQUFtQixFQUFFLEtBRnZCO0FBR0VnQix5QkFBaUIsRUFBRTlILE1BQU0sQ0FBQzBGO0FBSDVCOztBQUtGLFNBQUtmLHdFQUFMO0FBQ0UsNkNBQ0t3RCxLQURMO0FBRUVkLGtCQUFVLEVBQUVMLDhDQUFNLENBQUNDLE9BRnJCO0FBR0VlLGtCQUFVLEVBQUU7QUFIZDs7QUFLRixTQUFLbEQsOEVBQUw7QUFDRSw2Q0FDS3FELEtBREw7QUFFRWQsa0JBQVUsRUFBRUwsOENBQU0sQ0FBQ2UsT0FGckI7QUFHRUMsa0JBQVUsRUFBRTtBQUhkOztBQUtGLFNBQUtwRCxnRkFBTDtBQUNFLDZDQUNLdUQsS0FETDtBQUVFZCxrQkFBVSxFQUFFTCw4Q0FBTSxDQUFDb0IsT0FGckI7QUFHRUosa0JBQVUsRUFBRTtBQUhkOztBQUtGLFNBQUtuRCxnRkFBTDtBQUNFLDZDQUNLc0QsS0FETDtBQUVFZCxrQkFBVSxFQUFFTCw4Q0FBTSxDQUFDcUIsT0FGckI7QUFHRUwsa0JBQVUsRUFBRWhJLE1BQU0sQ0FBQzBGO0FBSHJCOztBQUtGLFNBQUtWLGdGQUFMO0FBQ0UsNkNBQ0ttRCxLQURMO0FBRUVaLGlCQUFTLEVBQUV2SCxNQUFNLENBQUMwRixPQUZwQjtBQUdFK0Isc0JBQWMsRUFBRVQsOENBQU0sQ0FBQ29CO0FBSHpCOztBQUtGLFNBQUtuRCxnRkFBTDtBQUNFLDZDQUNLa0QsS0FETDtBQUVFWixpQkFBUyxFQUFFLEVBRmI7QUFHRUUsc0JBQWMsRUFBRVQsOENBQU0sQ0FBQ3FCO0FBSHpCOztBQUtGLFNBQUtuRCw4RUFBTDtBQUNFLDZDQUNLaUQsS0FETDtBQUVFWixpQkFBUyxFQUFFLEVBRmI7QUFHRUUsc0JBQWMsRUFBRVQsOENBQU0sQ0FBQ2U7QUFIekI7O0FBS0YsU0FBSzNDLDJGQUFMO0FBQ0UsNkNBQ0srQyxLQURMO0FBRUVwQix3Q0FBZ0MsRUFBRUMsOENBQU0sQ0FBQ0M7QUFGM0M7O0FBSUYsU0FBSzVCLDJGQUFMO0FBQ0UsNkNBQ0s4QyxLQURMO0FBRUVwQix3Q0FBZ0MsRUFBRUMsOENBQU0sQ0FBQ29CO0FBRjNDOztBQUlGLFNBQUs5QywyRkFBTDtBQUNFLDZDQUNLNkMsS0FETDtBQUVFcEIsd0NBQWdDLEVBQUVDLDhDQUFNLENBQUNxQixPQUYzQztBQUdFVix3Q0FBZ0MsRUFBRTNILE1BQU0sQ0FBQzBGO0FBSDNDOztBQUtGLFNBQUtILGlGQUFMO0FBQ0UsNkNBQ0s0QyxLQURMO0FBRUV2QixtQkFBVyxFQUFFNUcsTUFBTSxDQUFDMEY7QUFGdEI7O0FBSUY7QUFDRSxhQUFPeUMsS0FBUDtBQTdGSjtBQStGRCxDOzs7Ozs7Ozs7Ozs7QUM5SkQ7QUFBQTtBQUFBO0FBQU8sTUFBTUcsc0JBQXNCLEdBQUcsd0JBQS9CO0FBUUEsU0FBUzNKLG9CQUFULENBQThCK0csT0FBOUIsRUFBK0Y7QUFDcEcsU0FBTztBQUNMM0IsUUFBSSxFQUFFdUUsc0JBREQ7QUFFTDVDO0FBRkssR0FBUDtBQUlELEM7Ozs7Ozs7Ozs7OztBQ1JEO0FBQUE7QUFBQSxNQUFNa0MsWUFBZ0MsR0FBRyxFQUF6QztBQUVPLFNBQVNNLE9BQVQsQ0FBaUJDLEtBQUssR0FBR1AsWUFBekIsRUFBdUM1SCxNQUF2QyxFQUF3RjtBQUM3RixVQUFRQSxNQUFNLENBQUMrRCxJQUFmO0FBQ0UsU0FBSyx3QkFBTDtBQUNFLGFBQU8vRCxNQUFNLENBQUMwRixPQUFkOztBQUNGO0FBQ0UsYUFBT3lDLEtBQVA7QUFKSjtBQU1ELEM7Ozs7Ozs7Ozs7OztBQ2REO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUVPLE1BQU1JLFdBQVcsR0FBR0MsNkRBQWUsQ0FBQztBQUN6Q3ZHLG1FQUR5QztBQUV6QzdELHVFQUFhQTtBQUY0QixDQUFELENBQW5DLEM7Ozs7Ozs7Ozs7OztBQ0xQO0FBQUE7QUFBTyxJQUFLNEksTUFBWjs7V0FBWUEsTTtBQUFBQSxRO0FBQUFBLFE7QUFBQUEsUTtBQUFBQSxRO0dBQUFBLE0sS0FBQUEsTTs7Ozs7Ozs7Ozs7O0FDQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBa0JBO0FBQ0E7QUFDQTtBQU9BO0FBQ0E7QUFFQSxNQUFNO0FBQUV6SDtBQUFGLElBQVlDLGdFQUFTLENBQUMsa0JBQUQsQ0FBM0IsQyxDQUNBOztBQUNBLE1BQU1pSixRQUFRLEdBQUcsSUFBSUMsNkNBQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsZ0JBQXJCLENBQ2YsQ0FDRTtBQUFFQyxVQUFRLEVBQUUsQ0FBWjtBQUFlSixVQUFRLEVBQUUsSUFBSUMsNkNBQU0sQ0FBQ0MsU0FBUCxDQUFpQkcsY0FBckIsQ0FBb0M3RixvREFBcEMsRUFBa0Q4RixrQ0FBbEQ7QUFBekIsQ0FERixFQUVFO0FBQUVGLFVBQVEsRUFBRSxFQUFaO0FBQWdCSixVQUFRLEVBQUUsSUFBSUMsNkNBQU0sQ0FBQ0MsU0FBUCxDQUFpQkssZUFBckIsQ0FBcUMvRixvREFBckMsRUFBbUQ4RixrQ0FBbkQ7QUFBMUIsQ0FGRixDQURlLEVBS2YsQ0FMZSxDQUFqQjtBQVFPLFVBQVVFLGlCQUFWLENBQTRCO0FBQUV2RCxTQUFPLEVBQUV6RDtBQUFYLENBQTVCLEVBQWdIO0FBQ3JILE1BQUk7QUFDRixVQUFNaUgsOERBQUcsQ0FBQ3ZELDBGQUFvQixFQUFyQixDQUFUO0FBQ0EsVUFBTXdELFNBQVMsR0FBRyxNQUFNQywrREFBSSxDQUFDQywwRUFBTSxDQUFDO0FBQUVaO0FBQUYsS0FBRCxDQUFQLEVBQXVCeEcsV0FBdkIsQ0FBNUI7QUFDQTFDLFNBQUssQ0FBRSx3QkFBdUIrSixJQUFJLENBQUNDLFNBQUwsQ0FBZUosU0FBZixDQUEwQixFQUFuRCxDQUFMO0FBRUEsVUFBTUQsOERBQUcsQ0FBQ3RELG1HQUE2QixDQUFDdUQsU0FBRCxDQUE5QixDQUFUOztBQUNBLFFBQUlLLDJFQUFPLENBQUNMLFNBQUQsQ0FBWCxFQUF3QjtBQUN0Qi9KLHdEQUFNLENBQUMvQixJQUFQLENBQVksU0FBWjtBQUNELEtBRkQsTUFFTztBQUNMLFlBQU0yRSxNQUFnQixHQUFHLEVBQXpCOztBQUNBLFVBQUksQ0FBQ3dILDJFQUFPLENBQUNMLFNBQUQsRUFBWSxDQUFDLG9CQUFELENBQVosQ0FBWixFQUFpRDtBQUMvQ25ILGNBQU0sQ0FBQzNFLElBQVAsQ0FBWSxrQkFBWjtBQUNEOztBQUVELFVBQUksQ0FBQ21NLDJFQUFPLENBQUNMLFNBQUQsRUFBWSxDQUFDLGlCQUFELENBQVosQ0FBWixFQUE4QztBQUM1QyxZQUFJTSxnRkFBb0IsQ0FBQ04sU0FBRCxDQUF4QixFQUFxQ25ILE1BQU0sQ0FBQzNFLElBQVAsQ0FBWSxzQkFBWixFQUFyQyxLQUNLLElBQUlxTSw4RUFBa0IsQ0FBQ1AsU0FBRCxDQUF0QixFQUFtQ25ILE1BQU0sQ0FBQzNFLElBQVAsQ0FBWSxxQkFBWixFQUFuQyxLQUNBLElBQUlzTSx1RUFBVyxDQUFDUixTQUFELENBQWYsRUFBNEJuSCxNQUFNLENBQUMzRSxJQUFQLENBQVksY0FBWixFQUE1QixLQUNBLElBQUl1TSwyRUFBZSxDQUFDVCxTQUFELENBQW5CLEVBQWdDbkgsTUFBTSxDQUFDM0UsSUFBUCxDQUFZLGtCQUFaLEVBQWhDLEtBQ0EsSUFBSXdNLDRFQUFnQixDQUFDVixTQUFELENBQXBCLEVBQWlDbkgsTUFBTSxDQUFDM0UsSUFBUCxDQUFZLDZCQUFaLEVBQWpDLEtBQ0EyRSxNQUFNLENBQUMzRSxJQUFQLENBQVksd0JBQVo7QUFDTjs7QUFFRCxVQUFJLENBQUNtTSwyRUFBTyxDQUFDTCxTQUFELEVBQVksQ0FBQyxpQkFBRCxDQUFaLENBQVosRUFBOEM7QUFDNUNuSCxjQUFNLENBQUMzRSxJQUFQLENBQVksaUJBQVo7QUFDRDs7QUFFRCxVQUFJMkUsTUFBTSxDQUFDOEgsTUFBUCxHQUFnQixDQUFwQixFQUF1QjtBQUNyQmhJLHlGQUFtQixDQUFDRyxXQUFELEVBQWNELE1BQWQsQ0FBbkI7QUFDRDtBQUNGO0FBQ0YsR0EvQkQsQ0ErQkUsT0FBTytILENBQVAsRUFBVTtBQUNWLFVBQU1iLDhEQUFHLENBQUNyRCxpR0FBMkIsQ0FBQ2tFLENBQUMsQ0FBQ0MsT0FBSCxDQUE1QixDQUFUO0FBQ0Q7QUFDRjtBQUVNLFVBQVVsRSxlQUFWLENBQTBCO0FBQUVKO0FBQUYsQ0FBMUIsRUFBd0Y7QUFDN0YsTUFBSTtBQUNGLFVBQU16RCxXQUFXLEdBQUcsTUFBTWdJLGlFQUFNLENBQUN0RCw4RUFBRCxDQUFoQztBQUNBLFVBQU07QUFBRXVELFdBQUY7QUFBU0M7QUFBVCxRQUFxQnpFLE9BQTNCO0FBQ0EsVUFBTTBFLE9BQU8sR0FBRyxNQUFNQyxrRUFBUyxDQUFDO0FBQzlCcEksaUJBRDhCO0FBRTlCaUksV0FGOEI7QUFHOUJDO0FBSDhCLEtBQUQsQ0FBL0I7O0FBTUEsUUFBSSxDQUFDQyxPQUFMLEVBQWM7QUFDWixZQUFNLElBQUluSyxLQUFKLENBQVUsMEJBQVYsQ0FBTjtBQUNEOztBQUVELFVBQU1pSiw4REFBRyxDQUFDbkQsNEZBQXNCLEVBQXZCLENBQVQ7QUFDRCxHQWRELENBY0UsT0FBT2dFLENBQVAsRUFBVTtBQUNWLFVBQU1iLDhEQUFHLENBQUNsRCw0RkFBc0IsQ0FBQytELENBQUMsQ0FBQ0MsT0FBSCxDQUF2QixDQUFUO0FBQ0Q7QUFDRjtBQUVNLFVBQVU5RCxpQkFBVixHQUE4QjtBQUNuQyxNQUFJO0FBQ0YsVUFBTWdELDhEQUFHLENBQUMvQyw0RkFBc0IsRUFBdkIsQ0FBVDtBQUNBLFVBQU1sRSxXQUFXLEdBQUcsTUFBTWdJLGlFQUFNLENBQUN0RCw4RUFBRCxDQUFoQztBQUNBLFVBQU15RCxPQUFPLEdBQUcsTUFBTUUsb0VBQVksQ0FBQ3JJLFdBQUQsQ0FBbEM7O0FBRUEsUUFBSSxDQUFDbUksT0FBTCxFQUFjO0FBQ1osWUFBTSxJQUFJbkssS0FBSixDQUFVLHlDQUFWLENBQU47QUFDRDs7QUFFRCxVQUFNaUosOERBQUcsQ0FBQzlDLDhGQUF3QixDQUFDZ0UsT0FBRCxDQUF6QixDQUFUO0FBQ0QsR0FWRCxDQVVFLE9BQU9MLENBQVAsRUFBVTtBQUNWLFVBQU1iLDhEQUFHLENBQUM3Qyw4RkFBd0IsQ0FBQzBELENBQUMsQ0FBQ0MsT0FBSCxDQUF6QixDQUFUO0FBQ0Q7QUFDRjtBQUVNLFVBQVUxRCwyQkFBVixDQUFzQztBQUFFWixTQUFPLEVBQUU7QUFBRTZFLE9BQUY7QUFBT0M7QUFBUDtBQUFYLENBQXRDLEVBQTZHO0FBQ2xILE1BQUk7QUFDRixVQUFNdEIsOERBQUcsQ0FBQzNDLHdHQUFrQyxFQUFuQyxDQUFULENBREUsQ0FHRjs7QUFDQSxRQUFJdEUsV0FBVyxHQUFHLE1BQU01RCxNQUFNLENBQUNDLEtBQVAsQ0FBYWlNLEdBQWIsRUFBa0IvTCxJQUFsQixDQUF3QkMsUUFBRCxJQUFjO0FBQzNELFVBQUlBLFFBQVEsQ0FBQ2dNLE1BQVQsSUFBbUIsR0FBbkIsSUFBMEJoTSxRQUFRLENBQUNnTSxNQUFULEdBQWtCLEdBQWhELEVBQXFEO0FBQ25ELGNBQU0sSUFBSXhLLEtBQUosQ0FBVyx1Q0FBc0NzSyxHQUFJLEVBQXJELENBQU47QUFDRDs7QUFDRCxhQUFPOUwsUUFBUSxDQUFDQyxJQUFULEVBQVA7QUFDRCxLQUx1QixDQUF4QjtBQU1BdUQsZUFBVyxHQUFHQSxXQUFXLENBQUN5SSxRQUFaLElBQXdCekksV0FBdEMsQ0FWRSxDQVVpRDs7QUFFbkQsUUFBSSxDQUFDQSxXQUFMLEVBQWtCO0FBQ2hCLFlBQU0sSUFBSWhDLEtBQUosQ0FBVywwQkFBeUJzSyxHQUFJLFdBQXhDLENBQU47QUFDRCxLQWRDLENBZUY7OztBQUNBLFFBQUlDLEdBQUcsSUFBSXZJLFdBQVcsQ0FBQzhCLElBQVosS0FBcUIseUJBQWhDLEVBQTJEO0FBQ3pEOUIsaUJBQVcsR0FBR3FILElBQUksQ0FBQ3FCLEtBQUwsQ0FDWkMsOEVBQWEsQ0FBQztBQUNaQyxXQUFHLEVBQUU1SSxXQUFXLENBQUM0SSxHQURMO0FBRVpDLGtCQUFVLEVBQUU3SSxXQUFXLENBQUM2SSxVQUZaO0FBR1pDLFVBQUUsRUFBRTlJLFdBQVcsQ0FBQzhJLEVBSEo7QUFJWlAsV0FKWTtBQUtaekcsWUFBSSxFQUFFOUIsV0FBVyxDQUFDOEI7QUFMTixPQUFELENBREQsQ0FBZDtBQVNELEtBVkQsTUFVTyxJQUFJeUcsR0FBRyxJQUFJdkksV0FBVyxDQUFDOEIsSUFBdkIsRUFBNkI7QUFDbEMsWUFBTSxJQUFJOUQsS0FBSixDQUFXLDBDQUF5Q3VLLEdBQUksYUFBWXZJLFdBQVcsQ0FBQzhCLElBQUssRUFBckYsQ0FBTjtBQUNEOztBQUVELFVBQU1tRiw4REFBRyxDQUFDekQsdUZBQWlCLENBQUN4RCxXQUFELENBQWxCLENBQVQ7QUFDQSxVQUFNaUgsOERBQUcsQ0FBQzFDLHdHQUFrQyxFQUFuQyxDQUFUO0FBQ0QsR0FoQ0QsQ0FnQ0UsT0FBT3VELENBQVAsRUFBVTtBQUNWLFVBQU1iLDhEQUFHLENBQUN6Qyx3R0FBa0MsQ0FBQ3NELENBQUMsQ0FBQ0MsT0FBSCxDQUFuQyxDQUFUO0FBQ0Q7QUFDRixDLENBRUQ7O0FBQ08sTUFBTWdCLEtBQUssR0FBRyxDQUNuQjtBQUNBO0FBQ0FDLG9FQUFTLENBQUM5Riw0RkFBRCxFQUFpQ21CLDJCQUFqQyxDQUhVLEVBSW5CO0FBQ0E7QUFDQTJFLG9FQUFTLENBQUMxRyxnRkFBRCxFQUFxQjBFLGlCQUFyQixDQU5VLEVBT25CO0FBQ0E7QUFDQWdDLG9FQUFTLENBQUN0RyxpRkFBRCxFQUFzQm1CLGVBQXRCLENBVFUsRUFVbkJtRixvRUFBUyxDQUFDbEcsaUZBQUQsRUFBc0JtQixpQkFBdEIsQ0FWVSxDQUFkLEM7Ozs7Ozs7Ozs7OztBQ25LUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVPLFVBQVVnRixRQUFWLEdBQWdDO0FBQ3JDLFFBQU1DLDhEQUFHLENBQUMsQ0FBQyxHQUFHQyxrREFBSixDQUFELENBQVQ7QUFDRCxDOzs7Ozs7Ozs7Ozs7QUNMRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUVPLFNBQVNmLFNBQVQsQ0FBbUI7QUFDeEJwSSxhQUR3QjtBQUV4QmlJLE9BRndCO0FBR3hCQztBQUh3QixDQUFuQixFQVFjO0FBQ25CLFNBQU85TCxNQUFNLENBQ1ZDLEtBREksQ0FDRStFLHFEQURGLEVBQ2lCO0FBQ3BCOUUsVUFBTSxFQUFFLE1BRFk7QUFFcEI4TSxXQUFPLEVBQUU7QUFDUEMsWUFBTSxFQUFFLGtCQUREO0FBRVAsc0JBQWdCO0FBRlQsS0FGVztBQU1wQkMsUUFBSSxFQUFFakMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDbkJpQyxVQUFJLEVBQUV2SixXQURhO0FBRW5Cd0osUUFBRSxFQUFFdkIsS0FGZTtBQUduQkM7QUFIbUIsS0FBZjtBQU5jLEdBRGpCLEVBYUozTCxJQWJJLENBYUVrTixHQUFELElBQVNBLEdBQUcsQ0FBQ2pCLE1BQUosS0FBZSxHQWJ6QixDQUFQO0FBY0QsQzs7Ozs7Ozs7Ozs7O0FDM0JEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBTUEsTUFBTWtCLGVBQWUsR0FBRyxDQUFDeEMsU0FBRCxFQUFvQ2xJLElBQXBDLEtBQ3RCa0ksU0FBUyxDQUFDeUMsTUFBVixDQUFrQm5CLE1BQUQsSUFBWUEsTUFBTSxDQUFDeEosSUFBUCxLQUFnQkEsSUFBN0MsRUFBbUQsQ0FBbkQsQ0FERixDLENBR0E7OztBQUNPLE1BQU00SyxjQUFjLEdBQUkxQyxTQUFELElBQWdEO0FBQUE7O0FBQzVFLFFBQU0yQywyQkFBMkIsR0FBR0gsZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5EO0FBQ0EsUUFBTTRDLDJCQUEyQixHQUFHSixlQUFlLENBQUN4QyxTQUFELEVBQVksNENBQVosQ0FBbkQsQ0FGNEUsQ0FHNUU7O0FBQ0EsU0FDRyxDQUFBMkMsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixxQ0FBQUEsMkJBQTJCLENBQUVFLE1BQTdCLGdGQUFxQ0MsSUFBckMsTUFBOENDLG1HQUE4QyxDQUFDQyxtQkFBN0YsSUFDQyxDQUFBTCwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUUsTUFBN0Isa0ZBQXFDaEMsT0FBckMsQ0FBNkNvQyxXQUE3QyxRQUErRCxpQ0FBaUNBLFdBQWpDLEVBRGpFLElBRUMsQ0FBQUwsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixxQ0FBQUEsMkJBQTJCLENBQUVDLE1BQTdCLGdGQUFxQ0MsSUFBckMsTUFBOENJLG1HQUE4QyxDQUFDQyxtQkFBN0YsSUFDQyxDQUFBUCwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUMsTUFBN0Isa0ZBQXFDaEMsT0FBckMsQ0FBNkNvQyxXQUE3QyxRQUErRCxpQ0FBaUNBLFdBQWpDLEVBSm5FO0FBTUQsQ0FWTSxDLENBWVA7O0FBQ08sTUFBTXZDLGdCQUFnQixHQUFJVixTQUFELElBQWdEO0FBQUE7O0FBQzlFLFFBQU0yQywyQkFBMkIsR0FBR0gsZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5ELENBRDhFLENBRTlFOztBQUNBLFNBQ0UsQ0FBQTJDLDJCQUEyQixTQUEzQixJQUFBQSwyQkFBMkIsV0FBM0Isc0NBQUFBLDJCQUEyQixDQUFFRSxNQUE3QixrRkFBcUNDLElBQXJDLE1BQThDQyxtR0FBOEMsQ0FBQ0MsbUJBQTdGLElBQ0EsQ0FBQUwsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixzQ0FBQUEsMkJBQTJCLENBQUVFLE1BQTdCLGtGQUFxQ2hDLE9BQXJDLENBQTZDb0MsV0FBN0MsUUFBK0Qsd0JBQXdCQSxXQUF4QixFQUZqRTtBQUlELENBUE0sQyxDQVNQOztBQUNPLE1BQU0zQyxvQkFBb0IsR0FBSU4sU0FBRCxJQUFnRDtBQUFBOztBQUNsRixRQUFNMkMsMkJBQTJCLEdBQUdILGVBQWUsQ0FBQ3hDLFNBQUQsRUFBWSw0Q0FBWixDQUFuRDtBQUNBLFFBQU00QywyQkFBMkIsR0FBR0osZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5ELENBRmtGLENBR2xGOztBQUNBLFNBQ0UsQ0FBQTJDLDJCQUEyQixTQUEzQixJQUFBQSwyQkFBMkIsV0FBM0Isc0NBQUFBLDJCQUEyQixDQUFFRSxNQUE3QixrRkFBcUNDLElBQXJDLE1BQThDQyxtR0FBOEMsQ0FBQ0MsbUJBQTdGLElBQ0EsQ0FBQUosMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixzQ0FBQUEsMkJBQTJCLENBQUVDLE1BQTdCLGtGQUFxQ0MsSUFBckMsTUFBOENJLG1HQUE4QyxDQUFDQyxtQkFGL0Y7QUFJRCxDQVJNLEMsQ0FVUDs7QUFDTyxNQUFNNUMsa0JBQWtCLEdBQUlQLFNBQUQsSUFBZ0Q7QUFBQTs7QUFDaEYsUUFBTTJDLDJCQUEyQixHQUFHSCxlQUFlLENBQUN4QyxTQUFELEVBQVksNENBQVosQ0FBbkQsQ0FEZ0YsQ0FFaEY7O0FBQ0EsU0FBTyxDQUFBMkMsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixzQ0FBQUEsMkJBQTJCLENBQUVFLE1BQTdCLGtGQUFxQ0MsSUFBckMsTUFBOENDLG1HQUE4QyxDQUFDSyxnQkFBcEc7QUFDRCxDQUpNLEMsQ0FNUDs7QUFDTyxNQUFNM0MsZUFBZSxHQUFJVCxTQUFELElBQWdEO0FBQUE7O0FBQzdFLFFBQU0yQywyQkFBMkIsR0FBR0gsZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5EO0FBQ0EsUUFBTTRDLDJCQUEyQixHQUFHSixlQUFlLENBQUN4QyxTQUFELEVBQVksNENBQVosQ0FBbkQsQ0FGNkUsQ0FHN0U7O0FBQ0EsU0FDRyxDQUFBMkMsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixzQ0FBQUEsMkJBQTJCLENBQUVFLE1BQTdCLGtGQUFxQ0MsSUFBckMsTUFBOENDLG1HQUE4QyxDQUFDQyxtQkFBN0YsSUFDQyxDQUFBTCwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUUsTUFBN0Isa0ZBQXFDaEMsT0FBckMsQ0FBNkNvQyxXQUE3QyxRQUErRCx5QkFBeUJBLFdBQXpCLEVBRGpFLElBRUMsQ0FBQUwsMkJBQTJCLFNBQTNCLElBQUFBLDJCQUEyQixXQUEzQixzQ0FBQUEsMkJBQTJCLENBQUVDLE1BQTdCLGtGQUFxQ0MsSUFBckMsTUFBOENJLG1HQUE4QyxDQUFDRyxnQkFBN0YsSUFDQyxDQUFBVCwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUMsTUFBN0Isa0ZBQXFDaEMsT0FBckMsQ0FBNkNvQyxXQUE3QyxRQUErRCw2QkFBNkJBLFdBQTdCLEVBSm5FO0FBTUQsQ0FWTSxDLENBWVA7O0FBQ08sTUFBTXpDLFdBQVcsR0FBSVIsU0FBRCxJQUFnRDtBQUFBOztBQUN6RSxRQUFNMkMsMkJBQTJCLEdBQUdILGVBQWUsQ0FBQ3hDLFNBQUQsRUFBWSw0Q0FBWixDQUFuRDtBQUNBLFFBQU00QywyQkFBMkIsR0FBR0osZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5ELENBRnlFLENBR3pFOztBQUNBLFNBQ0UsQ0FBQTJDLDJCQUEyQixTQUEzQixJQUFBQSwyQkFBMkIsV0FBM0Isc0NBQUFBLDJCQUEyQixDQUFFRSxNQUE3QixrRkFBcUNDLElBQXJDLE1BQThDQyxtR0FBOEMsQ0FBQ08sWUFBN0YsSUFDQSxDQUFBViwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUMsTUFBN0Isa0ZBQXFDQyxJQUFyQyxNQUE4Q0ksbUdBQThDLENBQUNJLFlBRi9GO0FBSUQsQ0FSTSxDLENBVVA7O0FBQ08sTUFBTUMsY0FBYyxHQUFJdkQsU0FBRCxJQUFnRDtBQUFBOztBQUM1RSxRQUFNMkMsMkJBQTJCLEdBQUdILGVBQWUsQ0FBQ3hDLFNBQUQsRUFBWSw0Q0FBWixDQUFuRDtBQUNBLFFBQU00QywyQkFBMkIsR0FBR0osZUFBZSxDQUFDeEMsU0FBRCxFQUFZLDRDQUFaLENBQW5ELENBRjRFLENBRzVFOztBQUNBLFNBQ0UsQ0FBQTJDLDJCQUEyQixTQUEzQixJQUFBQSwyQkFBMkIsV0FBM0IsdUNBQUFBLDJCQUEyQixDQUFFRSxNQUE3QixvRkFBcUNDLElBQXJDLE1BQ0VDLG1HQUE4QyxDQUFDUyxzQkFEakQsSUFFQSxDQUFBWiwyQkFBMkIsU0FBM0IsSUFBQUEsMkJBQTJCLFdBQTNCLHNDQUFBQSwyQkFBMkIsQ0FBRUMsTUFBN0Isa0ZBQXFDQyxJQUFyQyxNQUE4Q0MsbUdBQThDLENBQUNTLHNCQUgvRjtBQUtELENBVE0sQzs7Ozs7Ozs7Ozs7O0FDM0VQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBRU8sU0FBU3JDLFlBQVQsQ0FBc0JySSxXQUF0QixFQUEwRjtBQUMvRixTQUFPNUQsTUFBTSxDQUNWQyxLQURJLENBQ0csR0FBRWdGLDBEQUFtQixHQUR4QixFQUM0QjtBQUMvQi9FLFVBQU0sRUFBRSxNQUR1QjtBQUUvQjhNLFdBQU8sRUFBRTtBQUNQQyxZQUFNLEVBQUUsa0JBREQ7QUFFUCxzQkFBZ0I7QUFGVCxLQUZzQjtBQU0vQkMsUUFBSSxFQUFFakMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDbkJxRCxTQUFHLEVBQUVySixzREFEYztBQUVuQm1ILGNBQVEsRUFBRXpJO0FBRlMsS0FBZjtBQU55QixHQUQ1QixFQVlKekQsSUFaSSxDQVlFa04sR0FBRCxJQUFTQSxHQUFHLENBQUNoTixJQUFKLEVBWlYsQ0FBUDtBQWFELEM7Ozs7Ozs7Ozs7OztBQ2xCRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU1tTyxjQUFjLEdBQUdDLGlEQUFvQixFQUEzQztBQUVPLE1BQU1DLFNBQVMsR0FBRyxNQUF3QjtBQUMvQyxRQUFNbk0sS0FBSyxHQUFHb00seURBQVcsQ0FBQ3pFLHFEQUFELEVBQWMwRSxvRkFBbUIsQ0FBQ0MsNkRBQWUsQ0FBQ0wsY0FBRCxDQUFoQixDQUFqQyxDQUF6QjtBQUNBQSxnQkFBYyxDQUFDMU8sR0FBZixDQUFtQitNLCtDQUFuQjtBQUNBLFNBQU90SyxLQUFQO0FBQ0QsQ0FKTTtBQU1BLE1BQU12QixPQUFPLEdBQUc4Tix3RUFBYSxDQUFZSixTQUFaLENBQTdCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBRUE7O0FBQ08sTUFBTXhOLEtBQUssR0FBSTZOLFNBQUQsSUFBaUNDLDRDQUFLLENBQUUsMkJBQTBCRCxTQUFVLEVBQXRDLENBQXBEO0FBQ0EsTUFBTUUsS0FBSyxHQUFJRixTQUFELElBQWlDQyw0Q0FBSyxDQUFFLDJCQUEwQkQsU0FBVSxFQUF0QyxDQUFwRDtBQUVBLE1BQU01TixTQUFTLEdBQUk0TixTQUFELEtBQThEO0FBQ3JGN04sT0FBSyxFQUFFQSxLQUFLLENBQUM2TixTQUFELENBRHlFO0FBRXJGRSxPQUFLLEVBQUVBLEtBQUssQ0FBQ0YsU0FBRDtBQUZ5RSxDQUE5RCxDQUFsQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05QLHFEOzs7Ozs7Ozs7OztBQ0FBLGlEOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLG1DOzs7Ozs7Ozs7OztBQ0FBLDZDOzs7Ozs7Ozs7OztBQ0FBLG1DOzs7Ozs7Ozs7OztBQ0FBLG9DOzs7Ozs7Ozs7OztBQ0FBLCtDOzs7Ozs7Ozs7OztBQ0FBLHFDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtEOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHVDOzs7Ozs7Ozs7OztBQ0FBLCtDIiwiZmlsZSI6InBhZ2VzL19hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMCk7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3V0aWxzLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L3BhZ2VzL19hcHAnKVxuIiwiaW1wb3J0IFJlYWN0LCB7IEVycm9ySW5mbyB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHtcbiAgZXhlY09uY2UsXG4gIGxvYWRHZXRJbml0aWFsUHJvcHMsXG4gIEFwcENvbnRleHRUeXBlLFxuICBBcHBJbml0aWFsUHJvcHMsXG4gIEFwcFByb3BzVHlwZSxcbiAgTmV4dFdlYlZpdGFsc01ldHJpYyxcbn0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3V0aWxzJ1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnLi4vY2xpZW50L3JvdXRlcidcblxuZXhwb3J0IHsgQXBwSW5pdGlhbFByb3BzIH1cblxuZXhwb3J0IHsgTmV4dFdlYlZpdGFsc01ldHJpYyB9XG5cbmV4cG9ydCB0eXBlIEFwcENvbnRleHQgPSBBcHBDb250ZXh0VHlwZTxSb3V0ZXI+XG5cbmV4cG9ydCB0eXBlIEFwcFByb3BzPFAgPSB7fT4gPSBBcHBQcm9wc1R5cGU8Um91dGVyLCBQPlxuXG4vKipcbiAqIGBBcHBgIGNvbXBvbmVudCBpcyB1c2VkIGZvciBpbml0aWFsaXplIG9mIHBhZ2VzLiBJdCBhbGxvd3MgZm9yIG92ZXJ3cml0aW5nIGFuZCBmdWxsIGNvbnRyb2wgb2YgdGhlIGBwYWdlYCBpbml0aWFsaXphdGlvbi5cbiAqIFRoaXMgYWxsb3dzIGZvciBrZWVwaW5nIHN0YXRlIGJldHdlZW4gbmF2aWdhdGlvbiwgY3VzdG9tIGVycm9yIGhhbmRsaW5nLCBpbmplY3RpbmcgYWRkaXRpb25hbCBkYXRhLlxuICovXG5hc3luYyBmdW5jdGlvbiBhcHBHZXRJbml0aWFsUHJvcHMoe1xuICBDb21wb25lbnQsXG4gIGN0eCxcbn06IEFwcENvbnRleHQpOiBQcm9taXNlPEFwcEluaXRpYWxQcm9wcz4ge1xuICBjb25zdCBwYWdlUHJvcHMgPSBhd2FpdCBsb2FkR2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCwgY3R4KVxuICByZXR1cm4geyBwYWdlUHJvcHMgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBBcHA8UCA9IHt9LCBDUCA9IHt9LCBTID0ge30+IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PFxuICBQICYgQXBwUHJvcHM8Q1A+LFxuICBTXG4+IHtcbiAgc3RhdGljIG9yaWdHZXRJbml0aWFsUHJvcHMgPSBhcHBHZXRJbml0aWFsUHJvcHNcbiAgc3RhdGljIGdldEluaXRpYWxQcm9wcyA9IGFwcEdldEluaXRpYWxQcm9wc1xuXG4gIC8vIEtlcHQgaGVyZSBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHkuXG4gIC8vIFdoZW4gc29tZW9uZSBlbmRlZCBBcHAgdGhleSBjb3VsZCBjYWxsIGBzdXBlci5jb21wb25lbnREaWRDYXRjaGAuXG4gIC8vIEBkZXByZWNhdGVkIFRoaXMgbWV0aG9kIGlzIG5vIGxvbmdlciBuZWVkZWQuIEVycm9ycyBhcmUgY2F1Z2h0IGF0IHRoZSB0b3AgbGV2ZWxcbiAgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3I6IEVycm9yLCBfZXJyb3JJbmZvOiBFcnJvckluZm8pOiB2b2lkIHtcbiAgICB0aHJvdyBlcnJvclxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgcm91dGVyLCBDb21wb25lbnQsIHBhZ2VQcm9wcywgX19OX1NTRywgX19OX1NTUCB9ID0gdGhpc1xuICAgICAgLnByb3BzIGFzIEFwcFByb3BzPENQPlxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxDb21wb25lbnRcbiAgICAgICAgey4uLnBhZ2VQcm9wc31cbiAgICAgICAge1xuICAgICAgICAgIC8vIHdlIGRvbid0IGFkZCB0aGUgbGVnYWN5IFVSTCBwcm9wIGlmIGl0J3MgdXNpbmcgbm9uLWxlZ2FjeVxuICAgICAgICAgIC8vIG1ldGhvZHMgbGlrZSBnZXRTdGF0aWNQcm9wcyBhbmQgZ2V0U2VydmVyU2lkZVByb3BzXG4gICAgICAgICAgLi4uKCEoX19OX1NTRyB8fCBfX05fU1NQKSA/IHsgdXJsOiBjcmVhdGVVcmwocm91dGVyKSB9IDoge30pXG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgKVxuICB9XG59XG5cbmxldCB3YXJuQ29udGFpbmVyOiAoKSA9PiB2b2lkXG5sZXQgd2FyblVybDogKCkgPT4gdm9pZFxuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICB3YXJuQ29udGFpbmVyID0gZXhlY09uY2UoKCkgPT4ge1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIGBXYXJuaW5nOiB0aGUgXFxgQ29udGFpbmVyXFxgIGluIFxcYF9hcHBcXGAgaGFzIGJlZW4gZGVwcmVjYXRlZCBhbmQgc2hvdWxkIGJlIHJlbW92ZWQuIGh0dHBzOi8vZXJyLnNoL3ZlcmNlbC9uZXh0LmpzL2FwcC1jb250YWluZXItZGVwcmVjYXRlZGBcbiAgICApXG4gIH0pXG5cbiAgd2FyblVybCA9IGV4ZWNPbmNlKCgpID0+IHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYFdhcm5pbmc6IHRoZSAndXJsJyBwcm9wZXJ0eSBpcyBkZXByZWNhdGVkLiBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy91cmwtZGVwcmVjYXRlZGBcbiAgICApXG4gIH0pXG59XG5cbi8vIEBkZXByZWNhdGVkIG5vb3AgZm9yIG5vdyB1bnRpbCByZW1vdmFsXG5leHBvcnQgZnVuY3Rpb24gQ29udGFpbmVyKHA6IGFueSkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FybkNvbnRhaW5lcigpXG4gIHJldHVybiBwLmNoaWxkcmVuXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVVcmwocm91dGVyOiBSb3V0ZXIpIHtcbiAgLy8gVGhpcyBpcyB0byBtYWtlIHN1cmUgd2UgZG9uJ3QgcmVmZXJlbmNlcyB0aGUgcm91dGVyIG9iamVjdCBhdCBjYWxsIHRpbWVcbiAgY29uc3QgeyBwYXRobmFtZSwgYXNQYXRoLCBxdWVyeSB9ID0gcm91dGVyXG4gIHJldHVybiB7XG4gICAgZ2V0IHF1ZXJ5KCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHF1ZXJ5XG4gICAgfSxcbiAgICBnZXQgcGF0aG5hbWUoKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByZXR1cm4gcGF0aG5hbWVcbiAgICB9LFxuICAgIGdldCBhc1BhdGgoKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByZXR1cm4gYXNQYXRoXG4gICAgfSxcbiAgICBiYWNrOiAoKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByb3V0ZXIuYmFjaygpXG4gICAgfSxcbiAgICBwdXNoOiAodXJsOiBzdHJpbmcsIGFzPzogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByZXR1cm4gcm91dGVyLnB1c2godXJsLCBhcylcbiAgICB9LFxuICAgIHB1c2hUbzogKGhyZWY6IHN0cmluZywgYXM/OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIGNvbnN0IHB1c2hSb3V0ZSA9IGFzID8gaHJlZiA6ICcnXG4gICAgICBjb25zdCBwdXNoVXJsID0gYXMgfHwgaHJlZlxuXG4gICAgICByZXR1cm4gcm91dGVyLnB1c2gocHVzaFJvdXRlLCBwdXNoVXJsKVxuICAgIH0sXG4gICAgcmVwbGFjZTogKHVybDogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHJvdXRlci5yZXBsYWNlKHVybCwgYXMpXG4gICAgfSxcbiAgICByZXBsYWNlVG86IChocmVmOiBzdHJpbmcsIGFzPzogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICBjb25zdCByZXBsYWNlUm91dGUgPSBhcyA/IGhyZWYgOiAnJ1xuICAgICAgY29uc3QgcmVwbGFjZVVybCA9IGFzIHx8IGhyZWZcblxuICAgICAgcmV0dXJuIHJvdXRlci5yZXBsYWNlKHJlcGxhY2VSb3V0ZSwgcmVwbGFjZVVybClcbiAgICB9LFxuICB9XG59XG4iLCJmdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgIFwiZGVmYXVsdFwiOiBvYmpcbiAgfTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0OyIsImltcG9ydCB7IG1hcFZhbHVlcyB9IGZyb20gXCJsb2Rhc2hcIjtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbi8vIEB0cy1pZ25vcmUgcmVwb3NpdG9yeSBoYXMgYmVlbiBhcmNoaXZlZCwgd2lsbCB3YWl0IHRvIHVwZ3JhZGUgdG8gZml4XG5pbXBvcnQgd2l0aEdBIGZyb20gXCJuZXh0LWdhXCI7XG5pbXBvcnQgeyBEZWZhdWx0U2VvIH0gZnJvbSBcIm5leHQtc2VvXCI7XG5pbXBvcnQgQXBwIGZyb20gXCJuZXh0L2FwcFwiO1xuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZURpc3BhdGNoIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyBERUZBVUxUX1NFTywgRU5WSVJPTk1FTlQsIEdBX0lEIH0gZnJvbSBcIi4uL3NyYy9jb25maWdcIjtcbmltcG9ydCB7IHVwZGF0ZUZlYXR1cmVUb2dnbGVzIH0gZnJvbSBcIi4uL3NyYy9yZWR1Y2Vycy9mZWF0dXJlVG9nZ2xlLmFjdGlvbnNcIjtcbmltcG9ydCB7IHdyYXBwZXIgfSBmcm9tIFwiLi4vc3JjL3N0b3JlXCI7XG5pbXBvcnQgXCIuLi9zcmMvdGFpbHdpbmQuY3NzXCI7XG5cbmNvbnN0IEZlYXR1cmVGbGFnTG9hZGVyOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudCA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJ1biA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgIGNvbnN0IGZlYXR1cmVUb2dnbGUgPSBhd2FpdCB3aW5kb3dcbiAgICAgICAgLmZldGNoKFwiaHR0cHM6Ly9zMy1hcC1zb3V0aGVhc3QtMS5hbWF6b25hd3MuY29tL29wZW5jZXJ0cy5pby9mZWF0dXJlLXRvZ2dsZS5qc29uXCIsIHtcbiAgICAgICAgICBtZXRob2Q6IFwiR0VUXCIsXG4gICAgICAgIH0pXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuanNvbigpKTtcbiAgICAgIGRpc3BhdGNoKHVwZGF0ZUZlYXR1cmVUb2dnbGVzKG1hcFZhbHVlcyhmZWF0dXJlVG9nZ2xlLCBFTlZJUk9OTUVOVCkpKTtcbiAgICB9O1xuICAgIHJ1bigpO1xuICB9LCBbZGlzcGF0Y2hdKTtcbiAgcmV0dXJuIDw+e2NoaWxkcmVufTwvPjtcbn07XG5cbmNsYXNzIE15QXBwIGV4dGVuZHMgQXBwIHtcbiAgcmVuZGVyKCk6IEpTWC5FbGVtZW50IHtcbiAgICBjb25zdCB7IENvbXBvbmVudCwgcGFnZVByb3BzIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8RmVhdHVyZUZsYWdMb2FkZXI+XG4gICAgICAgICAgPERlZmF1bHRTZW8gey4uLkRFRkFVTFRfU0VPfSAvPlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgPC9GZWF0dXJlRmxhZ0xvYWRlcj5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgYXBwV3JhcHBlZFdpdGhHQSA9IHdpdGhHQShHQV9JRCwgUm91dGVyKShNeUFwcCk7XG5leHBvcnQgZGVmYXVsdCB3cmFwcGVyLndpdGhSZWR1eChhcHBXcmFwcGVkV2l0aEdBKTtcbiIsImltcG9ydCB7IHYyLCBXcmFwcGVkRG9jdW1lbnQsIGdldERhdGEgfSBmcm9tIFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCI7XG5pbXBvcnQgeyBSZWdpc3RyeUVudHJ5IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3BlbmNlcnRzLXZlcmlmeVwiO1xuaW1wb3J0IHJlZ2lzdHJ5IGZyb20gXCIuLi8uLi8uLi9wdWJsaWMvc3RhdGljL3JlZ2lzdHJ5Lmpzb25cIjtcbmltcG9ydCB7IGdldExvZ2dlciB9IGZyb20gXCIuLi8uLi91dGlscy9sb2dnZXJcIjtcbmNvbnN0IHsgdHJhY2UgfSA9IGdldExvZ2dlcihcImNvbXBvbmVudHM6QW5hbHl0aWNzOlwiKTtcbmNvbnN0IHsgdHJhY2U6IHRyYWNlRGV2IH0gPSBnZXRMb2dnZXIoXCJjb21wb25lbnRzOkFuYWx5dGljcyhJbmFjdGl2ZSk6XCIpO1xuXG5pbnRlcmZhY2UgRXZlbnQge1xuICBjYXRlZ29yeTogc3RyaW5nO1xuICBhY3Rpb246IHN0cmluZztcbiAgdmFsdWU/OiBzdHJpbmcgfCBudW1iZXI7XG4gIGxhYmVsPzogc3RyaW5nO1xuICBvcHRpb25zPzogVW5pdmVyc2FsQW5hbHl0aWNzLkZpZWxkc09iamVjdDtcbn1cblxuLypcbiAqIFRoaXMgZnVuY3Rpb24gY2hlY2tzIGlmIGFuIGFkZHJlc3MgaXMgaW4gcmVnaXN0cnkuanNvbiB0byBwcm92aWRlIHByb3BlcnR5IGFjY2Vzcy5cbiAqL1xuZnVuY3Rpb24gaXNJblJlZ2lzdHJ5KHZhbHVlOiBzdHJpbmcpOiB2YWx1ZSBpcyBrZXlvZiB0eXBlb2YgcmVnaXN0cnkuaXNzdWVycyB7XG4gIHJldHVybiB2YWx1ZSBpbiByZWdpc3RyeS5pc3N1ZXJzO1xufVxuXG5leHBvcnQgY29uc3QgdmFsaWRhdGVFdmVudCA9ICh7IGNhdGVnb3J5LCBhY3Rpb24sIHZhbHVlIH06IEV2ZW50KTogdm9pZCA9PiB7XG4gIGlmICghY2F0ZWdvcnkpIHRocm93IG5ldyBFcnJvcihcIkNhdGVnb3J5IGlzIHJlcXVpcmVkXCIpO1xuICBpZiAoIWFjdGlvbikgdGhyb3cgbmV3IEVycm9yKFwiQWN0aW9uIGlzIHJlcXVpcmVkXCIpO1xuICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlICE9PSBcIm51bWJlclwiKSB0aHJvdyBuZXcgRXJyb3IoXCJWYWx1ZSBtdXN0IGJlIGEgbnVtYmVyXCIpO1xufTtcblxuZXhwb3J0IGNvbnN0IHN0cmluZ2lmeUV2ZW50ID0gKHsgY2F0ZWdvcnksIGFjdGlvbiwgbGFiZWwsIHZhbHVlIH06IEV2ZW50KTogc3RyaW5nID0+XG4gIGBDYXRlZ29yeSo6ICR7Y2F0ZWdvcnl9LCBBY3Rpb24qOiAke2FjdGlvbn0sIExhYmVsOiAke2xhYmVsfSwgVmFsdWU6ICR7dmFsdWV9YDtcblxuZXhwb3J0IGNvbnN0IGFuYWx5dGljc0V2ZW50ID0gKHdpbmRvdzogUGFydGlhbDxXaW5kb3c+IHwgdW5kZWZpbmVkLCBldmVudDogRXZlbnQpOiB2b2lkID0+IHtcbiAgdmFsaWRhdGVFdmVudChldmVudCk7XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiB3aW5kb3cuZ2EgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBjb25zdCB7IGNhdGVnb3J5LCBhY3Rpb24sIGxhYmVsLCB2YWx1ZSwgb3B0aW9ucyA9IHVuZGVmaW5lZCB9ID0gZXZlbnQ7XG4gICAgdHJhY2Uoc3RyaW5naWZ5RXZlbnQoZXZlbnQpKTtcbiAgICByZXR1cm4gd2luZG93LmdhKFwic2VuZFwiLCBcImV2ZW50XCIsIGNhdGVnb3J5LCBhY3Rpb24sIGxhYmVsLCB2YWx1ZSwgb3B0aW9ucyk7XG4gIH1cbiAgdHJhY2VEZXYoc3RyaW5naWZ5RXZlbnQoZXZlbnQpKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzZW5kRXZlbnRDZXJ0aWZpY2F0ZVZpZXdlZERldGFpbGVkID0gKHtcbiAgaXNzdWVyLFxuICBjZXJ0aWZpY2F0ZURhdGEsXG59OiB7XG4gIGlzc3VlcjogdjIuSXNzdWVyO1xuICBjZXJ0aWZpY2F0ZURhdGE6IHsgaWQ/OiBzdHJpbmc7IG5hbWU/OiBzdHJpbmc7IGlzc3VlZE9uPzogc3RyaW5nIH07XG59KTogdm9pZCA9PiB7XG4gIGxldCBsYWJlbCA9IFwiXCI7XG4gIGxldCBpc3N1ZXJOYW1lID0gXCJcIjtcbiAgbGV0IHJlZ2lzdHJ5SWQgPSBudWxsO1xuXG4gIGNvbnN0IHNlcGFyYXRvciA9IFwiO1wiO1xuICBjb25zdCBzdG9yZSA9IGlzc3Vlci5jZXJ0aWZpY2F0ZVN0b3JlID8/IGlzc3Vlci5kb2N1bWVudFN0b3JlID8/IGlzc3Vlci50b2tlblJlZ2lzdHJ5ID8/IGlzc3Vlci5pZCA/PyBcIlwiOyAvLyB1c2UgaWQgZm9yIERJRFxuICBjb25zdCBpZCA9IGNlcnRpZmljYXRlRGF0YT8uaWQgPz8gXCJcIjtcbiAgY29uc3QgbmFtZSA9IGNlcnRpZmljYXRlRGF0YT8ubmFtZSA/PyBcIlwiO1xuICBjb25zdCBpc3N1ZWRPbiA9IGNlcnRpZmljYXRlRGF0YT8uaXNzdWVkT24gPz8gXCJcIjtcblxuICBpZiAoaXNJblJlZ2lzdHJ5KHN0b3JlKSkge1xuICAgIGNvbnN0IHJlZ2lzdHJ5SXNzdWVyOiBSZWdpc3RyeUVudHJ5ID0gcmVnaXN0cnkuaXNzdWVyc1tzdG9yZV07XG4gICAgcmVnaXN0cnlJZCA9IHJlZ2lzdHJ5SXNzdWVyLmlkO1xuICAgIGlzc3Vlck5hbWUgPSByZWdpc3RyeS5pc3N1ZXJzW3N0b3JlXS5uYW1lO1xuICAgIGxhYmVsID0gYFwic3RvcmVcIjpcIiR7c3RvcmV9XCIke3NlcGFyYXRvcn1cImRvY3VtZW50X2lkXCI6XCIke2lkfVwiJHtzZXBhcmF0b3J9XCJuYW1lXCI6XCIke25hbWV9XCIke3NlcGFyYXRvcn1cImlzc3VlZF9vblwiOlwiJHtpc3N1ZWRPbn1cIiR7c2VwYXJhdG9yfVwiaXNzdWVyX25hbWVcIjpcIiR7XG4gICAgICBpc3N1ZXJOYW1lID8/IFwiXCJcbiAgICB9XCIke3NlcGFyYXRvcn1cImlzc3Vlcl9pZFwiOlwiJHtyZWdpc3RyeUlzc3Vlci5pZCA/PyBcIlwifVwiYDtcbiAgfSBlbHNlIGlmIChpc3N1ZXIuaWRlbnRpdHlQcm9vZikge1xuICAgIGlzc3Vlck5hbWUgPSBpc3N1ZXIuaWRlbnRpdHlQcm9vZi5sb2NhdGlvbiB8fCBcIlwiO1xuICAgIGxhYmVsID0gYFwic3RvcmVcIjpcIiR7c3RvcmV9XCIke3NlcGFyYXRvcn1cImRvY3VtZW50X2lkXCI6XCIke2lkfVwiJHtzZXBhcmF0b3J9XCJuYW1lXCI6XCIke25hbWV9XCIke3NlcGFyYXRvcn1cImlzc3VlZF9vblwiOlwiJHtpc3N1ZWRPbn1cIiR7c2VwYXJhdG9yfVwiaXNzdWVyX25hbWVcIjpcIiR7XG4gICAgICBpc3N1ZXJOYW1lID8/IFwiXCJcbiAgICB9XCJgO1xuICB9IGVsc2Uge1xuICAgIGxhYmVsID0gXCJTb21ldGhpbmcgd2VudCB3cm9uZywgcGxlYXNlIGNoZWNrIHRoZSBhbmFseXRpY3MgY29kZSBvZiBzZW5kRXZlbnRDZXJ0aWZpY2F0ZVZpZXdlZERldGFpbGVkXCI7XG4gIH1cbiAgYW5hbHl0aWNzRXZlbnQod2luZG93LCB7XG4gICAgY2F0ZWdvcnk6IFwiQ0VSVElGSUNBVEVfREVUQUlMU1wiLFxuICAgIGFjdGlvbjogYFZJRVdFRCAtICR7aXNzdWVyTmFtZX1gLFxuICAgIGxhYmVsLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIG5vbkludGVyYWN0aW9uOiB0cnVlLFxuICAgICAgZGltZW5zaW9uMTogc3RvcmUgfHwgXCIobm90IHNldClcIixcbiAgICAgIGRpbWVuc2lvbjI6IGlkIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICBkaW1lbnNpb24zOiBuYW1lIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICBkaW1lbnNpb240OiBpc3N1ZWRPbiB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgZGltZW5zaW9uNTogaXNzdWVyTmFtZSB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgZGltZW5zaW9uNjogcmVnaXN0cnlJZCB8fCBcIihub3Qgc2V0KVwiLFxuICAgIH0sXG4gIH0pO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIHRyaWdnZXJFcnJvckxvZ2dpbmcoXG4gIHJhd0NlcnRpZmljYXRlOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+LFxuICBlcnJvcnM6IHN0cmluZ1tdXG4pOiB2b2lkIHtcbiAgY29uc3QgY2VydGlmaWNhdGU6IHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50ICYgeyBuYW1lPzogc3RyaW5nOyBpc3N1ZWRPbj86IHN0cmluZyB9ID0gZ2V0RGF0YShyYXdDZXJ0aWZpY2F0ZSk7XG5cbiAgY29uc3QgaWQgPSBjZXJ0aWZpY2F0ZT8uaWQ7XG4gIGNvbnN0IG5hbWUgPSBjZXJ0aWZpY2F0ZT8ubmFtZTtcbiAgY29uc3QgaXNzdWVkT24gPSBjZXJ0aWZpY2F0ZT8uaXNzdWVkT247XG4gIGNvbnN0IGVycm9yc0xpc3QgPSBlcnJvcnMuam9pbihcIixcIik7XG5cbiAgLy8gSWYgdGhlcmUgYXJlIG11bHRpcGxlIGlzc3VlcnMgaW4gYSBjZXJ0aWZpY2F0ZSwgd2Ugc2VuZCBtdWx0aXBsZSBldmVudHMhXG4gIGNlcnRpZmljYXRlLmlzc3VlcnMuZm9yRWFjaCgoaXNzdWVyOiB2Mi5Jc3N1ZXIpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IGlzc3Vlci5jZXJ0aWZpY2F0ZVN0b3JlID8/IGlzc3Vlci5kb2N1bWVudFN0b3JlID8/IGlzc3Vlci50b2tlblJlZ2lzdHJ5ID8/IGlzc3Vlci5pZCA/PyBcIlwiOyAvLyB1c2UgaWQgZm9yIERJRFxuICAgIGxldCBpc3N1ZXJOYW1lID0gaXNzdWVyLm5hbWU7XG4gICAgbGV0IHJlZ2lzdHJ5SWQgPSBudWxsO1xuXG4gICAgaWYgKGlzSW5SZWdpc3RyeShzdG9yZSkpIHtcbiAgICAgIGNvbnN0IHJlZ2lzdHJ5SXNzdWVyOiBSZWdpc3RyeUVudHJ5ID0gcmVnaXN0cnkuaXNzdWVyc1tzdG9yZV07XG4gICAgICBpc3N1ZXJOYW1lID0gcmVnaXN0cnlJc3N1ZXIubmFtZTtcbiAgICAgIHJlZ2lzdHJ5SWQgPSByZWdpc3RyeUlzc3Vlci5pZDtcbiAgICB9IGVsc2UgaWYgKGlzc3Vlci5pZGVudGl0eVByb29mKSB7XG4gICAgICBpc3N1ZXJOYW1lID0gaXNzdWVyLmlkZW50aXR5UHJvb2YubG9jYXRpb24gfHwgXCJcIjtcbiAgICB9XG5cbiAgICBhbmFseXRpY3NFdmVudCh3aW5kb3csIHtcbiAgICAgIGNhdGVnb3J5OiBcIkNFUlRJRklDQVRFX0VSUk9SXCIsXG4gICAgICBhY3Rpb246IGBFUlJPUiAtICR7aXNzdWVyTmFtZX1gLFxuICAgICAgbGFiZWw6IGVycm9yc0xpc3QsXG4gICAgICBvcHRpb25zOiB7XG4gICAgICAgIG5vbkludGVyYWN0aW9uOiB0cnVlLFxuICAgICAgICBkaW1lbnNpb24xOiBzdG9yZSB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgICBkaW1lbnNpb24yOiBpZCB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgICBkaW1lbnNpb24zOiBuYW1lIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICAgIGRpbWVuc2lvbjQ6IGlzc3VlZE9uIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICAgIGRpbWVuc2lvbjU6IGlzc3Vlck5hbWUgfHwgXCIobm90IHNldClcIixcbiAgICAgICAgZGltZW5zaW9uNjogcmVnaXN0cnlJZCB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgICBkaW1lbnNpb243OiBlcnJvcnNMaXN0LFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG59XG4iLCJpbXBvcnQgZ2V0Q29uZmlnIGZyb20gXCJuZXh0L2NvbmZpZ1wiO1xuaW1wb3J0IHsgZ2V0TG9nZ2VyIH0gZnJvbSBcIi4uL3V0aWxzL2xvZ2dlclwiO1xuXG5jb25zdCB7IHRyYWNlIH0gPSBnZXRMb2dnZXIoXCJjb25maWdcIik7XG4vLyBodHRwczovL2dpdGh1Yi5jb20vdmVyY2VsL25leHQuanMvaXNzdWVzLzc3MTNcbmNvbnN0IHsgcHVibGljUnVudGltZUNvbmZpZyA9IHt9IH0gPSBnZXRDb25maWcoKTtcblxuZXhwb3J0IGNvbnN0IFVSTCA9IFwiaHR0cHM6Ly9vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9NQUlOX1VSTCA9IFwiaHR0cHM6Ly9hcGkub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUk9QU1RFTl9VUkwgPSBcImh0dHBzOi8vYXBpLXJvcHN0ZW4ub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUklOS0VCWV9VUkwgPSBcImh0dHBzOi8vYXBpLXJpbmtlYnkub3BlbmNlcnRzLmlvXCI7XG5cbmNvbnN0IEdBX1BST0RVQ1RJT05fSUQgPSBcIlVBLTEzMDQ5MjI2MC0xXCI7XG5jb25zdCBHQV9ERVZFTE9QTUVOVF9JRCA9IFwiVUEtMTMwNDkyMjYwLTJcIjtcblxuZXhwb3J0IGNvbnN0IElTX01BSU5ORVQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLm5ldHdvcmsgPT09IFwibWFpbm5ldFwiO1xuZXhwb3J0IGNvbnN0IE5FVFdPUktfTkFNRSA9IChJU19NQUlOTkVUID8gXCJob21lc3RlYWRcIiA6IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yaykgPz8gXCJyb3BzdGVuXCI7IC8vIGV4cGVjdGVkIGJ5IGV0aGVyc1xuXG5leHBvcnQgY29uc3QgR0FfSUQgPSBJU19NQUlOTkVUID8gR0FfUFJPRFVDVElPTl9JRCA6IEdBX0RFVkVMT1BNRU5UX0lEO1xuZXhwb3J0IGNvbnN0IENBUFRDSEFfQ0xJRU5UX0tFWSA9IFwiNkxmaUwzRVVBQUFBQUhyZkx2bDJLaFJBY1hwYW5OWERxdTZNMENDU1wiO1xuXG5jb25zdCBnZXRBcGlVcmwgPSAobmV0d29ya05hbWU6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJob21lc3RlYWRcIikgcmV0dXJuIEFQSV9NQUlOX1VSTDtcbiAgZWxzZSBpZiAobmV0d29ya05hbWUgPT09IFwicmlua2VieVwiKSByZXR1cm4gQVBJX1JJTktFQllfVVJMO1xuICByZXR1cm4gQVBJX1JPUFNURU5fVVJMO1xufTtcbmV4cG9ydCBjb25zdCBFTUFJTF9BUElfVVJMID0gYCR7Z2V0QXBpVXJsKE5FVFdPUktfTkFNRSl9L2VtYWlsYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vc3RvcmFnZWA7XG5leHBvcnQgY29uc3QgU0hBUkVfTElOS19UVEwgPSAxMjA5NjAwO1xuXG5leHBvcnQgY29uc3QgTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiA9IHB1YmxpY1J1bnRpbWVDb25maWcubGVnYWN5UmVuZGVyZXJVcmwgfHwgXCJodHRwczovL2xlZ2FjeS5vcGVuY2VydHMuaW8vXCI7XG5leHBvcnQgY29uc3QgRU5WSVJPTk1FTlQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLmNvbnRleHQgPT09IFwicHJvZHVjdGlvblwiID8gXCJwcm9kdWN0aW9uXCIgOiBcImRldmVsb3BtZW50XCI7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFTyA9IHtcbiAgdGl0bGU6IFwiQW4gZWFzeSB3YXkgdG8gY2hlY2sgYW5kIHZlcmlmeSB5b3VyIGNlcnRpZmljYXRlc1wiLFxuICB0aXRsZVRlbXBsYXRlOiBgT3BlbkNlcnRzIC0gJXNgLFxuICBkZXNjcmlwdGlvbjpcbiAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgb3BlbkdyYXBoOiB7XG4gICAgdHlwZTogXCJ3ZWJzaXRlXCIsXG4gICAgdXJsOiBVUkwsXG4gICAgdGl0bGU6IFwiT3BlbkNlcnRzIC0gQW4gZWFzeSB3YXkgdG8gY2hlY2sgYW5kIHZlcmlmeSB5b3VyIGNlcnRpZmljYXRlc1wiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJXaGV0aGVyIHlvdSdyZSBhIHN0dWRlbnQgb3IgYW4gZW1wbG95ZXIsIE9wZW5DZXJ0cyBsZXRzIHlvdSB2ZXJpZnkgdGhlIGNlcnRpZmljYXRlcyB5b3UgaGF2ZSBvZiBhbnlvbmUgZnJvbSBhbnkgaW5zdGl0dXRpb24uIEFsbCBpbiBvbmUgcGxhY2UuXCIsXG4gICAgaW1hZ2VzOiBbXG4gICAgICB7XG4gICAgICAgIHVybDogYCR7VVJMfS9zdGF0aWMvaW1hZ2VzL29wZW5jZXJ0cy5wbmdgLFxuICAgICAgICB3aWR0aDogODAwLFxuICAgICAgICBoZWlnaHQ6IDYwMCxcbiAgICAgICAgYWx0OiBcIk9wZW5DZXJ0c1wiLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB0d2l0dGVyOiB7XG4gICAgY2FyZFR5cGU6IFwic3VtbWFyeV9sYXJnZV9pbWFnZVwiLFxuICB9LFxufTtcblxudHJhY2UoYE5FVFdPUks6ICR7TkVUV09SS19OQU1FfWApO1xudHJhY2UoYENBUFRDSEFfQ0xJRU5UX0tFWTogJHtDQVBUQ0hBX0NMSUVOVF9LRVl9YCk7XG50cmFjZShgRU1BSUxfQVBJX1VSTDogJHtFTUFJTF9BUElfVVJMfWApO1xuIiwiLy8gQWN0aW9uIENyZWF0b3JzXG5pbXBvcnQgeyBWZXJpZmljYXRpb25GcmFnbWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29hLXZlcmlmeVwiO1xuaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcblxuLy8gQWN0aW9uc1xuZXhwb3J0IGNvbnN0IFJFU0VUX0NFUlRJRklDQVRFID0gXCJSRVNFVF9DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFVQREFURV9DRVJUSUZJQ0FURSA9IFwiVVBEQVRFX0NFUlRJRklDQVRFXCI7XG5leHBvcnQgY29uc3QgVkVSSUZZSU5HX0NFUlRJRklDQVRFID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVcIjtcbmV4cG9ydCBjb25zdCBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEXCI7IC8vIGNvbXBsZXRlZFxuZXhwb3J0IGNvbnN0IFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEID0gXCJWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRFwiOyAvLyBlcnJvcmVkXG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURSA9IFwiU0VORElOR19DRVJUSUZJQ0FURVwiO1xuZXhwb3J0IGNvbnN0IFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUyA9IFwiU0VORElOR19DRVJUSUZJQ0FURV9TVUNDRVNTXCI7XG5leHBvcnQgY29uc3QgU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUID0gXCJTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOSyA9IFwiR0VORVJBVEVfU0hBUkVfTElOS1wiO1xuZXhwb3J0IGNvbnN0IEdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTUyA9IFwiR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTXCI7XG5leHBvcnQgY29uc3QgR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUID0gXCJHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUXCI7XG5leHBvcnQgY29uc3QgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OID0gXCJSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05cIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElORyA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkdcIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1NcIjtcbmV4cG9ydCBjb25zdCBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fRkFJTFVSRSA9IFwiUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkVcIjtcbmV4cG9ydCBjb25zdCBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFID0gXCJDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFXCI7XG5cbmludGVyZmFjZSBSZXNldENlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFU0VUX0NFUlRJRklDQVRFO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0Q2VydGlmaWNhdGVTdGF0ZSgpOiBSZXNldENlcnRpZmljYXRlQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSRVNFVF9DRVJUSUZJQ0FURSxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFVwZGF0ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFVQREFURV9DRVJUSUZJQ0FURTtcbiAgcGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50Pjtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVDZXJ0aWZpY2F0ZShwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+KTogVXBkYXRlQ2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFVQREFURV9DRVJUSUZJQ0FURSxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVkVSSUZZSU5HX0NFUlRJRklDQVRFO1xufVxuZXhwb3J0IGNvbnN0IHZlcmlmeWluZ0NlcnRpZmljYXRlID0gKCk6IFZlcmlmeWluZ0NlcnRpZmljYXRlQWN0aW9uID0+ICh7XG4gIHR5cGU6IFZFUklGWUlOR19DRVJUSUZJQ0FURSxcbn0pO1xuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRDtcbiAgcGF5bG9hZDogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXTtcbn1cbmV4cG9ydCBjb25zdCB2ZXJpZnlpbmdDZXJ0aWZpY2F0ZUNvbXBsZXRlZCA9IChcbiAgcGF5bG9hZDogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXVxuKTogVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb24gPT4gKHtcbiAgdHlwZTogVkVSSUZZSU5HX0NFUlRJRklDQVRFX0NPTVBMRVRFRCxcbiAgcGF5bG9hZCxcbn0pO1xuXG5pbnRlcmZhY2UgVmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgY29uc3QgdmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkID0gKHBheWxvYWQ6IHN0cmluZyk6IFZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZEFjdGlvbiA9PiAoe1xuICB0eXBlOiBWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRCxcbiAgcGF5bG9hZCxcbn0pO1xuXG5pbnRlcmZhY2UgU2VuZENlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEU7XG4gIHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgY2FwdGNoYTogc3RyaW5nIH07XG59XG5leHBvcnQgZnVuY3Rpb24gc2VuZENlcnRpZmljYXRlKHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgY2FwdGNoYTogc3RyaW5nIH0pOiBTZW5kQ2VydGlmaWNhdGVBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUztcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZW5kQ2VydGlmaWNhdGVTdWNjZXNzKCk6IFNlbmRDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUyxcbiAgfTtcbn1cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVGYWlsdXJlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFNFTkRJTkdfQ0VSVElGSUNBVEVfRkFJTFVSRTtcbiAgcGF5bG9hZDogc3RyaW5nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZUZhaWx1cmUocGF5bG9hZDogc3RyaW5nKTogU2VuZENlcnRpZmljYXRlRmFpbHVyZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBTZW5kQ2VydGlmaWNhdGVSZXNldEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRDZXJ0aWZpY2F0ZVJlc2V0KCk6IFNlbmRDZXJ0aWZpY2F0ZVJlc2V0QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VULFxuICB9O1xufVxuXG5pbnRlcmZhY2UgR2VuZXJhdGVTaGFyZUxpbmtBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOSztcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGluaygpOiBHZW5lcmF0ZVNoYXJlTGlua0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOSyxcbiAgfTtcbn1cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIEdFTkVSQVRFX1NIQVJFX0xJTktfUkVTRVQ7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmtSZXNldCgpOiBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VULFxuICB9O1xufVxuaW50ZXJmYWNlIEdlbmVyYXRlU2hhcmVMaW5rU3VjY2Vzc0FjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1M7XG4gIHBheWxvYWQ6IHsgaWQ6IHN0cmluZzsga2V5OiBzdHJpbmcgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVNoYXJlTGlua1N1Y2Nlc3MocGF5bG9hZDogeyBpZDogc3RyaW5nOyBrZXk6IHN0cmluZyB9KTogR2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzQWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBHRU5FUkFURV9TSEFSRV9MSU5LX1NVQ0NFU1MsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cbmludGVyZmFjZSBHZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmVBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFO1xuICBwYXlsb2FkOiBzdHJpbmc7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlKHBheWxvYWQ6IHN0cmluZyk6IEdlbmVyYXRlU2hhcmVMaW5rRmFpbHVyZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlQWN0aW9uIHtcbiAgdHlwZTogdHlwZW9mIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTjtcbiAgcGF5bG9hZDogeyB1cmk6IHN0cmluZzsga2V5Pzogc3RyaW5nIH07XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uKHBheWxvYWQ6IHsgdXJpOiBzdHJpbmc7IGtleT86IHN0cmluZyB9KTogUmV0cmlldmVDZXJ0aWZpY2F0ZUFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZVBlbmRpbmdBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkc7XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uUGVuZGluZygpOiBSZXRyaWV2ZUNlcnRpZmljYXRlUGVuZGluZ0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1BFTkRJTkcsXG4gIH07XG59XG5pbnRlcmZhY2UgUmV0cmlldmVDZXJ0aWZpY2F0ZVN1Y2Nlc3NBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1M7XG59XG5leHBvcnQgZnVuY3Rpb24gcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3VjY2VzcygpOiBSZXRyaWV2ZUNlcnRpZmljYXRlU3VjY2Vzc0FjdGlvbiB7XG4gIGRlYnVnZ2VyXG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1MsXG4gIH07XG59XG5cbmludGVyZmFjZSBSZXRyaWV2ZUNlcnRpZmljYXRlRXJyb3JBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkU7XG4gIHBheWxvYWQ6IHN0cmluZztcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25GYWlsdXJlKHBheWxvYWQ6IHN0cmluZyk6IFJldHJpZXZlQ2VydGlmaWNhdGVFcnJvckFjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkUsXG4gICAgcGF5bG9hZCxcbiAgfTtcbn1cblxuaW50ZXJmYWNlIFVwZGF0ZU9iZnVzY2F0ZWREb2N1bWVudEFjdGlvbiB7XG4gIHR5cGU6IHR5cGVvZiBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFO1xuICBwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZShcbiAgcGF5bG9hZDogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PlxuKTogVXBkYXRlT2JmdXNjYXRlZERvY3VtZW50QWN0aW9uIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBDRVJUSUZJQ0FURV9PQkZVU0NBVEVfVVBEQVRFLFxuICAgIHBheWxvYWQsXG4gIH07XG59XG5cbmV4cG9ydCB0eXBlIENlcnRpZmljYXRlQWN0aW9uVHlwZXMgPVxuICB8IFJlc2V0Q2VydGlmaWNhdGVBY3Rpb25cbiAgfCBVcGRhdGVDZXJ0aWZpY2F0ZUFjdGlvblxuICB8IFZlcmlmeWluZ0NlcnRpZmljYXRlQWN0aW9uXG4gIHwgVmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkQWN0aW9uXG4gIHwgVmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWRBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVBY3Rpb25cbiAgfCBTZW5kQ2VydGlmaWNhdGVTdWNjZXNzQWN0aW9uXG4gIHwgU2VuZENlcnRpZmljYXRlRmFpbHVyZUFjdGlvblxuICB8IFNlbmRDZXJ0aWZpY2F0ZVJlc2V0QWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtBY3Rpb25cbiAgfCBHZW5lcmF0ZVNoYXJlTGlua1Jlc2V0QWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlQWN0aW9uXG4gIHwgR2VuZXJhdGVTaGFyZUxpbmtTdWNjZXNzQWN0aW9uXG4gIHwgUmV0cmlldmVDZXJ0aWZpY2F0ZVBlbmRpbmdBY3Rpb25cbiAgfCBSZXRyaWV2ZUNlcnRpZmljYXRlU3VjY2Vzc0FjdGlvblxuICB8IFJldHJpZXZlQ2VydGlmaWNhdGVFcnJvckFjdGlvblxuICB8IFVwZGF0ZU9iZnVzY2F0ZWREb2N1bWVudEFjdGlvbjtcbiIsImltcG9ydCB7IFZlcmlmaWNhdGlvbkZyYWdtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb2EtdmVyaWZ5XCI7XG5pbXBvcnQgeyB2MiwgV3JhcHBlZERvY3VtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3Blbi1hdHRlc3RhdGlvblwiO1xuaW1wb3J0IHsgc3RhdGVzIH0gZnJvbSBcIi4vc2hhcmVkXCI7XG5pbXBvcnQgeyBSb290U3RhdGUgfSBmcm9tIFwiLi9pbmRleFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2VydGlmaWNhdGUoc3RvcmU6IFJvb3RTdGF0ZSk6IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD4gfCBudWxsIHtcbiAgcmV0dXJuIHN0b3JlLmNlcnRpZmljYXRlLnJhd01vZGlmaWVkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VmVyaWZ5aW5nKHN0b3JlOiBSb290U3RhdGUpOiBib29sZWFuIHtcbiAgcmV0dXJuIHN0b3JlLmNlcnRpZmljYXRlLnZlcmlmaWNhdGlvblBlbmRpbmcgfHwgc3RvcmUuY2VydGlmaWNhdGUucmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3RhdGUgPT09IHN0YXRlcy5QRU5ESU5HO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VmVyaWZpY2F0aW9uU3RhdHVzKHN0b3JlOiBSb290U3RhdGUpOiBWZXJpZmljYXRpb25GcmFnbWVudFtdIHwgbnVsbCB7XG4gIHJldHVybiBzdG9yZS5jZXJ0aWZpY2F0ZS52ZXJpZmljYXRpb25TdGF0dXM7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFbWFpbFNlbmRpbmdTdGF0ZShzdG9yZTogUm9vdFN0YXRlKTogc3RhdGVzIHtcbiAgcmV0dXJuIHN0b3JlLmNlcnRpZmljYXRlLmVtYWlsU3RhdGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRTaGFyZUxpbmsoc3RvcmU6IFJvb3RTdGF0ZSk6IHsgaWQ/OiBzdHJpbmc7IGtleT86IHN0cmluZyB9IHtcbiAgcmV0dXJuIHN0b3JlLmNlcnRpZmljYXRlLnNoYXJlTGluaztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNoYXJlTGlua1N0YXRlKHN0b3JlOiBSb290U3RhdGUpOiBzdGF0ZXMge1xuICByZXR1cm4gc3RvcmUuY2VydGlmaWNhdGUuc2hhcmVMaW5rU3RhdGU7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3Ioc3RvcmU6IFJvb3RTdGF0ZSk6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gc3RvcmUuY2VydGlmaWNhdGUucmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3I7XG59XG4iLCJpbXBvcnQgeyBWZXJpZmljYXRpb25GcmFnbWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29hLXZlcmlmeVwiO1xuaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcbmltcG9ydCB7XG4gIENFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEUsXG4gIENlcnRpZmljYXRlQWN0aW9uVHlwZXMsXG4gIEdFTkVSQVRFX1NIQVJFX0xJTktfRkFJTFVSRSxcbiAgR0VORVJBVEVfU0hBUkVfTElOS19SRVNFVCxcbiAgR0VORVJBVEVfU0hBUkVfTElOS19TVUNDRVNTLFxuICBSRVNFVF9DRVJUSUZJQ0FURSxcbiAgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX0ZBSUxVUkUsXG4gIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9QRU5ESU5HLFxuICBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fU1VDQ0VTUyxcbiAgU0VORElOR19DRVJUSUZJQ0FURSxcbiAgU0VORElOR19DRVJUSUZJQ0FURV9GQUlMVVJFLFxuICBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VULFxuICBTRU5ESU5HX0NFUlRJRklDQVRFX1NVQ0NFU1MsXG4gIFVQREFURV9DRVJUSUZJQ0FURSxcbiAgVkVSSUZZSU5HX0NFUlRJRklDQVRFLFxuICBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVELFxuICBWRVJJRllJTkdfQ0VSVElGSUNBVEVfRVJST1JFRCxcbn0gZnJvbSBcIi4vY2VydGlmaWNhdGUuYWN0aW9uc1wiO1xuaW1wb3J0IHsgc3RhdGVzIH0gZnJvbSBcIi4vc2hhcmVkXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2VydGlmaWNhdGVTdGF0ZSB7XG4gIHJhdzogbnVsbCB8IFdyYXBwZWREb2N1bWVudDx2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudD47XG4gIHJhd01vZGlmaWVkOiBudWxsIHwgV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PjtcblxuICB2ZXJpZmljYXRpb25QZW5kaW5nOiBib29sZWFuO1xuICB2ZXJpZmljYXRpb25TdGF0dXM6IG51bGwgfCBWZXJpZmljYXRpb25GcmFnbWVudFtdO1xuICB2ZXJpZmljYXRpb25FcnJvcjogbnVsbCB8IHN0cmluZztcblxuICBlbWFpbFN0YXRlOiBzdGF0ZXM7XG4gIGVtYWlsRXJyb3I6IG51bGwgfCBzdHJpbmc7XG5cbiAgc2hhcmVMaW5rOiB7IGlkPzogc3RyaW5nOyBrZXk/OiBzdHJpbmcgfTtcbiAgc2hhcmVMaW5rU3RhdGU6IHN0YXRlcztcbiAgc2hhcmVMaW5rRXJyb3I6IG51bGw7XG5cbiAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3RhdGU6IHN0YXRlcztcbiAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3I6IG51bGwgfCBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBpbml0aWFsU3RhdGU6IENlcnRpZmljYXRlU3RhdGUgPSB7XG4gIHJhdzogbnVsbCxcbiAgcmF3TW9kaWZpZWQ6IG51bGwsXG5cbiAgdmVyaWZpY2F0aW9uUGVuZGluZzogZmFsc2UsXG4gIHZlcmlmaWNhdGlvblN0YXR1czogbnVsbCxcbiAgdmVyaWZpY2F0aW9uRXJyb3I6IG51bGwsXG5cbiAgZW1haWxTdGF0ZTogc3RhdGVzLklOSVRJQUwsXG4gIGVtYWlsRXJyb3I6IG51bGwsXG5cbiAgc2hhcmVMaW5rOiB7fSxcbiAgc2hhcmVMaW5rU3RhdGU6IHN0YXRlcy5JTklUSUFMLFxuICBzaGFyZUxpbmtFcnJvcjogbnVsbCxcblxuICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdGF0ZTogc3RhdGVzLklOSVRJQUwsXG4gIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbkVycm9yOiBudWxsLFxufTtcblxuLy8gUmVkdWNlcnNcbmV4cG9ydCBmdW5jdGlvbiByZWR1Y2VyKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb246IENlcnRpZmljYXRlQWN0aW9uVHlwZXMpOiBDZXJ0aWZpY2F0ZVN0YXRlIHtcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xuICAgIGNhc2UgUkVTRVRfQ0VSVElGSUNBVEU6XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5pbml0aWFsU3RhdGUsXG4gICAgICB9O1xuICAgIGNhc2UgVVBEQVRFX0NFUlRJRklDQVRFOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uaW5pdGlhbFN0YXRlLFxuICAgICAgICByYXc6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgICByYXdNb2RpZmllZDogYWN0aW9uLnBheWxvYWQsXG4gICAgICB9O1xuICAgIGNhc2UgVkVSSUZZSU5HX0NFUlRJRklDQVRFOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHZlcmlmaWNhdGlvblBlbmRpbmc6IHRydWUsXG4gICAgICAgIHZlcmlmaWNhdGlvblN0YXR1czogbnVsbCxcbiAgICAgIH07XG4gICAgY2FzZSBWRVJJRllJTkdfQ0VSVElGSUNBVEVfQ09NUExFVEVEOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHZlcmlmaWNhdGlvblBlbmRpbmc6IGZhbHNlLFxuICAgICAgICB2ZXJpZmljYXRpb25TdGF0dXM6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgfTtcbiAgICBjYXNlIFZFUklGWUlOR19DRVJUSUZJQ0FURV9FUlJPUkVEOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHZlcmlmaWNhdGlvblBlbmRpbmc6IGZhbHNlLFxuICAgICAgICB2ZXJpZmljYXRpb25FcnJvcjogYWN0aW9uLnBheWxvYWQsXG4gICAgICB9O1xuICAgIGNhc2UgU0VORElOR19DRVJUSUZJQ0FURTpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBlbWFpbFN0YXRlOiBzdGF0ZXMuUEVORElORyxcbiAgICAgICAgZW1haWxFcnJvcjogbnVsbCxcbiAgICAgIH07XG4gICAgY2FzZSBTRU5ESU5HX0NFUlRJRklDQVRFX1JFU0VUOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIGVtYWlsU3RhdGU6IHN0YXRlcy5JTklUSUFMLFxuICAgICAgICBlbWFpbEVycm9yOiBudWxsLFxuICAgICAgfTtcbiAgICBjYXNlIFNFTkRJTkdfQ0VSVElGSUNBVEVfU1VDQ0VTUzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBlbWFpbFN0YXRlOiBzdGF0ZXMuU1VDQ0VTUyxcbiAgICAgICAgZW1haWxFcnJvcjogbnVsbCxcbiAgICAgIH07XG4gICAgY2FzZSBTRU5ESU5HX0NFUlRJRklDQVRFX0ZBSUxVUkU6XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgZW1haWxTdGF0ZTogc3RhdGVzLkZBSUxVUkUsXG4gICAgICAgIGVtYWlsRXJyb3I6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgfTtcbiAgICBjYXNlIEdFTkVSQVRFX1NIQVJFX0xJTktfU1VDQ0VTUzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBzaGFyZUxpbms6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgICBzaGFyZUxpbmtTdGF0ZTogc3RhdGVzLlNVQ0NFU1MsXG4gICAgICB9O1xuICAgIGNhc2UgR0VORVJBVEVfU0hBUkVfTElOS19GQUlMVVJFOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHNoYXJlTGluazoge30sXG4gICAgICAgIHNoYXJlTGlua1N0YXRlOiBzdGF0ZXMuRkFJTFVSRSxcbiAgICAgIH07XG4gICAgY2FzZSBHRU5FUkFURV9TSEFSRV9MSU5LX1JFU0VUOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHNoYXJlTGluazoge30sXG4gICAgICAgIHNoYXJlTGlua1N0YXRlOiBzdGF0ZXMuSU5JVElBTCxcbiAgICAgIH07XG4gICAgY2FzZSBSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT05fUEVORElORzpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdGF0ZTogc3RhdGVzLlBFTkRJTkcsXG4gICAgICB9O1xuICAgIGNhc2UgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OX1NVQ0NFU1M6XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uU3RhdGU6IHN0YXRlcy5TVUNDRVNTLFxuICAgICAgfTtcbiAgICBjYXNlIFJFVFJJRVZFX0NFUlRJRklDQVRFX0JZX0FDVElPTl9GQUlMVVJFOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblN0YXRlOiBzdGF0ZXMuRkFJTFVSRSxcbiAgICAgICAgcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRXJyb3I6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgfTtcbiAgICBjYXNlIENFUlRJRklDQVRFX09CRlVTQ0FURV9VUERBVEU6XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgcmF3TW9kaWZpZWQ6IGFjdGlvbi5wYXlsb2FkLFxuICAgICAgfTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHN0YXRlO1xuICB9XG59XG4iLCJleHBvcnQgY29uc3QgVVBEQVRFX0ZFQVRVUkVfVE9HR0xFUyA9IFwiVVBEQVRFX0ZFQVRVUkVfVE9HR0xFU1wiO1xuXG5pbnRlcmZhY2UgVXBkYXRlRmVhdHVyZVRvZ2dsZXNBY3Rpb24ge1xuICB0eXBlOiB0eXBlb2YgVVBEQVRFX0ZFQVRVUkVfVE9HR0xFUztcbiAgcGF5bG9hZDoge1xuICAgIFtrZXk6IHN0cmluZ106IGJvb2xlYW47XG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlRmVhdHVyZVRvZ2dsZXMocGF5bG9hZDogeyBba2V5OiBzdHJpbmddOiBib29sZWFuIH0pOiBVcGRhdGVGZWF0dXJlVG9nZ2xlc0FjdGlvbiB7XG4gIHJldHVybiB7XG4gICAgdHlwZTogVVBEQVRFX0ZFQVRVUkVfVE9HR0xFUyxcbiAgICBwYXlsb2FkLFxuICB9O1xufVxuXG5leHBvcnQgdHlwZSBGZWF0dXJlVG9nZ2xlc1R5cGVzID0gVXBkYXRlRmVhdHVyZVRvZ2dsZXNBY3Rpb247XG4iLCJpbXBvcnQgeyBGZWF0dXJlVG9nZ2xlc1R5cGVzIH0gZnJvbSBcIi4vZmVhdHVyZVRvZ2dsZS5hY3Rpb25zXCI7XG5cbmludGVyZmFjZSBGZWF0dXJlVG9nZ2xlU3RhdGUge1xuICBba2V5OiBzdHJpbmddOiBib29sZWFuO1xufVxuY29uc3QgaW5pdGlhbFN0YXRlOiBGZWF0dXJlVG9nZ2xlU3RhdGUgPSB7fTtcblxuZXhwb3J0IGZ1bmN0aW9uIHJlZHVjZXIoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbjogRmVhdHVyZVRvZ2dsZXNUeXBlcyk6IEZlYXR1cmVUb2dnbGVTdGF0ZSB7XG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcbiAgICBjYXNlIFwiVVBEQVRFX0ZFQVRVUkVfVE9HR0xFU1wiOlxuICAgICAgcmV0dXJuIGFjdGlvbi5wYXlsb2FkO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gc3RhdGU7XG4gIH1cbn1cbiIsImltcG9ydCB7IGNvbWJpbmVSZWR1Y2VycyB9IGZyb20gXCJyZWR1eFwiO1xuXG5pbXBvcnQgeyByZWR1Y2VyIGFzIGNlcnRpZmljYXRlIH0gZnJvbSBcIi4vY2VydGlmaWNhdGVcIjtcbmltcG9ydCB7IHJlZHVjZXIgYXMgZmVhdHVyZVRvZ2dsZSB9IGZyb20gXCIuL2ZlYXR1cmVUb2dnbGVcIjtcblxuZXhwb3J0IGNvbnN0IHJvb3RSZWR1Y2VyID0gY29tYmluZVJlZHVjZXJzKHtcbiAgY2VydGlmaWNhdGUsXG4gIGZlYXR1cmVUb2dnbGUsXG59KTtcbmV4cG9ydCB0eXBlIFJvb3RTdGF0ZSA9IFJldHVyblR5cGU8dHlwZW9mIHJvb3RSZWR1Y2VyPjtcbiIsImV4cG9ydCBlbnVtIHN0YXRlcyB7XG4gIElOSVRJQUwgPSBcIklOSVRJQUxcIixcbiAgUEVORElORyA9IFwiUEVORElOR1wiLFxuICBTVUNDRVNTID0gXCJTVUNDRVNTXCIsXG4gIEZBSUxVUkUgPSBcIkZBSUxVUkVcIixcbn1cbiIsIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1tb2R1bGUtYm91bmRhcnktdHlwZXMsQHR5cGVzY3JpcHQtZXNsaW50L2V4cGxpY2l0LWZ1bmN0aW9uLXJldHVybi10eXBlICovXG5pbXBvcnQgeyBkZWNyeXB0U3RyaW5nIH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb2EtZW5jcnlwdGlvblwiO1xuaW1wb3J0IHsgdjIsIFdyYXBwZWREb2N1bWVudCB9IGZyb20gXCJAZ292dGVjaHNnL29wZW4tYXR0ZXN0YXRpb25cIjtcbmltcG9ydCB7IGlzVmFsaWQsIHZlcmlmeSB9IGZyb20gXCJAZ292dGVjaHNnL29wZW5jZXJ0cy12ZXJpZnlcIjtcbmltcG9ydCB7IGV0aGVycyB9IGZyb20gXCJldGhlcnNcIjtcbmltcG9ydCBSb3V0ZXIgZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyBjYWxsLCBwdXQsIHNlbGVjdCwgdGFrZUV2ZXJ5IH0gZnJvbSBcInJlZHV4LXNhZ2EvZWZmZWN0c1wiO1xuaW1wb3J0IFwiaXNvbW9ycGhpYy1mZXRjaFwiO1xuaW1wb3J0IHsgdHJpZ2dlckVycm9yTG9nZ2luZyB9IGZyb20gXCIuLi9jb21wb25lbnRzL0FuYWx5dGljc1wiO1xuaW1wb3J0IHsgTkVUV09SS19OQU1FIH0gZnJvbSBcIi4uL2NvbmZpZ1wiO1xuXG5pbXBvcnQge1xuICBHRU5FUkFURV9TSEFSRV9MSU5LLFxuICBnZW5lcmF0ZVNoYXJlTGlua0ZhaWx1cmUsXG4gIGdlbmVyYXRlU2hhcmVMaW5rUmVzZXQsXG4gIGdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyxcbiAgUkVUUklFVkVfQ0VSVElGSUNBVEVfQllfQUNUSU9OLFxuICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25GYWlsdXJlLFxuICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25QZW5kaW5nLFxuICByZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25TdWNjZXNzLFxuICBzZW5kQ2VydGlmaWNhdGVGYWlsdXJlLFxuICBzZW5kQ2VydGlmaWNhdGVTdWNjZXNzLFxuICBTRU5ESU5HX0NFUlRJRklDQVRFLFxuICBVUERBVEVfQ0VSVElGSUNBVEUsXG4gIHVwZGF0ZUNlcnRpZmljYXRlLFxuICB2ZXJpZnlpbmdDZXJ0aWZpY2F0ZSxcbiAgdmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWQsXG4gIHZlcmlmeWluZ0NlcnRpZmljYXRlRXJyb3JlZCxcbn0gZnJvbSBcIi4uL3JlZHVjZXJzL2NlcnRpZmljYXRlLmFjdGlvbnNcIjtcbmltcG9ydCB7IGdldENlcnRpZmljYXRlIH0gZnJvbSBcIi4uL3JlZHVjZXJzL2NlcnRpZmljYXRlLnNlbGVjdG9yc1wiO1xuaW1wb3J0IHsgc2VuZEVtYWlsIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2VtYWlsXCI7XG5pbXBvcnQge1xuICBjZXJ0aWZpY2F0ZU5vdElzc3VlZCxcbiAgY2VydGlmaWNhdGVSZXZva2VkLFxuICBzZXJ2ZXJFcnJvcixcbiAgaW52YWxpZEFyZ3VtZW50LFxuICBjb250cmFjdE5vdEZvdW5kLFxufSBmcm9tIFwiLi4vc2VydmljZXMvZnJhZ21lbnRcIjtcbmltcG9ydCB7IGdlbmVyYXRlTGluayB9IGZyb20gXCIuLi9zZXJ2aWNlcy9saW5rXCI7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tIFwiLi4vdXRpbHMvbG9nZ2VyXCI7XG5cbmNvbnN0IHsgdHJhY2UgfSA9IGdldExvZ2dlcihcInNhZ2E6Y2VydGlmaWNhdGVcIik7XG4vLyBsb3dlciBwcmlvcml0eSA9PT0gaGlnaGVyIHByaW9yaXR5LCBzbyBpbmZ1cmEgaGFzIHByaW9yaXR5LCBhbGNoZW15IGlzIHVzZWQgYXMgZmFsbGJhY2tcbmNvbnN0IHByb3ZpZGVyID0gbmV3IGV0aGVycy5wcm92aWRlcnMuRmFsbGJhY2tQcm92aWRlcihcbiAgW1xuICAgIHsgcHJpb3JpdHk6IDEsIHByb3ZpZGVyOiBuZXcgZXRoZXJzLnByb3ZpZGVycy5JbmZ1cmFQcm92aWRlcihORVRXT1JLX05BTUUsIHByb2Nlc3MuZW52LklORlVSQV9BUElfS0VZKSB9LFxuICAgIHsgcHJpb3JpdHk6IDEwLCBwcm92aWRlcjogbmV3IGV0aGVycy5wcm92aWRlcnMuQWxjaGVteVByb3ZpZGVyKE5FVFdPUktfTkFNRSwgcHJvY2Vzcy5lbnYuQUxDSEVNWV9BUElfS0VZKSB9LFxuICBdLFxuICAxXG4pO1xuXG5leHBvcnQgZnVuY3Rpb24qIHZlcmlmeUNlcnRpZmljYXRlKHsgcGF5bG9hZDogY2VydGlmaWNhdGUgfTogeyBwYXlsb2FkOiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+IH0pIHtcbiAgdHJ5IHtcbiAgICB5aWVsZCBwdXQodmVyaWZ5aW5nQ2VydGlmaWNhdGUoKSk7XG4gICAgY29uc3QgZnJhZ21lbnRzID0geWllbGQgY2FsbCh2ZXJpZnkoeyBwcm92aWRlciB9KSwgY2VydGlmaWNhdGUpO1xuICAgIHRyYWNlKGBWZXJpZmljYXRpb24gU3RhdHVzOiAke0pTT04uc3RyaW5naWZ5KGZyYWdtZW50cyl9YCk7XG5cbiAgICB5aWVsZCBwdXQodmVyaWZ5aW5nQ2VydGlmaWNhdGVDb21wbGV0ZWQoZnJhZ21lbnRzKSk7XG4gICAgaWYgKGlzVmFsaWQoZnJhZ21lbnRzKSkge1xuICAgICAgUm91dGVyLnB1c2goXCIvdmlld2VyXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgICBpZiAoIWlzVmFsaWQoZnJhZ21lbnRzLCBbXCJET0NVTUVOVF9JTlRFR1JJVFlcIl0pKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKFwiQ0VSVElGSUNBVEVfSEFTSFwiKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFpc1ZhbGlkKGZyYWdtZW50cywgW1wiRE9DVU1FTlRfU1RBVFVTXCJdKSkge1xuICAgICAgICBpZiAoY2VydGlmaWNhdGVOb3RJc3N1ZWQoZnJhZ21lbnRzKSkgZXJyb3JzLnB1c2goXCJVTklTU1VFRF9DRVJUSUZJQ0FURVwiKTtcbiAgICAgICAgZWxzZSBpZiAoY2VydGlmaWNhdGVSZXZva2VkKGZyYWdtZW50cykpIGVycm9ycy5wdXNoKFwiUkVWT0tFRF9DRVJUSUZJQ0FURVwiKTtcbiAgICAgICAgZWxzZSBpZiAoc2VydmVyRXJyb3IoZnJhZ21lbnRzKSkgZXJyb3JzLnB1c2goXCJTRVJWRVJfRVJST1JcIik7XG4gICAgICAgIGVsc2UgaWYgKGludmFsaWRBcmd1bWVudChmcmFnbWVudHMpKSBlcnJvcnMucHVzaChcIklOVkFMSURfQVJHVU1FTlRcIik7XG4gICAgICAgIGVsc2UgaWYgKGNvbnRyYWN0Tm90Rm91bmQoZnJhZ21lbnRzKSkgZXJyb3JzLnB1c2goXCJDRVJUSUZJQ0FURV9TVE9SRV9OT1RfRk9VTkRcIik7XG4gICAgICAgIGVsc2UgZXJyb3JzLnB1c2goXCJFVEhFUlNfVU5IQU5ETEVEX0VSUk9SXCIpO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWlzVmFsaWQoZnJhZ21lbnRzLCBbXCJJU1NVRVJfSURFTlRJVFlcIl0pKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKFwiSVNTVUVSX0lERU5USVRZXCIpO1xuICAgICAgfVxuXG4gICAgICBpZiAoZXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdHJpZ2dlckVycm9yTG9nZ2luZyhjZXJ0aWZpY2F0ZSwgZXJyb3JzKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB5aWVsZCBwdXQodmVyaWZ5aW5nQ2VydGlmaWNhdGVFcnJvcmVkKGUubWVzc2FnZSkpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiogc2VuZENlcnRpZmljYXRlKHsgcGF5bG9hZCB9OiB7IHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgY2FwdGNoYTogc3RyaW5nIH0gfSkge1xuICB0cnkge1xuICAgIGNvbnN0IGNlcnRpZmljYXRlID0geWllbGQgc2VsZWN0KGdldENlcnRpZmljYXRlKTtcbiAgICBjb25zdCB7IGVtYWlsLCBjYXB0Y2hhIH0gPSBwYXlsb2FkO1xuICAgIGNvbnN0IHN1Y2Nlc3MgPSB5aWVsZCBzZW5kRW1haWwoe1xuICAgICAgY2VydGlmaWNhdGUsXG4gICAgICBlbWFpbCxcbiAgICAgIGNhcHRjaGEsXG4gICAgfSk7XG5cbiAgICBpZiAoIXN1Y2Nlc3MpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWwgdG8gc2VuZCBjZXJ0aWZpY2F0ZVwiKTtcbiAgICB9XG5cbiAgICB5aWVsZCBwdXQoc2VuZENlcnRpZmljYXRlU3VjY2VzcygpKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHlpZWxkIHB1dChzZW5kQ2VydGlmaWNhdGVGYWlsdXJlKGUubWVzc2FnZSkpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiogZ2VuZXJhdGVTaGFyZUxpbmsoKSB7XG4gIHRyeSB7XG4gICAgeWllbGQgcHV0KGdlbmVyYXRlU2hhcmVMaW5rUmVzZXQoKSk7XG4gICAgY29uc3QgY2VydGlmaWNhdGUgPSB5aWVsZCBzZWxlY3QoZ2V0Q2VydGlmaWNhdGUpO1xuICAgIGNvbnN0IHN1Y2Nlc3MgPSB5aWVsZCBnZW5lcmF0ZUxpbmsoY2VydGlmaWNhdGUpO1xuXG4gICAgaWYgKCFzdWNjZXNzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsIHRvIGdlbmVyYXRlIGNlcnRpZmljYXRlIHNoYXJlIGxpbmtcIik7XG4gICAgfVxuXG4gICAgeWllbGQgcHV0KGdlbmVyYXRlU2hhcmVMaW5rU3VjY2VzcyhzdWNjZXNzKSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB5aWVsZCBwdXQoZ2VuZXJhdGVTaGFyZUxpbmtGYWlsdXJlKGUubWVzc2FnZSkpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiogcmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uKHsgcGF5bG9hZDogeyB1cmksIGtleSB9IH06IHsgcGF5bG9hZDogeyB1cmk6IHN0cmluZzsga2V5Pzogc3RyaW5nIH0gfSkge1xuICB0cnkge1xuICAgIHlpZWxkIHB1dChyZXRyaWV2ZUNlcnRpZmljYXRlQnlBY3Rpb25QZW5kaW5nKCkpO1xuXG4gICAgLy8gaWYgYSBrZXkgaGFzIGJlZW4gcHJvdmlkZWQsIGxldCdzIGFzc3VtZVxuICAgIGxldCBjZXJ0aWZpY2F0ZSA9IHlpZWxkIHdpbmRvdy5mZXRjaCh1cmkpLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCAmJiByZXNwb25zZS5zdGF0dXMgPCA2MDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmFibGUgdG8gbG9hZCB0aGUgY2VydGlmaWNhdGUgZnJvbSAke3VyaX1gKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5qc29uKCk7XG4gICAgfSk7XG4gICAgY2VydGlmaWNhdGUgPSBjZXJ0aWZpY2F0ZS5kb2N1bWVudCB8fCBjZXJ0aWZpY2F0ZTsgLy8gb3BlbmNlcnRzLWZ1bmN0aW9uIHJldHVybnMgdGhlIGRvY3VtZW50IGluIGEgbmVzdGVkIGRvY3VtZW50IG9iamVjdFxuXG4gICAgaWYgKCFjZXJ0aWZpY2F0ZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBDZXJ0aWZpY2F0ZSBhdCBhZGRyZXNzICR7dXJpfSBpcyBlbXB0eWApO1xuICAgIH1cbiAgICAvLyBpZiB0aGVyZSBpcyBhIGtleSBhbmQgdGhlIHR5cGUgaXMgXCJPUEVOLUFUVEVTVEFUSU9OLVRZUEUtMVwiLCBsZXQncyB1c2Ugb2EtZW5jcnlwdGlvblxuICAgIGlmIChrZXkgJiYgY2VydGlmaWNhdGUudHlwZSA9PT0gXCJPUEVOLUFUVEVTVEFUSU9OLVRZUEUtMVwiKSB7XG4gICAgICBjZXJ0aWZpY2F0ZSA9IEpTT04ucGFyc2UoXG4gICAgICAgIGRlY3J5cHRTdHJpbmcoe1xuICAgICAgICAgIHRhZzogY2VydGlmaWNhdGUudGFnLFxuICAgICAgICAgIGNpcGhlclRleHQ6IGNlcnRpZmljYXRlLmNpcGhlclRleHQsXG4gICAgICAgICAgaXY6IGNlcnRpZmljYXRlLml2LFxuICAgICAgICAgIGtleSxcbiAgICAgICAgICB0eXBlOiBjZXJ0aWZpY2F0ZS50eXBlLFxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKGtleSB8fCBjZXJ0aWZpY2F0ZS50eXBlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuYWJsZSB0byBkZWNyeXB0IGNlcnRpZmljYXRlIHdpdGgga2V5PSR7a2V5fSBhbmQgdHlwZT0ke2NlcnRpZmljYXRlLnR5cGV9YCk7XG4gICAgfVxuXG4gICAgeWllbGQgcHV0KHVwZGF0ZUNlcnRpZmljYXRlKGNlcnRpZmljYXRlKSk7XG4gICAgeWllbGQgcHV0KHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvblN1Y2Nlc3MoKSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB5aWVsZCBwdXQocmV0cmlldmVDZXJ0aWZpY2F0ZUJ5QWN0aW9uRmFpbHVyZShlLm1lc3NhZ2UpKTtcbiAgfVxufVxuXG4vLyBUT0RPIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWR1eC1zYWdhL3JlZHV4LXNhZ2EvaXNzdWVzLzE4ODNcbmV4cG9ydCBjb25zdCBzYWdhcyA9IFtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudFxuICAvLyBAdHMtaWdub3JlXG4gIHRha2VFdmVyeShSRVRSSUVWRV9DRVJUSUZJQ0FURV9CWV9BQ1RJT04sIHJldHJpZXZlQ2VydGlmaWNhdGVCeUFjdGlvbiksXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgLy8gQHRzLWlnbm9yZVxuICB0YWtlRXZlcnkoVVBEQVRFX0NFUlRJRklDQVRFLCB2ZXJpZnlDZXJ0aWZpY2F0ZSksXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXRzLWNvbW1lbnRcbiAgLy8gQHRzLWlnbm9yZVxuICB0YWtlRXZlcnkoU0VORElOR19DRVJUSUZJQ0FURSwgc2VuZENlcnRpZmljYXRlKSxcbiAgdGFrZUV2ZXJ5KEdFTkVSQVRFX1NIQVJFX0xJTkssIGdlbmVyYXRlU2hhcmVMaW5rKSxcbl07XG4iLCJpbXBvcnQgeyBhbGwgfSBmcm9tIFwicmVkdXgtc2FnYS9lZmZlY3RzXCI7XG5pbXBvcnQgeyBzYWdhcyBhcyBjZXJ0aWZpY2F0ZVNhZ2EgfSBmcm9tIFwiLi9jZXJ0aWZpY2F0ZVwiO1xuXG5leHBvcnQgZnVuY3Rpb24qIHJvb3RTYWdhKCk6IEdlbmVyYXRvciB7XG4gIHlpZWxkIGFsbChbLi4uY2VydGlmaWNhdGVTYWdhXSk7XG59XG4iLCJpbXBvcnQgXCJpc29tb3JwaGljLWZldGNoXCI7XG5pbXBvcnQgeyBXcmFwcGVkRG9jdW1lbnQgfSBmcm9tIFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCI7XG5pbXBvcnQgeyBFTUFJTF9BUElfVVJMIH0gZnJvbSBcIi4uLy4uL2NvbmZpZ1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gc2VuZEVtYWlsKHtcbiAgY2VydGlmaWNhdGUsXG4gIGVtYWlsLFxuICBjYXB0Y2hhLFxufToge1xuICBjZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50O1xuICBlbWFpbDogc3RyaW5nO1xuICBjYXB0Y2hhOiBzdHJpbmc7XG59KTogUHJvbWlzZTxib29sZWFuPiB7XG4gIHJldHVybiB3aW5kb3dcbiAgICAuZmV0Y2goRU1BSUxfQVBJX1VSTCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBkYXRhOiBjZXJ0aWZpY2F0ZSxcbiAgICAgICAgdG86IGVtYWlsLFxuICAgICAgICBjYXB0Y2hhLFxuICAgICAgfSksXG4gICAgfSlcbiAgICAudGhlbigocmVzKSA9PiByZXMuc3RhdHVzID09PSAyMDApO1xufVxuIiwiaW1wb3J0IHtcbiAgT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzQ29kZSxcbiAgT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Ub2tlblJlZ2lzdHJ5U3RhdHVzQ29kZSxcbiAgVmVyaWZpY2F0aW9uRnJhZ21lbnQsXG59IGZyb20gXCJAZ292dGVjaHNnL29hLXZlcmlmeVwiO1xuXG5jb25zdCBnZXRGcmFnbWVudHNGb3IgPSAoZnJhZ21lbnRzOiBWZXJpZmljYXRpb25GcmFnbWVudFtdLCBuYW1lOiBzdHJpbmcpOiBWZXJpZmljYXRpb25GcmFnbWVudCA9PlxuICBmcmFnbWVudHMuZmlsdGVyKChzdGF0dXMpID0+IHN0YXR1cy5uYW1lID09PSBuYW1lKVswXTtcblxuLy8gdGhpcyBmdW5jdGlvbiBjaGVjayBpZiB0aGUgcmVhc29uIG9mIHRoZSBlcnJvciBpcyB0aGF0IHRoZSBkb2N1bWVudCBzdG9yZSBvciB0b2tlbiByZWdpc3RyeSBpcyBpbnZhbGlkXG5leHBvcnQgY29uc3QgYWRkcmVzc0ludmFsaWQgPSAoZnJhZ21lbnRzOiBWZXJpZmljYXRpb25GcmFnbWVudFtdKTogYm9vbGVhbiA9PiB7XG4gIGNvbnN0IGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudCA9IGdldEZyYWdtZW50c0ZvcihmcmFnbWVudHMsIFwiT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzXCIpO1xuICBjb25zdCB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtVG9rZW5SZWdpc3RyeVN0YXR1c1wiKTtcbiAgLy8gMiBpcyB0aGUgZXJyb3IgY29kZSB1c2VkIGJ5IG9hLXZlcmlmeSBpbiBjYXNlIG9mIGludmFsaWQgYWRkcmVzc1xuICByZXR1cm4gKFxuICAgIChkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzQ29kZS5ET0NVTUVOVF9OT1RfSVNTVUVEICYmXG4gICAgICBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8ubWVzc2FnZS50b0xvd2VyQ2FzZSgpID09PSBcIkludmFsaWQgZG9jdW1lbnQgc3RvcmUgYWRkcmVzc1wiLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgKHRva2VuUmVnaXN0cnlNaW50ZWRGcmFnbWVudD8ucmVhc29uPy5jb2RlID09PSBPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bVRva2VuUmVnaXN0cnlTdGF0dXNDb2RlLkRPQ1VNRU5UX05PVF9NSU5URUQgJiZcbiAgICAgIHRva2VuUmVnaXN0cnlNaW50ZWRGcmFnbWVudD8ucmVhc29uPy5tZXNzYWdlLnRvTG93ZXJDYXNlKCkgPT09IFwiSW52YWxpZCB0b2tlbiByZWdpc3RyeSBhZGRyZXNzXCIudG9Mb3dlckNhc2UoKSlcbiAgKTtcbn07XG5cbi8vIHRoaXMgZnVuY3Rpb24gY2hlY2sgaWYgdGhlIHJlYXNvbiBvZiB0aGUgZXJyb3IgaXMgdGhhdCB0aGUgZG9jdW1lbnQgc3RvcmVcbmV4cG9ydCBjb25zdCBjb250cmFjdE5vdEZvdW5kID0gKGZyYWdtZW50czogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXSk6IGJvb2xlYW4gPT4ge1xuICBjb25zdCBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c1wiKTtcbiAgLy8gNDA0IGlzIHRoZSBlcnJvciBjb2RlIHVzZWQgYnkgb2EtdmVyaWZ5IGluIGNhc2Ugb2YgY29udHJhY3Qgbm90IGZvdW5kXG4gIHJldHVybiAoXG4gICAgZG9jdW1lbnRTdG9yZUlzc3VlZEZyYWdtZW50Py5yZWFzb24/LmNvZGUgPT09IE9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c0NvZGUuRE9DVU1FTlRfTk9UX0lTU1VFRCAmJlxuICAgIGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudD8ucmVhc29uPy5tZXNzYWdlLnRvTG93ZXJDYXNlKCkgPT09IFwiQ29udHJhY3QgaXMgbm90IGZvdW5kXCIudG9Mb3dlckNhc2UoKVxuICApO1xufTtcblxuLy8gdGhpcyBmdW5jdGlvbiBjaGVjayBpZiB0aGUgcmVhc29uIG9mIHRoZSBlcnJvciBpcyB0aGF0IHRoZSBkb2N1bWVudCBzdG9yZSBvciB0b2tlbiBoYXMgbm90IGJlZW4gaXNzdWVkXG5leHBvcnQgY29uc3QgY2VydGlmaWNhdGVOb3RJc3N1ZWQgPSAoZnJhZ21lbnRzOiBWZXJpZmljYXRpb25GcmFnbWVudFtdKTogYm9vbGVhbiA9PiB7XG4gIGNvbnN0IGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudCA9IGdldEZyYWdtZW50c0ZvcihmcmFnbWVudHMsIFwiT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzXCIpO1xuICBjb25zdCB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtVG9rZW5SZWdpc3RyeVN0YXR1c1wiKTtcbiAgLy8gMSBpcyB0aGUgZXJyb3IgY29kZSB1c2VkIGJ5IG9hLXZlcmlmeSBpbiBjYXNlIG9mIGRvY3VtZW50IC8gdG9rZW4gbm90IGlzc3VlZCAvIG1pbnRlZFxuICByZXR1cm4gKFxuICAgIGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudD8ucmVhc29uPy5jb2RlID09PSBPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bURvY3VtZW50U3RvcmVTdGF0dXNDb2RlLkRPQ1VNRU5UX05PVF9JU1NVRUQgfHxcbiAgICB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Ub2tlblJlZ2lzdHJ5U3RhdHVzQ29kZS5ET0NVTUVOVF9OT1RfTUlOVEVEXG4gICk7XG59O1xuXG4vLyB0aGlzIGZ1bmN0aW9uIGNoZWNrIGlmIHRoZSByZWFzb24gb2YgdGhlIGVycm9yIGlzIHRoYXQgdGhlIGRvY3VtZW50IHN0b3JlIG9yIHRva2VuIGhhcyBub3QgYmVlbiBpc3N1ZWRcbmV4cG9ydCBjb25zdCBjZXJ0aWZpY2F0ZVJldm9rZWQgPSAoZnJhZ21lbnRzOiBWZXJpZmljYXRpb25GcmFnbWVudFtdKTogYm9vbGVhbiA9PiB7XG4gIGNvbnN0IGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudCA9IGdldEZyYWdtZW50c0ZvcihmcmFnbWVudHMsIFwiT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzXCIpO1xuICAvLyAxIGlzIHRoZSBlcnJvciBjb2RlIHVzZWQgYnkgb2EtdmVyaWZ5IGluIGNhc2Ugb2YgZG9jdW1lbnQgLyB0b2tlbiBub3QgaXNzdWVkIC8gbWludGVkXG4gIHJldHVybiBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzQ29kZS5ET0NVTUVOVF9SRVZPS0VEO1xufTtcblxuLy8gdGhpcyBmdW5jdGlvbiBjaGVjayBpZiB0aGUgZXJyb3IgaXMgY2F1c2VkIGJ5IGFuIGludmFsaWQgbWVya2xlIHJvb3QgKGluY29ycmVjdCBsZW5ndGgvb2RkIGxlbmd0aC9pbnZhbGlkIGNoYXJhY3RlcnMpXG5leHBvcnQgY29uc3QgaW52YWxpZEFyZ3VtZW50ID0gKGZyYWdtZW50czogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXSk6IGJvb2xlYW4gPT4ge1xuICBjb25zdCBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c1wiKTtcbiAgY29uc3QgdG9rZW5SZWdpc3RyeU1pbnRlZEZyYWdtZW50ID0gZ2V0RnJhZ21lbnRzRm9yKGZyYWdtZW50cywgXCJPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bVRva2VuUmVnaXN0cnlTdGF0dXNcIik7XG4gIC8vIHdoeSBJTlZBTElEX0FSR1VNRU5UIGlzIGJlY2F1c2Ugd2UgZm9sbG93IHRoZSBlcnJvciBjb2RlcyByZXR1cm5lZCBieSBFdGhlcnMgKGh0dHBzOi8vZG9jcy5ldGhlcnMuaW8vdjUvYXBpL3V0aWxzL2xvZ2dlci8jZXJyb3JzKVxuICByZXR1cm4gKFxuICAgIChkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzQ29kZS5ET0NVTUVOVF9OT1RfSVNTVUVEICYmXG4gICAgICBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8ubWVzc2FnZS50b0xvd2VyQ2FzZSgpID09PSBcIkludmFsaWQgY2FsbCBhcmd1bWVudHNcIi50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICh0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Ub2tlblJlZ2lzdHJ5U3RhdHVzQ29kZS5JTlZBTElEX0FSR1VNRU5UICYmXG4gICAgICB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQ/LnJlYXNvbj8ubWVzc2FnZS50b0xvd2VyQ2FzZSgpID09PSBcIkludmFsaWQgY29udHJhY3QgYXJndW1lbnRzXCIudG9Mb3dlckNhc2UoKSlcbiAgKTtcbn07XG5cbi8vIHRoaXMgZnVuY3Rpb24gY2hlY2sgaWYgdGhlIHJlYXNvbiBvZiB0aGUgZXJyb3IgaXMgdGhhdCB3ZSBjYW4ndCBjb25uZWN0IHRvIEV0aGVyZXVtIChkdWUgdG8gYW55IEhUVFAgNHh4IG9yIDV4eCBlcnJvcnMpXG5leHBvcnQgY29uc3Qgc2VydmVyRXJyb3IgPSAoZnJhZ21lbnRzOiBWZXJpZmljYXRpb25GcmFnbWVudFtdKTogYm9vbGVhbiA9PiB7XG4gIGNvbnN0IGRvY3VtZW50U3RvcmVJc3N1ZWRGcmFnbWVudCA9IGdldEZyYWdtZW50c0ZvcihmcmFnbWVudHMsIFwiT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzXCIpO1xuICBjb25zdCB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtVG9rZW5SZWdpc3RyeVN0YXR1c1wiKTtcbiAgLy8gNDI5IGlzIHRoZSBlcnJvciBjb2RlIHVzZWQgYnkgb2EtdmVyaWZ5IGluIGNhc2Ugb2YgRXRoZXJzIHJldHVybmluZyBhIG1pc3NpbmcgcmVzcG9uc2UgZXJyb3JcbiAgcmV0dXJuIChcbiAgICBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Eb2N1bWVudFN0b3JlU3RhdHVzQ29kZS5TRVJWRVJfRVJST1IgfHxcbiAgICB0b2tlblJlZ2lzdHJ5TWludGVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT0gT3BlbkF0dGVzdGF0aW9uRXRoZXJldW1Ub2tlblJlZ2lzdHJ5U3RhdHVzQ29kZS5TRVJWRVJfRVJST1JcbiAgKTtcbn07XG5cbi8vIHRoaXMgZnVuY3Rpb24gY2F0Y2hlcyBhbGwgb3RoZXIgdW5oYW5kbGVkIGVycm9yc1xuZXhwb3J0IGNvbnN0IHVuaGFuZGxlZEVycm9yID0gKGZyYWdtZW50czogVmVyaWZpY2F0aW9uRnJhZ21lbnRbXSk6IGJvb2xlYW4gPT4ge1xuICBjb25zdCBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQgPSBnZXRGcmFnbWVudHNGb3IoZnJhZ21lbnRzLCBcIk9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c1wiKTtcbiAgY29uc3QgdG9rZW5SZWdpc3RyeU1pbnRlZEZyYWdtZW50ID0gZ2V0RnJhZ21lbnRzRm9yKGZyYWdtZW50cywgXCJPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bVRva2VuUmVnaXN0cnlTdGF0dXNcIik7XG4gIC8vIDMgaXMgdGhlIGVycm9yIGNvZGUgdXNlZCBieSBvYS12ZXJpZnkgaW4gY2FzZSBvZiB3ZWlyZCBlcnJvcnMgdGhhdCB3ZSBkaWRuJ3QgZm9yZXNlZSB0byBoYW5kbGVcbiAgcmV0dXJuIChcbiAgICBkb2N1bWVudFN0b3JlSXNzdWVkRnJhZ21lbnQ/LnJlYXNvbj8uY29kZSA9PT1cbiAgICAgIE9wZW5BdHRlc3RhdGlvbkV0aGVyZXVtRG9jdW1lbnRTdG9yZVN0YXR1c0NvZGUuRVRIRVJTX1VOSEFORExFRF9FUlJPUiB8fFxuICAgIHRva2VuUmVnaXN0cnlNaW50ZWRGcmFnbWVudD8ucmVhc29uPy5jb2RlID09PSBPcGVuQXR0ZXN0YXRpb25FdGhlcmV1bURvY3VtZW50U3RvcmVTdGF0dXNDb2RlLkVUSEVSU19VTkhBTkRMRURfRVJST1JcbiAgKTtcbn07XG4iLCJpbXBvcnQgXCJpc29tb3JwaGljLWZldGNoXCI7XG5pbXBvcnQgeyBXcmFwcGVkRG9jdW1lbnQgfSBmcm9tIFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCI7XG5pbXBvcnQgeyBTSEFSRV9MSU5LX0FQSV9VUkwsIFNIQVJFX0xJTktfVFRMIH0gZnJvbSBcIi4uLy4uL2NvbmZpZ1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVMaW5rKGNlcnRpZmljYXRlOiBXcmFwcGVkRG9jdW1lbnQpOiBQcm9taXNlPHsgaWQ6IHN0cmluZzsga2V5OiBzdHJpbmcgfT4ge1xuICByZXR1cm4gd2luZG93XG4gICAgLmZldGNoKGAke1NIQVJFX0xJTktfQVBJX1VSTH0vYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0dGw6IFNIQVJFX0xJTktfVFRMLFxuICAgICAgICBkb2N1bWVudDogY2VydGlmaWNhdGUsXG4gICAgICB9KSxcbiAgICB9KVxuICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpO1xufVxuIiwiaW1wb3J0IHsgY3JlYXRlV3JhcHBlciB9IGZyb20gXCJuZXh0LXJlZHV4LXdyYXBwZXJcIjtcbmltcG9ydCB7IGFwcGx5TWlkZGxld2FyZSwgY3JlYXRlU3RvcmUsIFN0b3JlIH0gZnJvbSBcInJlZHV4XCI7XG5pbXBvcnQgeyBjb21wb3NlV2l0aERldlRvb2xzIH0gZnJvbSBcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiO1xuaW1wb3J0IGNyZWF0ZVNhZ2FNaWRkbGV3YXJlIGZyb20gXCJyZWR1eC1zYWdhXCI7XG5pbXBvcnQgeyByb290UmVkdWNlciwgUm9vdFN0YXRlIH0gZnJvbSBcIi4vcmVkdWNlcnNcIjtcbmltcG9ydCB7IHJvb3RTYWdhIH0gZnJvbSBcIi4vc2FnYXNcIjtcblxuY29uc3Qgc2FnYU1pZGRsZXdhcmUgPSBjcmVhdGVTYWdhTWlkZGxld2FyZSgpO1xuXG5leHBvcnQgY29uc3QgaW5pdFN0b3JlID0gKCk6IFN0b3JlPFJvb3RTdGF0ZT4gPT4ge1xuICBjb25zdCBzdG9yZSA9IGNyZWF0ZVN0b3JlKHJvb3RSZWR1Y2VyLCBjb21wb3NlV2l0aERldlRvb2xzKGFwcGx5TWlkZGxld2FyZShzYWdhTWlkZGxld2FyZSkpKTtcbiAgc2FnYU1pZGRsZXdhcmUucnVuKHJvb3RTYWdhKTtcbiAgcmV0dXJuIHN0b3JlO1xufTtcblxuZXhwb3J0IGNvbnN0IHdyYXBwZXIgPSBjcmVhdGVXcmFwcGVyPFJvb3RTdGF0ZT4oaW5pdFN0b3JlKTtcbiIsImltcG9ydCBkZWJ1ZywgeyBEZWJ1Z2dlciB9IGZyb20gXCJkZWJ1Z1wiO1xuXG4vLyBub3QgdXNpbmcgLmV4dGVuZHMgYmVjYXVzZSBvZiBzdHVwaWQgbmV4dC5qcyByZXNvbHZlIG1vZHVsZXMgYnVnIHdoZXJlIGl0cyBwaWNraW5nIHVwIG9sZCB2ZXJzaW9uIG9mIGRlYnVnXG5leHBvcnQgY29uc3QgdHJhY2UgPSAobmFtZXNwYWNlOiBzdHJpbmcpOiBEZWJ1Z2dlciA9PiBkZWJ1Zyhgb3BlbmNlcnRzLXdlYnNpdGU6dHJhY2U6JHtuYW1lc3BhY2V9YCk7XG5leHBvcnQgY29uc3QgZXJyb3IgPSAobmFtZXNwYWNlOiBzdHJpbmcpOiBEZWJ1Z2dlciA9PiBkZWJ1Zyhgb3BlbmNlcnRzLXdlYnNpdGU6ZXJyb3I6JHtuYW1lc3BhY2V9YCk7XG5cbmV4cG9ydCBjb25zdCBnZXRMb2dnZXIgPSAobmFtZXNwYWNlOiBzdHJpbmcpOiB7IHRyYWNlOiBEZWJ1Z2dlcjsgZXJyb3I6IERlYnVnZ2VyIH0gPT4gKHtcbiAgdHJhY2U6IHRyYWNlKG5hbWVzcGFjZSksXG4gIGVycm9yOiBlcnJvcihuYW1lc3BhY2UpLFxufSk7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAZ292dGVjaHNnL29hLWVuY3J5cHRpb25cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGdvdnRlY2hzZy9vYS12ZXJpZnlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGdvdnRlY2hzZy9vcGVuLWF0dGVzdGF0aW9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBnb3Z0ZWNoc2cvb3BlbmNlcnRzLXZlcmlmeVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJkZWJ1Z1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJldGhlcnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiaXNvbW9ycGhpYy1mZXRjaFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJsb2Rhc2hcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC1nYVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0LXJlZHV4LXdyYXBwZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC1zZW9cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9jb25maWdcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9yb3V0ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtcmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC1zYWdhXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LXNhZ2EvZWZmZWN0c1wiKTsiXSwic291cmNlUm9vdCI6IiJ9