exports.ids = [1];
exports.modules = {

/***/ "./src/components/CertificateSharing/CertificateSharingForm.tsx":
/*!**********************************************************************!*\
  !*** ./src/components/CertificateSharing/CertificateSharingForm.tsx ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-google-recaptcha */ "react-google-recaptcha");
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");
/* harmony import */ var _reducers_shared__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../reducers/shared */ "./src/reducers/shared.ts");

var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\CertificateSharing\\CertificateSharingForm.tsx";





class CertificateSharingForm extends react__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      captcha: "",
      email: ""
    };
    this.handleCaptchaChange = this.handleCaptchaChange.bind(this);
    this.handleEmailChange = this.handleEmailChange.bind(this);
    this.handleSend = this.handleSend.bind(this);
  }

  handleCaptchaChange(value) {
    if (value) this.setState({
      captcha: value
    });
  }

  handleEmailChange(event) {
    this.setState({
      email: event.target.value
    });
  }

  handleSend() {
    const {
      handleSendCertificate,
      emailSendingState
    } = this.props;

    if (emailSendingState !== _reducers_shared__WEBPACK_IMPORTED_MODULE_4__["states"].PENDING) {
      handleSendCertificate({
        email: this.state.email,
        captcha: this.state.captcha
      });
    }
  }

  render() {
    const {
      emailSendingState
    } = this.props;
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "text-center",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        className: "mb-2",
        children: "Send your certificate"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        children: "This sends an email with your .opencert attached, and instructions on how to view it."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        className: "border p-2 w-64",
        value: this.state.email,
        onChange: this.handleEmailChange,
        placeholder: "Enter recipient's email"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-center w-full my-4",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_2___default.a, {
          sitekey: _config__WEBPACK_IMPORTED_MODULE_3__["CAPTCHA_CLIENT_KEY"],
          onChange: this.handleCaptchaChange
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, this), emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_4__["states"].SUCCESS && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "my-4",
        children: "Email successfully sent!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 50
      }, this), emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_4__["states"].FAILURE && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "my-4",
        children: "An error occured, please check your email and captcha"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "mt-4",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
          type: "button",
          className: "button bg-navy text-white hover:bg-navy-300",
          onClick: this.handleSend,
          children: ["Send", emailSendingState === _reducers_shared__WEBPACK_IMPORTED_MODULE_4__["states"].PENDING && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            className: "ml-2 fas fa-spinner fa-pulse"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 54
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, this);
  }

} // looks needed for dynamic import
// eslint-disable-next-line import/no-default-export


/* harmony default export */ __webpack_exports__["default"] = (CertificateSharingForm);

/***/ }),

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "next/config");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;



const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"); // https://github.com/vercel/next.js/issues/7713

const {
  publicRuntimeConfig = {}
} = next_config__WEBPACK_IMPORTED_MODULE_0___default()();
const URL = "https://opencerts.io";
const API_MAIN_URL = "https://api.opencerts.io";
const API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
const API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
const GA_PRODUCTION_ID = "UA-130492260-1";
const GA_DEVELOPMENT_ID = "UA-130492260-2";
const IS_MAINNET = publicRuntimeConfig.network === "mainnet";
const NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

const GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
const CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

const getApiUrl = networkName => {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

const EMAIL_API_URL = `${getApiUrl(NETWORK_NAME)}/email`;
const SHARE_LINK_API_URL = `${getApiUrl(NETWORK_NAME)}/storage`;
const SHARE_LINK_TTL = 1209600;
const LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
const ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
const DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: `OpenCerts - %s`,
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: `${URL}/static/images/opencerts.png`,
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace(`NETWORK: ${NETWORK_NAME}`);
trace(`CAPTCHA_CLIENT_KEY: ${CAPTCHA_CLIENT_KEY}`);
trace(`EMAIL_API_URL: ${EMAIL_API_URL}`);

/***/ }),

/***/ "./src/utils/logger.ts":
/*!*****************************!*\
  !*** ./src/utils/logger.ts ***!
  \*****************************/
/*! exports provided: trace, error, getLogger */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trace", function() { return trace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLogger", function() { return getLogger; });
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! debug */ "debug");
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(debug__WEBPACK_IMPORTED_MODULE_0__);
 // not using .extends because of stupid next.js resolve modules bug where its picking up old version of debug

const trace = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:trace:${namespace}`);
const error = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:error:${namespace}`);
const getLogger = namespace => ({
  trace: trace(namespace),
  error: error(namespace)
});

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9DZXJ0aWZpY2F0ZVNoYXJpbmcvQ2VydGlmaWNhdGVTaGFyaW5nRm9ybS50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbmZpZy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvbG9nZ2VyLnRzIl0sIm5hbWVzIjpbIkNlcnRpZmljYXRlU2hhcmluZ0Zvcm0iLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJjYXB0Y2hhIiwiZW1haWwiLCJoYW5kbGVDYXB0Y2hhQ2hhbmdlIiwiYmluZCIsImhhbmRsZUVtYWlsQ2hhbmdlIiwiaGFuZGxlU2VuZCIsInZhbHVlIiwic2V0U3RhdGUiLCJldmVudCIsInRhcmdldCIsImhhbmRsZVNlbmRDZXJ0aWZpY2F0ZSIsImVtYWlsU2VuZGluZ1N0YXRlIiwic3RhdGVzIiwiUEVORElORyIsInJlbmRlciIsIkNBUFRDSEFfQ0xJRU5UX0tFWSIsIlNVQ0NFU1MiLCJGQUlMVVJFIiwidHJhY2UiLCJnZXRMb2dnZXIiLCJwdWJsaWNSdW50aW1lQ29uZmlnIiwiZ2V0Q29uZmlnIiwiVVJMIiwiQVBJX01BSU5fVVJMIiwiQVBJX1JPUFNURU5fVVJMIiwiQVBJX1JJTktFQllfVVJMIiwiR0FfUFJPRFVDVElPTl9JRCIsIkdBX0RFVkVMT1BNRU5UX0lEIiwiSVNfTUFJTk5FVCIsIm5ldHdvcmsiLCJORVRXT1JLX05BTUUiLCJHQV9JRCIsImdldEFwaVVybCIsIm5ldHdvcmtOYW1lIiwiRU1BSUxfQVBJX1VSTCIsIlNIQVJFX0xJTktfQVBJX1VSTCIsIlNIQVJFX0xJTktfVFRMIiwiTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiIsImxlZ2FjeVJlbmRlcmVyVXJsIiwiRU5WSVJPTk1FTlQiLCJjb250ZXh0IiwiREVGQVVMVF9TRU8iLCJ0aXRsZSIsInRpdGxlVGVtcGxhdGUiLCJkZXNjcmlwdGlvbiIsIm9wZW5HcmFwaCIsInR5cGUiLCJ1cmwiLCJpbWFnZXMiLCJ3aWR0aCIsImhlaWdodCIsImFsdCIsInR3aXR0ZXIiLCJjYXJkVHlwZSIsIm5hbWVzcGFjZSIsImRlYnVnIiwiZXJyb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFVQSxNQUFNQSxzQkFBTixTQUFxQ0MsK0NBQXJDLENBQXlHO0FBQ3ZHQyxhQUFXLENBQUNDLEtBQUQsRUFBcUM7QUFDOUMsVUFBTUEsS0FBTjtBQUVBLFNBQUtDLEtBQUwsR0FBYTtBQUNYQyxhQUFPLEVBQUUsRUFERTtBQUVYQyxXQUFLLEVBQUU7QUFGSSxLQUFiO0FBS0EsU0FBS0MsbUJBQUwsR0FBMkIsS0FBS0EsbUJBQUwsQ0FBeUJDLElBQXpCLENBQThCLElBQTlCLENBQTNCO0FBQ0EsU0FBS0MsaUJBQUwsR0FBeUIsS0FBS0EsaUJBQUwsQ0FBdUJELElBQXZCLENBQTRCLElBQTVCLENBQXpCO0FBQ0EsU0FBS0UsVUFBTCxHQUFrQixLQUFLQSxVQUFMLENBQWdCRixJQUFoQixDQUFxQixJQUFyQixDQUFsQjtBQUNEOztBQUVERCxxQkFBbUIsQ0FBQ0ksS0FBRCxFQUE2QjtBQUM5QyxRQUFJQSxLQUFKLEVBQVcsS0FBS0MsUUFBTCxDQUFjO0FBQUVQLGFBQU8sRUFBRU07QUFBWCxLQUFkO0FBQ1o7O0FBRURGLG1CQUFpQixDQUFDSSxLQUFELEVBQTZDO0FBQzVELFNBQUtELFFBQUwsQ0FBYztBQUFFTixXQUFLLEVBQUVPLEtBQUssQ0FBQ0MsTUFBTixDQUFhSDtBQUF0QixLQUFkO0FBQ0Q7O0FBRURELFlBQVUsR0FBUztBQUNqQixVQUFNO0FBQUVLLDJCQUFGO0FBQXlCQztBQUF6QixRQUErQyxLQUFLYixLQUExRDs7QUFDQSxRQUFJYSxpQkFBaUIsS0FBS0MsdURBQU0sQ0FBQ0MsT0FBakMsRUFBMEM7QUFDeENILDJCQUFxQixDQUFDO0FBQ3BCVCxhQUFLLEVBQUUsS0FBS0YsS0FBTCxDQUFXRSxLQURFO0FBRXBCRCxlQUFPLEVBQUUsS0FBS0QsS0FBTCxDQUFXQztBQUZBLE9BQUQsQ0FBckI7QUFJRDtBQUNGOztBQUVEYyxRQUFNLEdBQWM7QUFDbEIsVUFBTTtBQUFFSDtBQUFGLFFBQXdCLEtBQUtiLEtBQW5DO0FBQ0Esd0JBQ0U7QUFBSyxlQUFTLEVBQUMsYUFBZjtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBR0U7QUFDRSxpQkFBUyxFQUFDLGlCQURaO0FBRUUsYUFBSyxFQUFFLEtBQUtDLEtBQUwsQ0FBV0UsS0FGcEI7QUFHRSxnQkFBUSxFQUFFLEtBQUtHLGlCQUhqQjtBQUlFLG1CQUFXLEVBQUM7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSEYsZUFTRTtBQUFLLGlCQUFTLEVBQUMsaUNBQWY7QUFBQSwrQkFDRSxxRUFBQyw2REFBRDtBQUFXLGlCQUFPLEVBQUVXLDBEQUFwQjtBQUF3QyxrQkFBUSxFQUFFLEtBQUtiO0FBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEYsRUFZR1MsaUJBQWlCLEtBQUtDLHVEQUFNLENBQUNJLE9BQTdCLGlCQUF3QztBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVozQyxFQWFHTCxpQkFBaUIsS0FBS0MsdURBQU0sQ0FBQ0ssT0FBN0IsaUJBQ0M7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FkSixlQWdCRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLCtCQUNFO0FBQVEsY0FBSSxFQUFDLFFBQWI7QUFBc0IsbUJBQVMsRUFBQyw2Q0FBaEM7QUFBOEUsaUJBQU8sRUFBRSxLQUFLWixVQUE1RjtBQUFBLDZCQUVHTSxpQkFBaUIsS0FBS0MsdURBQU0sQ0FBQ0MsT0FBN0IsaUJBQXdDO0FBQUcscUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUF5QkQ7O0FBM0RzRyxDLENBNkR6RztBQUNBOzs7QUFDZWxCLHFGQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUVBO0FBQ0E7QUFFQSxNQUFNO0FBQUV1QjtBQUFGLElBQVlDLCtEQUFTLENBQUMsUUFBRCxDQUEzQixDLENBQ0E7O0FBQ0EsTUFBTTtBQUFFQyxxQkFBbUIsR0FBRztBQUF4QixJQUErQkMsa0RBQVMsRUFBOUM7QUFFTyxNQUFNQyxHQUFHLEdBQUcsc0JBQVo7QUFDUCxNQUFNQyxZQUFZLEdBQUcsMEJBQXJCO0FBQ0EsTUFBTUMsZUFBZSxHQUFHLGtDQUF4QjtBQUNBLE1BQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFFQSxNQUFNQyxnQkFBZ0IsR0FBRyxnQkFBekI7QUFDQSxNQUFNQyxpQkFBaUIsR0FBRyxnQkFBMUI7QUFFTyxNQUFNQyxVQUFVLEdBQUdSLG1CQUFtQixDQUFDUyxPQUFwQixLQUFnQyxTQUFuRDtBQUNBLE1BQU1DLFlBQVksV0FBSUYsVUFBVSxHQUFHLFdBQUgsR0FBaUJSLG1CQUFtQixDQUFDUyxPQUFuRCx1Q0FBK0QsU0FBakYsQyxDQUE0Rjs7QUFFNUYsTUFBTUUsS0FBSyxHQUFHSCxVQUFVLEdBQUdGLGdCQUFILEdBQXNCQyxpQkFBOUM7QUFDQSxNQUFNWixrQkFBa0IsR0FBRywwQ0FBM0I7O0FBRVAsTUFBTWlCLFNBQVMsR0FBSUMsV0FBRCxJQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1YsWUFBUCxDQUFqQyxLQUNLLElBQUlVLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPUixlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLE1BQU1VLGFBQWEsR0FBSSxHQUFFRixTQUFTLENBQUNGLFlBQUQsQ0FBZSxRQUFqRDtBQUNBLE1BQU1LLGtCQUFrQixHQUFJLEdBQUVILFNBQVMsQ0FBQ0YsWUFBRCxDQUFlLFVBQXREO0FBQ0EsTUFBTU0sY0FBYyxHQUFHLE9BQXZCO0FBRUEsTUFBTUMseUJBQXlCLEdBQUdqQixtQkFBbUIsQ0FBQ2tCLGlCQUFwQixJQUF5Qyw4QkFBM0U7QUFDQSxNQUFNQyxXQUFXLEdBQUduQixtQkFBbUIsQ0FBQ29CLE9BQXBCLEtBQWdDLFlBQWhDLEdBQStDLFlBQS9DLEdBQThELGFBQWxGO0FBRUEsTUFBTUMsV0FBVyxHQUFHO0FBQ3pCQyxPQUFLLEVBQUUsbURBRGtCO0FBRXpCQyxlQUFhLEVBQUcsZ0JBRlM7QUFHekJDLGFBQVcsRUFDVCxnSkFKdUI7QUFLekJDLFdBQVMsRUFBRTtBQUNUQyxRQUFJLEVBQUUsU0FERztBQUVUQyxPQUFHLEVBQUV6QixHQUZJO0FBR1RvQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRJLFVBQU0sRUFBRSxDQUNOO0FBQ0VELFNBQUcsRUFBRyxHQUFFekIsR0FBSSw4QkFEZDtBQUVFMkIsV0FBSyxFQUFFLEdBRlQ7QUFHRUMsWUFBTSxFQUFFLEdBSFY7QUFJRUMsU0FBRyxFQUFFO0FBSlAsS0FETTtBQU5DLEdBTGM7QUFvQnpCQyxTQUFPLEVBQUU7QUFDUEMsWUFBUSxFQUFFO0FBREg7QUFwQmdCLENBQXBCO0FBeUJQbkMsS0FBSyxDQUFFLFlBQVdZLFlBQWEsRUFBMUIsQ0FBTDtBQUNBWixLQUFLLENBQUUsdUJBQXNCSCxrQkFBbUIsRUFBM0MsQ0FBTDtBQUNBRyxLQUFLLENBQUUsa0JBQWlCZ0IsYUFBYyxFQUFqQyxDQUFMLEM7Ozs7Ozs7Ozs7OztBQzVEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Q0FFQTs7QUFDTyxNQUFNaEIsS0FBSyxHQUFJb0MsU0FBRCxJQUFpQ0MsNENBQUssQ0FBRSwyQkFBMEJELFNBQVUsRUFBdEMsQ0FBcEQ7QUFDQSxNQUFNRSxLQUFLLEdBQUlGLFNBQUQsSUFBaUNDLDRDQUFLLENBQUUsMkJBQTBCRCxTQUFVLEVBQXRDLENBQXBEO0FBRUEsTUFBTW5DLFNBQVMsR0FBSW1DLFNBQUQsS0FBOEQ7QUFDckZwQyxPQUFLLEVBQUVBLEtBQUssQ0FBQ29DLFNBQUQsQ0FEeUU7QUFFckZFLE9BQUssRUFBRUEsS0FBSyxDQUFDRixTQUFEO0FBRnlFLENBQTlELENBQWxCLEMiLCJmaWxlIjoiMS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDaGFuZ2VFdmVudCwgQ29tcG9uZW50LCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBSZUNBUFRDSEEgZnJvbSBcInJlYWN0LWdvb2dsZS1yZWNhcHRjaGFcIjtcbmltcG9ydCB7IENBUFRDSEFfQ0xJRU5UX0tFWSB9IGZyb20gXCIuLi8uLi9jb25maWdcIjtcbmltcG9ydCB7IHN0YXRlcyB9IGZyb20gXCIuLi8uLi9yZWR1Y2Vycy9zaGFyZWRcIjtcbmludGVyZmFjZSBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtUHJvcHMge1xuICBlbWFpbFNlbmRpbmdTdGF0ZTogc3RyaW5nO1xuICBoYW5kbGVTZW5kQ2VydGlmaWNhdGU6IChldmVudDogeyBjYXB0Y2hhOiBzdHJpbmc7IGVtYWlsOiBzdHJpbmcgfSkgPT4gdm9pZDtcbiAgaGFuZGxlU2hhcmluZ1RvZ2dsZTogKCkgPT4gdm9pZDtcbn1cbmludGVyZmFjZSBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtU3RhdGUge1xuICBjYXB0Y2hhOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG59XG5jbGFzcyBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtIGV4dGVuZHMgQ29tcG9uZW50PENlcnRpZmljYXRlU2hhcmluZ0Zvcm1Qcm9wcywgQ2VydGlmaWNhdGVTaGFyaW5nRm9ybVN0YXRlPiB7XG4gIGNvbnN0cnVjdG9yKHByb3BzOiBDZXJ0aWZpY2F0ZVNoYXJpbmdGb3JtUHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG5cbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgY2FwdGNoYTogXCJcIixcbiAgICAgIGVtYWlsOiBcIlwiLFxuICAgIH07XG5cbiAgICB0aGlzLmhhbmRsZUNhcHRjaGFDaGFuZ2UgPSB0aGlzLmhhbmRsZUNhcHRjaGFDaGFuZ2UuYmluZCh0aGlzKTtcbiAgICB0aGlzLmhhbmRsZUVtYWlsQ2hhbmdlID0gdGhpcy5oYW5kbGVFbWFpbENoYW5nZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMuaGFuZGxlU2VuZCA9IHRoaXMuaGFuZGxlU2VuZC5iaW5kKHRoaXMpO1xuICB9XG5cbiAgaGFuZGxlQ2FwdGNoYUNoYW5nZSh2YWx1ZTogc3RyaW5nIHwgbnVsbCk6IHZvaWQge1xuICAgIGlmICh2YWx1ZSkgdGhpcy5zZXRTdGF0ZSh7IGNhcHRjaGE6IHZhbHVlIH0pO1xuICB9XG5cbiAgaGFuZGxlRW1haWxDaGFuZ2UoZXZlbnQ6IENoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KTogdm9pZCB7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IGVtYWlsOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG4gIH1cblxuICBoYW5kbGVTZW5kKCk6IHZvaWQge1xuICAgIGNvbnN0IHsgaGFuZGxlU2VuZENlcnRpZmljYXRlLCBlbWFpbFNlbmRpbmdTdGF0ZSB9ID0gdGhpcy5wcm9wcztcbiAgICBpZiAoZW1haWxTZW5kaW5nU3RhdGUgIT09IHN0YXRlcy5QRU5ESU5HKSB7XG4gICAgICBoYW5kbGVTZW5kQ2VydGlmaWNhdGUoe1xuICAgICAgICBlbWFpbDogdGhpcy5zdGF0ZS5lbWFpbCxcbiAgICAgICAgY2FwdGNoYTogdGhpcy5zdGF0ZS5jYXB0Y2hhLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCk6IFJlYWN0Tm9kZSB7XG4gICAgY29uc3QgeyBlbWFpbFNlbmRpbmdTdGF0ZSB9ID0gdGhpcy5wcm9wcztcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMlwiPlNlbmQgeW91ciBjZXJ0aWZpY2F0ZTwvaDM+XG4gICAgICAgIDxwPlRoaXMgc2VuZHMgYW4gZW1haWwgd2l0aCB5b3VyIC5vcGVuY2VydCBhdHRhY2hlZCwgYW5kIGluc3RydWN0aW9ucyBvbiBob3cgdG8gdmlldyBpdC48L3A+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgdy02NFwiXG4gICAgICAgICAgdmFsdWU9e3RoaXMuc3RhdGUuZW1haWx9XG4gICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlRW1haWxDaGFuZ2V9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZWNpcGllbnQncyBlbWFpbFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciB3LWZ1bGwgbXktNFwiPlxuICAgICAgICAgIDxSZUNBUFRDSEEgc2l0ZWtleT17Q0FQVENIQV9DTElFTlRfS0VZfSBvbkNoYW5nZT17dGhpcy5oYW5kbGVDYXB0Y2hhQ2hhbmdlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2VtYWlsU2VuZGluZ1N0YXRlID09PSBzdGF0ZXMuU1VDQ0VTUyAmJiA8ZGl2IGNsYXNzTmFtZT1cIm15LTRcIj5FbWFpbCBzdWNjZXNzZnVsbHkgc2VudCE8L2Rpdj59XG4gICAgICAgIHtlbWFpbFNlbmRpbmdTdGF0ZSA9PT0gc3RhdGVzLkZBSUxVUkUgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNFwiPkFuIGVycm9yIG9jY3VyZWQsIHBsZWFzZSBjaGVjayB5b3VyIGVtYWlsIGFuZCBjYXB0Y2hhPC9kaXY+XG4gICAgICAgICl9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ1dHRvbiBiZy1uYXZ5IHRleHQtd2hpdGUgaG92ZXI6YmctbmF2eS0zMDBcIiBvbkNsaWNrPXt0aGlzLmhhbmRsZVNlbmR9PlxuICAgICAgICAgICAgU2VuZFxuICAgICAgICAgICAge2VtYWlsU2VuZGluZ1N0YXRlID09PSBzdGF0ZXMuUEVORElORyAmJiA8aSBjbGFzc05hbWU9XCJtbC0yIGZhcyBmYS1zcGlubmVyIGZhLXB1bHNlXCIgLz59XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuLy8gbG9va3MgbmVlZGVkIGZvciBkeW5hbWljIGltcG9ydFxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1kZWZhdWx0LWV4cG9ydFxuZXhwb3J0IGRlZmF1bHQgQ2VydGlmaWNhdGVTaGFyaW5nRm9ybTtcbiIsImltcG9ydCBnZXRDb25maWcgZnJvbSBcIm5leHQvY29uZmlnXCI7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tIFwiLi4vdXRpbHMvbG9nZ2VyXCI7XG5cbmNvbnN0IHsgdHJhY2UgfSA9IGdldExvZ2dlcihcImNvbmZpZ1wiKTtcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS92ZXJjZWwvbmV4dC5qcy9pc3N1ZXMvNzcxM1xuY29uc3QgeyBwdWJsaWNSdW50aW1lQ29uZmlnID0ge30gfSA9IGdldENvbmZpZygpO1xuXG5leHBvcnQgY29uc3QgVVJMID0gXCJodHRwczovL29wZW5jZXJ0cy5pb1wiO1xuY29uc3QgQVBJX01BSU5fVVJMID0gXCJodHRwczovL2FwaS5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9ST1BTVEVOX1VSTCA9IFwiaHR0cHM6Ly9hcGktcm9wc3Rlbi5vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9SSU5LRUJZX1VSTCA9IFwiaHR0cHM6Ly9hcGktcmlua2VieS5vcGVuY2VydHMuaW9cIjtcblxuY29uc3QgR0FfUFJPRFVDVElPTl9JRCA9IFwiVUEtMTMwNDkyMjYwLTFcIjtcbmNvbnN0IEdBX0RFVkVMT1BNRU5UX0lEID0gXCJVQS0xMzA0OTIyNjAtMlwiO1xuXG5leHBvcnQgY29uc3QgSVNfTUFJTk5FVCA9IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yayA9PT0gXCJtYWlubmV0XCI7XG5leHBvcnQgY29uc3QgTkVUV09SS19OQU1FID0gKElTX01BSU5ORVQgPyBcImhvbWVzdGVhZFwiIDogcHVibGljUnVudGltZUNvbmZpZy5uZXR3b3JrKSA/PyBcInJvcHN0ZW5cIjsgLy8gZXhwZWN0ZWQgYnkgZXRoZXJzXG5cbmV4cG9ydCBjb25zdCBHQV9JRCA9IElTX01BSU5ORVQgPyBHQV9QUk9EVUNUSU9OX0lEIDogR0FfREVWRUxPUE1FTlRfSUQ7XG5leHBvcnQgY29uc3QgQ0FQVENIQV9DTElFTlRfS0VZID0gXCI2TGZpTDNFVUFBQUFBSHJmTHZsMktoUkFjWHBhbk5YRHF1Nk0wQ0NTXCI7XG5cbmNvbnN0IGdldEFwaVVybCA9IChuZXR3b3JrTmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgaWYgKG5ldHdvcmtOYW1lID09PSBcImhvbWVzdGVhZFwiKSByZXR1cm4gQVBJX01BSU5fVVJMO1xuICBlbHNlIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJyaW5rZWJ5XCIpIHJldHVybiBBUElfUklOS0VCWV9VUkw7XG4gIHJldHVybiBBUElfUk9QU1RFTl9VUkw7XG59O1xuZXhwb3J0IGNvbnN0IEVNQUlMX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vZW1haWxgO1xuZXhwb3J0IGNvbnN0IFNIQVJFX0xJTktfQVBJX1VSTCA9IGAke2dldEFwaVVybChORVRXT1JLX05BTUUpfS9zdG9yYWdlYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX1RUTCA9IDEyMDk2MDA7XG5cbmV4cG9ydCBjb25zdCBMRUdBQ1lfT1BFTkNFUlRTX1JFTkRFUkVSID0gcHVibGljUnVudGltZUNvbmZpZy5sZWdhY3lSZW5kZXJlclVybCB8fCBcImh0dHBzOi8vbGVnYWN5Lm9wZW5jZXJ0cy5pby9cIjtcbmV4cG9ydCBjb25zdCBFTlZJUk9OTUVOVCA9IHB1YmxpY1J1bnRpbWVDb25maWcuY29udGV4dCA9PT0gXCJwcm9kdWN0aW9uXCIgPyBcInByb2R1Y3Rpb25cIiA6IFwiZGV2ZWxvcG1lbnRcIjtcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VPID0ge1xuICB0aXRsZTogXCJBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gIHRpdGxlVGVtcGxhdGU6IGBPcGVuQ2VydHMgLSAlc2AsXG4gIGRlc2NyaXB0aW9uOlxuICAgIFwiV2hldGhlciB5b3UncmUgYSBzdHVkZW50IG9yIGFuIGVtcGxveWVyLCBPcGVuQ2VydHMgbGV0cyB5b3UgdmVyaWZ5IHRoZSBjZXJ0aWZpY2F0ZXMgeW91IGhhdmUgb2YgYW55b25lIGZyb20gYW55IGluc3RpdHV0aW9uLiBBbGwgaW4gb25lIHBsYWNlLlwiLFxuICBvcGVuR3JhcGg6IHtcbiAgICB0eXBlOiBcIndlYnNpdGVcIixcbiAgICB1cmw6IFVSTCxcbiAgICB0aXRsZTogXCJPcGVuQ2VydHMgLSBBbiBlYXN5IHdheSB0byBjaGVjayBhbmQgdmVyaWZ5IHlvdXIgY2VydGlmaWNhdGVzXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgICBpbWFnZXM6IFtcbiAgICAgIHtcbiAgICAgICAgdXJsOiBgJHtVUkx9L3N0YXRpYy9pbWFnZXMvb3BlbmNlcnRzLnBuZ2AsXG4gICAgICAgIHdpZHRoOiA4MDAsXG4gICAgICAgIGhlaWdodDogNjAwLFxuICAgICAgICBhbHQ6IFwiT3BlbkNlcnRzXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHR3aXR0ZXI6IHtcbiAgICBjYXJkVHlwZTogXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIsXG4gIH0sXG59O1xuXG50cmFjZShgTkVUV09SSzogJHtORVRXT1JLX05BTUV9YCk7XG50cmFjZShgQ0FQVENIQV9DTElFTlRfS0VZOiAke0NBUFRDSEFfQ0xJRU5UX0tFWX1gKTtcbnRyYWNlKGBFTUFJTF9BUElfVVJMOiAke0VNQUlMX0FQSV9VUkx9YCk7XG4iLCJpbXBvcnQgZGVidWcsIHsgRGVidWdnZXIgfSBmcm9tIFwiZGVidWdcIjtcblxuLy8gbm90IHVzaW5nIC5leHRlbmRzIGJlY2F1c2Ugb2Ygc3R1cGlkIG5leHQuanMgcmVzb2x2ZSBtb2R1bGVzIGJ1ZyB3aGVyZSBpdHMgcGlja2luZyB1cCBvbGQgdmVyc2lvbiBvZiBkZWJ1Z1xuZXhwb3J0IGNvbnN0IHRyYWNlID0gKG5hbWVzcGFjZTogc3RyaW5nKTogRGVidWdnZXIgPT4gZGVidWcoYG9wZW5jZXJ0cy13ZWJzaXRlOnRyYWNlOiR7bmFtZXNwYWNlfWApO1xuZXhwb3J0IGNvbnN0IGVycm9yID0gKG5hbWVzcGFjZTogc3RyaW5nKTogRGVidWdnZXIgPT4gZGVidWcoYG9wZW5jZXJ0cy13ZWJzaXRlOmVycm9yOiR7bmFtZXNwYWNlfWApO1xuXG5leHBvcnQgY29uc3QgZ2V0TG9nZ2VyID0gKG5hbWVzcGFjZTogc3RyaW5nKTogeyB0cmFjZTogRGVidWdnZXI7IGVycm9yOiBEZWJ1Z2dlciB9ID0+ICh7XG4gIHRyYWNlOiB0cmFjZShuYW1lc3BhY2UpLFxuICBlcnJvcjogZXJyb3IobmFtZXNwYWNlKSxcbn0pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==