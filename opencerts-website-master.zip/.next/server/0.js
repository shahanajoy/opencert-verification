exports.ids = [0];
exports.modules = {

/***/ "./public/static/registry.json":
/*!*************************************!*\
  !*** ./public/static/registry.json ***!
  \*************************************/
/*! exports provided: issuers, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"issuers\":{\"0x007d40224f6562461633ccfbaffd359ebb2fc9ba\":{\"name\":\"Government Technology Agency of Singapore (GovTech)\",\"displayCard\":true,\"website\":\"https://www.tech.gov.sg\",\"email\":\"info@tech.gov.sg\",\"phone\":\"+65 6211 2100\",\"logo\":\"/static/images/GOVTECH_logo.png\",\"id\":\"govtech-registry\"},\"0x5CA3b9daC85DA4DE4030e59C1a0248004209e348\":{\"name\":\"Nanyang Polytechnic\",\"displayCard\":true,\"website\":\"https://www.nyp.edu.sg/\",\"email\":\"askNYP@nyp.edu.sg\",\"phone\":\"+65 6451 5115\",\"logo\":\"/static/images/NYP_logo.png\",\"id\":\"nyp-registry\"},\"0xa5d801265D29A6F1015a641BfC0e39Ee3dA2AC76\":{\"name\":\"Ngee Ann Polytechnic\",\"displayCard\":true,\"website\":\"https://www.np.edu.sg\",\"email\":\"asknp@np.edu.sg\",\"phone\":\"+65 6466 6555\",\"logo\":\"/static/images/NP_logo.svg\",\"id\":\"np-registry\",\"group\":\"np-registry\"},\"0x828dB5254a44e8630068107A2536219e0C84cacA\":{\"name\":\"Ngee Ann Polytechnic CET Academy\",\"displayCard\":true,\"website\":\"https://www.np.edu.sg\",\"email\":\"enquiryCET@np.edu.sg\",\"phone\":\"+65 6460 6353\",\"logo\":\"/static/images/NP_logo.svg\",\"id\":\"np-registry-academy\",\"group\":\"np-registry\"},\"0xE4a94Ef9C26904A02Cd6735F7D4De1D840146a0f\":{\"name\":\"Singapore Examinations and Assessment Board\",\"displayCard\":true,\"website\":\"https://www.seab.gov.sg/\",\"email\":\"\",\"phone\":\"+65 6872 2220\",\"logo\":\"/static/images/SEAB_logo_crop.png\",\"id\":\"seab-registry\"},\"0x24a7DE31D231221ab6B1B325Ca5F1AA7bfbaaabA\":{\"name\":\"Singapore Institute of Technology\",\"displayCard\":true,\"website\":\"https://www.singaporetech.edu.sg/\",\"email\":\"\",\"phone\":\"+65 6592 1136\",\"logo\":\"/static/images/SIT_logo.png\",\"id\":\"sit-registry\"},\"0x78CE67fcb40D9D9552A313670A2e0eef11043995\":{\"name\":\"SkillsFuture Singapore\",\"displayCard\":true,\"website\":\"https://www.ssg-wsg.gov.sg/\",\"email\":\"\",\"phone\":\"+65 6785 5785\",\"logo\":\"/static/images/SSG_logo.png\",\"id\":\"ssg-registry\"},\"0x4d05f843718da742b4229938f972a3eb969c25ce\":{\"name\":\"Temasek Polytechnic\",\"displayCard\":true,\"website\":\"https://www.tp.edu.sg/home\",\"email\":\"enquiry@tp.edu.sg\",\"phone\":\"+65 6789 8220\",\"logo\":\"/static/images/TP_logo.svg\",\"id\":\"tp-registry\"},\"0x0CE38eBEa3B943Ee6DA24163710b25Ef8654f39E\":{\"name\":\"Institute of Technical Education\",\"displayCard\":true,\"website\":\"https://www.ite.edu.sg\",\"email\":\"training@ite.edu.sg\",\"phone\":\"1800-2222 111\",\"logo\":\"/static/images/ITE_logo.png\",\"id\":\"ite-registry\"},\"0x18270bA6dA0380a2cbC705bc6C0AD6651282bD14\":{\"name\":\"Republic Polytechnic\",\"displayCard\":true,\"website\":\"https://www.rp.edu.sg/\",\"email\":\"one-stop@rp.edu.sg\",\"phone\":\"+65 6510 3000\",\"logo\":\"/static/images/RP_logo.svg\",\"id\":\"rp-registry\"},\"0x96a7bEefb0A7fb6B9d2101B0A27a734fA97E7221\":{\"name\":\"Singapore University of Technology and Design\",\"displayCard\":true,\"website\":\"https://sutd.edu.sg\",\"email\":\"opencert@sutd.edu.sg\",\"phone\":\"+65 6499 8922\",\"logo\":\"/static/images/SUTD_logo.png\",\"id\":\"sutd-registry\"},\"0x16E949FcDC655765959Ac085CA7B1aE353D6Ca35\":{\"name\":\"Nanyang Technological University\",\"displayCard\":true,\"website\":\"https://www.ntu.edu.sg\",\"email\":\"deg_verify@ntu.edu.sg\",\"phone\":\"+65 6592 2448\",\"logo\":\"/static/images/NTU_logo.png\",\"id\":\"ntu-registry\"},\"0x61783202d023fd08dcc7d7ca8a196697c46c9d57\":{\"name\":\"Nanyang Technological University\",\"displayCard\":true,\"website\":\"https://www.ntu.edu.sg\",\"email\":\"deg_verify@ntu.edu.sg\",\"phone\":\"+65 6592 2448\",\"logo\":\"/static/images/NTU_logo.png\",\"id\":\"ntu-registry\"},\"0xCFa2B7Fc3FdD5CA55715581e34420268CCcd3039\":{\"name\":\"Singapore Management University\",\"displayCard\":true,\"website\":\"https://www.smu.edu.sg\",\"email\":\"digitalcert@smu.edu.sg\",\"phone\":\"+65 6828 0583 / +65 6808 5264 / +65 6808 5138\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry\",\"group\":\"smu-registry\"},\"0x6c806e3E0Ea393eC7E8b7E7fa62eF92Fcd039404\":{\"name\":\"Singapore Management University Academy\",\"displayCard\":true,\"website\":\"https://academy.smu.edu.sg\",\"email\":\"academy@smu.edu.sg\",\"phone\":\"+65 6828 9688\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-academy\",\"group\":\"smu-registry\"},\"0x38c8d4cbc63a23739abfe9c280a3c533a8dbebf5\":{\"name\":\"Singapore Management University School of Accountancy\",\"displayCard\":true,\"website\":\"https://accountancy.smu.edu.sg\",\"email\":\"accountancy@smu.edu.sg\",\"phone\":\"+65 6828 0632\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-accountancy\",\"group\":\"smu-registry\"},\"0x6a8899bbe8bb1535e60cf9237fc6806c26066dee\":{\"name\":\"Singapore Management University School of Economics\",\"displayCard\":true,\"website\":\"https://economics.smu.edu.sg\",\"email\":\"economics_enquiries@smu.edu.sg\",\"phone\":\"+65 6808 5108\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-economics\",\"group\":\"smu-registry\"},\"0x94cbba4b50d2c29d247221a7cc2dda356054078b\":{\"name\":\"Singapore Management University School of Information Systems\",\"displayCard\":true,\"website\":\"https://sis.smu.edu.sg\",\"email\":\"enquiries@sis.smu.edu.sg\",\"phone\":\"+65 6808 5108\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-sis\",\"group\":\"smu-registry\"},\"0x5a8027a5fa187d495546c4041966703bf9018a11\":{\"name\":\"Singapore Management University Lee Kong Chian School of Business\",\"displayCard\":true,\"website\":\"https://business.smu.edu.sg\",\"email\":\"bschool@smu.edu.sg\",\"phone\":\"+65 6828 0549\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-business\",\"group\":\"smu-registry\"},\"0x86e7e573a18df76ed840d6ae2af11785c1453911\":{\"name\":\"Singapore Management University School of Law\",\"displayCard\":true,\"website\":\"https://law.smu.edu.sg\",\"email\":\"law@smu.edu.sg\",\"phone\":\"+65 6828 0502\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-law\",\"group\":\"smu-registry\"},\"0x5b3e03ec154629c67ad5d32e34048aac3fb0ddbe\":{\"name\":\"Singapore Management University Institute of Service Excellence\",\"displayCard\":true,\"website\":\"https://ise.smu.edu.sg\",\"email\":\"ise@smu.edu.sg\",\"phone\":\"+65 6828 0111\",\"logo\":\"/static/images/SMU_logo.png\",\"id\":\"smu-registry-excellence\",\"group\":\"smu-registry\"},\"0xA204F16717fbF580d6A0535b58063fB4fce969fF\":{\"name\":\"National University of Singapore\",\"displayCard\":true,\"website\":\"http://www.nus.edu.sg/\",\"email\":\"transcript@nus.edu.sg\",\"phone\":\"+65 6516 2304\",\"logo\":\"/static/images/NUS_logo.svg\",\"id\":\"nus-registry\"},\"0x66671988ee465b5c23Ef18838B32b1666d0EC8d6\":{\"name\":\"National University of Singapore\",\"displayCard\":true,\"website\":\"http://www.nus.edu.sg/\",\"email\":\"transcript@nus.edu.sg\",\"phone\":\"+65 6516 2304\",\"logo\":\"/static/images/NUS_logo.svg\",\"id\":\"nus-registry\"},\"0x69Ec8cA1A2A19566128F4157Dca6249d89046F1F\":{\"name\":\"Singapore Polytechnic\",\"displayCard\":true,\"website\":\"https://www.sp.edu.sg\",\"email\":\"contactus@sp.edu.sg\",\"phone\":\"+65 6775 1133\",\"logo\":\"/static/images/SP_logo.svg\",\"id\":\"sp-registry\"},\"0x45b04D7EFdfA1B25296e5BC9eC88E3ae3C53CE9f\":{\"name\":\"Singapore University of Social Sciences\",\"displayCard\":true,\"website\":\"https://www.suss.edu.sg/\",\"email\":\"alumni@suss.edu.sg\",\"phone\":\"+65 6248 9215\",\"logo\":\"/static/images/SUSS_logo.png\",\"id\":\"suss-registry\"},\"0x9cf976dc45bb5a9336238759e89051E7b09e016b\":{\"name\":\"National Institute of Early Childhood Development\",\"displayCard\":true,\"website\":\"https://www.niec.edu.sg/\",\"email\":\"aa@niec.edu.sg\",\"phone\":\"+65 6332 0668\",\"logo\":\"/static/images/NIEC_logo.png\",\"id\":\"niec-registry\"},\"0xa53C84A422D9cCc5C4aDA9fa65B03e2Bb25E2D03\":{\"name\":\"Lasalle College of the Arts\",\"displayCard\":true,\"website\":\"https://www.lasalle.edu.sg/\",\"email\":\"academic.admin@lasalle.edu.sg\",\"phone\":\"+65 6496 5200\",\"logo\":\"/static/images/LASALLE_logo.png\",\"id\":\"lasalle-registry\"},\"0x5af87c7C799FdD24418f436ccc5d0ef00a1D755B\":{\"name\":\"Nanyang Academy of Fine Arts\",\"displayCard\":true,\"website\":\"https://www.nafa.edu.sg/\",\"email\":\"nafacerts@nafa.edu.sg\",\"phone\":\"+65 6512 4000\",\"logo\":\"/static/images/NAFA_Arts_logo.png\",\"id\":\"nanyang-art-registry\"},\"0xb3c1404732585ddEB837Af28eBdAec504ed8Ba04\":{\"name\":\"ROPSTEN: Singapore Management University\",\"displayCard\":false},\"0x3FFB6b913E9874c7ddabD564d85676Bc5cAd16d4\":{\"name\":\"ROPSTEN: Nanyang Technological University\",\"displayCard\":false},\"0xdcb5bce006f5f369579854ec32ec6fa53ba915be\":{\"name\":\"ROPSTEN: Nanyang Polytechnic\",\"displayCard\":false},\"0xfEbB273495F5C2c4783E23424Fe9773691b57fcB\":{\"name\":\"ROPSTEN: National University of Singapore\",\"displayCard\":false},\"0x866Fb78aC3c87019aBff9FB566acfF66F75Cfa46\":{\"name\":\"ROPSTEN: Ngee Ann Polytechnic\",\"displayCard\":false},\"0xc36484efa1544c32ffed2e80a1ea9f0dfc517495\":{\"name\":\"ROPSTEN: Ngee Ann Polytechnic\",\"displayCard\":false},\"0xeDe1B6Fc03f1a9C6905C93a2fceb06E19624a55E\":{\"name\":\"ROPSTEN: Singapore Examinations and Assessment Board\",\"displayCard\":false},\"0x897E224a6a8b72535D67940B3B8CE53f9B596800\":{\"name\":\"ROPSTEN: Singapore Institute of Technology\",\"displayCard\":false},\"0x3f43FB8546E97b2c1D5eD087767C0d2eb2e13f8b\":{\"name\":\"ROPSTEN: Singapore Institute of Technology (Ledger Nano)\",\"displayCard\":false},\"0xCE4D56Fea4a4EB33E8A3502CEe6Db075224C896d\":{\"name\":\"ROPSTEN: Skillsfuture Singapore\",\"displayCard\":false},\"0xe825e69383a57eB686Fc7b8c455Dd982bB9680f6\":{\"name\":\"ROPSTEN: Temasek Polytechnic\",\"displayCard\":false},\"0xE5c693015460868F817799CAFb363EEDb4F9E446\":{\"name\":\"ROPSTEN: Institute of Technical Education\",\"displayCard\":false},\"0xdcA6Eea7024151c270b50FcA9E67161119B06BAD\":{\"name\":\"ROPSTEN: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false},\"0x532C9Ff853CA54370D7492cD84040F9f8099f11B\":{\"name\":\"ROPSTEN: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false},\"0x061aFcFF60b90E0F633F8ef157e01BaB9b2FfDD3\":{\"name\":\"ROPSTEN: Republic Polytechnic\",\"displayCard\":false},\"0x2456FC81C1342fB79D7C58A4682F031208A44d7F\":{\"name\":\"ROPSTEN: Singapore University of Technology and Design\",\"displayCard\":false},\"0x46cf931c320ce7277753dbb15567dD684404e36C\":{\"name\":\"ROPSTEN: Singapore University of Social Sciences\",\"displayCard\":false},\"0x146d1e1938dc0f5fbb2179727c2fa61522cd1834\":{\"name\":\"ROPSTEN: National Institute of Early Childhood Development\",\"displayCard\":false},\"0xb02bcBb4865d0301F6e4A5f46043498f7c348E03\":{\"name\":\"ROPSTEN: Lasalle College of the Arts\",\"displayCard\":false},\"0x7Ee2B9a0043Bda975398477695ba5c2361acC50C\":{\"name\":\"RINKEBY: Government Technology Agency of Singapore (GovTech)\",\"displayCard\":false}}}");

/***/ }),

/***/ "./src/components/Analytics/index.ts":
/*!*******************************************!*\
  !*** ./src/components/Analytics/index.ts ***!
  \*******************************************/
/*! exports provided: validateEvent, stringifyEvent, analyticsEvent, sendEventCertificateViewedDetailed, triggerErrorLogging */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validateEvent", function() { return validateEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stringifyEvent", function() { return stringifyEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "analyticsEvent", function() { return analyticsEvent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendEventCertificateViewedDetailed", function() { return sendEventCertificateViewedDetailed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "triggerErrorLogging", function() { return triggerErrorLogging; });
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @govtechsg/open-attestation */ "@govtechsg/open-attestation");
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../public/static/registry.json */ "./public/static/registry.json");
var _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../../public/static/registry.json */ "./public/static/registry.json", 1);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/logger */ "./src/utils/logger.ts");



const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_2__["getLogger"])("components:Analytics:");
const {
  trace: traceDev
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_2__["getLogger"])("components:Analytics(Inactive):");

/*
 * This function checks if an address is in registry.json to provide property access.
 */
function isInRegistry(value) {
  return value in _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers;
}

const validateEvent = ({
  category,
  action,
  value
}) => {
  if (!category) throw new Error("Category is required");
  if (!action) throw new Error("Action is required");
  if (value && typeof value !== "number") throw new Error("Value must be a number");
};
const stringifyEvent = ({
  category,
  action,
  label,
  value
}) => `Category*: ${category}, Action*: ${action}, Label: ${label}, Value: ${value}`;
const analyticsEvent = (window, event) => {
  validateEvent(event);

  if (false) {}

  traceDev(stringifyEvent(event));
};
const sendEventCertificateViewedDetailed = ({
  issuer,
  certificateData
}) => {
  var _ref, _ref2, _ref3, _issuer$certificateSt, _certificateData$id, _certificateData$name, _certificateData$issu;

  let label = "";
  let issuerName = "";
  let registryId = null;
  const separator = ";";
  const store = (_ref = (_ref2 = (_ref3 = (_issuer$certificateSt = issuer.certificateStore) !== null && _issuer$certificateSt !== void 0 ? _issuer$certificateSt : issuer.documentStore) !== null && _ref3 !== void 0 ? _ref3 : issuer.tokenRegistry) !== null && _ref2 !== void 0 ? _ref2 : issuer.id) !== null && _ref !== void 0 ? _ref : ""; // use id for DID

  const id = (_certificateData$id = certificateData === null || certificateData === void 0 ? void 0 : certificateData.id) !== null && _certificateData$id !== void 0 ? _certificateData$id : "";
  const name = (_certificateData$name = certificateData === null || certificateData === void 0 ? void 0 : certificateData.name) !== null && _certificateData$name !== void 0 ? _certificateData$name : "";
  const issuedOn = (_certificateData$issu = certificateData === null || certificateData === void 0 ? void 0 : certificateData.issuedOn) !== null && _certificateData$issu !== void 0 ? _certificateData$issu : "";

  if (isInRegistry(store)) {
    var _issuerName, _registryIssuer$id;

    const registryIssuer = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store];
    registryId = registryIssuer.id;
    issuerName = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store].name;
    label = `"store":"${store}"${separator}"document_id":"${id}"${separator}"name":"${name}"${separator}"issued_on":"${issuedOn}"${separator}"issuer_name":"${(_issuerName = issuerName) !== null && _issuerName !== void 0 ? _issuerName : ""}"${separator}"issuer_id":"${(_registryIssuer$id = registryIssuer.id) !== null && _registryIssuer$id !== void 0 ? _registryIssuer$id : ""}"`;
  } else if (issuer.identityProof) {
    var _issuerName2;

    issuerName = issuer.identityProof.location || "";
    label = `"store":"${store}"${separator}"document_id":"${id}"${separator}"name":"${name}"${separator}"issued_on":"${issuedOn}"${separator}"issuer_name":"${(_issuerName2 = issuerName) !== null && _issuerName2 !== void 0 ? _issuerName2 : ""}"`;
  } else {
    label = "Something went wrong, please check the analytics code of sendEventCertificateViewedDetailed";
  }

  analyticsEvent(window, {
    category: "CERTIFICATE_DETAILS",
    action: `VIEWED - ${issuerName}`,
    label,
    options: {
      nonInteraction: true,
      dimension1: store || "(not set)",
      dimension2: id || "(not set)",
      dimension3: name || "(not set)",
      dimension4: issuedOn || "(not set)",
      dimension5: issuerName || "(not set)",
      dimension6: registryId || "(not set)"
    }
  });
};
function triggerErrorLogging(rawCertificate, errors) {
  const certificate = Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_0__["getData"])(rawCertificate);
  const id = certificate === null || certificate === void 0 ? void 0 : certificate.id;
  const name = certificate === null || certificate === void 0 ? void 0 : certificate.name;
  const issuedOn = certificate === null || certificate === void 0 ? void 0 : certificate.issuedOn;
  const errorsList = errors.join(","); // If there are multiple issuers in a certificate, we send multiple events!

  certificate.issuers.forEach(issuer => {
    var _ref4, _ref5, _ref6, _issuer$certificateSt2;

    const store = (_ref4 = (_ref5 = (_ref6 = (_issuer$certificateSt2 = issuer.certificateStore) !== null && _issuer$certificateSt2 !== void 0 ? _issuer$certificateSt2 : issuer.documentStore) !== null && _ref6 !== void 0 ? _ref6 : issuer.tokenRegistry) !== null && _ref5 !== void 0 ? _ref5 : issuer.id) !== null && _ref4 !== void 0 ? _ref4 : ""; // use id for DID

    let issuerName = issuer.name;
    let registryId = null;

    if (isInRegistry(store)) {
      const registryIssuer = _public_static_registry_json__WEBPACK_IMPORTED_MODULE_1__.issuers[store];
      issuerName = registryIssuer.name;
      registryId = registryIssuer.id;
    } else if (issuer.identityProof) {
      issuerName = issuer.identityProof.location || "";
    }

    analyticsEvent(window, {
      category: "CERTIFICATE_ERROR",
      action: `ERROR - ${issuerName}`,
      label: errorsList,
      options: {
        nonInteraction: true,
        dimension1: store || "(not set)",
        dimension2: id || "(not set)",
        dimension3: name || "(not set)",
        dimension4: issuedOn || "(not set)",
        dimension5: issuerName || "(not set)",
        dimension6: registryId || "(not set)",
        dimension7: errorsList
      }
    });
  });
}

/***/ }),

/***/ "./src/components/DecentralisedTemplateRenderer/DecentralisedRenderer.tsx":
/*!********************************************************************************!*\
  !*** ./src/components/DecentralisedTemplateRenderer/DecentralisedRenderer.tsx ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @govtechsg/decentralized-renderer-react-components */ "@govtechsg/decentralized-renderer-react-components");
/* harmony import */ var _govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @govtechsg/open-attestation */ "@govtechsg/open-attestation");
/* harmony import */ var _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../config */ "./src/config/index.ts");
/* harmony import */ var _Analytics__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Analytics */ "./src/components/Analytics/index.ts");
/* harmony import */ var _MultiTabs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../MultiTabs */ "./src/components/MultiTabs.tsx");


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\DecentralisedTemplateRenderer\\DecentralisedRenderer.tsx";






// giving scrollbar a default width as there are no perfect ways to get it
const SCROLLBAR_WIDTH = 20;

const DecentralisedRenderer = ({
  rawDocument,
  updateObfuscatedCertificate,
  forwardedRef
}) => {
  const toFrame = Object(react__WEBPACK_IMPORTED_MODULE_3__["useRef"])();
  const documentRef = Object(react__WEBPACK_IMPORTED_MODULE_3__["useRef"])(rawDocument);
  const document = Object(react__WEBPACK_IMPORTED_MODULE_3__["useMemo"])(() => Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["getData"])(rawDocument), [rawDocument]);
  const {
    0: height,
    1: setHeight
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0);
  const {
    0: templates,
    1: setTemplates
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]);
  Object(react__WEBPACK_IMPORTED_MODULE_3__["useImperativeHandle"])(forwardedRef, () => ({
    print() {
      if (toFrame.current) {
        toFrame.current(Object(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__["print"])());
      }
    }

  }));
  const onConnected = Object(react__WEBPACK_IMPORTED_MODULE_3__["useCallback"])(frame => {
    toFrame.current = frame;

    if (toFrame.current) {
      toFrame.current(Object(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__["renderDocument"])({
        document,
        rawDocument
      }));
    }
  }, [document, rawDocument]);

  const dispatch = action => {
    if (action.type === "UPDATE_HEIGHT") {
      // adding SCROLLBAR_WIDTH in case the frame content overflow horizontally, which will cause scrollbars to appear
      setHeight(action.payload + SCROLLBAR_WIDTH);
    } else if (action.type === "OBFUSCATE") {
      const field = action.payload;
      const updatedDocument = Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["obfuscateDocument"])(documentRef.current, field);
      updateObfuscatedCertificate(updatedDocument);
      const newDocument = Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["getData"])(updatedDocument);

      if (toFrame.current) {
        toFrame.current(Object(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__["renderDocument"])({
          document: newDocument,
          rawDocument: documentRef.current
        }));
      }
    } else if (action.type === "UPDATE_TEMPLATES") {
      setTemplates(action.payload);
    }
  }; // effects
  // update document after every changes


  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(() => {
    documentRef.current = rawDocument;
  }, [rawDocument]); // send analytics on which document has been displayed

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(() => {
    var _certificateData$id;

    const certificateData = Object(_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["getData"])(rawDocument);
    let action;

    if (_govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["utils"].isSignedWrappedV2Document(rawDocument)) {
      action = certificateData.issuers.map(issuer => issuer.id).join(",");
    } else {
      const storeAddresses = _govtechsg_open_attestation__WEBPACK_IMPORTED_MODULE_2__["utils"].getIssuerAddress(rawDocument);
      action = Array.isArray(storeAddresses) ? storeAddresses.join(",") : storeAddresses;
    }

    Object(_Analytics__WEBPACK_IMPORTED_MODULE_5__["analyticsEvent"])(window, {
      category: "CERTIFICATE_VIEWED",
      action,
      label: (_certificateData$id = certificateData === null || certificateData === void 0 ? void 0 : certificateData.id) !== null && _certificateData$id !== void 0 ? _certificateData$id : undefined
    });
    certificateData.issuers.forEach(issuer => {
      Object(_Analytics__WEBPACK_IMPORTED_MODULE_5__["sendEventCertificateViewedDetailed"])({
        issuer,
        certificateData
      });
    });
  }, [rawDocument]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_MultiTabs__WEBPACK_IMPORTED_MODULE_6__["MutiTabsContainer"], {
      templates: templates,
      onSelectTemplate: label => {
        if (toFrame.current) {
          toFrame.current(Object(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__["selectTemplate"])(label));
        }
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 104,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
      className: "print-only exact-print text-center py-8",
      children: "If you want to print the certificate, please click on the highlighted button above."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 7
    }, undefined), !toFrame.current && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container text-blue text-center py-16",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
        className: "fas fa-spinner fa-pulse fa-3x"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "my-3",
        children: "Loading Renderer..."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 116,
      columnNumber: 9
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_govtechsg_decentralized_renderer_react_components__WEBPACK_IMPORTED_MODULE_1__["FrameConnector"], {
      className: "w-full max-w-full",
      style: {
        height: `${height}px`
      },
      source: `${typeof document.$template === "object" ? document.$template.url : _config__WEBPACK_IMPORTED_MODULE_4__["LEGACY_OPENCERTS_RENDERER"]}`,
      dispatch: dispatch,
      onConnected: onConnected
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 121,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
}; // looks needed for dynamic import
// eslint-disable-next-line import/no-default-export


/* harmony default export */ __webpack_exports__["default"] = (DecentralisedRenderer);

/***/ }),

/***/ "./src/components/MultiTabs.tsx":
/*!**************************************!*\
  !*** ./src/components/MultiTabs.tsx ***!
  \**************************************/
/*! exports provided: MutiTabsContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MutiTabsContainer", function() { return MutiTabsContainer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../reducers/certificate.actions */ "./src/reducers/certificate.actions.ts");
/* harmony import */ var _UI_Drawer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./UI/Drawer */ "./src/components/UI/Drawer/index.ts");

var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\MultiTabs.tsx";






const MultiTabs = ({
  resetData,
  templates,
  onSelectTemplate
}) => {
  const {
    0: selectedTemplate,
    1: setSelectedTemplate
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(0);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("nav", {
    className: "bg-blue-100 py-4 border-b-4 mb-4",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "block md:hidden",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_UI_Drawer__WEBPACK_IMPORTED_MODULE_5__["Drawer"], {
        tabs: templates,
        activeIdx: selectedTemplate,
        toggle: (index, id) => {
          setSelectedTemplate(index);
          onSelectTemplate(id);
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "hidden md:block",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex flex-wrap",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "w-full ml-auto mb-16 lg:mb-0 lg:w-auto lg:order-2",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_1___default.a, {
              href: "/",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                className: "button border border-navy text-navy bg-white hover:bg-navy",
                id: "btn-view-another",
                onClick: () => resetData(),
                children: "View another"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "w-full lg:flex-1 lg:order-1",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
              id: "template-tabs-list",
              className: "flex flex-wrap -mx-4",
              children: templates && templates.length > 0 ? templates.map((template, idx) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
                className: "w-auto mr-2",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  className: `p-4 border-b-4 uppercase text-black hover:text-black hover:text-opacity-75 hover:border-black ${idx === selectedTemplate ? "font-semi border-black" : "border-grey text-opacity-50"}`,
                  "data-testid": template.id,
                  onClick: () => {
                    setSelectedTemplate(idx);
                    onSelectTemplate(template.id);
                  },
                  children: template.label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 45,
                  columnNumber: 25
                }, undefined)
              }, idx, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 23
              }, undefined)) : null
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined);
};

const MutiTabsContainer = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["connect"])(null, dispatch => ({
  resetData: () => dispatch(Object(_reducers_certificate_actions__WEBPACK_IMPORTED_MODULE_4__["resetCertificateState"])())
}))(MultiTabs);

/***/ }),

/***/ "./src/components/UI/Drawer/drawer.tsx":
/*!*********************************************!*\
  !*** ./src/components/UI/Drawer/drawer.tsx ***!
  \*********************************************/
/*! exports provided: Drawer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Drawer", function() { return Drawer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\MohamedFarshad\\source\\repos\\DocumentWebViewer\\opencerts-website-master\\src\\components\\UI\\Drawer\\drawer.tsx";

class Drawer extends react__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      showAbsHeader: false
    };
  }

  toggleDrawer() {
    this.setState({
      visible: !this.state.visible
    });
  }

  createTabs(tabs) {
    const {
      activeIdx
    } = this.props;
    return tabs.map((tab, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: `cursor-pointer w-full text-white border-b py-4 hover:text-opacity-100 ${activeIdx === index ? "" : "text-opacity-50"}`,
      onClick: e => {
        e.preventDefault();
        this.renderContent(index, tab.id);
      },
      children: tab.label
    }, index, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, this));
  }

  renderContent(index, id) {
    this.props.toggle(index, id);
    this.toggleDrawer();
  }

  render() {
    const {
      tabs
    } = this.props;
    const {
      visible,
      showAbsHeader
    } = this.state;
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: `cursor-pointer text-lg text-white ${showAbsHeader ? "" : "absolute top-0 right-0 mt-4 mr-4"}`,
        onClick: () => this.toggleDrawer(),
        children: "\u2630"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, this), visible ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("aside", {
        className: "bg-navy text-lg fixed top-0 right-0 h-screen p-4",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "cursor-pointer text-white",
          onClick: e => {
            e.preventDefault();
            this.toggleDrawer();
          },
          children: "\xD7"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex flex-wrap",
          children: this.createTabs(tabs)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 11
      }, this) : null]
    }, void 0, true);
  }

}

/***/ }),

/***/ "./src/components/UI/Drawer/index.ts":
/*!*******************************************!*\
  !*** ./src/components/UI/Drawer/index.ts ***!
  \*******************************************/
/*! exports provided: Drawer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _drawer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./drawer */ "./src/components/UI/Drawer/drawer.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Drawer", function() { return _drawer__WEBPACK_IMPORTED_MODULE_0__["Drawer"]; });



/***/ }),

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/*! exports provided: URL, IS_MAINNET, NETWORK_NAME, GA_ID, CAPTCHA_CLIENT_KEY, EMAIL_API_URL, SHARE_LINK_API_URL, SHARE_LINK_TTL, LEGACY_OPENCERTS_RENDERER, ENVIRONMENT, DEFAULT_SEO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "URL", function() { return URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_MAINNET", function() { return IS_MAINNET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NETWORK_NAME", function() { return NETWORK_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GA_ID", function() { return GA_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CAPTCHA_CLIENT_KEY", function() { return CAPTCHA_CLIENT_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EMAIL_API_URL", function() { return EMAIL_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_API_URL", function() { return SHARE_LINK_API_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SHARE_LINK_TTL", function() { return SHARE_LINK_TTL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEGACY_OPENCERTS_RENDERER", function() { return LEGACY_OPENCERTS_RENDERER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENVIRONMENT", function() { return ENVIRONMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_SEO", function() { return DEFAULT_SEO; });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/config */ "next/config");
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/logger */ "./src/utils/logger.ts");
var _ref;



const {
  trace
} = Object(_utils_logger__WEBPACK_IMPORTED_MODULE_1__["getLogger"])("config"); // https://github.com/vercel/next.js/issues/7713

const {
  publicRuntimeConfig = {}
} = next_config__WEBPACK_IMPORTED_MODULE_0___default()();
const URL = "https://opencerts.io";
const API_MAIN_URL = "https://api.opencerts.io";
const API_ROPSTEN_URL = "https://api-ropsten.opencerts.io";
const API_RINKEBY_URL = "https://api-rinkeby.opencerts.io";
const GA_PRODUCTION_ID = "UA-130492260-1";
const GA_DEVELOPMENT_ID = "UA-130492260-2";
const IS_MAINNET = publicRuntimeConfig.network === "mainnet";
const NETWORK_NAME = (_ref = IS_MAINNET ? "homestead" : publicRuntimeConfig.network) !== null && _ref !== void 0 ? _ref : "ropsten"; // expected by ethers

const GA_ID = IS_MAINNET ? GA_PRODUCTION_ID : GA_DEVELOPMENT_ID;
const CAPTCHA_CLIENT_KEY = "6LfiL3EUAAAAAHrfLvl2KhRAcXpanNXDqu6M0CCS";

const getApiUrl = networkName => {
  if (networkName === "homestead") return API_MAIN_URL;else if (networkName === "rinkeby") return API_RINKEBY_URL;
  return API_ROPSTEN_URL;
};

const EMAIL_API_URL = `${getApiUrl(NETWORK_NAME)}/email`;
const SHARE_LINK_API_URL = `${getApiUrl(NETWORK_NAME)}/storage`;
const SHARE_LINK_TTL = 1209600;
const LEGACY_OPENCERTS_RENDERER = publicRuntimeConfig.legacyRendererUrl || "https://legacy.opencerts.io/";
const ENVIRONMENT = publicRuntimeConfig.context === "production" ? "production" : "development";
const DEFAULT_SEO = {
  title: "An easy way to check and verify your certificates",
  titleTemplate: `OpenCerts - %s`,
  description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
  openGraph: {
    type: "website",
    url: URL,
    title: "OpenCerts - An easy way to check and verify your certificates",
    description: "Whether you're a student or an employer, OpenCerts lets you verify the certificates you have of anyone from any institution. All in one place.",
    images: [{
      url: `${URL}/static/images/opencerts.png`,
      width: 800,
      height: 600,
      alt: "OpenCerts"
    }]
  },
  twitter: {
    cardType: "summary_large_image"
  }
};
trace(`NETWORK: ${NETWORK_NAME}`);
trace(`CAPTCHA_CLIENT_KEY: ${CAPTCHA_CLIENT_KEY}`);
trace(`EMAIL_API_URL: ${EMAIL_API_URL}`);

/***/ }),

/***/ "./src/utils/logger.ts":
/*!*****************************!*\
  !*** ./src/utils/logger.ts ***!
  \*****************************/
/*! exports provided: trace, error, getLogger */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trace", function() { return trace; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLogger", function() { return getLogger; });
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! debug */ "debug");
/* harmony import */ var debug__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(debug__WEBPACK_IMPORTED_MODULE_0__);
 // not using .extends because of stupid next.js resolve modules bug where its picking up old version of debug

const trace = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:trace:${namespace}`);
const error = namespace => debug__WEBPACK_IMPORTED_MODULE_0___default()(`opencerts-website:error:${namespace}`);
const getLogger = namespace => ({
  trace: trace(namespace),
  error: error(namespace)
});

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9BbmFseXRpY3MvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvRGVjZW50cmFsaXNlZFRlbXBsYXRlUmVuZGVyZXIvRGVjZW50cmFsaXNlZFJlbmRlcmVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9NdWx0aVRhYnMudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL1VJL0RyYXdlci9kcmF3ZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL1VJL0RyYXdlci9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29uZmlnL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy91dGlscy9sb2dnZXIudHMiXSwibmFtZXMiOlsidHJhY2UiLCJnZXRMb2dnZXIiLCJ0cmFjZURldiIsImlzSW5SZWdpc3RyeSIsInZhbHVlIiwicmVnaXN0cnkiLCJpc3N1ZXJzIiwidmFsaWRhdGVFdmVudCIsImNhdGVnb3J5IiwiYWN0aW9uIiwiRXJyb3IiLCJzdHJpbmdpZnlFdmVudCIsImxhYmVsIiwiYW5hbHl0aWNzRXZlbnQiLCJ3aW5kb3ciLCJldmVudCIsInNlbmRFdmVudENlcnRpZmljYXRlVmlld2VkRGV0YWlsZWQiLCJpc3N1ZXIiLCJjZXJ0aWZpY2F0ZURhdGEiLCJpc3N1ZXJOYW1lIiwicmVnaXN0cnlJZCIsInNlcGFyYXRvciIsInN0b3JlIiwiY2VydGlmaWNhdGVTdG9yZSIsImRvY3VtZW50U3RvcmUiLCJ0b2tlblJlZ2lzdHJ5IiwiaWQiLCJuYW1lIiwiaXNzdWVkT24iLCJyZWdpc3RyeUlzc3VlciIsImlkZW50aXR5UHJvb2YiLCJsb2NhdGlvbiIsIm9wdGlvbnMiLCJub25JbnRlcmFjdGlvbiIsImRpbWVuc2lvbjEiLCJkaW1lbnNpb24yIiwiZGltZW5zaW9uMyIsImRpbWVuc2lvbjQiLCJkaW1lbnNpb241IiwiZGltZW5zaW9uNiIsInRyaWdnZXJFcnJvckxvZ2dpbmciLCJyYXdDZXJ0aWZpY2F0ZSIsImVycm9ycyIsImNlcnRpZmljYXRlIiwiZ2V0RGF0YSIsImVycm9yc0xpc3QiLCJqb2luIiwiZm9yRWFjaCIsImRpbWVuc2lvbjciLCJTQ1JPTExCQVJfV0lEVEgiLCJEZWNlbnRyYWxpc2VkUmVuZGVyZXIiLCJyYXdEb2N1bWVudCIsInVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSIsImZvcndhcmRlZFJlZiIsInRvRnJhbWUiLCJ1c2VSZWYiLCJkb2N1bWVudFJlZiIsImRvY3VtZW50IiwidXNlTWVtbyIsImhlaWdodCIsInNldEhlaWdodCIsInVzZVN0YXRlIiwidGVtcGxhdGVzIiwic2V0VGVtcGxhdGVzIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsInByaW50IiwiY3VycmVudCIsIm9uQ29ubmVjdGVkIiwidXNlQ2FsbGJhY2siLCJmcmFtZSIsInJlbmRlckRvY3VtZW50IiwiZGlzcGF0Y2giLCJ0eXBlIiwicGF5bG9hZCIsImZpZWxkIiwidXBkYXRlZERvY3VtZW50Iiwib2JmdXNjYXRlRG9jdW1lbnQiLCJuZXdEb2N1bWVudCIsInVzZUVmZmVjdCIsInV0aWxzIiwiaXNTaWduZWRXcmFwcGVkVjJEb2N1bWVudCIsIm1hcCIsInN0b3JlQWRkcmVzc2VzIiwiZ2V0SXNzdWVyQWRkcmVzcyIsIkFycmF5IiwiaXNBcnJheSIsInVuZGVmaW5lZCIsInNlbGVjdFRlbXBsYXRlIiwiJHRlbXBsYXRlIiwidXJsIiwiTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiIsIk11bHRpVGFicyIsInJlc2V0RGF0YSIsIm9uU2VsZWN0VGVtcGxhdGUiLCJzZWxlY3RlZFRlbXBsYXRlIiwic2V0U2VsZWN0ZWRUZW1wbGF0ZSIsImluZGV4IiwibGVuZ3RoIiwidGVtcGxhdGUiLCJpZHgiLCJNdXRpVGFic0NvbnRhaW5lciIsImNvbm5lY3QiLCJyZXNldENlcnRpZmljYXRlU3RhdGUiLCJEcmF3ZXIiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJ2aXNpYmxlIiwic2hvd0Fic0hlYWRlciIsInRvZ2dsZURyYXdlciIsInNldFN0YXRlIiwiY3JlYXRlVGFicyIsInRhYnMiLCJhY3RpdmVJZHgiLCJ0YWIiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZW5kZXJDb250ZW50IiwidG9nZ2xlIiwicmVuZGVyIiwicHVibGljUnVudGltZUNvbmZpZyIsImdldENvbmZpZyIsIlVSTCIsIkFQSV9NQUlOX1VSTCIsIkFQSV9ST1BTVEVOX1VSTCIsIkFQSV9SSU5LRUJZX1VSTCIsIkdBX1BST0RVQ1RJT05fSUQiLCJHQV9ERVZFTE9QTUVOVF9JRCIsIklTX01BSU5ORVQiLCJuZXR3b3JrIiwiTkVUV09SS19OQU1FIiwiR0FfSUQiLCJDQVBUQ0hBX0NMSUVOVF9LRVkiLCJnZXRBcGlVcmwiLCJuZXR3b3JrTmFtZSIsIkVNQUlMX0FQSV9VUkwiLCJTSEFSRV9MSU5LX0FQSV9VUkwiLCJTSEFSRV9MSU5LX1RUTCIsImxlZ2FjeVJlbmRlcmVyVXJsIiwiRU5WSVJPTk1FTlQiLCJjb250ZXh0IiwiREVGQVVMVF9TRU8iLCJ0aXRsZSIsInRpdGxlVGVtcGxhdGUiLCJkZXNjcmlwdGlvbiIsIm9wZW5HcmFwaCIsImltYWdlcyIsIndpZHRoIiwiYWx0IiwidHdpdHRlciIsImNhcmRUeXBlIiwibmFtZXNwYWNlIiwiZGVidWciLCJlcnJvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQSxNQUFNO0FBQUVBO0FBQUYsSUFBWUMsK0RBQVMsQ0FBQyx1QkFBRCxDQUEzQjtBQUNBLE1BQU07QUFBRUQsT0FBSyxFQUFFRTtBQUFULElBQXNCRCwrREFBUyxDQUFDLGlDQUFELENBQXJDOztBQVVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNFLFlBQVQsQ0FBc0JDLEtBQXRCLEVBQTZFO0FBQzNFLFNBQU9BLEtBQUssSUFBSUMseURBQVEsQ0FBQ0MsT0FBekI7QUFDRDs7QUFFTSxNQUFNQyxhQUFhLEdBQUcsQ0FBQztBQUFFQyxVQUFGO0FBQVlDLFFBQVo7QUFBb0JMO0FBQXBCLENBQUQsS0FBOEM7QUFDekUsTUFBSSxDQUFDSSxRQUFMLEVBQWUsTUFBTSxJQUFJRSxLQUFKLENBQVUsc0JBQVYsQ0FBTjtBQUNmLE1BQUksQ0FBQ0QsTUFBTCxFQUFhLE1BQU0sSUFBSUMsS0FBSixDQUFVLG9CQUFWLENBQU47QUFDYixNQUFJTixLQUFLLElBQUksT0FBT0EsS0FBUCxLQUFpQixRQUE5QixFQUF3QyxNQUFNLElBQUlNLEtBQUosQ0FBVSx3QkFBVixDQUFOO0FBQ3pDLENBSk07QUFNQSxNQUFNQyxjQUFjLEdBQUcsQ0FBQztBQUFFSCxVQUFGO0FBQVlDLFFBQVo7QUFBb0JHLE9BQXBCO0FBQTJCUjtBQUEzQixDQUFELEtBQzNCLGNBQWFJLFFBQVMsY0FBYUMsTUFBTyxZQUFXRyxLQUFNLFlBQVdSLEtBQU0sRUFEeEU7QUFHQSxNQUFNUyxjQUFjLEdBQUcsQ0FBQ0MsTUFBRCxFQUFzQ0MsS0FBdEMsS0FBNkQ7QUFDekZSLGVBQWEsQ0FBQ1EsS0FBRCxDQUFiOztBQUNBLE1BQUksS0FBSixFQUF1RSxFQUl0RTs7QUFDRGIsVUFBUSxDQUFDUyxjQUFjLENBQUNJLEtBQUQsQ0FBZixDQUFSO0FBQ0QsQ0FSTTtBQVVBLE1BQU1DLGtDQUFrQyxHQUFHLENBQUM7QUFDakRDLFFBRGlEO0FBRWpEQztBQUZpRCxDQUFELEtBTXRDO0FBQUE7O0FBQ1YsTUFBSU4sS0FBSyxHQUFHLEVBQVo7QUFDQSxNQUFJTyxVQUFVLEdBQUcsRUFBakI7QUFDQSxNQUFJQyxVQUFVLEdBQUcsSUFBakI7QUFFQSxRQUFNQyxTQUFTLEdBQUcsR0FBbEI7QUFDQSxRQUFNQyxLQUFLLHNEQUFHTCxNQUFNLENBQUNNLGdCQUFWLHlFQUE4Qk4sTUFBTSxDQUFDTyxhQUFyQyx5Q0FBc0RQLE1BQU0sQ0FBQ1EsYUFBN0QseUNBQThFUixNQUFNLENBQUNTLEVBQXJGLHVDQUEyRixFQUF0RyxDQU5VLENBTWdHOztBQUMxRyxRQUFNQSxFQUFFLDBCQUFHUixlQUFILGFBQUdBLGVBQUgsdUJBQUdBLGVBQWUsQ0FBRVEsRUFBcEIscUVBQTBCLEVBQWxDO0FBQ0EsUUFBTUMsSUFBSSw0QkFBR1QsZUFBSCxhQUFHQSxlQUFILHVCQUFHQSxlQUFlLENBQUVTLElBQXBCLHlFQUE0QixFQUF0QztBQUNBLFFBQU1DLFFBQVEsNEJBQUdWLGVBQUgsYUFBR0EsZUFBSCx1QkFBR0EsZUFBZSxDQUFFVSxRQUFwQix5RUFBZ0MsRUFBOUM7O0FBRUEsTUFBSXpCLFlBQVksQ0FBQ21CLEtBQUQsQ0FBaEIsRUFBeUI7QUFBQTs7QUFDdkIsVUFBTU8sY0FBNkIsR0FBR3hCLHlEQUFRLENBQUNDLE9BQVQsQ0FBaUJnQixLQUFqQixDQUF0QztBQUNBRixjQUFVLEdBQUdTLGNBQWMsQ0FBQ0gsRUFBNUI7QUFDQVAsY0FBVSxHQUFHZCx5REFBUSxDQUFDQyxPQUFULENBQWlCZ0IsS0FBakIsRUFBd0JLLElBQXJDO0FBQ0FmLFNBQUssR0FBSSxZQUFXVSxLQUFNLElBQUdELFNBQVUsa0JBQWlCSyxFQUFHLElBQUdMLFNBQVUsV0FBVU0sSUFBSyxJQUFHTixTQUFVLGdCQUFlTyxRQUFTLElBQUdQLFNBQVUsa0JBQWpJLGVBQ05GLFVBRE0scURBQ1EsRUFDZixJQUFHRSxTQUFVLGdCQUZOLHNCQUVxQlEsY0FBYyxDQUFDSCxFQUZwQyxtRUFFMEMsRUFBRyxHQUZyRDtBQUdELEdBUEQsTUFPTyxJQUFJVCxNQUFNLENBQUNhLGFBQVgsRUFBMEI7QUFBQTs7QUFDL0JYLGNBQVUsR0FBR0YsTUFBTSxDQUFDYSxhQUFQLENBQXFCQyxRQUFyQixJQUFpQyxFQUE5QztBQUNBbkIsU0FBSyxHQUFJLFlBQVdVLEtBQU0sSUFBR0QsU0FBVSxrQkFBaUJLLEVBQUcsSUFBR0wsU0FBVSxXQUFVTSxJQUFLLElBQUdOLFNBQVUsZ0JBQWVPLFFBQVMsSUFBR1AsU0FBVSxrQkFBakksZ0JBQ05GLFVBRE0sdURBQ1EsRUFDZixHQUZEO0FBR0QsR0FMTSxNQUtBO0FBQ0xQLFNBQUssR0FBRyw2RkFBUjtBQUNEOztBQUNEQyxnQkFBYyxDQUFDQyxNQUFELEVBQVM7QUFDckJOLFlBQVEsRUFBRSxxQkFEVztBQUVyQkMsVUFBTSxFQUFHLFlBQVdVLFVBQVcsRUFGVjtBQUdyQlAsU0FIcUI7QUFJckJvQixXQUFPLEVBQUU7QUFDUEMsb0JBQWMsRUFBRSxJQURUO0FBRVBDLGdCQUFVLEVBQUVaLEtBQUssSUFBSSxXQUZkO0FBR1BhLGdCQUFVLEVBQUVULEVBQUUsSUFBSSxXQUhYO0FBSVBVLGdCQUFVLEVBQUVULElBQUksSUFBSSxXQUpiO0FBS1BVLGdCQUFVLEVBQUVULFFBQVEsSUFBSSxXQUxqQjtBQU1QVSxnQkFBVSxFQUFFbkIsVUFBVSxJQUFJLFdBTm5CO0FBT1BvQixnQkFBVSxFQUFFbkIsVUFBVSxJQUFJO0FBUG5CO0FBSlksR0FBVCxDQUFkO0FBY0QsQ0E5Q007QUFnREEsU0FBU29CLG1CQUFULENBQ0xDLGNBREssRUFFTEMsTUFGSyxFQUdDO0FBQ04sUUFBTUMsV0FBOEUsR0FBR0MsMkVBQU8sQ0FBQ0gsY0FBRCxDQUE5RjtBQUVBLFFBQU1mLEVBQUUsR0FBR2lCLFdBQUgsYUFBR0EsV0FBSCx1QkFBR0EsV0FBVyxDQUFFakIsRUFBeEI7QUFDQSxRQUFNQyxJQUFJLEdBQUdnQixXQUFILGFBQUdBLFdBQUgsdUJBQUdBLFdBQVcsQ0FBRWhCLElBQTFCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHZSxXQUFILGFBQUdBLFdBQUgsdUJBQUdBLFdBQVcsQ0FBRWYsUUFBOUI7QUFDQSxRQUFNaUIsVUFBVSxHQUFHSCxNQUFNLENBQUNJLElBQVAsQ0FBWSxHQUFaLENBQW5CLENBTk0sQ0FRTjs7QUFDQUgsYUFBVyxDQUFDckMsT0FBWixDQUFvQnlDLE9BQXBCLENBQTZCOUIsTUFBRCxJQUF1QjtBQUFBOztBQUNqRCxVQUFNSyxLQUFLLHdEQUFHTCxNQUFNLENBQUNNLGdCQUFWLDJFQUE4Qk4sTUFBTSxDQUFDTyxhQUFyQyx5Q0FBc0RQLE1BQU0sQ0FBQ1EsYUFBN0QseUNBQThFUixNQUFNLENBQUNTLEVBQXJGLHlDQUEyRixFQUF0RyxDQURpRCxDQUN5RDs7QUFDMUcsUUFBSVAsVUFBVSxHQUFHRixNQUFNLENBQUNVLElBQXhCO0FBQ0EsUUFBSVAsVUFBVSxHQUFHLElBQWpCOztBQUVBLFFBQUlqQixZQUFZLENBQUNtQixLQUFELENBQWhCLEVBQXlCO0FBQ3ZCLFlBQU1PLGNBQTZCLEdBQUd4Qix5REFBUSxDQUFDQyxPQUFULENBQWlCZ0IsS0FBakIsQ0FBdEM7QUFDQUgsZ0JBQVUsR0FBR1UsY0FBYyxDQUFDRixJQUE1QjtBQUNBUCxnQkFBVSxHQUFHUyxjQUFjLENBQUNILEVBQTVCO0FBQ0QsS0FKRCxNQUlPLElBQUlULE1BQU0sQ0FBQ2EsYUFBWCxFQUEwQjtBQUMvQlgsZ0JBQVUsR0FBR0YsTUFBTSxDQUFDYSxhQUFQLENBQXFCQyxRQUFyQixJQUFpQyxFQUE5QztBQUNEOztBQUVEbEIsa0JBQWMsQ0FBQ0MsTUFBRCxFQUFTO0FBQ3JCTixjQUFRLEVBQUUsbUJBRFc7QUFFckJDLFlBQU0sRUFBRyxXQUFVVSxVQUFXLEVBRlQ7QUFHckJQLFdBQUssRUFBRWlDLFVBSGM7QUFJckJiLGFBQU8sRUFBRTtBQUNQQyxzQkFBYyxFQUFFLElBRFQ7QUFFUEMsa0JBQVUsRUFBRVosS0FBSyxJQUFJLFdBRmQ7QUFHUGEsa0JBQVUsRUFBRVQsRUFBRSxJQUFJLFdBSFg7QUFJUFUsa0JBQVUsRUFBRVQsSUFBSSxJQUFJLFdBSmI7QUFLUFUsa0JBQVUsRUFBRVQsUUFBUSxJQUFJLFdBTGpCO0FBTVBVLGtCQUFVLEVBQUVuQixVQUFVLElBQUksV0FObkI7QUFPUG9CLGtCQUFVLEVBQUVuQixVQUFVLElBQUksV0FQbkI7QUFRUDRCLGtCQUFVLEVBQUVIO0FBUkw7QUFKWSxLQUFULENBQWQ7QUFlRCxHQTVCRDtBQTZCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsSUQ7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBU0E7QUFDQSxNQUFNSSxlQUFlLEdBQUcsRUFBeEI7O0FBRUEsTUFBTUMscUJBQTBFLEdBQUcsQ0FBQztBQUNsRkMsYUFEa0Y7QUFFbEZDLDZCQUZrRjtBQUdsRkM7QUFIa0YsQ0FBRCxLQUk3RTtBQUNKLFFBQU1DLE9BQU8sR0FBR0Msb0RBQU0sRUFBdEI7QUFDQSxRQUFNQyxXQUFXLEdBQUdELG9EQUFNLENBQUNKLFdBQUQsQ0FBMUI7QUFDQSxRQUFNTSxRQUFRLEdBQUdDLHFEQUFPLENBQUMsTUFBTWQsMkVBQU8sQ0FBQ08sV0FBRCxDQUFkLEVBQTZCLENBQUNBLFdBQUQsQ0FBN0IsQ0FBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ1EsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JDLHNEQUFRLENBQUMsQ0FBRCxDQUFwQztBQUNBLFFBQU07QUFBQSxPQUFDQyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QkYsc0RBQVEsQ0FBa0MsRUFBbEMsQ0FBMUM7QUFFQUcsbUVBQW1CLENBQUNYLFlBQUQsRUFBZSxPQUFPO0FBQ3ZDWSxTQUFLLEdBQUc7QUFDTixVQUFJWCxPQUFPLENBQUNZLE9BQVosRUFBcUI7QUFDbkJaLGVBQU8sQ0FBQ1ksT0FBUixDQUFnQkQsZ0dBQUssRUFBckI7QUFDRDtBQUNGOztBQUxzQyxHQUFQLENBQWYsQ0FBbkI7QUFRQSxRQUFNRSxXQUFXLEdBQUdDLHlEQUFXLENBQzVCQyxLQUFELElBQVc7QUFDVGYsV0FBTyxDQUFDWSxPQUFSLEdBQWtCRyxLQUFsQjs7QUFDQSxRQUFJZixPQUFPLENBQUNZLE9BQVosRUFBcUI7QUFDbkJaLGFBQU8sQ0FBQ1ksT0FBUixDQUFnQkkseUdBQWMsQ0FBQztBQUFFYixnQkFBRjtBQUFZTjtBQUFaLE9BQUQsQ0FBOUI7QUFDRDtBQUNGLEdBTjRCLEVBTzdCLENBQUNNLFFBQUQsRUFBV04sV0FBWCxDQVA2QixDQUEvQjs7QUFVQSxRQUFNb0IsUUFBUSxHQUFJOUQsTUFBRCxJQUFnQztBQUMvQyxRQUFJQSxNQUFNLENBQUMrRCxJQUFQLEtBQWdCLGVBQXBCLEVBQXFDO0FBQ25DO0FBQ0FaLGVBQVMsQ0FBQ25ELE1BQU0sQ0FBQ2dFLE9BQVAsR0FBaUJ4QixlQUFsQixDQUFUO0FBQ0QsS0FIRCxNQUdPLElBQUl4QyxNQUFNLENBQUMrRCxJQUFQLEtBQWdCLFdBQXBCLEVBQWlDO0FBQ3RDLFlBQU1FLEtBQUssR0FBR2pFLE1BQU0sQ0FBQ2dFLE9BQXJCO0FBQ0EsWUFBTUUsZUFBZSxHQUFHQyxxRkFBaUIsQ0FBQ3BCLFdBQVcsQ0FBQ1UsT0FBYixFQUFzQlEsS0FBdEIsQ0FBekM7QUFDQXRCLGlDQUEyQixDQUFDdUIsZUFBRCxDQUEzQjtBQUNBLFlBQU1FLFdBQVcsR0FBR2pDLDJFQUFPLENBQUMrQixlQUFELENBQTNCOztBQUVBLFVBQUlyQixPQUFPLENBQUNZLE9BQVosRUFBcUI7QUFDbkJaLGVBQU8sQ0FBQ1ksT0FBUixDQUFnQkkseUdBQWMsQ0FBQztBQUFFYixrQkFBUSxFQUFFb0IsV0FBWjtBQUF5QjFCLHFCQUFXLEVBQUVLLFdBQVcsQ0FBQ1U7QUFBbEQsU0FBRCxDQUE5QjtBQUNEO0FBQ0YsS0FUTSxNQVNBLElBQUl6RCxNQUFNLENBQUMrRCxJQUFQLEtBQWdCLGtCQUFwQixFQUF3QztBQUM3Q1Qsa0JBQVksQ0FBQ3RELE1BQU0sQ0FBQ2dFLE9BQVIsQ0FBWjtBQUNEO0FBQ0YsR0FoQkQsQ0F6QkksQ0EyQ0o7QUFDQTs7O0FBQ0FLLHlEQUFTLENBQUMsTUFBTTtBQUNkdEIsZUFBVyxDQUFDVSxPQUFaLEdBQXNCZixXQUF0QjtBQUNELEdBRlEsRUFFTixDQUFDQSxXQUFELENBRk0sQ0FBVCxDQTdDSSxDQWlESjs7QUFDQTJCLHlEQUFTLENBQUMsTUFBTTtBQUFBOztBQUNkLFVBQU01RCxlQUFlLEdBQUcwQiwyRUFBTyxDQUFDTyxXQUFELENBQS9CO0FBQ0EsUUFBSTFDLE1BQUo7O0FBQ0EsUUFBSXNFLGlFQUFLLENBQUNDLHlCQUFOLENBQWdDN0IsV0FBaEMsQ0FBSixFQUFrRDtBQUNoRDFDLFlBQU0sR0FBR1MsZUFBZSxDQUFDWixPQUFoQixDQUF3QjJFLEdBQXhCLENBQTZCaEUsTUFBRCxJQUFZQSxNQUFNLENBQUNTLEVBQS9DLEVBQW1Eb0IsSUFBbkQsQ0FBd0QsR0FBeEQsQ0FBVDtBQUNELEtBRkQsTUFFTztBQUNMLFlBQU1vQyxjQUFjLEdBQUdILGlFQUFLLENBQUNJLGdCQUFOLENBQXVCaEMsV0FBdkIsQ0FBdkI7QUFDQTFDLFlBQU0sR0FBRzJFLEtBQUssQ0FBQ0MsT0FBTixDQUFjSCxjQUFkLElBQWdDQSxjQUFjLENBQUNwQyxJQUFmLENBQW9CLEdBQXBCLENBQWhDLEdBQTJEb0MsY0FBcEU7QUFDRDs7QUFDRHJFLHFFQUFjLENBQUNDLE1BQUQsRUFBUztBQUNyQk4sY0FBUSxFQUFFLG9CQURXO0FBRXJCQyxZQUZxQjtBQUdyQkcsV0FBSyx5QkFBRU0sZUFBRixhQUFFQSxlQUFGLHVCQUFFQSxlQUFlLENBQUVRLEVBQW5CLHFFQUF5QjREO0FBSFQsS0FBVCxDQUFkO0FBTUFwRSxtQkFBZSxDQUFDWixPQUFoQixDQUF3QnlDLE9BQXhCLENBQWlDOUIsTUFBRCxJQUF1QjtBQUNyREQsMkZBQWtDLENBQUM7QUFDakNDLGNBRGlDO0FBRWpDQztBQUZpQyxPQUFELENBQWxDO0FBSUQsS0FMRDtBQU1ELEdBckJRLEVBcUJOLENBQUNpQyxXQUFELENBckJNLENBQVQ7QUF1QkEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyw0REFBRDtBQUNFLGVBQVMsRUFBRVcsU0FEYjtBQUVFLHNCQUFnQixFQUFHbEQsS0FBRCxJQUFXO0FBQzNCLFlBQUkwQyxPQUFPLENBQUNZLE9BQVosRUFBcUI7QUFDbkJaLGlCQUFPLENBQUNZLE9BQVIsQ0FBZ0JxQix5R0FBYyxDQUFDM0UsS0FBRCxDQUE5QjtBQUNEO0FBQ0Y7QUFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBU0U7QUFBSSxlQUFTLEVBQUMseUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEYsRUFZRyxDQUFDMEMsT0FBTyxDQUFDWSxPQUFULGlCQUNDO0FBQUssZUFBUyxFQUFDLHVDQUFmO0FBQUEsOEJBQ0U7QUFBRyxpQkFBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFiSixlQWtCRSxxRUFBQyxpR0FBRDtBQUNFLGVBQVMsRUFBQyxtQkFEWjtBQUVFLFdBQUssRUFBRTtBQUFFUCxjQUFNLEVBQUcsR0FBRUEsTUFBTztBQUFwQixPQUZUO0FBR0UsWUFBTSxFQUFHLEdBQUUsT0FBT0YsUUFBUSxDQUFDK0IsU0FBaEIsS0FBOEIsUUFBOUIsR0FBeUMvQixRQUFRLENBQUMrQixTQUFULENBQW1CQyxHQUE1RCxHQUFrRUMsaUVBQTBCLEVBSHpHO0FBSUUsY0FBUSxFQUFFbkIsUUFKWjtBQUtFLGlCQUFXLEVBQUVKO0FBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFsQkY7QUFBQSxrQkFERjtBQTRCRCxDQXpHRCxDLENBMkdBO0FBQ0E7OztBQUNlakIsb0ZBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNySUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFPQSxNQUFNeUMsU0FBa0QsR0FBRyxDQUFDO0FBQUVDLFdBQUY7QUFBYTlCLFdBQWI7QUFBd0IrQjtBQUF4QixDQUFELEtBQWdEO0FBQ3pHLFFBQU07QUFBQSxPQUFDQyxnQkFBRDtBQUFBLE9BQW1CQztBQUFuQixNQUEwQ2xDLHNEQUFRLENBQUMsQ0FBRCxDQUF4RDtBQUNBLHNCQUNFO0FBQUssYUFBUyxFQUFDLGtDQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDRSxxRUFBQyxpREFBRDtBQUNFLFlBQUksRUFBRUMsU0FEUjtBQUVFLGlCQUFTLEVBQUVnQyxnQkFGYjtBQUdFLGNBQU0sRUFBRSxDQUFDRSxLQUFELEVBQVF0RSxFQUFSLEtBQWU7QUFDckJxRSw2QkFBbUIsQ0FBQ0MsS0FBRCxDQUFuQjtBQUNBSCwwQkFBZ0IsQ0FBQ25FLEVBQUQsQ0FBaEI7QUFDRDtBQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBV0U7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxnQkFBZjtBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxtREFBZjtBQUFBLG1DQUNFLHFFQUFDLGdEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQUEscUNBQ0U7QUFDRSx5QkFBUyxFQUFDLDREQURaO0FBRUUsa0JBQUUsRUFBQyxrQkFGTDtBQUdFLHVCQUFPLEVBQUUsTUFBTWtFLFNBQVMsRUFIMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQVlFO0FBQUsscUJBQVMsRUFBQyw2QkFBZjtBQUFBLG1DQUNFO0FBQUksZ0JBQUUsRUFBQyxvQkFBUDtBQUE0Qix1QkFBUyxFQUFDLHNCQUF0QztBQUFBLHdCQUNHOUIsU0FBUyxJQUFJQSxTQUFTLENBQUNtQyxNQUFWLEdBQW1CLENBQWhDLEdBQ0duQyxTQUFTLENBQUNtQixHQUFWLENBQWMsQ0FBQ2lCLFFBQUQsRUFBV0MsR0FBWCxrQkFDWjtBQUFjLHlCQUFTLEVBQUMsYUFBeEI7QUFBQSx1Q0FDRTtBQUNFLDJCQUFTLEVBQUcsaUdBQ1ZBLEdBQUcsS0FBS0wsZ0JBQVIsR0FBMkIsd0JBQTNCLEdBQXNELDZCQUN2RCxFQUhIO0FBSUUsaUNBQWFJLFFBQVEsQ0FBQ3hFLEVBSnhCO0FBS0UseUJBQU8sRUFBRSxNQUFNO0FBQ2JxRSx1Q0FBbUIsQ0FBQ0ksR0FBRCxDQUFuQjtBQUNBTixvQ0FBZ0IsQ0FBQ0ssUUFBUSxDQUFDeEUsRUFBVixDQUFoQjtBQUNELG1CQVJIO0FBQUEsNEJBVUd3RSxRQUFRLENBQUN0RjtBQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixpQkFBU3VGLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixDQURILEdBaUJHO0FBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcURELENBdkREOztBQXlETyxNQUFNQyxpQkFBaUIsR0FBR0MsMkRBQU8sQ0FBQyxJQUFELEVBQVE5QixRQUFELEtBQWU7QUFDNURxQixXQUFTLEVBQUUsTUFBTXJCLFFBQVEsQ0FBQytCLDJGQUFxQixFQUF0QjtBQURtQyxDQUFmLENBQVAsQ0FBUCxDQUU3QlgsU0FGNkIsQ0FBMUIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEVQO0FBZ0JPLE1BQU1ZLE1BQU4sU0FBcUJDLCtDQUFyQixDQUF5RDtBQUM5REMsYUFBVyxDQUFDQyxLQUFELEVBQXFCO0FBQzlCLFVBQU1BLEtBQU47QUFDQSxTQUFLQyxLQUFMLEdBQWE7QUFDWEMsYUFBTyxFQUFFLEtBREU7QUFFWEMsbUJBQWEsRUFBRTtBQUZKLEtBQWI7QUFJRDs7QUFFREMsY0FBWSxHQUFTO0FBQ25CLFNBQUtDLFFBQUwsQ0FBYztBQUFFSCxhQUFPLEVBQUUsQ0FBQyxLQUFLRCxLQUFMLENBQVdDO0FBQXZCLEtBQWQ7QUFDRDs7QUFFREksWUFBVSxDQUFDQyxJQUFELEVBQXlCO0FBQ2pDLFVBQU07QUFBRUM7QUFBRixRQUFnQixLQUFLUixLQUEzQjtBQUNBLFdBQU9PLElBQUksQ0FBQ2hDLEdBQUwsQ0FBUyxDQUFDa0MsR0FBRCxFQUFNbkIsS0FBTixrQkFDZDtBQUNFLGVBQVMsRUFBRyx5RUFDVmtCLFNBQVMsS0FBS2xCLEtBQWQsR0FBc0IsRUFBdEIsR0FBMkIsaUJBQzVCLEVBSEg7QUFLRSxhQUFPLEVBQUdvQixDQUFELElBQU87QUFDZEEsU0FBQyxDQUFDQyxjQUFGO0FBQ0EsYUFBS0MsYUFBTCxDQUFtQnRCLEtBQW5CLEVBQTBCbUIsR0FBRyxDQUFDekYsRUFBOUI7QUFDRCxPQVJIO0FBQUEsZ0JBVUd5RixHQUFHLENBQUN2RztBQVZQLE9BSU9vRixLQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESyxDQUFQO0FBY0Q7O0FBRURzQixlQUFhLENBQUN0QixLQUFELEVBQWdCdEUsRUFBaEIsRUFBa0M7QUFDN0MsU0FBS2dGLEtBQUwsQ0FBV2EsTUFBWCxDQUFrQnZCLEtBQWxCLEVBQXlCdEUsRUFBekI7QUFDQSxTQUFLb0YsWUFBTDtBQUNEOztBQUVEVSxRQUFNLEdBQWM7QUFDbEIsVUFBTTtBQUFFUDtBQUFGLFFBQVcsS0FBS1AsS0FBdEI7QUFDQSxVQUFNO0FBQUVFLGFBQUY7QUFBV0M7QUFBWCxRQUE2QixLQUFLRixLQUF4QztBQUVBLHdCQUNFO0FBQUEsOEJBQ0U7QUFDRSxpQkFBUyxFQUFHLHFDQUFvQ0UsYUFBYSxHQUFHLEVBQUgsR0FBUSxrQ0FBbUMsRUFEMUc7QUFFRSxlQUFPLEVBQUUsTUFBTSxLQUFLQyxZQUFMLEVBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsRUFPR0YsT0FBTyxnQkFDTjtBQUFPLGlCQUFTLEVBQUMsa0RBQWpCO0FBQUEsZ0NBQ0U7QUFDRSxtQkFBUyxFQUFDLDJCQURaO0FBRUUsaUJBQU8sRUFBR1EsQ0FBRCxJQUFPO0FBQ2RBLGFBQUMsQ0FBQ0MsY0FBRjtBQUNBLGlCQUFLUCxZQUFMO0FBQ0QsV0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQVVFO0FBQUssbUJBQVMsRUFBQyxnQkFBZjtBQUFBLG9CQUFpQyxLQUFLRSxVQUFMLENBQWdCQyxJQUFoQjtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURNLEdBYUosSUFwQk47QUFBQSxvQkFERjtBQXdCRDs7QUFoRTZELEM7Ozs7Ozs7Ozs7OztBQ2hCaEU7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFFQSxNQUFNO0FBQUVqSDtBQUFGLElBQVlDLCtEQUFTLENBQUMsUUFBRCxDQUEzQixDLENBQ0E7O0FBQ0EsTUFBTTtBQUFFd0gscUJBQW1CLEdBQUc7QUFBeEIsSUFBK0JDLGtEQUFTLEVBQTlDO0FBRU8sTUFBTUMsR0FBRyxHQUFHLHNCQUFaO0FBQ1AsTUFBTUMsWUFBWSxHQUFHLDBCQUFyQjtBQUNBLE1BQU1DLGVBQWUsR0FBRyxrQ0FBeEI7QUFDQSxNQUFNQyxlQUFlLEdBQUcsa0NBQXhCO0FBRUEsTUFBTUMsZ0JBQWdCLEdBQUcsZ0JBQXpCO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcsZ0JBQTFCO0FBRU8sTUFBTUMsVUFBVSxHQUFHUixtQkFBbUIsQ0FBQ1MsT0FBcEIsS0FBZ0MsU0FBbkQ7QUFDQSxNQUFNQyxZQUFZLFdBQUlGLFVBQVUsR0FBRyxXQUFILEdBQWlCUixtQkFBbUIsQ0FBQ1MsT0FBbkQsdUNBQStELFNBQWpGLEMsQ0FBNEY7O0FBRTVGLE1BQU1FLEtBQUssR0FBR0gsVUFBVSxHQUFHRixnQkFBSCxHQUFzQkMsaUJBQTlDO0FBQ0EsTUFBTUssa0JBQWtCLEdBQUcsMENBQTNCOztBQUVQLE1BQU1DLFNBQVMsR0FBSUMsV0FBRCxJQUFpQztBQUNqRCxNQUFJQSxXQUFXLEtBQUssV0FBcEIsRUFBaUMsT0FBT1gsWUFBUCxDQUFqQyxLQUNLLElBQUlXLFdBQVcsS0FBSyxTQUFwQixFQUErQixPQUFPVCxlQUFQO0FBQ3BDLFNBQU9ELGVBQVA7QUFDRCxDQUpEOztBQUtPLE1BQU1XLGFBQWEsR0FBSSxHQUFFRixTQUFTLENBQUNILFlBQUQsQ0FBZSxRQUFqRDtBQUNBLE1BQU1NLGtCQUFrQixHQUFJLEdBQUVILFNBQVMsQ0FBQ0gsWUFBRCxDQUFlLFVBQXREO0FBQ0EsTUFBTU8sY0FBYyxHQUFHLE9BQXZCO0FBRUEsTUFBTWhELHlCQUF5QixHQUFHK0IsbUJBQW1CLENBQUNrQixpQkFBcEIsSUFBeUMsOEJBQTNFO0FBQ0EsTUFBTUMsV0FBVyxHQUFHbkIsbUJBQW1CLENBQUNvQixPQUFwQixLQUFnQyxZQUFoQyxHQUErQyxZQUEvQyxHQUE4RCxhQUFsRjtBQUVBLE1BQU1DLFdBQVcsR0FBRztBQUN6QkMsT0FBSyxFQUFFLG1EQURrQjtBQUV6QkMsZUFBYSxFQUFHLGdCQUZTO0FBR3pCQyxhQUFXLEVBQ1QsZ0pBSnVCO0FBS3pCQyxXQUFTLEVBQUU7QUFDVDFFLFFBQUksRUFBRSxTQURHO0FBRVRpQixPQUFHLEVBQUVrQyxHQUZJO0FBR1RvQixTQUFLLEVBQUUsK0RBSEU7QUFJVEUsZUFBVyxFQUNULGdKQUxPO0FBTVRFLFVBQU0sRUFBRSxDQUNOO0FBQ0UxRCxTQUFHLEVBQUcsR0FBRWtDLEdBQUksOEJBRGQ7QUFFRXlCLFdBQUssRUFBRSxHQUZUO0FBR0V6RixZQUFNLEVBQUUsR0FIVjtBQUlFMEYsU0FBRyxFQUFFO0FBSlAsS0FETTtBQU5DLEdBTGM7QUFvQnpCQyxTQUFPLEVBQUU7QUFDUEMsWUFBUSxFQUFFO0FBREg7QUFwQmdCLENBQXBCO0FBeUJQdkosS0FBSyxDQUFFLFlBQVdtSSxZQUFhLEVBQTFCLENBQUw7QUFDQW5JLEtBQUssQ0FBRSx1QkFBc0JxSSxrQkFBbUIsRUFBM0MsQ0FBTDtBQUNBckksS0FBSyxDQUFFLGtCQUFpQndJLGFBQWMsRUFBakMsQ0FBTCxDOzs7Ozs7Ozs7Ozs7QUM1REE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBRUE7O0FBQ08sTUFBTXhJLEtBQUssR0FBSXdKLFNBQUQsSUFBaUNDLDRDQUFLLENBQUUsMkJBQTBCRCxTQUFVLEVBQXRDLENBQXBEO0FBQ0EsTUFBTUUsS0FBSyxHQUFJRixTQUFELElBQWlDQyw0Q0FBSyxDQUFFLDJCQUEwQkQsU0FBVSxFQUF0QyxDQUFwRDtBQUVBLE1BQU12SixTQUFTLEdBQUl1SixTQUFELEtBQThEO0FBQ3JGeEosT0FBSyxFQUFFQSxLQUFLLENBQUN3SixTQUFELENBRHlFO0FBRXJGRSxPQUFLLEVBQUVBLEtBQUssQ0FBQ0YsU0FBRDtBQUZ5RSxDQUE5RCxDQUFsQixDIiwiZmlsZSI6IjAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB2MiwgV3JhcHBlZERvY3VtZW50LCBnZXREYXRhIH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3Blbi1hdHRlc3RhdGlvblwiO1xuaW1wb3J0IHsgUmVnaXN0cnlFbnRyeSB9IGZyb20gXCJAZ292dGVjaHNnL29wZW5jZXJ0cy12ZXJpZnlcIjtcbmltcG9ydCByZWdpc3RyeSBmcm9tIFwiLi4vLi4vLi4vcHVibGljL3N0YXRpYy9yZWdpc3RyeS5qc29uXCI7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tIFwiLi4vLi4vdXRpbHMvbG9nZ2VyXCI7XG5jb25zdCB7IHRyYWNlIH0gPSBnZXRMb2dnZXIoXCJjb21wb25lbnRzOkFuYWx5dGljczpcIik7XG5jb25zdCB7IHRyYWNlOiB0cmFjZURldiB9ID0gZ2V0TG9nZ2VyKFwiY29tcG9uZW50czpBbmFseXRpY3MoSW5hY3RpdmUpOlwiKTtcblxuaW50ZXJmYWNlIEV2ZW50IHtcbiAgY2F0ZWdvcnk6IHN0cmluZztcbiAgYWN0aW9uOiBzdHJpbmc7XG4gIHZhbHVlPzogc3RyaW5nIHwgbnVtYmVyO1xuICBsYWJlbD86IHN0cmluZztcbiAgb3B0aW9ucz86IFVuaXZlcnNhbEFuYWx5dGljcy5GaWVsZHNPYmplY3Q7XG59XG5cbi8qXG4gKiBUaGlzIGZ1bmN0aW9uIGNoZWNrcyBpZiBhbiBhZGRyZXNzIGlzIGluIHJlZ2lzdHJ5Lmpzb24gdG8gcHJvdmlkZSBwcm9wZXJ0eSBhY2Nlc3MuXG4gKi9cbmZ1bmN0aW9uIGlzSW5SZWdpc3RyeSh2YWx1ZTogc3RyaW5nKTogdmFsdWUgaXMga2V5b2YgdHlwZW9mIHJlZ2lzdHJ5Lmlzc3VlcnMge1xuICByZXR1cm4gdmFsdWUgaW4gcmVnaXN0cnkuaXNzdWVycztcbn1cblxuZXhwb3J0IGNvbnN0IHZhbGlkYXRlRXZlbnQgPSAoeyBjYXRlZ29yeSwgYWN0aW9uLCB2YWx1ZSB9OiBFdmVudCk6IHZvaWQgPT4ge1xuICBpZiAoIWNhdGVnb3J5KSB0aHJvdyBuZXcgRXJyb3IoXCJDYXRlZ29yeSBpcyByZXF1aXJlZFwiKTtcbiAgaWYgKCFhY3Rpb24pIHRocm93IG5ldyBFcnJvcihcIkFjdGlvbiBpcyByZXF1aXJlZFwiKTtcbiAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSAhPT0gXCJudW1iZXJcIikgdGhyb3cgbmV3IEVycm9yKFwiVmFsdWUgbXVzdCBiZSBhIG51bWJlclwiKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzdHJpbmdpZnlFdmVudCA9ICh7IGNhdGVnb3J5LCBhY3Rpb24sIGxhYmVsLCB2YWx1ZSB9OiBFdmVudCk6IHN0cmluZyA9PlxuICBgQ2F0ZWdvcnkqOiAke2NhdGVnb3J5fSwgQWN0aW9uKjogJHthY3Rpb259LCBMYWJlbDogJHtsYWJlbH0sIFZhbHVlOiAke3ZhbHVlfWA7XG5cbmV4cG9ydCBjb25zdCBhbmFseXRpY3NFdmVudCA9ICh3aW5kb3c6IFBhcnRpYWw8V2luZG93PiB8IHVuZGVmaW5lZCwgZXZlbnQ6IEV2ZW50KTogdm9pZCA9PiB7XG4gIHZhbGlkYXRlRXZlbnQoZXZlbnQpO1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2Ygd2luZG93LmdhICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgY29uc3QgeyBjYXRlZ29yeSwgYWN0aW9uLCBsYWJlbCwgdmFsdWUsIG9wdGlvbnMgPSB1bmRlZmluZWQgfSA9IGV2ZW50O1xuICAgIHRyYWNlKHN0cmluZ2lmeUV2ZW50KGV2ZW50KSk7XG4gICAgcmV0dXJuIHdpbmRvdy5nYShcInNlbmRcIiwgXCJldmVudFwiLCBjYXRlZ29yeSwgYWN0aW9uLCBsYWJlbCwgdmFsdWUsIG9wdGlvbnMpO1xuICB9XG4gIHRyYWNlRGV2KHN0cmluZ2lmeUV2ZW50KGV2ZW50KSk7XG59O1xuXG5leHBvcnQgY29uc3Qgc2VuZEV2ZW50Q2VydGlmaWNhdGVWaWV3ZWREZXRhaWxlZCA9ICh7XG4gIGlzc3VlcixcbiAgY2VydGlmaWNhdGVEYXRhLFxufToge1xuICBpc3N1ZXI6IHYyLklzc3VlcjtcbiAgY2VydGlmaWNhdGVEYXRhOiB7IGlkPzogc3RyaW5nOyBuYW1lPzogc3RyaW5nOyBpc3N1ZWRPbj86IHN0cmluZyB9O1xufSk6IHZvaWQgPT4ge1xuICBsZXQgbGFiZWwgPSBcIlwiO1xuICBsZXQgaXNzdWVyTmFtZSA9IFwiXCI7XG4gIGxldCByZWdpc3RyeUlkID0gbnVsbDtcblxuICBjb25zdCBzZXBhcmF0b3IgPSBcIjtcIjtcbiAgY29uc3Qgc3RvcmUgPSBpc3N1ZXIuY2VydGlmaWNhdGVTdG9yZSA/PyBpc3N1ZXIuZG9jdW1lbnRTdG9yZSA/PyBpc3N1ZXIudG9rZW5SZWdpc3RyeSA/PyBpc3N1ZXIuaWQgPz8gXCJcIjsgLy8gdXNlIGlkIGZvciBESURcbiAgY29uc3QgaWQgPSBjZXJ0aWZpY2F0ZURhdGE/LmlkID8/IFwiXCI7XG4gIGNvbnN0IG5hbWUgPSBjZXJ0aWZpY2F0ZURhdGE/Lm5hbWUgPz8gXCJcIjtcbiAgY29uc3QgaXNzdWVkT24gPSBjZXJ0aWZpY2F0ZURhdGE/Lmlzc3VlZE9uID8/IFwiXCI7XG5cbiAgaWYgKGlzSW5SZWdpc3RyeShzdG9yZSkpIHtcbiAgICBjb25zdCByZWdpc3RyeUlzc3VlcjogUmVnaXN0cnlFbnRyeSA9IHJlZ2lzdHJ5Lmlzc3VlcnNbc3RvcmVdO1xuICAgIHJlZ2lzdHJ5SWQgPSByZWdpc3RyeUlzc3Vlci5pZDtcbiAgICBpc3N1ZXJOYW1lID0gcmVnaXN0cnkuaXNzdWVyc1tzdG9yZV0ubmFtZTtcbiAgICBsYWJlbCA9IGBcInN0b3JlXCI6XCIke3N0b3JlfVwiJHtzZXBhcmF0b3J9XCJkb2N1bWVudF9pZFwiOlwiJHtpZH1cIiR7c2VwYXJhdG9yfVwibmFtZVwiOlwiJHtuYW1lfVwiJHtzZXBhcmF0b3J9XCJpc3N1ZWRfb25cIjpcIiR7aXNzdWVkT259XCIke3NlcGFyYXRvcn1cImlzc3Vlcl9uYW1lXCI6XCIke1xuICAgICAgaXNzdWVyTmFtZSA/PyBcIlwiXG4gICAgfVwiJHtzZXBhcmF0b3J9XCJpc3N1ZXJfaWRcIjpcIiR7cmVnaXN0cnlJc3N1ZXIuaWQgPz8gXCJcIn1cImA7XG4gIH0gZWxzZSBpZiAoaXNzdWVyLmlkZW50aXR5UHJvb2YpIHtcbiAgICBpc3N1ZXJOYW1lID0gaXNzdWVyLmlkZW50aXR5UHJvb2YubG9jYXRpb24gfHwgXCJcIjtcbiAgICBsYWJlbCA9IGBcInN0b3JlXCI6XCIke3N0b3JlfVwiJHtzZXBhcmF0b3J9XCJkb2N1bWVudF9pZFwiOlwiJHtpZH1cIiR7c2VwYXJhdG9yfVwibmFtZVwiOlwiJHtuYW1lfVwiJHtzZXBhcmF0b3J9XCJpc3N1ZWRfb25cIjpcIiR7aXNzdWVkT259XCIke3NlcGFyYXRvcn1cImlzc3Vlcl9uYW1lXCI6XCIke1xuICAgICAgaXNzdWVyTmFtZSA/PyBcIlwiXG4gICAgfVwiYDtcbiAgfSBlbHNlIHtcbiAgICBsYWJlbCA9IFwiU29tZXRoaW5nIHdlbnQgd3JvbmcsIHBsZWFzZSBjaGVjayB0aGUgYW5hbHl0aWNzIGNvZGUgb2Ygc2VuZEV2ZW50Q2VydGlmaWNhdGVWaWV3ZWREZXRhaWxlZFwiO1xuICB9XG4gIGFuYWx5dGljc0V2ZW50KHdpbmRvdywge1xuICAgIGNhdGVnb3J5OiBcIkNFUlRJRklDQVRFX0RFVEFJTFNcIixcbiAgICBhY3Rpb246IGBWSUVXRUQgLSAke2lzc3Vlck5hbWV9YCxcbiAgICBsYWJlbCxcbiAgICBvcHRpb25zOiB7XG4gICAgICBub25JbnRlcmFjdGlvbjogdHJ1ZSxcbiAgICAgIGRpbWVuc2lvbjE6IHN0b3JlIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICBkaW1lbnNpb24yOiBpZCB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgZGltZW5zaW9uMzogbmFtZSB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgZGltZW5zaW9uNDogaXNzdWVkT24gfHwgXCIobm90IHNldClcIixcbiAgICAgIGRpbWVuc2lvbjU6IGlzc3Vlck5hbWUgfHwgXCIobm90IHNldClcIixcbiAgICAgIGRpbWVuc2lvbjY6IHJlZ2lzdHJ5SWQgfHwgXCIobm90IHNldClcIixcbiAgICB9LFxuICB9KTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiB0cmlnZ2VyRXJyb3JMb2dnaW5nKFxuICByYXdDZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PixcbiAgZXJyb3JzOiBzdHJpbmdbXVxuKTogdm9pZCB7XG4gIGNvbnN0IGNlcnRpZmljYXRlOiB2Mi5PcGVuQXR0ZXN0YXRpb25Eb2N1bWVudCAmIHsgbmFtZT86IHN0cmluZzsgaXNzdWVkT24/OiBzdHJpbmcgfSA9IGdldERhdGEocmF3Q2VydGlmaWNhdGUpO1xuXG4gIGNvbnN0IGlkID0gY2VydGlmaWNhdGU/LmlkO1xuICBjb25zdCBuYW1lID0gY2VydGlmaWNhdGU/Lm5hbWU7XG4gIGNvbnN0IGlzc3VlZE9uID0gY2VydGlmaWNhdGU/Lmlzc3VlZE9uO1xuICBjb25zdCBlcnJvcnNMaXN0ID0gZXJyb3JzLmpvaW4oXCIsXCIpO1xuXG4gIC8vIElmIHRoZXJlIGFyZSBtdWx0aXBsZSBpc3N1ZXJzIGluIGEgY2VydGlmaWNhdGUsIHdlIHNlbmQgbXVsdGlwbGUgZXZlbnRzIVxuICBjZXJ0aWZpY2F0ZS5pc3N1ZXJzLmZvckVhY2goKGlzc3VlcjogdjIuSXNzdWVyKSA9PiB7XG4gICAgY29uc3Qgc3RvcmUgPSBpc3N1ZXIuY2VydGlmaWNhdGVTdG9yZSA/PyBpc3N1ZXIuZG9jdW1lbnRTdG9yZSA/PyBpc3N1ZXIudG9rZW5SZWdpc3RyeSA/PyBpc3N1ZXIuaWQgPz8gXCJcIjsgLy8gdXNlIGlkIGZvciBESURcbiAgICBsZXQgaXNzdWVyTmFtZSA9IGlzc3Vlci5uYW1lO1xuICAgIGxldCByZWdpc3RyeUlkID0gbnVsbDtcblxuICAgIGlmIChpc0luUmVnaXN0cnkoc3RvcmUpKSB7XG4gICAgICBjb25zdCByZWdpc3RyeUlzc3VlcjogUmVnaXN0cnlFbnRyeSA9IHJlZ2lzdHJ5Lmlzc3VlcnNbc3RvcmVdO1xuICAgICAgaXNzdWVyTmFtZSA9IHJlZ2lzdHJ5SXNzdWVyLm5hbWU7XG4gICAgICByZWdpc3RyeUlkID0gcmVnaXN0cnlJc3N1ZXIuaWQ7XG4gICAgfSBlbHNlIGlmIChpc3N1ZXIuaWRlbnRpdHlQcm9vZikge1xuICAgICAgaXNzdWVyTmFtZSA9IGlzc3Vlci5pZGVudGl0eVByb29mLmxvY2F0aW9uIHx8IFwiXCI7XG4gICAgfVxuXG4gICAgYW5hbHl0aWNzRXZlbnQod2luZG93LCB7XG4gICAgICBjYXRlZ29yeTogXCJDRVJUSUZJQ0FURV9FUlJPUlwiLFxuICAgICAgYWN0aW9uOiBgRVJST1IgLSAke2lzc3Vlck5hbWV9YCxcbiAgICAgIGxhYmVsOiBlcnJvcnNMaXN0LFxuICAgICAgb3B0aW9uczoge1xuICAgICAgICBub25JbnRlcmFjdGlvbjogdHJ1ZSxcbiAgICAgICAgZGltZW5zaW9uMTogc3RvcmUgfHwgXCIobm90IHNldClcIixcbiAgICAgICAgZGltZW5zaW9uMjogaWQgfHwgXCIobm90IHNldClcIixcbiAgICAgICAgZGltZW5zaW9uMzogbmFtZSB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgICBkaW1lbnNpb240OiBpc3N1ZWRPbiB8fCBcIihub3Qgc2V0KVwiLFxuICAgICAgICBkaW1lbnNpb241OiBpc3N1ZXJOYW1lIHx8IFwiKG5vdCBzZXQpXCIsXG4gICAgICAgIGRpbWVuc2lvbjY6IHJlZ2lzdHJ5SWQgfHwgXCIobm90IHNldClcIixcbiAgICAgICAgZGltZW5zaW9uNzogZXJyb3JzTGlzdCxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xufVxuIiwiaW1wb3J0IHtcbiAgRnJhbWVBY3Rpb25zLFxuICBGcmFtZUNvbm5lY3RvcixcbiAgSG9zdEFjdGlvbnMsXG4gIHJlbmRlckRvY3VtZW50LFxuICBzZWxlY3RUZW1wbGF0ZSxcbiAgcHJpbnQsXG59IGZyb20gXCJAZ292dGVjaHNnL2RlY2VudHJhbGl6ZWQtcmVuZGVyZXItcmVhY3QtY29tcG9uZW50c1wiO1xuaW1wb3J0IHsgZ2V0RGF0YSwgb2JmdXNjYXRlRG9jdW1lbnQsIHV0aWxzLCB2MiwgV3JhcHBlZERvY3VtZW50IH0gZnJvbSBcIkBnb3Z0ZWNoc2cvb3Blbi1hdHRlc3RhdGlvblwiO1xuaW1wb3J0IFJlYWN0LCB7IFJlZiwgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlSW1wZXJhdGl2ZUhhbmRsZSwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiB9IGZyb20gXCIuLi8uLi9jb25maWdcIjtcbmltcG9ydCB7IGFuYWx5dGljc0V2ZW50LCBzZW5kRXZlbnRDZXJ0aWZpY2F0ZVZpZXdlZERldGFpbGVkIH0gZnJvbSBcIi4uL0FuYWx5dGljc1wiO1xuaW1wb3J0IHsgTXV0aVRhYnNDb250YWluZXIgfSBmcm9tIFwiLi4vTXVsdGlUYWJzXCI7XG5cbmludGVyZmFjZSBEZWNlbnRyYWxpc2VkUmVuZGVyZXJQcm9wcyB7XG4gIHJhd0RvY3VtZW50OiBXcmFwcGVkRG9jdW1lbnQ8djIuT3BlbkF0dGVzdGF0aW9uRG9jdW1lbnQ+O1xuICB1cGRhdGVPYmZ1c2NhdGVkQ2VydGlmaWNhdGU6IChjZXJ0aWZpY2F0ZTogV3JhcHBlZERvY3VtZW50PHYyLk9wZW5BdHRlc3RhdGlvbkRvY3VtZW50PikgPT4gdm9pZDtcbiAgZm9yd2FyZGVkUmVmOiBSZWY8eyBwcmludDogKCkgPT4gdm9pZCB9IHwgdW5kZWZpbmVkPjtcbn1cblxudHlwZSBEaXNwYXRjaCA9IChhY3Rpb246IEhvc3RBY3Rpb25zKSA9PiB2b2lkO1xuLy8gZ2l2aW5nIHNjcm9sbGJhciBhIGRlZmF1bHQgd2lkdGggYXMgdGhlcmUgYXJlIG5vIHBlcmZlY3Qgd2F5cyB0byBnZXQgaXRcbmNvbnN0IFNDUk9MTEJBUl9XSURUSCA9IDIwO1xuXG5jb25zdCBEZWNlbnRyYWxpc2VkUmVuZGVyZXI6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PERlY2VudHJhbGlzZWRSZW5kZXJlclByb3BzPiA9ICh7XG4gIHJhd0RvY3VtZW50LFxuICB1cGRhdGVPYmZ1c2NhdGVkQ2VydGlmaWNhdGUsXG4gIGZvcndhcmRlZFJlZixcbn0pID0+IHtcbiAgY29uc3QgdG9GcmFtZSA9IHVzZVJlZjxEaXNwYXRjaD4oKTtcbiAgY29uc3QgZG9jdW1lbnRSZWYgPSB1c2VSZWYocmF3RG9jdW1lbnQpO1xuICBjb25zdCBkb2N1bWVudCA9IHVzZU1lbW8oKCkgPT4gZ2V0RGF0YShyYXdEb2N1bWVudCksIFtyYXdEb2N1bWVudF0pO1xuICBjb25zdCBbaGVpZ2h0LCBzZXRIZWlnaHRdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFt0ZW1wbGF0ZXMsIHNldFRlbXBsYXRlc10gPSB1c2VTdGF0ZTx7IGlkOiBzdHJpbmc7IGxhYmVsOiBzdHJpbmcgfVtdPihbXSk7XG5cbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShmb3J3YXJkZWRSZWYsICgpID0+ICh7XG4gICAgcHJpbnQoKSB7XG4gICAgICBpZiAodG9GcmFtZS5jdXJyZW50KSB7XG4gICAgICAgIHRvRnJhbWUuY3VycmVudChwcmludCgpKTtcbiAgICAgIH1cbiAgICB9LFxuICB9KSk7XG5cbiAgY29uc3Qgb25Db25uZWN0ZWQgPSB1c2VDYWxsYmFjayhcbiAgICAoZnJhbWUpID0+IHtcbiAgICAgIHRvRnJhbWUuY3VycmVudCA9IGZyYW1lO1xuICAgICAgaWYgKHRvRnJhbWUuY3VycmVudCkge1xuICAgICAgICB0b0ZyYW1lLmN1cnJlbnQocmVuZGVyRG9jdW1lbnQoeyBkb2N1bWVudCwgcmF3RG9jdW1lbnQgfSkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW2RvY3VtZW50LCByYXdEb2N1bWVudF1cbiAgKTtcblxuICBjb25zdCBkaXNwYXRjaCA9IChhY3Rpb246IEZyYW1lQWN0aW9ucyk6IHZvaWQgPT4ge1xuICAgIGlmIChhY3Rpb24udHlwZSA9PT0gXCJVUERBVEVfSEVJR0hUXCIpIHtcbiAgICAgIC8vIGFkZGluZyBTQ1JPTExCQVJfV0lEVEggaW4gY2FzZSB0aGUgZnJhbWUgY29udGVudCBvdmVyZmxvdyBob3Jpem9udGFsbHksIHdoaWNoIHdpbGwgY2F1c2Ugc2Nyb2xsYmFycyB0byBhcHBlYXJcbiAgICAgIHNldEhlaWdodChhY3Rpb24ucGF5bG9hZCArIFNDUk9MTEJBUl9XSURUSCk7XG4gICAgfSBlbHNlIGlmIChhY3Rpb24udHlwZSA9PT0gXCJPQkZVU0NBVEVcIikge1xuICAgICAgY29uc3QgZmllbGQgPSBhY3Rpb24ucGF5bG9hZDtcbiAgICAgIGNvbnN0IHVwZGF0ZWREb2N1bWVudCA9IG9iZnVzY2F0ZURvY3VtZW50KGRvY3VtZW50UmVmLmN1cnJlbnQsIGZpZWxkKTtcbiAgICAgIHVwZGF0ZU9iZnVzY2F0ZWRDZXJ0aWZpY2F0ZSh1cGRhdGVkRG9jdW1lbnQpO1xuICAgICAgY29uc3QgbmV3RG9jdW1lbnQgPSBnZXREYXRhKHVwZGF0ZWREb2N1bWVudCk7XG5cbiAgICAgIGlmICh0b0ZyYW1lLmN1cnJlbnQpIHtcbiAgICAgICAgdG9GcmFtZS5jdXJyZW50KHJlbmRlckRvY3VtZW50KHsgZG9jdW1lbnQ6IG5ld0RvY3VtZW50LCByYXdEb2N1bWVudDogZG9jdW1lbnRSZWYuY3VycmVudCB9KSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChhY3Rpb24udHlwZSA9PT0gXCJVUERBVEVfVEVNUExBVEVTXCIpIHtcbiAgICAgIHNldFRlbXBsYXRlcyhhY3Rpb24ucGF5bG9hZCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIGVmZmVjdHNcbiAgLy8gdXBkYXRlIGRvY3VtZW50IGFmdGVyIGV2ZXJ5IGNoYW5nZXNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkb2N1bWVudFJlZi5jdXJyZW50ID0gcmF3RG9jdW1lbnQ7XG4gIH0sIFtyYXdEb2N1bWVudF0pO1xuXG4gIC8vIHNlbmQgYW5hbHl0aWNzIG9uIHdoaWNoIGRvY3VtZW50IGhhcyBiZWVuIGRpc3BsYXllZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNlcnRpZmljYXRlRGF0YSA9IGdldERhdGEocmF3RG9jdW1lbnQpO1xuICAgIGxldCBhY3Rpb246IHN0cmluZztcbiAgICBpZiAodXRpbHMuaXNTaWduZWRXcmFwcGVkVjJEb2N1bWVudChyYXdEb2N1bWVudCkpIHtcbiAgICAgIGFjdGlvbiA9IGNlcnRpZmljYXRlRGF0YS5pc3N1ZXJzLm1hcCgoaXNzdWVyKSA9PiBpc3N1ZXIuaWQpLmpvaW4oXCIsXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBzdG9yZUFkZHJlc3NlcyA9IHV0aWxzLmdldElzc3VlckFkZHJlc3MocmF3RG9jdW1lbnQpO1xuICAgICAgYWN0aW9uID0gQXJyYXkuaXNBcnJheShzdG9yZUFkZHJlc3NlcykgPyBzdG9yZUFkZHJlc3Nlcy5qb2luKFwiLFwiKSA6IHN0b3JlQWRkcmVzc2VzO1xuICAgIH1cbiAgICBhbmFseXRpY3NFdmVudCh3aW5kb3csIHtcbiAgICAgIGNhdGVnb3J5OiBcIkNFUlRJRklDQVRFX1ZJRVdFRFwiLFxuICAgICAgYWN0aW9uLFxuICAgICAgbGFiZWw6IGNlcnRpZmljYXRlRGF0YT8uaWQgPz8gdW5kZWZpbmVkLFxuICAgIH0pO1xuXG4gICAgY2VydGlmaWNhdGVEYXRhLmlzc3VlcnMuZm9yRWFjaCgoaXNzdWVyOiB2Mi5Jc3N1ZXIpID0+IHtcbiAgICAgIHNlbmRFdmVudENlcnRpZmljYXRlVmlld2VkRGV0YWlsZWQoe1xuICAgICAgICBpc3N1ZXIsXG4gICAgICAgIGNlcnRpZmljYXRlRGF0YSxcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LCBbcmF3RG9jdW1lbnRdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8TXV0aVRhYnNDb250YWluZXJcbiAgICAgICAgdGVtcGxhdGVzPXt0ZW1wbGF0ZXN9XG4gICAgICAgIG9uU2VsZWN0VGVtcGxhdGU9eyhsYWJlbCkgPT4ge1xuICAgICAgICAgIGlmICh0b0ZyYW1lLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHRvRnJhbWUuY3VycmVudChzZWxlY3RUZW1wbGF0ZShsYWJlbCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwicHJpbnQtb25seSBleGFjdC1wcmludCB0ZXh0LWNlbnRlciBweS04XCI+XG4gICAgICAgIElmIHlvdSB3YW50IHRvIHByaW50IHRoZSBjZXJ0aWZpY2F0ZSwgcGxlYXNlIGNsaWNrIG9uIHRoZSBoaWdobGlnaHRlZCBidXR0b24gYWJvdmUuXG4gICAgICA8L2gyPlxuICAgICAgeyF0b0ZyYW1lLmN1cnJlbnQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciB0ZXh0LWJsdWUgdGV4dC1jZW50ZXIgcHktMTZcIj5cbiAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYXMgZmEtc3Bpbm5lciBmYS1wdWxzZSBmYS0zeFwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS0zXCI+TG9hZGluZyBSZW5kZXJlci4uLjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICA8RnJhbWVDb25uZWN0b3JcbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LWZ1bGxcIlxuICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IGAke2hlaWdodH1weGAgfX1cbiAgICAgICAgc291cmNlPXtgJHt0eXBlb2YgZG9jdW1lbnQuJHRlbXBsYXRlID09PSBcIm9iamVjdFwiID8gZG9jdW1lbnQuJHRlbXBsYXRlLnVybCA6IExFR0FDWV9PUEVOQ0VSVFNfUkVOREVSRVJ9YH1cbiAgICAgICAgZGlzcGF0Y2g9e2Rpc3BhdGNofVxuICAgICAgICBvbkNvbm5lY3RlZD17b25Db25uZWN0ZWR9XG4gICAgICAvPlxuICAgIDwvPlxuICApO1xufTtcblxuLy8gbG9va3MgbmVlZGVkIGZvciBkeW5hbWljIGltcG9ydFxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1kZWZhdWx0LWV4cG9ydFxuZXhwb3J0IGRlZmF1bHQgRGVjZW50cmFsaXNlZFJlbmRlcmVyO1xuIiwiaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyByZXNldENlcnRpZmljYXRlU3RhdGUgfSBmcm9tIFwiLi4vcmVkdWNlcnMvY2VydGlmaWNhdGUuYWN0aW9uc1wiO1xuaW1wb3J0IHsgRHJhd2VyIH0gZnJvbSBcIi4vVUkvRHJhd2VyXCI7XG5cbmludGVyZmFjZSBNdWx0aVRhYnNQcm9wcyB7XG4gIHJlc2V0RGF0YTogKCkgPT4gdm9pZDtcbiAgdGVtcGxhdGVzOiB7IGlkOiBzdHJpbmc7IGxhYmVsOiBzdHJpbmcgfVtdO1xuICBvblNlbGVjdFRlbXBsYXRlOiAobGFiZWw6IHN0cmluZykgPT4gdm9pZDtcbn1cbmNvbnN0IE11bHRpVGFiczogUmVhY3QuRnVuY3Rpb25Db21wb25lbnQ8TXVsdGlUYWJzUHJvcHM+ID0gKHsgcmVzZXREYXRhLCB0ZW1wbGF0ZXMsIG9uU2VsZWN0VGVtcGxhdGUgfSkgPT4ge1xuICBjb25zdCBbc2VsZWN0ZWRUZW1wbGF0ZSwgc2V0U2VsZWN0ZWRUZW1wbGF0ZV0gPSB1c2VTdGF0ZSgwKTtcbiAgcmV0dXJuIChcbiAgICA8bmF2IGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHB5LTQgYm9yZGVyLWItNCBtYi00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2NrIG1kOmhpZGRlblwiPlxuICAgICAgICA8RHJhd2VyXG4gICAgICAgICAgdGFicz17dGVtcGxhdGVzfVxuICAgICAgICAgIGFjdGl2ZUlkeD17c2VsZWN0ZWRUZW1wbGF0ZX1cbiAgICAgICAgICB0b2dnbGU9eyhpbmRleCwgaWQpID0+IHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkVGVtcGxhdGUoaW5kZXgpO1xuICAgICAgICAgICAgb25TZWxlY3RUZW1wbGF0ZShpZCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2tcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtbC1hdXRvIG1iLTE2IGxnOm1iLTAgbGc6dy1hdXRvIGxnOm9yZGVyLTJcIj5cbiAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnV0dG9uIGJvcmRlciBib3JkZXItbmF2eSB0ZXh0LW5hdnkgYmctd2hpdGUgaG92ZXI6YmctbmF2eVwiXG4gICAgICAgICAgICAgICAgICBpZD1cImJ0bi12aWV3LWFub3RoZXJcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVzZXREYXRhKCl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgVmlldyBhbm90aGVyXG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGxnOmZsZXgtMSBsZzpvcmRlci0xXCI+XG4gICAgICAgICAgICAgIDx1bCBpZD1cInRlbXBsYXRlLXRhYnMtbGlzdFwiIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIC1teC00XCI+XG4gICAgICAgICAgICAgICAge3RlbXBsYXRlcyAmJiB0ZW1wbGF0ZXMubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgPyB0ZW1wbGF0ZXMubWFwKCh0ZW1wbGF0ZSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aWR4fSBjbGFzc05hbWU9XCJ3LWF1dG8gbXItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IGJvcmRlci1iLTQgdXBwZXJjYXNlIHRleHQtYmxhY2sgaG92ZXI6dGV4dC1ibGFjayBob3Zlcjp0ZXh0LW9wYWNpdHktNzUgaG92ZXI6Ym9yZGVyLWJsYWNrICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWR4ID09PSBzZWxlY3RlZFRlbXBsYXRlID8gXCJmb250LXNlbWkgYm9yZGVyLWJsYWNrXCIgOiBcImJvcmRlci1ncmV5IHRleHQtb3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD17dGVtcGxhdGUuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRlbXBsYXRlKGlkeCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RUZW1wbGF0ZSh0ZW1wbGF0ZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0ZW1wbGF0ZS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgOiBudWxsfVxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9uYXY+XG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgTXV0aVRhYnNDb250YWluZXIgPSBjb25uZWN0KG51bGwsIChkaXNwYXRjaCkgPT4gKHtcbiAgcmVzZXREYXRhOiAoKSA9PiBkaXNwYXRjaChyZXNldENlcnRpZmljYXRlU3RhdGUoKSksXG59KSkoTXVsdGlUYWJzKTtcbiIsImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5pbnRlcmZhY2UgVGFiIHtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbn1cbmludGVyZmFjZSBEcmF3ZXJQcm9wcyB7XG4gIHRvZ2dsZTogKGluZGV4OiBudW1iZXIsIGlkOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHRhYnM6IFRhYltdO1xuICBhY3RpdmVJZHg6IG51bWJlcjtcbn1cbmludGVyZmFjZSBEcmF3ZXJTdGF0ZSB7XG4gIHZpc2libGU6IGJvb2xlYW47XG4gIHNob3dBYnNIZWFkZXI6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjbGFzcyBEcmF3ZXIgZXh0ZW5kcyBDb21wb25lbnQ8RHJhd2VyUHJvcHMsIERyYXdlclN0YXRlPiB7XG4gIGNvbnN0cnVjdG9yKHByb3BzOiBEcmF3ZXJQcm9wcykge1xuICAgIHN1cGVyKHByb3BzKTtcbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgdmlzaWJsZTogZmFsc2UsXG4gICAgICBzaG93QWJzSGVhZGVyOiBmYWxzZSxcbiAgICB9O1xuICB9XG5cbiAgdG9nZ2xlRHJhd2VyKCk6IHZvaWQge1xuICAgIHRoaXMuc2V0U3RhdGUoeyB2aXNpYmxlOiAhdGhpcy5zdGF0ZS52aXNpYmxlIH0pO1xuICB9XG5cbiAgY3JlYXRlVGFicyh0YWJzOiBUYWJbXSk6IFJlYWN0Tm9kZSB7XG4gICAgY29uc3QgeyBhY3RpdmVJZHggfSA9IHRoaXMucHJvcHM7XG4gICAgcmV0dXJuIHRhYnMubWFwKCh0YWIsIGluZGV4KSA9PiAoXG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT17YGN1cnNvci1wb2ludGVyIHctZnVsbCB0ZXh0LXdoaXRlIGJvcmRlci1iIHB5LTQgaG92ZXI6dGV4dC1vcGFjaXR5LTEwMCAke1xuICAgICAgICAgIGFjdGl2ZUlkeCA9PT0gaW5kZXggPyBcIlwiIDogXCJ0ZXh0LW9wYWNpdHktNTBcIlxuICAgICAgICB9YH1cbiAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgdGhpcy5yZW5kZXJDb250ZW50KGluZGV4LCB0YWIuaWQpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICB7dGFiLmxhYmVsfVxuICAgICAgPC9kaXY+XG4gICAgKSk7XG4gIH1cblxuICByZW5kZXJDb250ZW50KGluZGV4OiBudW1iZXIsIGlkOiBzdHJpbmcpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BzLnRvZ2dsZShpbmRleCwgaWQpO1xuICAgIHRoaXMudG9nZ2xlRHJhd2VyKCk7XG4gIH1cblxuICByZW5kZXIoKTogUmVhY3ROb2RlIHtcbiAgICBjb25zdCB7IHRhYnMgfSA9IHRoaXMucHJvcHM7XG4gICAgY29uc3QgeyB2aXNpYmxlLCBzaG93QWJzSGVhZGVyIH0gPSB0aGlzLnN0YXRlO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9e2BjdXJzb3ItcG9pbnRlciB0ZXh0LWxnIHRleHQtd2hpdGUgJHtzaG93QWJzSGVhZGVyID8gXCJcIiA6IFwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCBtdC00IG1yLTRcIn1gfVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRoaXMudG9nZ2xlRHJhd2VyKCl9XG4gICAgICAgID5cbiAgICAgICAgICAmIzk3NzY7XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7dmlzaWJsZSA/IChcbiAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwiYmctbmF2eSB0ZXh0LWxnIGZpeGVkIHRvcC0wIHJpZ2h0LTAgaC1zY3JlZW4gcC00XCI+XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnRvZ2dsZURyYXdlcigpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAmdGltZXM7XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXBcIj57dGhpcy5jcmVhdGVUYWJzKHRhYnMpfTwvZGl2PlxuICAgICAgICAgIDwvYXNpZGU+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC8+XG4gICAgKTtcbiAgfVxufVxuIiwiZXhwb3J0ICogZnJvbSBcIi4vZHJhd2VyXCI7XG4iLCJpbXBvcnQgZ2V0Q29uZmlnIGZyb20gXCJuZXh0L2NvbmZpZ1wiO1xuaW1wb3J0IHsgZ2V0TG9nZ2VyIH0gZnJvbSBcIi4uL3V0aWxzL2xvZ2dlclwiO1xuXG5jb25zdCB7IHRyYWNlIH0gPSBnZXRMb2dnZXIoXCJjb25maWdcIik7XG4vLyBodHRwczovL2dpdGh1Yi5jb20vdmVyY2VsL25leHQuanMvaXNzdWVzLzc3MTNcbmNvbnN0IHsgcHVibGljUnVudGltZUNvbmZpZyA9IHt9IH0gPSBnZXRDb25maWcoKTtcblxuZXhwb3J0IGNvbnN0IFVSTCA9IFwiaHR0cHM6Ly9vcGVuY2VydHMuaW9cIjtcbmNvbnN0IEFQSV9NQUlOX1VSTCA9IFwiaHR0cHM6Ly9hcGkub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUk9QU1RFTl9VUkwgPSBcImh0dHBzOi8vYXBpLXJvcHN0ZW4ub3BlbmNlcnRzLmlvXCI7XG5jb25zdCBBUElfUklOS0VCWV9VUkwgPSBcImh0dHBzOi8vYXBpLXJpbmtlYnkub3BlbmNlcnRzLmlvXCI7XG5cbmNvbnN0IEdBX1BST0RVQ1RJT05fSUQgPSBcIlVBLTEzMDQ5MjI2MC0xXCI7XG5jb25zdCBHQV9ERVZFTE9QTUVOVF9JRCA9IFwiVUEtMTMwNDkyMjYwLTJcIjtcblxuZXhwb3J0IGNvbnN0IElTX01BSU5ORVQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLm5ldHdvcmsgPT09IFwibWFpbm5ldFwiO1xuZXhwb3J0IGNvbnN0IE5FVFdPUktfTkFNRSA9IChJU19NQUlOTkVUID8gXCJob21lc3RlYWRcIiA6IHB1YmxpY1J1bnRpbWVDb25maWcubmV0d29yaykgPz8gXCJyb3BzdGVuXCI7IC8vIGV4cGVjdGVkIGJ5IGV0aGVyc1xuXG5leHBvcnQgY29uc3QgR0FfSUQgPSBJU19NQUlOTkVUID8gR0FfUFJPRFVDVElPTl9JRCA6IEdBX0RFVkVMT1BNRU5UX0lEO1xuZXhwb3J0IGNvbnN0IENBUFRDSEFfQ0xJRU5UX0tFWSA9IFwiNkxmaUwzRVVBQUFBQUhyZkx2bDJLaFJBY1hwYW5OWERxdTZNMENDU1wiO1xuXG5jb25zdCBnZXRBcGlVcmwgPSAobmV0d29ya05hbWU6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGlmIChuZXR3b3JrTmFtZSA9PT0gXCJob21lc3RlYWRcIikgcmV0dXJuIEFQSV9NQUlOX1VSTDtcbiAgZWxzZSBpZiAobmV0d29ya05hbWUgPT09IFwicmlua2VieVwiKSByZXR1cm4gQVBJX1JJTktFQllfVVJMO1xuICByZXR1cm4gQVBJX1JPUFNURU5fVVJMO1xufTtcbmV4cG9ydCBjb25zdCBFTUFJTF9BUElfVVJMID0gYCR7Z2V0QXBpVXJsKE5FVFdPUktfTkFNRSl9L2VtYWlsYDtcbmV4cG9ydCBjb25zdCBTSEFSRV9MSU5LX0FQSV9VUkwgPSBgJHtnZXRBcGlVcmwoTkVUV09SS19OQU1FKX0vc3RvcmFnZWA7XG5leHBvcnQgY29uc3QgU0hBUkVfTElOS19UVEwgPSAxMjA5NjAwO1xuXG5leHBvcnQgY29uc3QgTEVHQUNZX09QRU5DRVJUU19SRU5ERVJFUiA9IHB1YmxpY1J1bnRpbWVDb25maWcubGVnYWN5UmVuZGVyZXJVcmwgfHwgXCJodHRwczovL2xlZ2FjeS5vcGVuY2VydHMuaW8vXCI7XG5leHBvcnQgY29uc3QgRU5WSVJPTk1FTlQgPSBwdWJsaWNSdW50aW1lQ29uZmlnLmNvbnRleHQgPT09IFwicHJvZHVjdGlvblwiID8gXCJwcm9kdWN0aW9uXCIgOiBcImRldmVsb3BtZW50XCI7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFTyA9IHtcbiAgdGl0bGU6IFwiQW4gZWFzeSB3YXkgdG8gY2hlY2sgYW5kIHZlcmlmeSB5b3VyIGNlcnRpZmljYXRlc1wiLFxuICB0aXRsZVRlbXBsYXRlOiBgT3BlbkNlcnRzIC0gJXNgLFxuICBkZXNjcmlwdGlvbjpcbiAgICBcIldoZXRoZXIgeW91J3JlIGEgc3R1ZGVudCBvciBhbiBlbXBsb3llciwgT3BlbkNlcnRzIGxldHMgeW91IHZlcmlmeSB0aGUgY2VydGlmaWNhdGVzIHlvdSBoYXZlIG9mIGFueW9uZSBmcm9tIGFueSBpbnN0aXR1dGlvbi4gQWxsIGluIG9uZSBwbGFjZS5cIixcbiAgb3BlbkdyYXBoOiB7XG4gICAgdHlwZTogXCJ3ZWJzaXRlXCIsXG4gICAgdXJsOiBVUkwsXG4gICAgdGl0bGU6IFwiT3BlbkNlcnRzIC0gQW4gZWFzeSB3YXkgdG8gY2hlY2sgYW5kIHZlcmlmeSB5b3VyIGNlcnRpZmljYXRlc1wiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJXaGV0aGVyIHlvdSdyZSBhIHN0dWRlbnQgb3IgYW4gZW1wbG95ZXIsIE9wZW5DZXJ0cyBsZXRzIHlvdSB2ZXJpZnkgdGhlIGNlcnRpZmljYXRlcyB5b3UgaGF2ZSBvZiBhbnlvbmUgZnJvbSBhbnkgaW5zdGl0dXRpb24uIEFsbCBpbiBvbmUgcGxhY2UuXCIsXG4gICAgaW1hZ2VzOiBbXG4gICAgICB7XG4gICAgICAgIHVybDogYCR7VVJMfS9zdGF0aWMvaW1hZ2VzL29wZW5jZXJ0cy5wbmdgLFxuICAgICAgICB3aWR0aDogODAwLFxuICAgICAgICBoZWlnaHQ6IDYwMCxcbiAgICAgICAgYWx0OiBcIk9wZW5DZXJ0c1wiLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB0d2l0dGVyOiB7XG4gICAgY2FyZFR5cGU6IFwic3VtbWFyeV9sYXJnZV9pbWFnZVwiLFxuICB9LFxufTtcblxudHJhY2UoYE5FVFdPUks6ICR7TkVUV09SS19OQU1FfWApO1xudHJhY2UoYENBUFRDSEFfQ0xJRU5UX0tFWTogJHtDQVBUQ0hBX0NMSUVOVF9LRVl9YCk7XG50cmFjZShgRU1BSUxfQVBJX1VSTDogJHtFTUFJTF9BUElfVVJMfWApO1xuIiwiaW1wb3J0IGRlYnVnLCB7IERlYnVnZ2VyIH0gZnJvbSBcImRlYnVnXCI7XG5cbi8vIG5vdCB1c2luZyAuZXh0ZW5kcyBiZWNhdXNlIG9mIHN0dXBpZCBuZXh0LmpzIHJlc29sdmUgbW9kdWxlcyBidWcgd2hlcmUgaXRzIHBpY2tpbmcgdXAgb2xkIHZlcnNpb24gb2YgZGVidWdcbmV4cG9ydCBjb25zdCB0cmFjZSA9IChuYW1lc3BhY2U6IHN0cmluZyk6IERlYnVnZ2VyID0+IGRlYnVnKGBvcGVuY2VydHMtd2Vic2l0ZTp0cmFjZToke25hbWVzcGFjZX1gKTtcbmV4cG9ydCBjb25zdCBlcnJvciA9IChuYW1lc3BhY2U6IHN0cmluZyk6IERlYnVnZ2VyID0+IGRlYnVnKGBvcGVuY2VydHMtd2Vic2l0ZTplcnJvcjoke25hbWVzcGFjZX1gKTtcblxuZXhwb3J0IGNvbnN0IGdldExvZ2dlciA9IChuYW1lc3BhY2U6IHN0cmluZyk6IHsgdHJhY2U6IERlYnVnZ2VyOyBlcnJvcjogRGVidWdnZXIgfSA9PiAoe1xuICB0cmFjZTogdHJhY2UobmFtZXNwYWNlKSxcbiAgZXJyb3I6IGVycm9yKG5hbWVzcGFjZSksXG59KTtcbiJdLCJzb3VyY2VSb290IjoiIn0=